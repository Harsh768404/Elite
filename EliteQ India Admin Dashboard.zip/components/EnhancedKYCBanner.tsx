import React, { useState } from 'react';
import { AlertTriangle, X, Upload, FileText, CheckCircle, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';

interface Document {
  id: string;
  name: string;
  required: boolean;
  uploaded: boolean;
  status: 'pending' | 'approved' | 'rejected';
  file?: File;
}

const requiredDocuments: Document[] = [
  { id: 'aadhaar', name: 'Aadhaar Card', required: true, uploaded: false, status: 'pending' },
  { id: 'pan', name: 'PAN Card', required: true, uploaded: false, status: 'pending' },
  { id: 'bank', name: 'Bank Statement', required: true, uploaded: false, status: 'pending' },
  { id: 'gst', name: 'GST Certificate', required: true, uploaded: false, status: 'pending' },
  { id: 'udyam', name: 'Udyam Aadhar', required: true, uploaded: false, status: 'pending' }
];

interface EnhancedKYCBannerProps {
  kycStatus: 'pending' | 'approved' | 'rejected';
  onSubmit: (documents: any) => Promise<void>;
  onClose: () => void;
}

export function EnhancedKYCBanner({ kycStatus, onSubmit, onClose }: EnhancedKYCBannerProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [documents, setDocuments] = useState<Document[]>(requiredDocuments);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});

  if (kycStatus !== 'pending') return null;

  const uploadedCount = documents.filter(doc => doc.uploaded).length;
  const totalCount = documents.length;
  const completionPercentage = (uploadedCount / totalCount) * 100;

  const handleFileUpload = async (documentId: string, file: File) => {
    if (file.size > 2 * 1024 * 1024) {
      alert('File size must be under 2MB');
      return;
    }

    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!allowedTypes.includes(file.type)) {
      alert('Only PDF, JPG, and PNG files are allowed');
      return;
    }

    // Simulate upload progress
    setUploadProgress(prev => ({ ...prev, [documentId]: 0 }));
    
    for (let i = 0; i <= 100; i += 10) {
      await new Promise(resolve => setTimeout(resolve, 50));
      setUploadProgress(prev => ({ ...prev, [documentId]: i }));
    }

    setDocuments(prev => prev.map(doc => 
      doc.id === documentId 
        ? { ...doc, uploaded: true, file, status: 'pending' as const }
        : doc
    ));

    setUploadProgress(prev => {
      const newProgress = { ...prev };
      delete newProgress[documentId];
      return newProgress;
    });
  };

  const handleSubmitForReview = async () => {
    const allUploaded = documents.every(doc => doc.uploaded);
    if (!allUploaded) {
      alert('Please upload all required documents');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit(documents);
    } catch (error) {
      console.error('Failed to submit documents:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Alert className="border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50 border-l-4 border-l-amber-500 kyc-banner-mobile sm:kyc-banner-desktop">
      <AlertTriangle className="h-5 w-5 text-amber-600" />
      <AlertDescription>
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <div className="font-semibold text-amber-800 mb-1">
              KYC Verification Required
            </div>
            <p className="text-amber-700 text-sm">
              Your application is pending. Complete your KYC to activate your EliteQ India vendor account.
            </p>
            {uploadedCount > 0 && (
              <div className="mt-2">
                <div className="flex items-center gap-2 text-xs text-amber-700">
                  <span>{uploadedCount}/{totalCount} documents uploaded</span>
                  <div className="flex-1 max-w-24">
                    <Progress value={completionPercentage} className="h-2" />
                  </div>
                  <span>{Math.round(completionPercentage)}%</span>
                </div>
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
              className="text-amber-700 border-amber-300 hover:bg-amber-100"
            >
              {isExpanded ? (
                <>
                  <ChevronUp className="h-4 w-4 mr-1" />
                  Hide
                </>
              ) : (
                <>
                  <ChevronDown className="h-4 w-4 mr-1" />
                  Upload Documents
                </>
              )}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-amber-600 hover:bg-amber-100"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {isExpanded && (
          <Card className="mt-4 border-amber-200 bg-white/50">
            <CardContent className="p-4">
              <div className="grid kyc-upload-grid gap-4">
                {documents.map((document) => (
                  <div
                    key={document.id}
                    className="border-2 border-dashed border-gray-300 rounded-lg p-4 hover:border-blue-400 transition-colors"
                  >
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-2">
                        <FileText className="h-8 w-8 text-gray-400" />
                      </div>
                      <h3 className="font-medium text-gray-900 mb-1">
                        {document.name}
                        {document.required && (
                          <span className="text-red-500 ml-1">*</span>
                        )}
                      </h3>
                      
                      {document.uploaded ? (
                        <div className="space-y-2">
                          <Badge variant="secondary" className="text-green-700 bg-green-100">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Uploaded
                          </Badge>
                          <p className="text-xs text-gray-500">
                            {document.file?.name}
                          </p>
                        </div>
                      ) : uploadProgress[document.id] !== undefined ? (
                        <div className="space-y-2">
                          <div className="text-sm text-blue-600">Uploading...</div>
                          <Progress 
                            value={uploadProgress[document.id]} 
                            className="kyc-progress-bar"
                          />
                          <div className="text-xs text-gray-500">
                            {uploadProgress[document.id]}%
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <input
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) handleFileUpload(document.id, file);
                            }}
                            className="hidden"
                            id={`file-${document.id}`}
                          />
                          <label
                            htmlFor={`file-${document.id}`}
                            className="inline-flex items-center gap-2 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors text-sm"
                          >
                            <Upload className="h-4 w-4" />
                            Choose File
                          </label>
                          <p className="text-xs text-gray-500">
                            PDF, JPG, PNG (max 2MB)
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  {uploadedCount === totalCount ? (
                    <div className="flex items-center gap-2 text-green-700">
                      <CheckCircle className="h-4 w-4" />
                      All documents uploaded. Ready for review.
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-amber-700">
                      <AlertCircle className="h-4 w-4" />
                      {totalCount - uploadedCount} documents remaining
                    </div>
                  )}
                </div>

                <Button
                  onClick={handleSubmitForReview}
                  disabled={uploadedCount !== totalCount || isSubmitting}
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Submitting...
                    </div>
                  ) : (
                    'Submit for Review'
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </AlertDescription>
    </Alert>
  );
}