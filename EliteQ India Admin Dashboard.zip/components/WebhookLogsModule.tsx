import React, { useState, useEffect } from 'react';
import { 
  Webhook, Search, Filter, Eye, Trash2, RefreshCw, 
  Clock, CheckCircle, XCircle, AlertTriangle,
  Download, Calendar, Activity, Database, Zap
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Alert, AlertDescription } from './ui/alert';
import { Skeleton } from './ui/skeleton';

interface WebhookLog {
  id: string;
  event_type: string;
  status: 'success' | 'failed' | 'pending' | 'retrying';
  timestamp: string;
  payload_size: number;
  response_status?: number;
  response_time?: number;
  error_message?: string;
  retry_count: number;
  endpoint: string;
  source: string;
}

interface WebhookStats {
  total: number;
  successful: number;
  failed: number;
  pending: number;
  avgResponseTime: number;
}

interface WebhookLogsModuleProps {
  userRole: string;
}

const WebhookLogsModule: React.FC<WebhookLogsModuleProps> = ({ userRole }) => {
  const [logs, setLogs] = useState<WebhookLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [eventFilter, setEventFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState<WebhookStats>({
    total: 0,
    successful: 0,
    failed: 0,
    pending: 0,
    avgResponseTime: 0
  });

  const logsPerPage = 20;

  // Generate mock webhook logs for demonstration
  const generateMockLogs = (): WebhookLog[] => {
    const events = [
      'woocommerce.order.created',
      'woocommerce.order.updated', 
      'woocommerce.product.created',
      'woocommerce.product.updated',
      'woocommerce.customer.created',
      'dokan.vendor.created',
      'dokan.vendor.updated'
    ];

    const statuses: Array<'success' | 'failed' | 'pending' | 'retrying'> = ['success', 'failed', 'pending', 'retrying'];
    
    const mockLogs: WebhookLog[] = [];
    
    for (let i = 0; i < 50; i++) {
      const eventType = events[Math.floor(Math.random() * events.length)];
      const status = statuses[Math.floor(Math.random() * statuses.length)];
      const timestamp = new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString();
      
      mockLogs.push({
        id: `wh_${Date.now()}_${i}`,
        event_type: eventType,
        status,
        timestamp,
        payload_size: Math.floor(Math.random() * 5000) + 500,
        response_status: status === 'success' ? 200 : status === 'failed' ? 500 : undefined,
        response_time: status !== 'pending' ? Math.floor(Math.random() * 2000) + 100 : undefined,
        error_message: status === 'failed' ? 'Connection timeout' : undefined,
        retry_count: status === 'failed' || status === 'retrying' ? Math.floor(Math.random() * 3) : 0,
        endpoint: 'https://eliteq.in/?wpwhpro_action=main_9798',
        source: 'WooCommerce'
      });
    }

    return mockLogs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  };

  // Fetch webhook logs (mocked for now)
  const fetchWebhookLogs = async (page = 1, search = '', status = 'all', event = 'all') => {
    try {
      setLoading(page === 1);
      setError(null);

      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      let mockLogs = generateMockLogs();

      // Apply filters
      if (search.trim()) {
        mockLogs = mockLogs.filter(log => 
          log.event_type.toLowerCase().includes(search.toLowerCase()) ||
          log.id.toLowerCase().includes(search.toLowerCase())
        );
      }

      if (status !== 'all') {
        mockLogs = mockLogs.filter(log => log.status === status);
      }

      if (event !== 'all') {
        mockLogs = mockLogs.filter(log => log.event_type === event);
      }

      // Pagination
      const startIndex = (page - 1) * logsPerPage;
      const endIndex = startIndex + logsPerPage;
      const paginatedLogs = mockLogs.slice(startIndex, endIndex);
      
      const totalPagesCount = Math.ceil(mockLogs.length / logsPerPage);

      setLogs(paginatedLogs);
      setTotalPages(totalPagesCount);

      // Calculate stats
      const newStats: WebhookStats = {
        total: mockLogs.length,
        successful: mockLogs.filter(log => log.status === 'success').length,
        failed: mockLogs.filter(log => log.status === 'failed').length,
        pending: mockLogs.filter(log => log.status === 'pending').length,
        avgResponseTime: Math.round(
          mockLogs
            .filter(log => log.response_time)
            .reduce((sum, log) => sum + (log.response_time || 0), 0) /
          mockLogs.filter(log => log.response_time).length || 0
        )
      };
      setStats(newStats);

      console.log('✅ Webhook logs loaded:', {
        count: paginatedLogs.length,
        total: mockLogs.length,
        pages: totalPagesCount,
        stats: newStats
      });

    } catch (error) {
      console.error('❌ Failed to fetch webhook logs:', error);
      setError(error instanceof Error ? error.message : 'Failed to fetch webhook logs');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchWebhookLogs(currentPage, searchTerm, statusFilter, eventFilter);
  }, [currentPage, statusFilter, eventFilter]);

  // Search handler with debouncing
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      setCurrentPage(1);
      fetchWebhookLogs(1, searchTerm, statusFilter, eventFilter);
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchTerm]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchWebhookLogs(currentPage, searchTerm, statusFilter, eventFilter);
  };

  const getStatusBadge = (status: WebhookLog['status']) => {
    switch (status) {
      case 'success':
        return (
          <Badge variant="default" className="bg-green-100 text-green-700 border-green-300">
            <CheckCircle className="w-3 h-3 mr-1" />
            Success
          </Badge>
        );
      case 'failed':
        return (
          <Badge variant="default" className="bg-red-100 text-red-700 border-red-300">
            <XCircle className="w-3 h-3 mr-1" />
            Failed
          </Badge>
        );
      case 'pending':
        return (
          <Badge variant="default" className="bg-yellow-100 text-yellow-700 border-yellow-300">
            <Clock className="w-3 h-3 mr-1" />
            Pending
          </Badge>
        );
      case 'retrying':
        return (
          <Badge variant="default" className="bg-blue-100 text-blue-700 border-blue-300">
            <RefreshCw className="w-3 h-3 mr-1" />
            Retrying
          </Badge>
        );
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
    } catch {
      return 'Invalid date';
    }
  };

  if (loading && logs.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Webhook Logs</h2>
            <p className="text-muted-foreground">Monitor webhook activity</p>
          </div>
          <Skeleton className="h-10 w-32" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>

        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48" />
          </CardHeader>
          <CardContent className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Webhook className="w-6 h-6 text-purple-600" />
            Webhook Logs
          </h2>
          <p className="text-muted-foreground">
            Monitor and debug your WordPress webhooks
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleRefresh}
            disabled={refreshing}
          >
            {refreshing ? (
              <RefreshCw className="w-4 h-4 animate-spin mr-1" />
            ) : (
              <RefreshCw className="w-4 h-4 mr-1" />
            )}
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-1" />
            Export
          </Button>
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription>
            <strong>Error loading webhook logs:</strong> {error}
          </AlertDescription>
        </Alert>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm text-muted-foreground">Total Events</p>
                <p className="text-2xl font-bold">{stats.total.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm text-muted-foreground">Successful</p>
                <p className="text-2xl font-bold">{stats.successful.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <XCircle className="w-5 h-5 text-red-600" />
              <div>
                <p className="text-sm text-muted-foreground">Failed</p>
                <p className="text-2xl font-bold">{stats.failed.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-yellow-600" />
              <div>
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold">{stats.pending.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-sm text-muted-foreground">Avg Response</p>
                <p className="text-2xl font-bold">{stats.avgResponseTime}ms</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search by event type or log ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="success">Success</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="retrying">Retrying</SelectItem>
              </SelectContent>
            </Select>
            <Select value={eventFilter} onValueChange={setEventFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by event" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Events</SelectItem>
                <SelectItem value="woocommerce.order.created">Order Created</SelectItem>
                <SelectItem value="woocommerce.order.updated">Order Updated</SelectItem>
                <SelectItem value="woocommerce.product.created">Product Created</SelectItem>
                <SelectItem value="woocommerce.product.updated">Product Updated</SelectItem>
                <SelectItem value="woocommerce.customer.created">Customer Created</SelectItem>
                <SelectItem value="dokan.vendor.created">Vendor Created</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle>Webhook Activity</CardTitle>
          <CardDescription>
            Showing {logs.length} of {stats.total} webhook events
          </CardDescription>
        </CardHeader>
        <CardContent>
          {logs.length === 0 ? (
            <div className="text-center py-8">
              <Webhook className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground">No webhook logs found</p>
            </div>
          ) : (
            <div className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Event</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Response</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Retries</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="font-medium">{log.event_type}</div>
                          <div className="text-sm text-muted-foreground">
                            ID: {log.id}
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {log.source}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {getStatusBadge(log.status)}
                          {log.error_message && (
                            <div className="text-xs text-red-600">
                              {log.error_message}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {formatDate(log.timestamp)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {log.response_status && (
                            <Badge 
                              variant={log.response_status === 200 ? "default" : "destructive"}
                              className="text-xs"
                            >
                              {log.response_status}
                            </Badge>
                          )}
                          {log.response_time && (
                            <div className="text-xs text-muted-foreground">
                              {log.response_time}ms
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {formatBytes(log.payload_size)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {log.retry_count > 0 ? (
                            <Badge variant="outline" className="text-xs">
                              {log.retry_count} retries
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">None</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    Page {currentPage} of {totalPages}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1 || loading}
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                      disabled={currentPage === totalPages || loading}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Activity Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            Recent Activity Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Alert>
              <Activity className="w-4 w-4" />
              <AlertDescription>
                <strong>Webhook Status:</strong> All webhook endpoints are functioning normally. 
                Average response time is {stats.avgResponseTime}ms with a {
                  Math.round((stats.successful / stats.total) * 100)
                }% success rate.
              </AlertDescription>
            </Alert>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                <div className="flex items-center gap-2 text-green-700 dark:text-green-300">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm font-medium">Healthy Endpoints</span>
                </div>
                <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                  1
                </p>
                <p className="text-xs text-green-600 dark:text-green-400">
                  EliteQ Webhook Endpoint
                </p>
              </div>
              
              <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                <div className="flex items-center gap-2 text-blue-700 dark:text-blue-300">
                  <Zap className="w-4 h-4" />
                  <span className="text-sm font-medium">Events Today</span>
                </div>
                <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                  {logs.filter(log => {
                    const today = new Date().toDateString();
                    return new Date(log.timestamp).toDateString() === today;
                  }).length}
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-400">
                  Processed successfully
                </p>
              </div>
              
              <div className="p-4 rounded-lg bg-purple-50 dark:bg-purple-900/20">
                <div className="flex items-center gap-2 text-purple-700 dark:text-purple-300">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm font-medium">Last Event</span>
                </div>
                <p className="text-sm font-bold text-purple-900 dark:text-purple-100">
                  {logs.length > 0 ? formatDate(logs[0].timestamp) : 'No events'}
                </p>
                <p className="text-xs text-purple-600 dark:text-purple-400">
                  {logs.length > 0 ? logs[0].event_type : 'N/A'}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default WebhookLogsModule;