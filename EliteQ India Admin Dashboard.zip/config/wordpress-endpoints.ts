/**
 * Comprehensive WordPress/WooCommerce API Endpoints Configuration
 * EliteQ India - Complete Backend Integration with Real Credentials
 * Base URL: https://eliteq.in
 */

export const WORDPRESS_BASE_URL = 'https://eliteq.in';
export const WP_JSON_BASE = `${WORDPRESS_BASE_URL}/wp-json`;

// Real API Configuration for EliteQ India
export const ELITEQ_API_CONFIG = {
  baseUrl: 'https://eliteq.in',
  consumerKey: 'ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9',
  consumerSecret: 'cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3',
  jwtSecret: '9=<QX7=<(iLPhXh[G21AjCh#x-{%z)jA;FK]bRFpQT4jx?x+3l${m,IGCcVx&}Hm',
  
  // Webhook Configuration
  webhookUrl: 'https://eliteq.in/?wpwhpro_action=main_9798&wpwhpro_api_key=w7mcvsqva35rns5bchiwnn4alrcg4jymowrmcox99kyg3n1zxwvsjuxix7ikrsdw',
  webhookApiKey: 'w7mcvsqva35rns5bchiwnn4alrcg4jymowrmcox99kyg3n1zxwvsjuxix7ikrsdw',
  
  // Webhook Secrets for different events
  webhookSecrets: {
    'product.created': 'Du83&G.64ti/5a#plclUwhF;WIjsQEHy_>hdFQ-/pv/CLJ$s#0',
    'product.updated': '#c8Zo$DbY]<`lA>G,*n.,Ma|)K!Y)A GODev-BXz84Weu;5Pft',
    'product.deleted': '.^u4wdi|D%I_H~SBwL>ea9w`yEbq?[NWnIynZ*wun[2UXP&&8G',
    'product.restored': '{`{[pV1&Ct8d `nF_26JE{WBqnA,t=:eB_H$q#-`qVnLsWJI%4',
    
    'order.created': '^Yzssk4<*N~P,mR8kfQ}fjQ-|VX-d>g/ICNY2W&MA/8o$Cy;3b',
    'order.updated': '*-Hj1yY?WEaui1l>lk; a&8bv<t(7&4)qLJ(]aQgEyIIF^3[EB',
    'order.deleted': 's-pl<s?p=r1?kNJHHv vpl|=e,?$ftt4W*hIg~:yQaU9/yvCqM',
    'order.restored': 'Y4X{0>qe7%~!k:zqI6FmN5UsN-*_0d{GU{I3E_TDVt#&G@D9So',
    'order.invoice-saved': 'F]]*do98.[o r`f61!+[%u%(@0f+LEY=(?8B%1gvLSt$i,^u,s',
    'order.packing-slip-saved': ':>/hl27UE0s]JD}*W0,OmhJ*]=lV%$4Z}fc^;<jgjOx0ybr,aA',
    
    'customer.created': 'A-%`*8U-t*9)8[lEm**/Xu#1N|ArGL*#^sS?Q!d`qbJHGMO[(w',
    'customer.updated': 'M.8didCQMyT!bI48dpz<D3P`61RESK;lv{&4x:F_sX8r<Ld*W~',
    'customer.deleted': 'B%cqq#K@cFyDxaU3(Q{e,!X W|*hg6X`(Nk>OuG%,<-ay<>UVT',
    
    'coupon.created': '8SrnTGD|o&aLw 7JC{G-H;X#qD8nr-TwyykGEeyGaKCCRr+aBb',
    'coupon.updated': 'fm/U2v5,Wxrc,4Oa9vP/uPM4)={wPlzDG8yK`c|dD/W=)1tYvN',
    'coupon.deleted': '8;H2F{d^9<--q:^4#2iurFu1t/YiGgdNW4rB;ZJfWjuF?6Kz]`',
    'coupon.restored': 'p]I78Vgrv!}jZ[gXKwO{?v5Qa:Kh3JSfP`6w/I`_4c4XvymOA=',
  },
  
  // Database Configuration (for direct access if needed)
  database: {
    name: 'u486691522_TeviK',
    user: 'u486691522_laGJZ', 
    password: 'UvAsryquxW',
    host: '127.0.0.1',
    charset: 'utf8',
  }
};

// WordPress Core Endpoints
export const CORE_ENDPOINTS = {
  // Content Management
  posts: `${WP_JSON_BASE}/wp/v2/posts`,
  pages: `${WP_JSON_BASE}/wp/v2/pages`,
  media: `${WP_JSON_BASE}/wp/v2/media`,
  revisions: `${WP_JSON_BASE}/wp/v2/revision`,
  
  // System & Configuration
  customCSS: `${WP_JSON_BASE}/wp/v2/custom_css`,
  changesets: `${WP_JSON_BASE}/wp/v2/customize_changeset`,
  oEmbedResponses: `${WP_JSON_BASE}/wp/v2/oembed_cache`,
  userRequests: `${WP_JSON_BASE}/wp/v2/user_request`,
  
  // Block Editor & Themes
  patterns: `${WP_JSON_BASE}/wp/v2/blocks`,
  globalStyles: `${WP_JSON_BASE}/wp/v2/global-styles`,
  navigationMenus: `${WP_JSON_BASE}/wp/v2/navigation`,
  fontFamilies: `${WP_JSON_BASE}/wp/v2/font-families`,
  fontFaces: `${WP_JSON_BASE}/wp/v2/font-families/(?P<font_family_id>[\\d]+)/font-faces`,
  
  // Elementor Integration
  floatingElements: `${WP_JSON_BASE}/wp/v2/e-floating-buttons`,
  elementorTemplates: `${WP_JSON_BASE}/wp/v2/elementor_library`,
  elementorSnippets: `${WP_JSON_BASE}/wp/v2/elementor_snippet`,
  customFonts: `${WP_JSON_BASE}/wp/v2/elementor_font`,
  customIcons: `${WP_JSON_BASE}/wp/v2/elementor_icons`,
};

// WoodMart Theme Specific Endpoints
export const WOODMART_ENDPOINTS = {
  layouts: `${WP_JSON_BASE}/wp/v2/woodmart_layout`,
  linkedVariations: `${WP_JSON_BASE}/wp/v2/woodmart_woo_lv`,
  frequentlyBoughtTogether: `${WP_JSON_BASE}/wp/v2/woodmart_woo_fbt`,
  htmlBlocks: `${WP_JSON_BASE}/wp/v2/cms_block`,
  sizeGuides: `${WP_JSON_BASE}/wp/v2/woodmart_size_guide`,
  slides: `${WP_JSON_BASE}/wp/v2/woodmart_slide`,
  sidebars: `${WP_JSON_BASE}/wp/v2/woodmart_sidebar`,
};

// WooCommerce Core Endpoints - Using REST API v3
export const WOOCOMMERCE_ENDPOINTS = {
  // Products & Catalog
  products: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/products`,
  productVariations: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/products`,
  productAttributes: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/products/attributes`,
  productCategories: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/products/categories`,
  productTags: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/products/tags`,
  productShippingClasses: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/products/shipping_classes`,
  productReviews: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/products/reviews`,
  
  // Orders & Commerce
  orders: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/orders`,
  orderNotes: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/orders`,
  refunds: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/orders`,
  
  // Customers
  customers: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/customers`,
  
  // Coupons
  coupons: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/coupons`,
  
  // Reports
  reports: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/reports`,
  reportsSales: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/reports/sales`,
  reportsTopSellers: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/reports/top_sellers`,
  reportsCustomers: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/reports/customers`,
  
  // Settings
  settings: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/settings`,
  paymentGateways: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/payment_gateways`,
  shippingZones: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/shipping/zones`,
  shippingMethods: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/shipping_methods`,
  taxRates: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/taxes`,
  taxClasses: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/taxes/classes`,
  
  // Webhooks
  webhooks: `${WORDPRESS_BASE_URL}/wp-json/wc/v3/webhooks`,
  
  // Legacy WP API endpoints for compatibility
  wpProducts: `${WP_JSON_BASE}/wp/v2/product`,
  wpOrders: `${WP_JSON_BASE}/wp/v2/shop_order`,
  wpCoupons: `${WP_JSON_BASE}/wp/v2/shop_coupon`,
  wpRefunds: `${WP_JSON_BASE}/wp/v2/shop_order_refund`,
};

// Portfolio & Projects
export const PORTFOLIO_ENDPOINTS = {
  portfolio: `${WP_JSON_BASE}/wp/v2/portfolio`,
};

// Form & Communication Endpoints
export const COMMUNICATION_ENDPOINTS = {
  formResponses: `${WP_JSON_BASE}/wp/v2/feedback`,
  contactForms: `${WP_JSON_BASE}/wp/v2/wpcf7_contact_form`,
  mailchimpForms: `${WP_JSON_BASE}/wp/v2/mc4wp-form`,
};

// Advanced Features & Plugins
export const PLUGIN_ENDPOINTS = {
  advancedLabels: `${WP_JSON_BASE}/wp/v2/br_labels`,
  templately: `${WP_JSON_BASE}/wp/v2/templately_library`,
  warrantyRequests: `${WP_JSON_BASE}/wp/v2/warranty_request`,
  jpayOrders: `${WP_JSON_BASE}/wp/v2/jp_pay_order`,
  jpayProducts: `${WP_JSON_BASE}/wp/v2/jp_pay_product`,
  rankMathSchemas: `${WP_JSON_BASE}/wp/v2/rank_math_schema`,
};

// Dokan Pro Multivendor Endpoints
export const DOKAN_ENDPOINTS = {
  storeReviews: `${WP_JSON_BASE}/wp/v2/dokan_store_reviews`,
  announcements: `${WP_JSON_BASE}/wp/v2/dokan_announcement`,
  
  // Dokan REST API endpoints
  stores: `${WORDPRESS_BASE_URL}/wp-json/dokan/v1/stores`,
  vendors: `${WORDPRESS_BASE_URL}/wp-json/dokan/v1/vendors`,
  withdraw: `${WORDPRESS_BASE_URL}/wp-json/dokan/v1/withdraw`,
  vendorBalance: `${WORDPRESS_BASE_URL}/wp-json/dokan/v1/vendor-balance`,
  vendorOrders: `${WORDPRESS_BASE_URL}/wp-json/dokan/v1/orders`,
  vendorProducts: `${WORDPRESS_BASE_URL}/wp-json/dokan/v1/products`,
  vendorReports: `${WORDPRESS_BASE_URL}/wp-json/dokan/v1/reports`,
};

// Taxonomies & Categories
export const TAXONOMY_ENDPOINTS = {
  // WordPress Core Taxonomies
  categories: `${WP_JSON_BASE}/wp/v2/categories`,
  tags: `${WP_JSON_BASE}/wp/v2/tags`,
  linkCategories: `${WP_JSON_BASE}/wp/v2/link_category`,
  postFormats: `${WP_JSON_BASE}/wp/v2/post_format`,
  
  // WordPress System Taxonomies
  themes: `${WP_JSON_BASE}/wp/v2/wp_theme`,
  templatePartAreas: `${WP_JSON_BASE}/wp/v2/wp_template_part_area`,
  patternCategories: `${WP_JSON_BASE}/wp/v2/wp_pattern_category`,
  
  // Custom Taxonomies
  cmsBlockCategories: `${WP_JSON_BASE}/wp/v2/cms_block_cat`,
  projectCategories: `${WP_JSON_BASE}/wp/v2/project-cat`,
  
  // WooCommerce Taxonomies
  productBrands: `${WP_JSON_BASE}/wp/v2/product_brand`,
  productTypes: `${WP_JSON_BASE}/wp/v2/product_type`,
  productVisibility: `${WP_JSON_BASE}/wp/v2/product_visibility`,
  productCategories: `${WP_JSON_BASE}/wp/v2/product_cat`,
  productTags: `${WP_JSON_BASE}/wp/v2/product_tag`,
  productShippingClasses: `${WP_JSON_BASE}/wp/v2/product_shipping_class`,
  
  // Product Attributes
  colorAttributes: `${WP_JSON_BASE}/wp/v2/pa_color`,
  ramAttributes: `${WP_JSON_BASE}/wp/v2/pa_ram`,
  storageAttributes: `${WP_JSON_BASE}/wp/v2/pa_storege`,
  
  // Plugin Taxonomies
  berocketTaxonomyData: `${WP_JSON_BASE}/wp/v2/berocket_taxonomy_data`,
  storeCategories: `${WP_JSON_BASE}/wp/v2/store_category`,
  warrantyStatuses: `${WP_JSON_BASE}/wp/v2/shop_warranty_status`,
  elementorFontTypes: `${WP_JSON_BASE}/wp/v2/elementor_font_type`,
  rankMathRedirectionCategories: `${WP_JSON_BASE}/wp/v2/rank_math_redirection_category`,
};

// User & Authentication Endpoints
export const USER_ENDPOINTS = {
  users: `${WP_JSON_BASE}/wp/v2/users`,
  me: `${WP_JSON_BASE}/wp/v2/users/me`,
  
  // JWT Authentication
  jwtAuth: `${WORDPRESS_BASE_URL}/wp-json/jwt-auth/v1/token`,
  jwtValidate: `${WORDPRESS_BASE_URL}/wp-json/jwt-auth/v1/token/validate`,
  jwtRefresh: `${WORDPRESS_BASE_URL}/wp-json/jwt-auth/v1/token/refresh`,
};

// Complete Endpoint Categories for easy access
export const ALL_ENDPOINTS = {
  core: CORE_ENDPOINTS,
  woodmart: WOODMART_ENDPOINTS,
  woocommerce: WOOCOMMERCE_ENDPOINTS,
  portfolio: PORTFOLIO_ENDPOINTS,
  communication: COMMUNICATION_ENDPOINTS,
  plugins: PLUGIN_ENDPOINTS,
  dokan: DOKAN_ENDPOINTS,
  taxonomies: TAXONOMY_ENDPOINTS,
  users: USER_ENDPOINTS,
};

// Real Data Helpers
export const getRealDataEndpoint = (type: string, params: Record<string, any> = {}) => {
  const baseUrls = {
    products: WOOCOMMERCE_ENDPOINTS.products,
    orders: WOOCOMMERCE_ENDPOINTS.orders,
    customers: WOOCOMMERCE_ENDPOINTS.customers,
    coupons: WOOCOMMERCE_ENDPOINTS.coupons,
    categories: WOOCOMMERCE_ENDPOINTS.productCategories,
    stores: DOKAN_ENDPOINTS.stores,
    vendors: DOKAN_ENDPOINTS.vendors,
    posts: CORE_ENDPOINTS.posts,
    pages: CORE_ENDPOINTS.pages,
    users: USER_ENDPOINTS.users,
  };

  const baseUrl = baseUrls[type];
  if (!baseUrl) {
    throw new Error(`Unknown endpoint type: ${type}`);
  }

  const url = new URL(baseUrl);
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      url.searchParams.append(key, String(value));
    }
  });

  return url.toString();
};

// Authentication helper
export const getAuthHeaders = (authType: 'consumer' | 'jwt' = 'consumer', token?: string) => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (authType === 'jwt' && token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  return headers;
};

// Build URL with consumer auth
export const buildAuthenticatedUrl = (endpoint: string, params: Record<string, any> = {}) => {
  const url = new URL(endpoint);
  
  // Add consumer key and secret for WooCommerce API
  url.searchParams.append('consumer_key', ELITEQ_API_CONFIG.consumerKey);
  url.searchParams.append('consumer_secret', ELITEQ_API_CONFIG.consumerSecret);
  
  // Add additional parameters
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      url.searchParams.append(key, String(value));
    }
  });

  return url.toString();
};

// Endpoint metadata for documentation and validation
export const ENDPOINT_METADATA = {
  products: {
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    auth: 'consumer',
    description: 'WooCommerce products management with real EliteQ data',
    supports: ['create', 'read', 'update', 'delete', 'batch'],
    realDataAvailable: true,
  },
  orders: {
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    auth: 'consumer',
    description: 'WooCommerce orders management with real EliteQ data',
    supports: ['create', 'read', 'update', 'delete', 'notes'],
    realDataAvailable: true,
  },
  customers: {
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    auth: 'consumer',
    description: 'WooCommerce customers with real EliteQ data',
    supports: ['create', 'read', 'update', 'delete'],
    realDataAvailable: true,
  },
  stores: {
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    auth: 'consumer',
    description: 'Dokan stores with real EliteQ vendor data',
    supports: ['create', 'read', 'update', 'delete'],
    realDataAvailable: true,
  },
};

// Helper function to get all endpoints as flat array
export function getAllEndpoints(): string[] {
  const allEndpoints: string[] = [];
  
  Object.values(ALL_ENDPOINTS).forEach(category => {
    Object.values(category).forEach(endpoint => {
      if (typeof endpoint === 'string') {
        allEndpoints.push(endpoint);
      }
    });
  });
  
  return allEndpoints;
}

// Helper function to get endpoints by category
export function getEndpointsByCategory(category: keyof typeof ALL_ENDPOINTS) {
  return ALL_ENDPOINTS[category];
}

// Helper function to build endpoint URL with parameters
export function buildEndpointUrl(baseEndpoint: string, params: Record<string, any> = {}): string {
  return buildAuthenticatedUrl(baseEndpoint, params);
}

export default ALL_ENDPOINTS;