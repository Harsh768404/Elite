import React from 'react';
import { BarChart3, Zap, PieChart, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Skeleton } from './ui/skeleton';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart as RechartsPieChart, Pie, Cell } from 'recharts';

interface DashboardChartsProps {
  salesData: any[];
  loading: boolean;
  darkMode: boolean;
  currentRole: 'vendor' | 'admin';
}

export function DashboardCharts({ salesData, loading, darkMode, currentRole }: DashboardChartsProps) {
  const pieData = currentRole === 'admin' ? [
    { name: 'Electronics', value: 45, color: '#3b82f6' },
    { name: 'Fashion', value: 25, color: '#10b981' },
    { name: 'Home & Garden', value: 20, color: '#f59e0b' },
    { name: 'Sports', value: 10, color: '#ef4444' }
  ] : [
    { name: 'Smartphones', value: 35, color: '#3b82f6' },
    { name: 'Laptops', value: 30, color: '#10b981' },
    { name: 'Accessories', value: 25, color: '#f59e0b' },
    { name: 'Others', value: 10, color: '#ef4444' }
  ];

  const quickStats = currentRole === 'admin' ? [
    { label: 'Platform Revenue', value: '₹45.67L', change: '+18%', color: 'text-green-600' },
    { label: 'Vendor Onboarding', value: '8 new', change: '+2 vs last week', color: 'text-blue-600' },
    { label: 'Average Commission', value: '12.5%', change: '+0.5%', color: 'text-purple-600' },
    { label: 'Platform Rating', value: '4.9/5', change: '+0.1', color: 'text-green-600' }
  ] : [
    { label: 'Avg. Order Value', value: '₹1,847', change: '+12%', color: 'text-green-600' },
    { label: 'Conversion Rate', value: '3.2%', change: '+0.8%', color: 'text-green-600' },
    { label: 'Customer Rating', value: '4.8/5', change: '+0.2', color: 'text-green-600' },
    { label: 'Response Time', value: '2.3 hrs', change: '-45 min', color: 'text-green-600' }
  ];

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      
      {/* Sales Chart */}
      <Card className="xl:col-span-2 bg-white dark:bg-gray-900 border-0 shadow-lg">
        <CardHeader className="border-b border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-lg font-bold">
              <BarChart3 className="h-5 w-5 text-blue-600" />
              {currentRole === 'admin' ? 'Platform Performance' : 'Sales Performance'}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">Weekly</Button>
              <Button variant="ghost" size="sm">Monthly</Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="h-80">
            {loading ? (
              <div className="space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-64 w-full" />
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={salesData}>
                  <defs>
                    <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" stroke="#64748b" />
                  <YAxis stroke="#64748b" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: darkMode ? '#1f2937' : '#ffffff',
                      border: 'none',
                      borderRadius: '12px',
                      boxShadow: '0 10px 25px rgba(0,0,0,0.1)'
                    }}
                    formatter={(value, name) => [
                      name === 'sales' ? `₹${value.toLocaleString()}` : value,
                      name === 'sales' ? 'Sales' : 'Orders'
                    ]}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="sales" 
                    stroke="#2563eb" 
                    fill="url(#salesGradient)"
                    strokeWidth={3}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="orders" 
                    stroke="#10b981" 
                    strokeWidth={3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Analytics Sidebar */}
      <div className="space-y-6">
        
        {/* Quick Stats */}
        <Card className="bg-white dark:bg-gray-900 border-0 shadow-lg">
          <CardHeader className="border-b border-gray-100 dark:border-gray-800">
            <CardTitle className="flex items-center gap-2 text-lg font-bold">
              <Zap className="h-5 w-5 text-yellow-600" />
              Quick Stats
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-4">
              {quickStats.map((stat, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800">
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</p>
                    <p className="font-bold text-gray-900 dark:text-white">{stat.value}</p>
                  </div>
                  <div className={`text-sm font-medium ${stat.color}`}>
                    {stat.change}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Category Distribution */}
        <Card className="bg-white dark:bg-gray-900 border-0 shadow-lg">
          <CardHeader className="border-b border-gray-100 dark:border-gray-800">
            <CardTitle className="flex items-center gap-2 text-lg font-bold">
              <PieChart className="h-5 w-5 text-purple-600" />
              {currentRole === 'admin' ? 'Category Distribution' : 'Product Mix'}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 space-y-2">
              {pieData.map((item, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    ></div>
                    <span className="text-gray-600 dark:text-gray-400">{item.name}</span>
                  </div>
                  <span className="font-medium">{item.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}