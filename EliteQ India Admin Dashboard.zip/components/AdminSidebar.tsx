import React, { useState } from 'react';
import { 
  LayoutDashboard, Package, ShoppingCart, Users, TrendingUp, 
  Settings, Database, FileText, Truck, CreditCard, MessageSquare, 
  Shield, Bell, Globe, Zap, BarChart3, UserCheck, Webhook, TestTube, 
  Activity, Store, UserCog, GitBranch, ChevronDown, ChevronRight, Megaphone
} from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { cn } from './ui/utils';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';

interface AdminSidebarProps {
  activeModule: string;
  onModuleChange: (module: string) => void;
  className?: string;
}

interface SidebarSection {
  title: string;
  items: SidebarItem[];
}

interface SidebarItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string | number;
  description?: string;
  isNew?: boolean;
  isPopular?: boolean;
  hasSubmenu?: boolean;
  submenu?: SubMenuItem[];
}

interface SubMenuItem {
  id: string;
  label: string;
  description?: string;
  isNew?: boolean;
}

const AdminSidebar: React.FC<AdminSidebarProps> = ({ 
  activeModule, 
  onModuleChange, 
  className 
}) => {
  const [usersOpen, setUsersOpen] = useState(false); // Start collapsed
  const [settingsOpen, setSettingsOpen] = useState(false); // Start collapsed

  const sidebarSections: SidebarSection[] = [
    {
      title: "Dashboard & Analytics",
      items: [
        {
          id: 'dashboard',
          label: 'Dashboard',
          icon: LayoutDashboard,
          description: 'Main admin overview'
        },
        {
          id: 'announcements',
          label: 'Announcements',
          icon: Megaphone,
          description: 'System-wide announcements and updates'
        },
        {
          id: 'analytics',
          label: 'Analytics',
          icon: BarChart3,
          badge: 'Pro',
          description: 'Advanced analytics & insights'
        },
        {
          id: 'performance',
          label: 'Performance',
          icon: Activity,
          description: 'Site performance metrics'
        }
      ]
    },
    {
      title: "E-commerce Management",
      items: [
        {
          id: 'products',
          label: 'Products',
          icon: Package,
          badge: '1,247',
          description: 'Manage product catalog'
        },
        {
          id: 'orders',
          label: 'Orders',
          icon: ShoppingCart,
          badge: '89',
          description: 'Order management & fulfillment'
        },
        {
          id: 'users',
          label: 'Users',
          icon: Users,
          badge: '3,421',
          description: 'Customer and vendor management',
          hasSubmenu: true,
          submenu: [
            {
              id: 'users-customers',
              label: 'Customers',
              description: 'Registered customers (real-time fetch)'
            },
            {
              id: 'users-vendors',
              label: 'Vendors',
              description: 'Active/inactive vendors (real data)'
            }
          ]
        },
        {
          id: 'inventory',
          label: 'Inventory',
          icon: Database,
          description: 'Stock & inventory tracking'
        },
        {
          id: 'shipping',
          label: 'Shipping',
          icon: Truck,
          description: 'Shipping methods & zones'
        },
        {
          id: 'payments',
          label: 'Payments',
          icon: CreditCard,
          description: 'Payment gateways & transactions'
        }
      ]
    },
    {
      title: "Content & SEO",
      items: [
        {
          id: 'content',
          label: 'Content',
          icon: FileText,
          description: 'Posts, pages & media'
        },
        {
          id: 'seo',
          label: 'SEO & Marketing',
          icon: TrendingUp,
          description: 'Search optimization & marketing'
        },
        {
          id: 'reviews',
          label: 'Reviews',
          icon: MessageSquare,
          badge: '156',
          description: 'Customer reviews & ratings'
        }
      ]
    },
    {
      title: "User & Security",
      items: [
        {
          id: 'user-management',
          label: 'User Management',
          icon: UserCheck,
          description: 'Admin & vendor accounts'
        },
        {
          id: 'security',
          label: 'Security',
          icon: Shield,
          description: 'Security settings & monitoring'
        },
        {
          id: 'notifications',
          label: 'Notifications',
          icon: Bell,
          badge: '12',
          description: 'System alerts & notifications'
        }
      ]
    },
    {
      title: "System & Integration",
      items: [
        {
          id: 'api-integration',
          label: 'API Integration',
          icon: Globe,
          isNew: true,
          description: 'WordPress/WooCommerce API testing'
        },
        {
          id: 'webhooks',
          label: 'Webhooks',
          icon: Webhook,
          description: 'Webhook logs & management'
        },
        {
          id: 'system-config',
          label: 'System Config',
          icon: Settings,
          description: 'System configuration & settings',
          hasSubmenu: true,
          submenu: [
            {
              id: 'settings-general',
              label: 'General Settings',
              description: 'Basic system configuration'
            },
            {
              id: 'settings-api',
              label: 'API Settings',
              description: 'API keys and endpoints'
            },
            {
              id: 'settings-interaction',
              label: 'Interaction',
              description: 'Backend ↔ frontend connection guide',
              isNew: true
            }
          ]
        },
        {
          id: 'api-testing',
          label: 'API Testing',
          icon: TestTube,
          isPopular: true,
          description: 'Comprehensive API endpoint testing'
        },
        {
          id: 'api-explorer',
          label: 'API Explorer',
          icon: Globe,
          isNew: true,
          description: 'Explore all WordPress/WooCommerce endpoints'
        }
      ]
    }
  ];

  const handleItemClick = (itemId: string) => {
    console.log('🎯 Admin module selected:', itemId);
    
    // Handle submenu items
    if (itemId.startsWith('users-')) {
      onModuleChange(itemId);
    } else if (itemId.startsWith('settings-')) {
      onModuleChange(itemId);
    } else {
      onModuleChange(itemId);
    }
  };

  const isItemActive = (item: SidebarItem, activeModule: string) => {
    if (item.hasSubmenu && item.submenu) {
      return item.submenu.some(subItem => activeModule === subItem.id);
    }
    return activeModule === item.id;
  };

  const isSubMenuOpen = (itemId: string) => {
    switch (itemId) {
      case 'users':
        return usersOpen;
      case 'system-config':
        return settingsOpen;
      default:
        return false;
    }
  };

  const setSubMenuOpen = (itemId: string, open: boolean) => {
    switch (itemId) {
      case 'users':
        setUsersOpen(open);
        break;
      case 'system-config':
        setSettingsOpen(open);
        break;
    }
  };

  return (
    <div className={cn("h-full bg-card border-r border-border", className)}>
      <div className="p-6">
        <div className="space-y-6">
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-2">
              EliteQ Admin Panel
            </h2>
            <p className="text-sm text-muted-foreground">
              Comprehensive marketplace management
            </p>
          </div>

          <div className="space-y-6">
            {sidebarSections.map((section) => (
              <div key={section.title} className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                  {section.title}
                </h3>
                
                <div className="space-y-1">
                  {section.items.map((item) => {
                    const Icon = item.icon;
                    const isActive = isItemActive(item, activeModule);
                    
                    if (item.hasSubmenu && item.submenu) {
                      const isOpen = isSubMenuOpen(item.id);
                      
                      return (
                        <Collapsible key={item.id} open={isOpen} onOpenChange={(open) => setSubMenuOpen(item.id, open)}>
                          <CollapsibleTrigger asChild>
                            <Button
                              variant="ghost"
                              className={cn(
                                "w-full justify-between h-12 px-4 transition-all duration-200",
                                "hover:bg-accent hover:text-accent-foreground",
                                "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
                                "group relative",
                                isActive && "bg-primary text-primary-foreground hover:bg-primary/90"
                              )}
                            >
                              <div className="flex items-center space-x-3">
                                <Icon className={cn(
                                  "h-4 w-4 transition-colors",
                                  isActive ? "text-primary-foreground" : "text-muted-foreground group-hover:text-accent-foreground"
                                )} />
                                
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2">
                                    <span className={cn(
                                      "text-sm font-medium truncate",
                                      isActive ? "text-primary-foreground" : "text-foreground"
                                    )}>
                                      {item.label}
                                    </span>
                                    
                                    {item.isNew && (
                                      <Badge variant="default" className="text-xs px-1.5 py-0.5">
                                        New
                                      </Badge>
                                    )}
                                    
                                    {item.isPopular && (
                                      <Badge variant="secondary" className="text-xs px-1.5 py-0.5">
                                        Popular
                                      </Badge>
                                    )}
                                  </div>
                                  
                                  {item.description && (
                                    <p className={cn(
                                      "text-xs truncate mt-0.5",
                                      isActive ? "text-primary-foreground/80" : "text-muted-foreground"
                                    )}>
                                      {item.description}
                                    </p>
                                  )}
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-2">
                                {item.badge && (
                                  <Badge 
                                    variant={isActive ? "secondary" : "outline"}
                                    className="text-xs flex-shrink-0"
                                  >
                                    {item.badge}
                                  </Badge>
                                )}
                                {isOpen ? (
                                  <ChevronDown className="h-4 w-4" />
                                ) : (
                                  <ChevronRight className="h-4 w-4" />
                                )}
                              </div>
                            </Button>
                          </CollapsibleTrigger>
                          <CollapsibleContent className="mt-1">
                            <div className="ml-6 space-y-1">
                              {item.submenu.map((subItem) => (
                                <Button
                                  key={subItem.id}
                                  variant="ghost"
                                  onClick={() => handleItemClick(subItem.id)}
                                  className={cn(
                                    "w-full justify-start h-auto px-4 py-3 text-left transition-all duration-200",
                                    activeModule === subItem.id
                                      ? "bg-primary/10 text-primary border-l-2 border-primary"
                                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                                  )}
                                >
                                  <div className="space-y-1">
                                    <div className="flex items-center gap-2">
                                      <span className="text-sm font-medium">
                                        {subItem.label}
                                      </span>
                                      {subItem.isNew && (
                                        <Badge variant="default" className="text-xs px-1.5 py-0.5">
                                          New
                                        </Badge>
                                      )}
                                    </div>
                                    {subItem.description && (
                                      <p className="text-xs text-muted-foreground">
                                        {subItem.description}
                                      </p>
                                    )}
                                  </div>
                                </Button>
                              ))}
                            </div>
                          </CollapsibleContent>
                        </Collapsible>
                      );
                    }

                    return (
                      <button
                        key={item.id}
                        onClick={() => handleItemClick(item.id)}
                        className={cn(
                          "w-full text-left p-3 rounded-lg transition-all duration-200",
                          "hover:bg-accent hover:text-accent-foreground",
                          "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
                          "group relative",
                          isActive && "bg-primary text-primary-foreground hover:bg-primary/90"
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Icon className={cn(
                              "h-4 w-4 transition-colors",
                              isActive ? "text-primary-foreground" : "text-muted-foreground group-hover:text-accent-foreground"
                            )} />
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className={cn(
                                  "text-sm font-medium truncate",
                                  isActive ? "text-primary-foreground" : "text-foreground"
                                )}>
                                  {item.label}
                                </span>
                                
                                {item.isNew && (
                                  <Badge variant="default" className="text-xs px-1.5 py-0.5">
                                    New
                                  </Badge>
                                )}
                                
                                {item.isPopular && (
                                  <Badge variant="secondary" className="text-xs px-1.5 py-0.5">
                                    Popular
                                  </Badge>
                                )}
                              </div>
                              
                              {item.description && (
                                <p className={cn(
                                  "text-xs truncate mt-0.5",
                                  isActive ? "text-primary-foreground/80" : "text-muted-foreground"
                                )}>
                                  {item.description}
                                </p>
                              )}
                            </div>
                          </div>
                          
                          {item.badge && (
                            <Badge 
                              variant={isActive ? "secondary" : "outline"}
                              className="text-xs ml-2 flex-shrink-0"
                            >
                              {item.badge}
                            </Badge>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* System Status Footer */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-muted/30 border-t border-border">
        <Card className="p-3">
          <CardContent className="p-0">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-muted-foreground">System Online</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="h-3 w-3 text-yellow-500" />
                <span className="text-muted-foreground">Fast</span>
              </div>
            </div>
            
            <div className="mt-2 text-xs text-muted-foreground">
              API: Connected • Cache: Active • Sync: Running
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminSidebar;