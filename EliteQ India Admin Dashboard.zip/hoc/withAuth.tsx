import React, { useEffect, useState } from 'react';
import { Loader2, Shield, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Alert, AlertDescription } from '../components/ui/alert';

// Types for the HOC
interface WithAuthOptions {
  allowedRoles: string[];
  redirectTo?: string;
  fallbackComponent?: React.ComponentType;
  requiresExactRole?: boolean;
}

interface AuthState {
  isAuthenticated: boolean;
  userRoles: string[];
  token: string | null;
  isLoading: boolean;
  error: string | null;
}

// Enhanced withAuth HOC with role-based protection
const withAuth = (
  WrappedComponent: React.ComponentType<any>,
  allowedRoles: string[] = [],
  options: Partial<WithAuthOptions> = {}
) => {
  return function AuthenticatedComponent(props: any) {
    const [authState, setAuthState] = useState<AuthState>({
      isAuthenticated: false,
      userRoles: [],
      token: null,
      isLoading: true,
      error: null
    });

    const {
      redirectTo = '/login',
      fallbackComponent: FallbackComponent,
      requiresExactRole = false
    } = options;

    useEffect(() => {
      const checkAuthentication = async () => {
        console.log('🔒 ===== withAuth: CHECKING AUTHENTICATION =====');
        console.log('🎭 Required roles:', allowedRoles);
        console.log('⚙️ Options:', { redirectTo, requiresExactRole });

        try {
          // Get stored authentication data
          const token = localStorage.getItem('eliteq_jwt_token') || localStorage.getItem('eliteq_remember_token');
          const storedRole = localStorage.getItem('eliteq_user_role') as 'administrator' | 'vendor' | null;
          const storedUserInfo = localStorage.getItem('eliteq_user_info');

          console.log('📦 Stored auth data:', {
            hasToken: !!token,
            storedRole: storedRole,
            hasUserInfo: !!storedUserInfo,
            tokenPreview: token ? token.substring(0, 20) + '...' : null
          });

          if (!token || !storedRole) {
            console.log('❌ withAuth: Missing token or role - redirecting to login');
            setAuthState({
              isAuthenticated: false,
              userRoles: [],
              token: null,
              isLoading: false,
              error: 'Authentication required'
            });
            window.location.href = redirectTo;
            return;
          }

          // Parse user info to get detailed roles
          let userRoles: string[] = [];
          if (storedUserInfo) {
            try {
              const userInfo = JSON.parse(storedUserInfo);
              userRoles = userInfo.roles || [];
              console.log('📋 Parsed user roles from userInfo:', userRoles);
            } catch (parseError) {
              console.warn('⚠️ Failed to parse user info, using stored role as fallback');
            }
          }

          // Fallback to stored role if no detailed roles available
          if (userRoles.length === 0) {
            // Map dashboard roles to WordPress roles
            if (storedRole === 'administrator') {
              userRoles = ['administrator'];
            } else if (storedRole === 'vendor') {
              userRoles = ['dokan_vendor', 'vendor', 'seller', 'shop_manager'];
            }
            console.log('🔄 Using role mapping fallback:', userRoles);
          }

          // Enhanced role validation
          console.log('🎭 ===== ROLE VALIDATION =====');
          console.log('👤 User roles:', userRoles);
          console.log('🔐 Required roles:', allowedRoles);
          console.log('⚙️ Exact role required:', requiresExactRole);

          let hasAccess = false;

          if (allowedRoles.length === 0) {
            // No specific roles required - any authenticated user
            hasAccess = true;
            console.log('✅ Access granted: No specific roles required');
          } else if (requiresExactRole) {
            // Exact role match required
            hasAccess = allowedRoles.every(role => userRoles.includes(role));
            console.log('🎯 Exact role check result:', hasAccess);
          } else {
            // Any of the allowed roles
            hasAccess = userRoles.some(role => allowedRoles.includes(role));
            console.log('🔍 Any role check result:', hasAccess);
          }

          if (hasAccess) {
            console.log('✅ ===== ACCESS GRANTED =====');
            console.log('👑 User has required permissions');
            console.log('🎭 Matching roles:', userRoles.filter(role => allowedRoles.includes(role)));
            
            setAuthState({
              isAuthenticated: true,
              userRoles: userRoles,
              token: token,
              isLoading: false,
              error: null
            });
          } else {
            console.log('❌ ===== ACCESS DENIED =====');
            console.log('🚫 User lacks required permissions');
            console.log('💼 User roles:', userRoles);
            console.log('🔐 Required roles:', allowedRoles);
            
            setAuthState({
              isAuthenticated: false,
              userRoles: userRoles,
              token: token,
              isLoading: false,
              error: `Access denied. Required roles: ${allowedRoles.join(', ')}`
            });
          }

        } catch (error) {
          console.error('🚨 withAuth: Authentication check failed:', error);
          setAuthState({
            isAuthenticated: false,
            userRoles: [],
            token: null,
            isLoading: false,
            error: error instanceof Error ? error.message : 'Authentication check failed'
          });
        }
      };

      checkAuthentication();
    }, [redirectTo, requiresExactRole]);

    // Loading state
    if (authState.isLoading) {
      return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center pb-4">
              <div className="flex justify-center mb-4">
                <Shield className="h-12 w-12 text-blue-600 animate-pulse" />
              </div>
              <CardTitle className="text-xl">Validating Access</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="flex items-center justify-center gap-2">
                <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
                <span className="text-gray-600 dark:text-gray-400">
                  Checking authentication and permissions...
                </span>
              </div>
              <div className="text-sm text-gray-500 dark:text-gray-400">
                Verifying JWT token and user roles
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    // Access denied state
    if (!authState.isAuthenticated) {
      if (FallbackComponent) {
        return <FallbackComponent />;
      }

      return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
          <Card className="w-full max-w-lg">
            <CardHeader className="text-center pb-4">
              <div className="flex justify-center mb-4">
                <AlertCircle className="h-12 w-12 text-red-600" />
              </div>
              <CardTitle className="text-xl text-red-600">Access Denied</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-700">
                <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
                <AlertDescription className="text-red-700 dark:text-red-300">
                  {authState.error || 'You do not have permission to access this page.'}
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                <div className="text-sm">
                  <strong className="text-gray-900 dark:text-white">Your Roles:</strong>
                  <div className="mt-1">
                    {authState.userRoles.length > 0 ? (
                      authState.userRoles.map(role => (
                        <span key={role} className="inline-block bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 px-2 py-1 rounded text-xs mr-2 mb-1">
                          {role}
                        </span>
                      ))
                    ) : (
                      <span className="text-gray-500 dark:text-gray-400 text-xs">No roles assigned</span>
                    )}
                  </div>
                </div>

                <div className="text-sm">
                  <strong className="text-gray-900 dark:text-white">Required Roles:</strong>
                  <div className="mt-1">
                    {allowedRoles.map(role => (
                      <span key={role} className="inline-block bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 px-2 py-1 rounded text-xs mr-2 mb-1">
                        {role}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button 
                  onClick={() => window.location.href = redirectTo}
                  variant="outline"
                  className="flex-1"
                >
                  Back to Login
                </Button>
                <Button 
                  onClick={() => window.history.back()}
                  className="flex-1"
                >
                  Go Back
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    // Render the protected component
    console.log('🎉 withAuth: Rendering protected component');
    return <WrappedComponent {...props} authState={authState} />;
  };
};

export default withAuth;

// Convenience functions for common role combinations
export const withAdminAuth = (component: React.ComponentType<any>) => 
  withAuth(component, ['administrator']);

export const withVendorAuth = (component: React.ComponentType<any>) => 
  withAuth(component, ['dokan_vendor', 'vendor', 'seller', 'shop_manager']);

export const withAdminOrVendorAuth = (component: React.ComponentType<any>) => 
  withAuth(component, ['administrator', 'dokan_vendor', 'vendor', 'seller', 'shop_manager']);

// Enhanced auth utilities
export const AuthUtils = {
  // Check if user has specific role
  hasRole: (role: string): boolean => {
    const storedUserInfo = localStorage.getItem('eliteq_user_info');
    if (!storedUserInfo) return false;
    
    try {
      const userInfo = JSON.parse(storedUserInfo);
      return userInfo.roles?.includes(role) || false;
    } catch {
      return false;
    }
  },

  // Check if user has any of the specified roles
  hasAnyRole: (roles: string[]): boolean => {
    const storedUserInfo = localStorage.getItem('eliteq_user_info');
    if (!storedUserInfo) return false;
    
    try {
      const userInfo = JSON.parse(storedUserInfo);
      const userRoles = userInfo.roles || [];
      return roles.some(role => userRoles.includes(role));
    } catch {
      return false;
    }
  },

  // Get current user roles
  getCurrentRoles: (): string[] => {
    const storedUserInfo = localStorage.getItem('eliteq_user_info');
    if (!storedUserInfo) return [];
    
    try {
      const userInfo = JSON.parse(storedUserInfo);
      return userInfo.roles || [];
    } catch {
      return [];
    }
  },

  // Check if user is administrator
  isAdmin: (): boolean => {
    return AuthUtils.hasRole('administrator');
  },

  // Check if user is vendor
  isVendor: (): boolean => {
    return AuthUtils.hasAnyRole(['dokan_vendor', 'vendor', 'seller', 'shop_manager']);
  },

  // Redirect based on user role
  redirectToRoleDashboard: (): void => {
    if (AuthUtils.isAdmin()) {
      window.location.href = '/admin/dashboard';
    } else if (AuthUtils.isVendor()) {
      window.location.href = '/vendor/dashboard';
    } else {
      window.location.href = '/';
    }
  }
};