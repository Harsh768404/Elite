// Route configuration for the EliteQ Admin Control Panel
export interface RouteConfig {
  path: string;
  name: string;
  requiresAuth: boolean;
  allowedRoles: string[];
  title: string;
  description?: string;
}

export const routes: RouteConfig[] = [
  {
    path: '/',
    name: 'login',
    requiresAuth: false,
    allowedRoles: [],
    title: 'EliteQ Control Panel - Login',
    description: 'Login to EliteQ WordPress + WooCommerce + Dokan Pro Admin Panel'
  },
  {
    path: '/login',
    name: 'login',
    requiresAuth: false,
    allowedRoles: [],
    title: 'EliteQ Control Panel - Login',
    description: 'Login to EliteQ WordPress + WooCommerce + Dokan Pro Admin Panel'
  },
  {
    path: '/admin-dashboard',
    name: 'admin-dashboard',
    requiresAuth: true,
    allowedRoles: ['admin'],
    title: 'EliteQ Admin Dashboard',
    description: 'Administrator dashboard for complete WordPress marketplace management'
  },
  {
    path: '/admin',
    name: 'admin-dashboard',
    requiresAuth: true,
    allowedRoles: ['admin'],
    title: 'EliteQ Admin Dashboard',
    description: 'Administrator dashboard for complete WordPress marketplace management'
  },
  {
    path: '/vendor-dashboard',
    name: 'vendor-dashboard',
    requiresAuth: true,
    allowedRoles: ['vendor', 'user'],
    title: 'EliteQ Vendor Dashboard',
    description: 'Vendor dashboard for store management and analytics'
  },
  {
    path: '/vendor',
    name: 'vendor-dashboard',
    requiresAuth: true,
    allowedRoles: ['vendor', 'user'],
    title: 'EliteQ Vendor Dashboard',
    description: 'Vendor dashboard for store management and analytics'
  },
  {
    path: '/user-dashboard',
    name: 'user-dashboard',
    requiresAuth: true,
    allowedRoles: ['user'],
    title: 'EliteQ User Dashboard',
    description: 'User dashboard with limited access'
  },
  {
    path: '/user',
    name: 'user-dashboard',
    requiresAuth: true,
    allowedRoles: ['user'],
    title: 'EliteQ User Dashboard',
    description: 'User dashboard with limited access'
  },
  {
    path: '/unauthorized',
    name: 'unauthorized',
    requiresAuth: true,
    allowedRoles: [],
    title: 'Unauthorized Access - EliteQ',
    description: 'Access denied - insufficient permissions'
  }
];

// Route utilities
export const RouteHelpers = {
  // Find route config by path
  findRouteByPath: (path: string): RouteConfig | undefined => {
    return routes.find(route => 
      route.path === path || 
      (path.startsWith(route.path) && route.path !== '/')
    );
  },

  // Check if path is valid
  isValidPath: (path: string): boolean => {
    return !!RouteHelpers.findRouteByPath(path);
  },

  // Check if user can access path
  canAccessPath: (path: string, userRole: string | null): boolean => {
    const route = RouteHelpers.findRouteByPath(path);
    if (!route) return false;

    if (!route.requiresAuth) return true;
    if (!userRole) return false;

    return route.allowedRoles.length === 0 || route.allowedRoles.includes(userRole);
  },

  // Get title for path
  getTitleForPath: (path: string, userRole?: string | null): string => {
    const route = RouteHelpers.findRouteByPath(path);
    if (!route) return 'Page Not Found - EliteQ Control Panel';

    // Customize title based on user role for dashboards
    if (route.name === 'vendor-dashboard' && userRole === 'user') {
      return 'EliteQ User Dashboard';
    }

    return route.title;
  },

  // Get description for path
  getDescriptionForPath: (path: string): string => {
    const route = RouteHelpers.findRouteByPath(path);
    return route?.description || 'EliteQ WordPress + WooCommerce + Dokan Pro Admin Control Panel';
  },

  // Get all public routes
  getPublicRoutes: (): RouteConfig[] => {
    return routes.filter(route => !route.requiresAuth);
  },

  // Get all protected routes
  getProtectedRoutes: (): RouteConfig[] => {
    return routes.filter(route => route.requiresAuth);
  },

  // Get routes for specific role
  getRoutesForRole: (role: string): RouteConfig[] => {
    return routes.filter(route => 
      !route.requiresAuth || 
      route.allowedRoles.length === 0 || 
      route.allowedRoles.includes(role)
    );
  }
};

export default routes;