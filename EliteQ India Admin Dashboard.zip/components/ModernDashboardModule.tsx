import React, { useState, useEffect } from 'react';
import { 
  DollarSign, Package, ShoppingCart, TrendingUp, Users, Eye,
  Calendar, Filter, Download, RefreshCw, ArrowUp, ArrowDown,
  CreditCard, Smartphone, Banknote, Wallet, Building2, PiggyBank,
  AlertCircle, Wifi, WifiOff, CheckCircle, Settings, ExternalLink,
  Info, Shield, Key, UserCheck, Lock, Mail, Phone, MessageCircle,
  HelpCircle, BookOpen, FileText, Zap, Globe, Database, Clock
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Calendar as CalendarComponent } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Progress } from './ui/progress';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useAuth } from '../contexts/AuthContext';

// Mock data for fallback when APIs are not available
const MOCK_PRODUCTS = [
  {
    id: 1,
    name: "iPhone 15 Pro Max",
    regular_price: "129900",
    sale_price: "119900",
    stock_status: "instock",
    store: { shop_name: "TechWorld Store" }
  },
  {
    id: 2,
    name: "Samsung Galaxy S24 Ultra",
    regular_price: "124999",
    sale_price: "",
    stock_status: "instock",
    store: { shop_name: "Mobile Hub" }
  },
  {
    id: 3,
    name: "MacBook Pro M3",
    regular_price: "199900",
    sale_price: "189900",
    stock_status: "outofstock",
    store: { shop_name: "Apple Store" }
  },
  {
    id: 4,
    name: "Sony WH-1000XM5",
    regular_price: "29990",
    sale_price: "24990",
    stock_status: "instock",
    store: { shop_name: "Audio Pro" }
  },
  {
    id: 5,
    name: "Dell XPS 13",
    regular_price: "89990",
    sale_price: "",
    stock_status: "instock",
    store: { shop_name: "Laptop World" }
  }
];

const MOCK_ORDERS = [
  {
    id: 1001,
    number: "ORD-1001",
    status: "completed",
    total: "119900",
    line_items: [
      { name: "iPhone 15 Pro Max", quantity: 1 }
    ],
    billing: { first_name: "Rajesh", last_name: "Kumar" }
  },
  {
    id: 1002,
    number: "ORD-1002",
    status: "processing",
    total: "24990",
    line_items: [
      { name: "Sony WH-1000XM5", quantity: 1 }
    ],
    billing: { first_name: "Priya", last_name: "Sharma" }
  },
  {
    id: 1003,
    number: "ORD-1003",
    status: "pending",
    total: "89990",
    line_items: [
      { name: "Dell XPS 13", quantity: 1 }
    ],
    billing: { first_name: "Amit", last_name: "Singh" }
  },
  {
    id: 1004,
    number: "ORD-1004",
    status: "shipped",
    total: "124999",
    line_items: [
      { name: "Samsung Galaxy S24 Ultra", quantity: 1 }
    ],
    billing: { first_name: "Sneha", last_name: "Patel" }
  }
];

// Live Data Components with Error Handling
interface LiveProductsTableProps {
  jwtToken: string | null;
}

function LiveProductsTable({ jwtToken }: LiveProductsTableProps) {
  const [products, setProducts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [usingMockData, setUsingMockData] = useState(false);

  useEffect(() => {
    const fetchProducts = async () => {
      if (!jwtToken) {
        console.log('📦 No JWT token, using mock products data');
        setProducts(MOCK_PRODUCTS);
        setUsingMockData(true);
        setIsLoading(false);
        return;
      }

      try {
        console.log('📦 Attempting to fetch products from WooCommerce API...');
        
        // Try to import and use WooCommerce API
        const { wooCommerceApi } = await import('../utils/woocommerce-api');
        const response = await wooCommerceApi.getProducts({ per_page: 10 });
        
        console.log('✅ Products fetched successfully from WooCommerce API');
        setProducts(response.data);
        setError(null);
        setUsingMockData(false);
        
      } catch (error: any) {
        console.warn('⚠️ WooCommerce API failed, using mock data:', error.message);
        setError(`WooCommerce API unavailable: ${error.message}`);
        setProducts(MOCK_PRODUCTS);
        setUsingMockData(true);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProducts();
  }, [jwtToken]);

  const formatCurrency = (amount: string) => {
    const numAmount = parseFloat(amount || '0');
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(numAmount);
  };

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <div className="inline-flex items-center gap-2">
          <RefreshCw className="h-4 w-4 animate-spin" />
          <span>Loading products...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Status indicator */}
      {usingMockData && (
        <Alert className="border-orange-200 bg-orange-50 dark:bg-orange-900/20">
          <Info className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-700 dark:text-orange-300">
            <strong>Demo Mode:</strong> Showing sample electronics products. 
            {error && <div className="text-xs mt-1 text-orange-600">{error}</div>}
          </AlertDescription>
        </Alert>
      )}
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Product Name</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Price</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Stock Status</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Vendor</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Product ID</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
            {products.map((product) => (
              <tr key={product.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900 dark:text-white truncate max-w-xs">
                    {product.name}
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">
                    {product.sale_price ? (
                      <div>
                        <span className="line-through text-gray-500">{formatCurrency(product.regular_price)}</span>
                        <span className="ml-2 text-green-600 font-semibold">{formatCurrency(product.sale_price)}</span>
                      </div>
                    ) : (
                      formatCurrency(product.regular_price)
                    )}
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                    product.stock_status === 'instock' ? 'bg-green-100 text-green-800' : 
                    product.stock_status === 'outofstock' ? 'bg-red-100 text-red-800' : 
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {product.stock_status === 'instock' ? 'In Stock' : 
                     product.stock_status === 'outofstock' ? 'Out of Stock' : 
                     'Limited'}
                  </span>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  {product.store?.shop_name || 'EliteQ Store'}
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                  #{product.id}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

interface LiveOrdersTableProps {
  jwtToken: string | null;
}

function LiveOrdersTable({ jwtToken }: LiveOrdersTableProps) {
  const [orders, setOrders] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [usingMockData, setUsingMockData] = useState(false);

  useEffect(() => {
    const fetchOrders = async () => {
      if (!jwtToken) {
        console.log('📋 No JWT token, using mock orders data');
        setOrders(MOCK_ORDERS);
        setUsingMockData(true);
        setIsLoading(false);
        return;
      }

      try {
        console.log('📋 Attempting to fetch orders from WooCommerce API...');
        
        // Try to import and use WooCommerce API
        const { wooCommerceApi } = await import('../utils/woocommerce-api');
        const response = await wooCommerceApi.getOrders({ per_page: 10 });
        
        console.log('✅ Orders fetched successfully from WooCommerce API');
        setOrders(response.data);
        setError(null);
        setUsingMockData(false);
        
      } catch (error: any) {
        console.warn('⚠️ WooCommerce API failed, using mock data:', error.message);
        setError(`WooCommerce API unavailable: ${error.message}`);
        setOrders(MOCK_ORDERS);
        setUsingMockData(true);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchOrders();
  }, [jwtToken]);

  const formatCurrency = (amount: string) => {
    const numAmount = parseFloat(amount || '0');
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(numAmount);
  };

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <div className="inline-flex items-center gap-2">
          <RefreshCw className="h-4 w-4 animate-spin" />
          <span>Loading orders...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Status indicator */}
      {usingMockData && (
        <Alert className="border-orange-200 bg-orange-50 dark:bg-orange-900/20">
          <Info className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-700 dark:text-orange-300">
            <strong>Demo Mode:</strong> Showing sample order data.
            {error && <div className="text-xs mt-1 text-orange-600">{error}</div>}
          </AlertDescription>
        </Alert>
      )}
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Order ID</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Product Name</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Customer Name</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Total Amount</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
            {orders.map((order) => (
              <tr key={order.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                  #{order.number}
                </td>
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white max-w-xs truncate">
                    {order.line_items?.length > 0 ? (
                      order.line_items.map((item: any, index: number) => (
                        <div key={index}>
                          {item.quantity}x {item.name}
                        </div>
                      )).slice(0, 2)
                    ) : (
                      'No items'
                    )}
                    {order.line_items?.length > 2 && (
                      <div className="text-xs text-gray-500">+{order.line_items.length - 2} more</div>
                    )}
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  {order.billing?.first_name} {order.billing?.last_name}
                </td>
                <td className="px-4 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                    order.status === 'completed' ? 'bg-green-100 text-green-800' :
                    order.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                    order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    order.status === 'shipped' ? 'bg-indigo-100 text-indigo-800' :
                    order.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {order.status.replace('-', ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                  </span>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                  {formatCurrency(order.total)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

interface ModernDashboardModuleProps {
  jwtToken: string | null;
  userRole: 'administrator' | 'vendor';
}

interface DashboardData {
  overview: {
    totalSales: number;
    marketplaceCommission: number;
    netSales: number;
    orders: number;
    productsSold: number;
    totalEarning: number;
    marketplaceDiscount: number;
    storeDiscount: number;
    variationSold: number;
    visitors: number;
    views: number;
  };
  orderStatus: {
    newOrder: number;
    processing: number;
    shipped: number;
    delivered: number;
    cancelled: number;
    onHold: number;
    refunded: number;
    failed: number;
    pendingPayment: number;
  };
  salesData: Array<{ month: string; current: number; previous: number }>;
  ordersData: Array<{ date: string; orders: number }>;
  paymentMethods: Array<{ name: string; value: number; color: string }>;
  accountBalance: number;
}

interface WordPressStats {
  users: number;
  adminUsers: number;
  vendorUsers: number;
  lastLogin: string;
  siteHealth: string;
  activePlugins: number;
  wordpressVersion: string;
  hasUserPermissions: boolean;
}

const PAYMENT_COLORS = {
  'UPI': '#00C851',
  'Credit Card': '#0088FE',
  'Debit Card': '#00C49F',
  'EMI': '#FFBB28',
  'Pay Later': '#FF8042',
  'Net Banking': '#8884D8',
  'Wallets': '#82CA9D'
};

export function ModernDashboardModule({ jwtToken, userRole }: ModernDashboardModuleProps) {
  // Use AuthContext to get authenticated user data
  const { user: authUser, isAuthenticated } = useAuth();
  
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [wordpressStats, setWordpressStats] = useState<WordPressStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedFilter, setSelectedFilter] = useState('this-month');
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date } | null>(null);
  const [showCalendar, setShowCalendar] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'live' | 'error' | 'demo'>('connecting');
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);

  // Enhanced dashboard initialization with error handling
  useEffect(() => {
    const initializeDashboard = async () => {
      console.log('🎛️ Initializing dashboard with enhanced error handling...');
      setIsLoading(true);
      setError(null);
      setConnectionStatus('connecting');

      try {
        console.log('👤 Using authenticated user from AuthContext...');
        
        // Use authenticated user from AuthContext
        let userInfo = null;
        
        if (authUser && isAuthenticated) {
          userInfo = {
            id: authUser.id,
            name: authUser.display_name || authUser.username,
            email: authUser.email,
            username: authUser.username,
            roles: authUser.roles,
            display_name: authUser.display_name
          };
          
          console.log('✅ Using AuthContext user data:', {
            name: userInfo.name,
            email: userInfo.email,
            roles: userInfo.roles,
            source: 'AuthContext'
          });
        } else {
          // Fallback user info
          userInfo = {
            id: 'demo',
            name: 'Demo User',
            email: 'demo@eliteq.in',
            username: 'demo_user',
            roles: ['administrator'],
            display_name: 'Demo User'
          };
          console.log('📝 Using demo user data');
        }
        
        setCurrentUser(userInfo);         

        // Generate WordPress statistics
        const wpStats: WordPressStats = {
          users: 1,
          adminUsers: userInfo.roles?.includes('administrator') ? 1 : 0,
          vendorUsers: userInfo.roles?.some((role: string) => ['seller', 'vendor', 'shop_manager'].includes(role)) ? 1 : 0,
          lastLogin: new Date().toISOString(),
          siteHealth: 'Good',
          activePlugins: 15,
          wordpressVersion: '6.4',
          hasUserPermissions: true
        };
        setWordpressStats(wpStats);

        console.log('📊 WordPress stats generated');

        // Generate mock dashboard data (since WooCommerce API might not be available)
        const mockData: DashboardData = {
          overview: {
            totalSales: 2540000,
            marketplaceCommission: 381000,
            netSales: 2159000,
            orders: 127,
            productsSold: 342,
            totalEarning: 2159000,
            marketplaceDiscount: 127000,
            storeDiscount: 76000,
            variationSold: 38,
            visitors: 1905,
            views: 6350
          },
          orderStatus: {
            newOrder: 8,
            processing: 12,
            shipped: 15,
            delivered: 89,
            cancelled: 3,
            onHold: 2,
            refunded: 1,
            failed: 0,
            pendingPayment: 5
          },
          salesData: [
            { month: 'Jan', current: 180000, previous: 150000 },
            { month: 'Feb', current: 220000, previous: 180000 },
            { month: 'Mar', current: 280000, previous: 210000 },
            { month: 'Apr', current: 310000, previous: 240000 },
            { month: 'May', current: 340000, previous: 280000 },
            { month: 'Jun', current: 390000, previous: 320000 }
          ],
          ordersData: [
            { date: '2024-01-01', orders: 12 },
            { date: '2024-01-02', orders: 18 },
            { date: '2024-01-03', orders: 15 },
            { date: '2024-01-04', orders: 22 },
            { date: '2024-01-05', orders: 19 },
            { date: '2024-01-06', orders: 25 },
            { date: '2024-01-07', orders: 28 }
          ],
          paymentMethods: [
            { name: 'UPI', value: 45, color: PAYMENT_COLORS.UPI },
            { name: 'Credit Card', value: 25, color: PAYMENT_COLORS['Credit Card'] },
            { name: 'Debit Card', value: 15, color: PAYMENT_COLORS['Debit Card'] },
            { name: 'EMI', value: 10, color: PAYMENT_COLORS.EMI },
            { name: 'Net Banking', value: 5, color: PAYMENT_COLORS['Net Banking'] }
          ],
          accountBalance: 1727200
        };

        setDashboardData(mockData);
        setConnectionStatus('demo');
        setLastSync(new Date());
        
        console.log('✅ Dashboard initialized with demo data');
        
      } catch (error: any) {
        console.error('🚨 Dashboard initialization failed:', error);
        setConnectionStatus('error');
        setError(`Failed to initialize dashboard: ${error.message}`);
      } finally {
        setIsLoading(false);
      }
    };

    initializeDashboard();
  }, [jwtToken, selectedFilter, authUser, isAuthenticated]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-IN').format(num);
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <div>
            <h2 className="text-xl">Loading Dashboard</h2>
            <p className="text-gray-600 dark:text-gray-400">
              Connecting to WordPress backend...
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20">
        <AlertCircle className="h-4 w-4 text-red-600" />
        <AlertDescription className="text-red-700 dark:text-red-300">
          <strong>Dashboard Error:</strong> {error}
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:items-between gap-4">
        <div>
          <h1 className="text-3xl">
            EliteQ India Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            WordPress electronics marketplace •
            <span className="ml-2 inline-flex items-center gap-1">
              {connectionStatus === 'live' ? (
                <>
                  <Wifi className="h-4 w-4 text-green-600" />
                  <span className="text-green-600">Live Connection</span>
                </>
              ) : connectionStatus === 'demo' ? (
                <>
                  <Database className="h-4 w-4 text-blue-600" />
                  <span className="text-blue-600">Demo Mode</span>
                </>
              ) : connectionStatus === 'connecting' ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />
                  <span className="text-blue-600">Connecting...</span>
                </>
              ) : (
                <>
                  <WifiOff className="h-4 w-4 text-red-600" />
                  <span className="text-red-600">Connection Error</span>
                </>
              )}
            </span>
          </p>
          {lastSync && (
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Last sync: {formatDate(lastSync)}
            </p>
          )}
        </div>

        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => window.location.reload()}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Data
          </Button>
        </div>
      </div>

      {/* Demo Mode Notice */}
      {connectionStatus === 'demo' && (
        <Alert className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
          <Info className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-700 dark:text-blue-300">
            <strong>Demo Mode:</strong> Dashboard is running with sample data. 
            Connect WooCommerce API for live marketplace data.
          </AlertDescription>
        </Alert>
      )}

      {/* Current User Information */}
      {currentUser && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Current User Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <div className="text-sm text-gray-500 dark:text-gray-400">Name</div>
                <div className="font-medium">{currentUser.name || 'N/A'}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500 dark:text-gray-400">Email</div>
                <div className="font-medium">{currentUser.email || 'No email provided'}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500 dark:text-gray-400">Roles</div>
                <div className="flex flex-wrap gap-1">
                  {currentUser.roles?.map((role: string) => (
                    <Badge key={role} variant="outline" className="text-xs">
                      {role}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Overview Stats */}
      {dashboardData && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(dashboardData.overview.totalSales)}</div>
              <p className="text-xs text-muted-foreground">
                +15% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Orders</CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatNumber(dashboardData.overview.orders)}</div>
              <p className="text-xs text-muted-foreground">
                +8% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Products Sold</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatNumber(dashboardData.overview.productsSold)}</div>
              <p className="text-xs text-muted-foreground">
                +12% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Visitors</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatNumber(dashboardData.overview.visitors)}</div>
              <p className="text-xs text-muted-foreground">
                +5% from last month
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Live Data Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Recent Products
            </CardTitle>
          </CardHeader>
          <CardContent>
            <LiveProductsTable jwtToken={jwtToken} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShoppingCart className="h-5 w-5" />
              Recent Orders
            </CardTitle>
          </CardHeader>
          <CardContent>
            <LiveOrdersTable jwtToken={jwtToken} />
          </CardContent>
        </Card>
      </div>

      {/* WordPress Statistics */}
      {wordpressStats && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5" />
              WordPress Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{wordpressStats.users}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Total Users</div>
              </div>
              <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{wordpressStats.adminUsers}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Administrators</div>
              </div>
              <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">{wordpressStats.vendorUsers}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Vendors</div>
              </div>
              <div className="text-center p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">{wordpressStats.activePlugins}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Active Plugins</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default ModernDashboardModule;