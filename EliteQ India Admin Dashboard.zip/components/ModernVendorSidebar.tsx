import React, { useState } from 'react';
import { 
  LayoutDashboard, Package, ShoppingCart, Ticket, BarChart3, 
  Clock, Star, CreditCard, Award, MessageCircle, RotateCcw,
  Users, Megaphone, Activity, Wrench, Settings, ChevronDown,
  ChevronRight, Store, DollarSign, Shield, Truck, Globe,
  Search, Menu, X
} from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { EliteQLogo } from './EliteQLogo';

interface ModernVendorSidebarProps {
  activeModule: string;
  setActiveModule: (module: string) => void;
  darkMode: boolean;
  userRole: 'administrator' | 'vendor';
  sidebarOpen?: boolean;
  setSidebarOpen?: (open: boolean) => void;
}

export function ModernVendorSidebar({ 
  activeModule, 
  setActiveModule, 
  darkMode, 
  userRole,
  sidebarOpen = true,
  setSidebarOpen 
}: ModernVendorSidebarProps) {
  const [ordersOpen, setOrdersOpen] = useState(false); // Start collapsed
  const [reportsOpen, setReportsOpen] = useState(false); // Start collapsed
  const [settingsOpen, setSettingsOpen] = useState(false); // Start collapsed

  const navigationItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
      show: true
    },
    {
      id: 'announcements',
      label: 'Announcements',
      icon: Megaphone,
      badge: null,
      show: true
    },
    {
      id: 'products',
      label: 'Products',
      icon: Package,
      badge: null,
      show: true
    },
    {
      id: 'orders',
      label: 'Orders',
      icon: ShoppingCart,
      badge: '12',
      show: true,
      hasSubmenu: true,
      submenu: [
        { id: 'orders-all', label: 'All Orders', show: true },
        { id: 'orders-new', label: 'Add New Order', show: userRole === 'administrator' }
      ]
    },
    {
      id: 'coupon',
      label: 'Coupon',
      icon: Ticket,
      badge: null,
      show: true
    },
    {
      id: 'reports',
      label: 'Reports',
      icon: BarChart3,
      badge: null,
      show: true,
      hasSubmenu: true,
      submenu: [
        { id: 'reports-products', label: 'Products', show: true },
        { id: 'reports-revenue', label: 'Revenue', show: true },
        { id: 'reports-orders', label: 'Orders', show: true },
        { id: 'reports-variations', label: 'Variations', show: true },
        { id: 'reports-categories', label: 'Categories', show: true },
        { id: 'reports-stock', label: 'Stock', show: true },
        { id: 'reports-statement', label: 'Statement', show: true }
      ]
    },
    {
      id: 'delivery-time',
      label: 'Delivery Time',
      icon: Clock,
      badge: null,
      show: true
    },
    {
      id: 'reviews',
      label: 'Reviews',
      icon: Star,
      badge: '5',
      show: true
    },
    {
      id: 'withdraw',
      label: 'Withdraw',
      icon: CreditCard,
      badge: null,
      show: true
    },
    {
      id: 'badge',
      label: 'Badge',
      icon: Award,
      badge: null,
      show: true
    },
    {
      id: 'product-qa',
      label: 'Product Q&A',
      icon: MessageCircle,
      badge: '3',
      show: true
    },
    {
      id: 'return-request',
      label: 'Return Request',
      icon: RotateCcw,
      badge: '2',
      show: true
    },
    {
      id: 'staff',
      label: 'Staff',
      icon: Users,
      badge: null,
      show: userRole === 'administrator'
    },
    {
      id: 'followers',
      label: 'Followers',
      icon: Users,
      badge: '1.2k',
      show: true
    },
    {
      id: 'announcements',
      label: 'Announcements',
      icon: Megaphone,
      badge: null,
      show: true
    },
    {
      id: 'store-stats',
      label: 'Store Stats',
      icon: Activity,
      badge: null,
      show: true
    },
    {
      id: 'tools',
      label: 'Tools',
      icon: Wrench,
      badge: null,
      show: userRole === 'administrator'
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      badge: null,
      show: true,
      hasSubmenu: true,
      submenu: [
        { id: 'settings-store', label: 'Store', show: true },
        { id: 'settings-payment', label: 'Payment', show: true },
        { id: 'settings-verification', label: 'Verification', show: true },
        { id: 'settings-shipping', label: 'Shipping', show: true },
        { id: 'settings-social', label: 'Social Profile', show: true },
        { id: 'settings-rma', label: 'RMA', show: true },
        { id: 'settings-seo', label: 'Store SEO', show: true }
      ]
    }
  ];

  const handleItemClick = (id: string) => {
    if (id.startsWith('orders-')) {
      setActiveModule('orders');
    } else if (id.startsWith('reports-')) {
      setActiveModule('reports');
    } else if (id.startsWith('settings-')) {
      setActiveModule('settings');
    } else {
      setActiveModule(id);
    }
    
    // Close mobile sidebar when item is selected
    if (setSidebarOpen) {
      setSidebarOpen(false);
    }
  };

  return (
    <div className={`flex flex-col h-full bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 ${
      darkMode ? 'sidebar-dark' : 'sidebar-light'
    }`}>
      
      {/* Sidebar Header */}
      <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center gap-3">
          <EliteQLogo darkMode={darkMode} size="sm" showText={false} animated={true} />
          <div>
            <h3 className="font-bold text-gray-900 dark:text-white">
              {userRole === 'administrator' ? 'Admin Panel' : 'Vendor Dashboard'}
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {userRole === 'administrator' ? 'Full Control' : 'Store Management'}
            </p>
          </div>
        </div>
        
        {/* Mobile Close Button */}
        {setSidebarOpen && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
        {navigationItems.filter(item => item.show).map((item) => {
          const Icon = item.icon;
          const isActive = activeModule === item.id || 
            (item.id === 'orders' && activeModule === 'orders') ||
            (item.id === 'reports' && activeModule === 'reports') ||
            (item.id === 'settings' && activeModule === 'settings');

          if (item.hasSubmenu) {
            const isOpen = item.id === 'orders' ? ordersOpen : 
                          item.id === 'reports' ? reportsOpen : 
                          item.id === 'settings' ? settingsOpen : false;
            
            const setOpen = item.id === 'orders' ? setOrdersOpen : 
                           item.id === 'reports' ? setReportsOpen : 
                           item.id === 'settings' ? setSettingsOpen : () => {};

            return (
              <Collapsible key={item.id} open={isOpen} onOpenChange={setOpen}>
                <CollapsibleTrigger asChild>
                  <Button
                    variant="ghost"
                    className={`w-full justify-between h-12 px-4 transition-all duration-200 ${
                      isActive
                        ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border-r-2 border-blue-600 dark:border-blue-400'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="h-5 w-5" />
                      <span className="font-medium">{item.label}</span>
                      {item.badge && (
                        <Badge variant="secondary" className="ml-auto text-xs">
                          {item.badge}
                        </Badge>
                      )}
                    </div>
                    {isOpen ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-1">
                  <div className="ml-6 space-y-1">
                    {item.submenu?.filter(subItem => subItem.show).map((subItem) => (
                      <Button
                        key={subItem.id}
                        variant="ghost"
                        onClick={() => handleItemClick(subItem.id)}
                        className={`w-full justify-start h-10 px-4 text-sm transition-all duration-200 ${
                          activeModule === subItem.id
                            ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                            : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
                        }`}
                      >
                        {subItem.label}
                      </Button>
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            );
          }

          return (
            <Button
              key={item.id}
              variant="ghost"
              onClick={() => handleItemClick(item.id)}
              className={`w-full justify-start h-12 px-4 transition-all duration-200 ${
                isActive
                  ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border-r-2 border-blue-600 dark:border-blue-400'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <div className="flex items-center gap-3 w-full">
                <Icon className="h-5 w-5" />
                <span className="font-medium">{item.label}</span>
                {item.badge && (
                  <Badge variant="secondary" className="ml-auto text-xs">
                    {item.badge}
                  </Badge>
                )}
              </div>
            </Button>
          );
        })}
      </nav>

      {/* Sidebar Footer */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="flex items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 text-white">
          <div className="p-2 bg-white/20 rounded-lg">
            <Award className="h-5 w-5" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium text-sm">Store Performance</p>
            <p className="text-xs opacity-90 truncate">
              {userRole === 'administrator' ? 'All stores monitored' : 'Your store is verified'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}