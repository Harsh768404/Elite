// Dashboard Configuration Constants
export const DASHBOARD_METRICS = {
  totalUsers: 1247,
  totalOrders: 856,
  totalProducts: 342,
  revenue: 45280
};

export const DASHBOARD_TABS = [
  { value: 'overview', label: 'Overview' },
  { value: 'api-testing', label: 'API Testing' },
  { value: 'real-data', label: 'Real Data' },
  { value: 'network', label: 'Network' },
  { value: 'role-debug', label: 'Role Debug' },
  { value: 'permissions', label: 'Permissions' },
  { value: 'settings', label: 'Settings' }
];

export const QUICK_ACTIONS = [
  {
    id: 'users',
    label: 'Manage Users',
    icon: 'Users',
    url: 'https://eliteq.in/wp-admin/users.php'
  },
  {
    id: 'products',
    label: 'Products',
    icon: 'Package',
    url: 'https://eliteq.in/wp-admin/edit.php?post_type=product'
  },
  {
    id: 'orders',
    label: 'Orders',
    icon: 'ShoppingCart',
    url: 'https://eliteq.in/wp-admin/edit.php?post_type=shop_order'
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: 'Settings',
    url: 'https://eliteq.in/wp-admin/admin.php?page=wc-settings'
  }
];

export const SYSTEM_CONNECTIONS = {
  wordpress: {
    url: 'https://eliteq.in',
    status: 'Connected',
    version: 'WordPress 6.x'
  },
  woocommerce: {
    consumerKey: 'ck_4d0...bd9',
    status: 'Connected',
    version: 'WooCommerce 8.x'
  }
};

export const SYSTEM_HEALTH_INDICATORS = [
  { name: 'Application', status: 'Running', color: 'green' },
  { name: 'Authentication', status: 'Active', color: 'green' },
  { name: 'WordPress API', status: 'Connected', color: 'green' },
  { name: 'WooCommerce API', status: 'Limited Permissions', color: 'yellow' }
];