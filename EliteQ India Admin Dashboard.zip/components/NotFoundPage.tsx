import React from 'react';
import { Home, ArrowLeft, Search, HelpCircle, Shield, User } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { EliteQIndiaLogo } from './EliteQIndiaLogo';

interface NotFoundPageProps {
  currentRoute: string;
  user?: any;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ currentRoute, user }) => {
  const handleGoHome = () => {
    if (user) {
      // Redirect to user's appropriate dashboard
      const route = user.primary_role === 'administrator' 
        ? '/admin-dashboard' 
        : user.primary_role === 'vendor' 
        ? '/vendor-dashboard' 
        : '/account-dashboard';
      
      window.history.pushState({}, '', route);
      window.dispatchEvent(new PopStateEvent('popstate'));
    } else {
      // Redirect to login
      window.history.pushState({}, '', '/');
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  };

  const handleGoBack = () => {
    window.history.back();
  };

  const getSuggestedRoutes = () => {
    if (!user) {
      return [
        { path: '/', label: 'Login Page', icon: Home, description: 'Sign in to your WordPress account' }
      ];
    }

    const routes = [
      { 
        path: '/account-dashboard', 
        label: 'Account Dashboard', 
        icon: User, 
        description: 'Your personal dashboard' 
      }
    ];

    if (user.primary_role === 'administrator') {
      routes.unshift({
        path: '/admin-dashboard',
        label: 'Admin Dashboard',
        icon: Shield,
        description: 'Platform administration and management'
      });
    }

    if (user.primary_role === 'vendor') {
      routes.unshift({
        path: '/vendor-dashboard',
        label: 'Vendor Dashboard',
        icon: User,
        description: 'Manage your store and products'
      });
    }

    return routes;
  };

  const navigateToRoute = (path: string) => {
    window.history.pushState({}, '', path);
    window.dispatchEvent(new PopStateEvent('popstate'));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-blue-900/20 dark:to-indigo-900/30 flex items-center justify-center p-4">
      
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-blue-500/3 to-indigo-500/3 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 w-full max-w-2xl">
        
        {/* Header with Logo */}
        <div className="text-center mb-8">
          <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/20 p-8 mb-6">
            <div className="flex justify-center mb-6">
              <EliteQIndiaLogo size="lg" showTagline={false} />
            </div>
            
            <div className="text-center space-y-4">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-100 to-indigo-100 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="w-12 h-12 text-blue-600 dark:text-blue-400" />
              </div>
              
              <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
                Page Not Found
              </h1>
              
              <p className="text-xl text-gray-600 dark:text-gray-400">
                The page you're looking for doesn't exist
              </p>
              
              <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 mt-6">
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  <strong>Requested URL:</strong>
                </div>
                <div className="font-mono text-sm bg-white dark:bg-gray-800 rounded px-3 py-2 mt-1 border">
                  {currentRoute || '/'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* User Info (if authenticated) */}
        {user && (
          <Card className="mb-6 bg-white/90 dark:bg-gray-800/90 backdrop-blur-xl border border-white/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Current User Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Name</div>
                  <div className="font-medium">{user.display_name || 'N/A'}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Email</div>
                  <div className="font-medium">{user.email}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Role</div>
                  <div className="flex flex-wrap gap-1">
                    <Badge variant="outline" className="text-xs capitalize">
                      {user.primary_role}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main Action Card */}
        <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-xl border border-white/20 shadow-2xl">
          <CardContent className="p-8">
            
            {/* Quick Actions */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button 
                onClick={handleGoHome}
                className="flex-1 h-12 bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 hover:from-blue-700 hover:via-blue-800 hover:to-blue-900 text-white shadow-lg hover:shadow-xl transition-all duration-200"
              >
                <Home className="h-4 w-4 mr-2" />
                {user ? 'Go to Dashboard' : 'Go to Login'}
              </Button>
              
              <Button 
                onClick={handleGoBack}
                variant="outline"
                className="flex-1 h-12 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Go Back
              </Button>
            </div>

            {/* Suggested Routes */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                Available Pages
              </h3>
              
              <div className="grid gap-3">
                {getSuggestedRoutes().map((route, index) => (
                  <button
                    key={index}
                    onClick={() => navigateToRoute(route.path)}
                    className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors text-left w-full"
                  >
                    <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                      <route.icon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900 dark:text-white">
                        {route.label}
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {route.description}
                      </div>
                    </div>
                    <div className="text-gray-400">
                      <ArrowLeft className="h-4 w-4 rotate-180" />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Help Section */}
            <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-2 mb-4">
                <HelpCircle className="h-5 w-5 text-gray-500" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Need Help?
                </span>
              </div>
              
              <div className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                <p>
                  If you're looking for a specific page, make sure the URL is correct.
                </p>
                <p>
                  Common URLs include:
                </p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li><code className="bg-gray-200 dark:bg-gray-700 px-1 rounded">/admin-dashboard</code> - Administrator dashboard</li>
                  <li><code className="bg-gray-200 dark:bg-gray-700 px-1 rounded">/vendor-dashboard</code> - Vendor dashboard</li>
                  <li><code className="bg-gray-200 dark:bg-gray-700 px-1 rounded">/account-dashboard</code> - Account dashboard</li>
                </ul>
              </div>
            </div>

            {/* Footer */}
            <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 text-center">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                © 2024 EliteQ India. WordPress electronics marketplace platform.
              </p>
            </div>

          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NotFoundPage;