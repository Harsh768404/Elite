import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Settings } from 'lucide-react';
import { SYSTEM_CONNECTIONS, SYSTEM_HEALTH_INDICATORS } from '../../constants/dashboard-config';

interface User {
  display_name?: string;
  email?: string;
  primary_role?: string;
  roles?: string[];
  dashboard_route?: string;
  authenticated_at?: string;
}

interface SettingsTabContentProps {
  user: User | null;
}

export const SettingsTabContent: React.FC<SettingsTabContentProps> = ({ user }) => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            System Settings
          </CardTitle>
          <CardDescription>
            Configure your EliteQ admin panel settings
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">WordPress Connection</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div><strong>URL:</strong> {SYSTEM_CONNECTIONS.wordpress.url}</div>
                    <div><strong>Status:</strong> <Badge variant="default">{SYSTEM_CONNECTIONS.wordpress.status}</Badge></div>
                    <div><strong>Version:</strong> {SYSTEM_CONNECTIONS.wordpress.version}</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">WooCommerce Connection</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div><strong>Consumer Key:</strong> {SYSTEM_CONNECTIONS.woocommerce.consumerKey}</div>
                    <div><strong>Status:</strong> <Badge variant="default">{SYSTEM_CONNECTIONS.woocommerce.status}</Badge></div>
                    <div><strong>Version:</strong> {SYSTEM_CONNECTIONS.woocommerce.version}</div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">User Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2 md:grid-cols-2 text-sm">
                  <div><strong>Name:</strong> {user?.display_name}</div>
                  <div><strong>Email:</strong> {user?.email}</div>
                  <div><strong>Primary Role:</strong> {user?.primary_role}</div>
                  <div><strong>All Roles:</strong> {user?.roles?.join(', ')}</div>
                  <div><strong>Dashboard Route:</strong> {user?.dashboard_route}</div>
                  <div><strong>Login Time:</strong> {user?.authenticated_at && new Date(user.authenticated_at).toLocaleString()}</div>
                </div>
              </CardContent>
            </Card>

            {/* System Health */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">System Health</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  {SYSTEM_HEALTH_INDICATORS.map((indicator, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className={`w-2 h-2 bg-${indicator.color}-500 rounded-full`}></div>
                      <span>{indicator.name}: {indicator.status}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SettingsTabContent;