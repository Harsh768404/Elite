import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Product {
  id: string;
  title: string;
  price: string;
  image: string;
  stock: 'in-stock' | 'low-stock' | 'out-of-stock';
  stockCount: number;
  category: string;
}

const recentProducts: Product[] = [
  {
    id: 'PRD-001',
    title: 'iPhone 15 Pro Max 256GB',
    price: '₹1,49,900',
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=100&h=100&fit=crop',
    stock: 'in-stock',
    stockCount: 25,
    category: 'Smartphones'
  },
  {
    id: 'PRD-002',
    title: 'Samsung Galaxy S24 Ultra',
    price: '₹1,29,999',
    image: 'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=100&h=100&fit=crop',
    stock: 'low-stock',
    stockCount: 3,
    category: 'Smartphones'
  },
  {
    id: 'PRD-003',
    title: 'MacBook Air M2 13-inch',
    price: '₹1,14,900',
    image: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=100&h=100&fit=crop',
    stock: 'in-stock',
    stockCount: 12,
    category: 'Laptops'
  },
  {
    id: 'PRD-004',
    title: 'Sony WH-1000XM5 Headphones',
    price: '₹29,990',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=100&h=100&fit=crop',
    stock: 'out-of-stock',
    stockCount: 0,
    category: 'Audio'
  },
  {
    id: 'PRD-005',
    title: 'iPad Pro 12.9" M2',
    price: '₹1,12,900',
    image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=100&h=100&fit=crop',
    stock: 'in-stock',
    stockCount: 8,
    category: 'Tablets'
  }
];

function getStockBadge(stock: Product['stock'], count: number) {
  const variants = {
    'in-stock': 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400',
    'low-stock': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400',
    'out-of-stock': 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
  };

  const labels = {
    'in-stock': `In Stock (${count})`,
    'low-stock': `Low Stock (${count})`,
    'out-of-stock': 'Out of Stock'
  };

  return (
    <Badge variant="secondary" className={`${variants[stock]} text-xs`}>
      {labels[stock]}
    </Badge>
  );
}

export function RecentProductsList() {
  const handleViewProduct = (productId: string) => {
    console.log('Viewing product:', productId);
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">
            Recent Products
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Latest products in your store
          </p>
        </div>
        <Button variant="outline" size="sm">
          View All
        </Button>
      </div>

      <div className="space-y-4">
        {recentProducts.map((product) => (
          <div 
            key={product.id}
            className="flex items-center space-x-4 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors duration-150 cursor-pointer"
            onClick={() => handleViewProduct(product.id)}
          >
            <div className="flex-shrink-0">
              <ImageWithFallback
                src={product.image}
                alt={product.title}
                className="w-12 h-12 rounded-lg object-cover"
              />
            </div>
            
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-medium text-gray-900 dark:text-white truncate">
                {product.title}
              </h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {product.category}
              </p>
              <div className="flex items-center justify-between mt-2">
                <span className="text-sm font-medium text-gray-900 dark:text-white">
                  {product.price}
                </span>
                {getStockBadge(product.stock, product.stockCount)}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-lg font-semibold text-gray-900 dark:text-white">48</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">In Stock</p>
          </div>
          <div>
            <p className="text-lg font-semibold text-yellow-600">8</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">Low Stock</p>
          </div>
          <div>
            <p className="text-lg font-semibold text-red-600">3</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">Out of Stock</p>
          </div>
        </div>
      </div>
    </Card>
  );
}