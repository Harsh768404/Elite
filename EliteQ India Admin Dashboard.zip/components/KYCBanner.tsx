import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Upload, 
  FileText, 
  CheckCircle, 
  XCircle, 
  ChevronDown,
  ChevronUp,
  Shield,
  CreditCard,
  Building,
  IdCard,
  FileCheck,
  Loader2,
  X
} from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface KYCDocument {
  id: string;
  name: string;
  icon: any;
  required: boolean;
  file?: File;
  uploaded: boolean;
  progress: number;
  error?: string;
}

interface KYCBannerProps {
  kycStatus: 'pending' | 'approved' | 'rejected' | 'not_submitted';
  onSubmit?: (documents: KYCDocument[]) => Promise<void>;
  onClose?: () => void;
}

const initialDocuments: KYCDocument[] = [
  {
    id: 'aadhaar',
    name: 'Aadhaar Card',
    icon: IdCard,
    required: true,
    uploaded: false,
    progress: 0
  },
  {
    id: 'pan',
    name: 'PAN Card',
    icon: CreditCard,
    required: true,
    uploaded: false,
    progress: 0
  },
  {
    id: 'bank_statement',
    name: 'Bank Statement',
    icon: Building,
    required: true,
    uploaded: false,
    progress: 0
  },
  {
    id: 'gst_certificate',
    name: 'GST Certificate',
    icon: FileText,
    required: true,
    uploaded: false,
    progress: 0
  },
  {
    id: 'udyam_aadhar',
    name: 'Udyam Aadhar',
    icon: Shield,
    required: false,
    uploaded: false,
    progress: 0
  }
];

export const KYCBanner: React.FC<KYCBannerProps> = ({ 
  kycStatus, 
  onSubmit,
  onClose 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [documents, setDocuments] = useState<KYCDocument[]>(initialDocuments);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showBanner, setShowBanner] = useState(true);

  // Only show banner if KYC status is pending
  if (kycStatus !== 'pending' || !showBanner) {
    return null;
  }

  const validateFile = (file: File): string | null => {
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
    const maxSize = 2 * 1024 * 1024; // 2MB

    if (!allowedTypes.includes(file.type)) {
      return 'Only PDF, JPG, and PNG files are allowed';
    }

    if (file.size > maxSize) {
      return 'File size must be less than 2MB';
    }

    return null;
  };

  const handleFileUpload = (documentId: string, file: File) => {
    const error = validateFile(file);
    
    setDocuments(prev => prev.map(doc => {
      if (doc.id === documentId) {
        if (error) {
          return { ...doc, error, progress: 0, uploaded: false, file: undefined };
        }
        
        // Simulate upload progress
        const updatedDoc = { ...doc, file, error: undefined, progress: 0 };
        
        // Simulate file upload progress
        let progress = 0;
        const interval = setInterval(() => {
          progress += 10;
          setDocuments(current => current.map(d => 
            d.id === documentId ? { ...d, progress } : d
          ));
          
          if (progress >= 100) {
            clearInterval(interval);
            setDocuments(current => current.map(d => 
              d.id === documentId ? { ...d, uploaded: true, progress: 100 } : d
            ));
          }
        }, 100);
        
        return updatedDoc;
      }
      return doc;
    }));
  };

  const handleRemoveFile = (documentId: string) => {
    setDocuments(prev => prev.map(doc => 
      doc.id === documentId 
        ? { ...doc, file: undefined, uploaded: false, progress: 0, error: undefined }
        : doc
    ));
  };

  const handleSubmit = async () => {
    const requiredDocuments = documents.filter(doc => doc.required);
    const uploadedRequiredDocs = requiredDocuments.filter(doc => doc.uploaded);

    if (uploadedRequiredDocs.length < requiredDocuments.length) {
      alert('Please upload all required documents before submitting');
      return;
    }

    setIsSubmitting(true);
    try {
      if (onSubmit) {
        await onSubmit(documents);
      }
      // Show success message or redirect
    } catch (error) {
      console.error('Failed to submit KYC documents:', error);
      alert('Failed to submit documents. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const allRequiredUploaded = documents
    .filter(doc => doc.required)
    .every(doc => doc.uploaded);

  const uploadedCount = documents.filter(doc => doc.uploaded).length;
  const totalRequired = documents.filter(doc => doc.required).length;

  return (
    <div className="mb-6 animate-slide-in">
      <Alert className="border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50 border-l-4 border-l-amber-500 relative shadow-lg hover:shadow-xl transition-all duration-300">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0 mt-1">
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 flex items-center justify-center animate-pulse shadow-lg">
              <AlertTriangle className="h-5 w-5 text-white" />
            </div>
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-2">
              <div>
                <h3 className="text-lg font-bold text-amber-900 mb-1">
                  KYC Verification Required
                </h3>
                <AlertDescription className="text-amber-800 text-sm">
                  Your application is pending. Complete your KYC to activate your EliteQ India vendor account.
                </AlertDescription>
              </div>
              
              <div className="flex items-center gap-2 ml-4">
                <Badge variant="secondary" className="bg-amber-100 text-amber-800 border-amber-300">
                  {uploadedCount}/{documents.length} Documents
                </Badge>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsExpanded(!isExpanded)}
                  className="text-amber-700 hover:bg-amber-100 p-2"
                >
                  {isExpanded ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </Button>
                
                {onClose && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onClose}
                    className="text-amber-700 hover:bg-amber-100 p-2"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-3">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-medium text-amber-700">
                  KYC Completion Progress
                </span>
                <span className="text-xs font-medium text-amber-700">
                  {Math.round((uploadedCount / documents.length) * 100)}%
                </span>
              </div>
              <Progress 
                value={(uploadedCount / documents.length) * 100} 
                className="h-3 bg-amber-200 rounded-full overflow-hidden"
              />
            </div>

            {/* Expandable KYC Form */}
            {isExpanded && (
              <Card className="mt-4 bg-white/95 backdrop-blur-sm border-amber-200 shadow-xl animate-fade-in">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <FileCheck className="h-5 w-5 text-blue-600" />
                    <h4 className="text-lg font-bold text-gray-900">
                      Upload KYC Documents
                    </h4>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {documents.map((doc) => {
                      const Icon = doc.icon;
                      return (
                        <div
                          key={doc.id}
                          className="border-2 border-dashed border-gray-300 rounded-lg p-4 hover:border-blue-400 transition-all duration-200 hover:shadow-md hover:bg-gray-50"
                        >
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-50 to-blue-100 flex items-center justify-center shadow-sm">
                              <Icon className="h-5 w-5 text-blue-600" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <Label className="text-sm font-medium text-gray-900">
                                  {doc.name}
                                </Label>
                                {doc.required && (
                                  <Badge variant="outline" className="text-xs border-red-200 text-red-600">
                                    Required
                                  </Badge>
                                )}
                              </div>
                              <p className="text-xs text-gray-500 mt-1">
                                PDF, JPG, PNG (Max 2MB)
                              </p>
                            </div>
                          </div>

                          {doc.uploaded ? (
                            <div className="space-y-2">
                              <div className="flex items-center justify-between p-2 bg-green-50 rounded-lg border border-green-200">
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="h-4 w-4 text-green-600" />
                                  <span className="text-sm font-medium text-green-800">
                                    {doc.file?.name}
                                  </span>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleRemoveFile(doc.id)}
                                  className="text-red-600 hover:bg-red-50 p-1 h-6 w-6"
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          ) : doc.progress > 0 ? (
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">{doc.file?.name}</span>
                                <span className="text-xs text-gray-500">{doc.progress}%</span>
                              </div>
                              <Progress value={doc.progress} className="h-2" />
                            </div>
                          ) : (
                            <div>
                              <Input
                                type="file"
                                accept=".pdf,.jpg,.jpeg,.png"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    handleFileUpload(doc.id, file);
                                  }
                                }}
                                className="cursor-pointer file:cursor-pointer file:border-0 file:bg-blue-50 file:text-blue-700 file:font-medium file:rounded-md file:px-4 file:py-2 file:mr-4"
                              />
                              {doc.error && (
                                <div className="flex items-center gap-1 mt-2 text-red-600">
                                  <XCircle className="h-3 w-3" />
                                  <span className="text-xs">{doc.error}</span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Submit Button */}
                  <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Shield className="h-4 w-4" />
                      Your documents are encrypted and secure
                    </div>
                    
                    <Button
                      onClick={handleSubmit}
                      disabled={!allRequiredUploaded || isSubmitting}
                      className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium px-6 py-2 disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Upload className="h-4 w-4 mr-2" />
                          Submit for Review
                        </>
                      )}
                    </Button>
                  </div>

                  {/* Help Text */}
                  <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm text-blue-800">
                        <p className="font-medium mb-1">Important Guidelines:</p>
                        <ul className="text-xs space-y-1 text-blue-700">
                          <li>• Ensure all documents are clear and readable</li>
                          <li>• Documents should be recent (within 6 months)</li>
                          <li>• File size should not exceed 2MB per document</li>
                          <li>• Review will be completed within 2-3 business days</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </Alert>
    </div>
  );
};