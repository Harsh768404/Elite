import React from 'react';
import { Clock, Package, Users, Shield, Eye, MoreVertical } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import { OrderStatus, ProductStatus } from './StatusIndicator';

interface DashboardTablesProps {
  orders: any[];
  products: any[];
  currentRole: 'vendor' | 'admin';
}

export function DashboardTables({ orders, products, currentRole }: DashboardTablesProps) {
  // Mock admin-specific data
  const vendors = [
    { id: 1, name: 'TechWorld Store', email: 'tech@example.com', status: 'active', orders: 245, revenue: '₹2,45,000', rating: 4.8 },
    { id: 2, name: 'Fashion Hub', email: 'fashion@example.com', status: 'pending', orders: 89, revenue: '₹89,000', rating: 4.6 },
    { id: 3, name: 'Home Essentials', email: 'home@example.com', status: 'active', orders: 156, revenue: '₹1,56,000', rating: 4.7 },
    { id: 4, name: 'Sports Central', email: 'sports@example.com', status: 'suspended', orders: 67, revenue: '₹67,000', rating: 4.2 },
    { id: 5, name: 'Book Paradise', email: 'books@example.com', status: 'active', orders: 123, revenue: '₹1,23,000', rating: 4.9 }
  ];

  const kycApplications = [
    { id: 1, vendor: 'New Electronics Store', submitted: '2024-01-15', status: 'pending', documents: 5 },
    { id: 2, vendor: 'Fashion Forward', submitted: '2024-01-14', status: 'approved', documents: 5 },
    { id: 3, vendor: 'Home Decor Plus', submitted: '2024-01-13', status: 'rejected', documents: 4 },
    { id: 4, vendor: 'Sports Gear Pro', submitted: '2024-01-12', status: 'pending', documents: 5 },
    { id: 5, vendor: 'Digital World', submitted: '2024-01-11', status: 'under_review', documents: 5 }
  ];

  const VendorStatusBadge = ({ status }) => {
    const colors = {
      active: 'bg-green-100 text-green-700',
      pending: 'bg-yellow-100 text-yellow-700',
      suspended: 'bg-red-100 text-red-700'
    };
    return <Badge className={colors[status]}>{status}</Badge>;
  };

  const KYCStatusBadge = ({ status }) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-700',
      approved: 'bg-green-100 text-green-700',
      rejected: 'bg-red-100 text-red-700',
      under_review: 'bg-blue-100 text-blue-700'
    };
    const labels = {
      pending: 'Pending',
      approved: 'Approved',
      rejected: 'Rejected',
      under_review: 'Under Review'
    };
    return <Badge className={colors[status]}>{labels[status]}</Badge>;
  };

  if (currentRole === 'admin') {
    return (
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        
        {/* Vendor Management */}
        <Card className="bg-white dark:bg-gray-900 border-0 shadow-lg">
          <CardHeader className="border-b border-gray-100 dark:border-gray-800">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-lg font-bold">
                <Users className="h-5 w-5 text-blue-600" />
                Vendor Management
              </CardTitle>
              <Button variant="ghost" size="sm">View All</Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-100 dark:border-gray-800">
                    <TableHead className="font-semibold">Vendor</TableHead>
                    <TableHead className="font-semibold">Status</TableHead>
                    <TableHead className="font-semibold">Orders</TableHead>
                    <TableHead className="font-semibold">Revenue</TableHead>
                    <TableHead className="font-semibold">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vendors.slice(0, 5).map((vendor) => (
                    <TableRow key={vendor.id} className="border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback>{vendor.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{vendor.name}</div>
                            <div className="text-xs text-gray-500">{vendor.email}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <VendorStatusBadge status={vendor.status} />
                      </TableCell>
                      <TableCell className="font-medium">{vendor.orders}</TableCell>
                      <TableCell className="font-semibold">{vendor.revenue}</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem>View Details</DropdownMenuItem>
                            <DropdownMenuItem>Edit Vendor</DropdownMenuItem>
                            <DropdownMenuItem>View Orders</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* KYC Management */}
        <Card className="bg-white dark:bg-gray-900 border-0 shadow-lg">
          <CardHeader className="border-b border-gray-100 dark:border-gray-800">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-lg font-bold">
                <Shield className="h-5 w-5 text-purple-600" />
                KYC Applications
              </CardTitle>
              <Button variant="ghost" size="sm">View All</Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-100 dark:border-gray-800">
                    <TableHead className="font-semibold">Vendor</TableHead>
                    <TableHead className="font-semibold">Submitted</TableHead>
                    <TableHead className="font-semibold">Status</TableHead>
                    <TableHead className="font-semibold">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {kycApplications.slice(0, 5).map((application) => (
                    <TableRow key={application.id} className="border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800">
                      <TableCell>
                        <div>
                          <div className="font-medium">{application.vendor}</div>
                          <div className="text-xs text-gray-500">{application.documents}/5 documents</div>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">{application.submitted}</TableCell>
                      <TableCell>
                        <KYCStatusBadge status={application.status} />
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem>Review Documents</DropdownMenuItem>
                            <DropdownMenuItem>Approve KYC</DropdownMenuItem>
                            <DropdownMenuItem>Request Changes</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Vendor dashboard tables
  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
      
      {/* Recent Orders */}
      <Card className="bg-white dark:bg-gray-900 border-0 shadow-lg">
        <CardHeader className="border-b border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-lg font-bold">
              <Clock className="h-5 w-5 text-blue-600" />
              Recent Orders
            </CardTitle>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-100 dark:border-gray-800">
                  <TableHead className="font-semibold">Order</TableHead>
                  <TableHead className="font-semibold">Customer</TableHead>
                  <TableHead className="font-semibold">Status</TableHead>
                  <TableHead className="font-semibold">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.slice(0, 5).map((order) => (
                  <TableRow key={order.id} className="border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800">
                    <TableCell className="font-medium">#{order.id}</TableCell>
                    <TableCell>{order.customer}</TableCell>
                    <TableCell>
                      <OrderStatus status={order.status} />
                    </TableCell>
                    <TableCell className="font-semibold">{order.total}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Top Products */}
      <Card className="bg-white dark:bg-gray-900 border-0 shadow-lg">
        <CardHeader className="border-b border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-lg font-bold">
              <Package className="h-5 w-5 text-green-600" />
              Top Products
            </CardTitle>
            <Button variant="ghost" size="sm">Manage</Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-100 dark:border-gray-800">
                  <TableHead className="font-semibold">Product</TableHead>
                  <TableHead className="font-semibold">Stock</TableHead>
                  <TableHead className="font-semibold">Status</TableHead>
                  <TableHead className="font-semibold">Price</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.slice(0, 5).map((product) => (
                  <TableRow key={product.id} className="border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800">
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell>
                      <span className={`font-medium ${product.stock > 10 ? 'text-green-600' : product.stock > 0 ? 'text-yellow-600' : 'text-red-600'}`}>
                        {product.stock}
                      </span>
                    </TableCell>
                    <TableCell>
                      <ProductStatus status={product.status} stock={product.stock} />
                    </TableCell>
                    <TableCell className="font-semibold">{product.price}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}