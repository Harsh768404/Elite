import React, { useState } from 'react';
import { 
  Store, Key, Link, Webhook, CheckCircle, AlertCircle, 
  Globe, Shield, Zap, Database, ExternalLink, Copy,
  ChevronDown, ChevronRight, Settings, User, Lock,
  AlertTriangle, Eye, EyeOff, RefreshCw, Activity,
  FileCheck, Users, Package, ShoppingCart
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Progress } from './ui/progress';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';

interface AddStoreFormProps {
  onStoreAdded: () => void;
}

interface ValidationStep {
  id: string;
  name: string;
  status: 'pending' | 'running' | 'success' | 'error';
  message?: string;
  details?: any;
}

export const AddStoreForm: React.FC<AddStoreFormProps> = ({ onStoreAdded }) => {
  const [formData, setFormData] = useState({
    storeName: '',
    storeUrl: '',
    consumerKey: '',
    consumerSecret: '',
    adminUsername: '',
    adminPassword: '',
    jwtAuthUrl: '/wp-json/jwt-auth/v1/token',
    webhookBaseUrl: 'https://eliteq.in/api/webhook/woocommerce'
  });

  const [webhookEvents] = useState({
    'order.created': true,
    'order.updated': true,
    'order.deleted': false,
    'product.created': true,
    'product.updated': true,
    'product.deleted': false,
    'customer.created': true,
    'customer.updated': false,
    'customer.deleted': false,
    'dokan.vendor.updated': true
  });

  const [validationSteps, setValidationSteps] = useState<ValidationStep[]>([
    { id: 'jwt', name: 'Admin Credentials Validation', status: 'pending' },
    { id: 'api', name: 'WooCommerce API Connection', status: 'pending' },
    { id: 'webhooks', name: 'Webhook Registration', status: 'pending' },
    { id: 'sync', name: 'Initial Data Synchronization', status: 'pending' },
    { id: 'status', name: 'Store Status Configuration', status: 'pending' }
  ]);

  const [isValidating, setIsValidating] = useState(false);
  const [validationProgress, setValidationProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);
  const [syncData, setSyncData] = useState<any>(null);

  const handleInputChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [field]: e.target.value
    }));

    // Auto-populate JWT URL when store URL changes
    if (field === 'storeUrl') {
      const url = e.target.value;
      if (url && !formData.jwtAuthUrl.includes(url)) {
        setFormData(prev => ({
          ...prev,
          jwtAuthUrl: `${url.replace(/\/$/, '')}/wp-json/jwt-auth/v1/token`
        }));
      }
    }
  };

  const updateValidationStep = (stepId: string, status: ValidationStep['status'], message?: string, details?: any) => {
    setValidationSteps(prev => prev.map(step => 
      step.id === stepId ? { ...step, status, message, details } : step
    ));
  };

  const validateAdminCredentials = async (): Promise<boolean> => {
    updateValidationStep('jwt', 'running', 'Validating admin credentials...');
    
    try {
      // Simulate JWT authentication
      const response = await fetch(formData.jwtAuthUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: formData.adminUsername,
          password: formData.adminPassword
        })
      });

      // Simulate admin-only validation
      if (formData.adminUsername.toLowerCase().includes('vendor') || 
          formData.adminUsername.toLowerCase().includes('seller')) {
        updateValidationStep('jwt', 'error', 
          'Access Denied — Only Admin Credentials Are Allowed', 
          { error: 'Vendor-level credentials detected' });
        return false;
      }

      // Simulate successful admin validation
      const mockSuccess = Math.random() > 0.3;
      if (mockSuccess) {
        updateValidationStep('jwt', 'success', 
          'Admin credentials validated successfully', 
          { token: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...', role: 'administrator' });
        return true;
      } else {
        updateValidationStep('jwt', 'error', 
          'Invalid admin credentials', 
          { error: 'Authentication failed' });
        return false;
      }
    } catch (error) {
      updateValidationStep('jwt', 'error', 
        'Connection failed to JWT endpoint', 
        { error: error.message });
      return false;
    }
  };

  const testWooCommerceAPI = async (): Promise<boolean> => {
    updateValidationStep('api', 'running', 'Testing WooCommerce API connection...');
    
    try {
      // Simulate API testing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockSuccess = Math.random() > 0.2;
      if (mockSuccess) {
        updateValidationStep('api', 'success', 
          'WooCommerce API connection successful', 
          { 
            version: 'v3',
            products: 156,
            orders: 1247,
            customers: 89
          });
        return true;
      } else {
        updateValidationStep('api', 'error', 
          'API authentication failed', 
          { error: 'Invalid consumer key or secret' });
        return false;
      }
    } catch (error) {
      updateValidationStep('api', 'error', 
        'API connection failed', 
        { error: error.message });
      return false;
    }
  };

  const registerWebhooks = async (): Promise<boolean> => {
    updateValidationStep('webhooks', 'running', 'Registering webhook endpoints...');
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const enabledEvents = Object.entries(webhookEvents)
        .filter(([_, enabled]) => enabled)
        .map(([event, _]) => event);

      const mockSuccess = Math.random() > 0.4;
      if (mockSuccess) {
        updateValidationStep('webhooks', 'success', 
          `Successfully registered ${enabledEvents.length} webhook events`, 
          { 
            registered: enabledEvents,
            endpoint: formData.webhookBaseUrl,
            secret: 'wh_' + Math.random().toString(36).substr(2, 16)
          });
        return true;
      } else {
        updateValidationStep('webhooks', 'error', 
          'Webhook registration failed', 
          { error: 'Unable to create webhook endpoints' });
        return false;
      }
    } catch (error) {
      updateValidationStep('webhooks', 'error', 
        'Webhook setup failed', 
        { error: error.message });
      return false;
    }
  };

  const syncInitialData = async (): Promise<boolean> => {
    updateValidationStep('sync', 'running', 'Synchronizing initial data...');
    
    try {
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      const mockData = {
        products: {
          total: 156,
          recent: [
            { id: 1, name: 'Premium Widget', status: 'publish', price: 299.99 },
            { id: 2, name: 'Advanced Tool', status: 'draft', price: 199.99 },
            { id: 3, name: 'Basic Package', status: 'publish', price: 99.99 }
          ]
        },
        orders: {
          total: 1247,
          recent: [
            { id: 1001, status: 'processing', total: 599.98, customer: 'John Doe' },
            { id: 1002, status: 'completed', total: 299.99, customer: 'Jane Smith' }
          ]
        },
        vendors: {
          total: 23,
          pending_kyc: 5,
          approved: 18
        },
        categories: ['Electronics', 'Clothing', 'Home & Garden', 'Sports'],
        dokan_data: {
          kyc_enabled: true,
          commission_rate: '15%',
          withdrawal_methods: ['PayPal', 'Bank Transfer']
        }
      };

      setSyncData(mockData);
      updateValidationStep('sync', 'success', 
        'Initial data synchronization completed', 
        mockData);
      return true;
    } catch (error) {
      updateValidationStep('sync', 'error', 
        'Data synchronization failed', 
        { error: error.message });
      return false;
    }
  };

  const setStoreStatus = async (): Promise<boolean> => {
    updateValidationStep('status', 'running', 'Configuring store status...');
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if all previous steps were successful
      const previousSteps = validationSteps.slice(0, 4);
      const allSuccessful = previousSteps.every(step => step.status === 'success');
      
      if (allSuccessful) {
        updateValidationStep('status', 'success', 
          'Store successfully connected and configured', 
          { 
            status: 'connected',
            health_score: 95,
            last_sync: new Date().toISOString(),
            features: ['Orders', 'Products', 'Webhooks', 'Dokan KYC']
          });
        return true;
      } else {
        updateValidationStep('status', 'error', 
          'Store connection incomplete due to previous failures', 
          { status: 'failed' });
        return false;
      }
    } catch (error) {
      updateValidationStep('status', 'error', 
        'Status configuration failed', 
        { error: error.message });
      return false;
    }
  };

  const runValidation = async () => {
    setIsValidating(true);
    setValidationProgress(0);
    setCurrentStep(0);

    const steps = [
      validateAdminCredentials,
      testWooCommerceAPI,
      registerWebhooks,
      syncInitialData,
      setStoreStatus
    ];

    for (let i = 0; i < steps.length; i++) {
      setCurrentStep(i);
      setValidationProgress((i / steps.length) * 100);
      
      const success = await steps[i]();
      
      if (!success && i < 2) { // Stop on critical failures (JWT or API)
        setIsValidating(false);
        return;
      }
    }

    setValidationProgress(100);
    setIsValidating(false);

    // Check if all steps were successful
    const allSuccessful = validationSteps.every(step => step.status === 'success');
    if (allSuccessful) {
      setTimeout(() => {
        onStoreAdded();
      }, 2000);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await runValidation();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const getStepIcon = (step: ValidationStep) => {
    switch (step.status) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-red-600" />;
      case 'running':
        return <RefreshCw className="h-5 w-5 text-blue-600 animate-spin" />;
      default:
        return <div className="h-5 w-5 rounded-full border-2 border-gray-300" />;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Security Warning */}
      <Alert className="border-orange-200 bg-orange-50 dark:bg-orange-900/20 dark:border-orange-800">
        <AlertTriangle className="h-4 w-4 text-orange-600" />
        <AlertDescription className="text-orange-800 dark:text-orange-200">
          <div className="space-y-2">
            <div className="font-semibold">⚠️ Admin-Only Access Required</div>
            <div className="text-sm">
              Please enter correct <strong>WordPress Admin Credentials</strong> only. 
              Vendor or editor-level accounts will not be accepted. 
              All actions are logged and strictly verified.
            </div>
          </div>
        </AlertDescription>
      </Alert>

      {/* Validation Progress */}
      {isValidating && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-blue-600" />
              Store Integration Progress
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Overall Progress</span>
                <span>{Math.round(validationProgress)}%</span>
              </div>
              <Progress value={validationProgress} className="h-2" />
            </div>
            
            <div className="space-y-3">
              {validationSteps.map((step, index) => (
                <div key={step.id} className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                  index === currentStep ? 'bg-blue-50 dark:bg-blue-900/20' : 'bg-gray-50 dark:bg-gray-800'
                }`}>
                  {getStepIcon(step)}
                  <div className="flex-1">
                    <div className="font-medium text-sm">{step.name}</div>
                    {step.message && (
                      <div className={`text-xs mt-1 ${
                        step.status === 'error' ? 'text-red-600' : 
                        step.status === 'success' ? 'text-green-600' : 
                        'text-gray-600'
                      }`}>
                        {step.message}
                      </div>
                    )}
                  </div>
                  {step.status === 'success' && step.details && (
                    <Button variant="ghost" size="sm" onClick={() => console.log(step.details)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Sync Results */}
      {syncData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5 text-green-600" />
              Synchronized Data Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <Package className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-blue-600">{syncData.products?.total}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Products</div>
              </div>
              <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <ShoppingCart className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-green-600">{syncData.orders?.total}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Orders</div>
              </div>
              <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                <Users className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-purple-600">{syncData.vendors?.total}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Vendors</div>
              </div>
              <div className="text-center p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <FileCheck className="h-8 w-8 text-orange-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-orange-600">{syncData.vendors?.pending_kyc}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Pending KYC</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Store Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Store className="h-5 w-5 text-blue-600" />
              Store Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="storeName">Store Name *</Label>
                <Input
                  id="storeName"
                  placeholder="e.g., My WooCommerce Store"
                  value={formData.storeName}
                  onChange={handleInputChange('storeName')}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="storeUrl">Store URL *</Label>
                <div className="relative">
                  <Globe className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="storeUrl"
                    placeholder="https://yourstore.com"
                    value={formData.storeUrl}
                    onChange={handleInputChange('storeUrl')}
                    className="pl-10"
                    pattern="https://.*"
                    title="Must be HTTPS URL"
                    required
                  />
                </div>
                <p className="text-xs text-gray-500">Must be HTTPS for security</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* WooCommerce API Credentials */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Key className="h-5 w-5 text-green-600" />
              WooCommerce REST API Credentials
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="consumerKey">Consumer Key *</Label>
                <div className="relative">
                  <Input
                    id="consumerKey"
                    placeholder="ck_xxxxxxxxxxxxxxxx"
                    value={formData.consumerKey}
                    onChange={handleInputChange('consumerKey')}
                    type="password"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    onClick={() => copyToClipboard(formData.consumerKey)}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500">From WooCommerce REST API (Admin Generated)</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="consumerSecret">Consumer Secret *</Label>
                <div className="relative">
                  <Input
                    id="consumerSecret"
                    placeholder="cs_xxxxxxxxxxxxxxxx"
                    value={formData.consumerSecret}
                    onChange={handleInputChange('consumerSecret')}
                    type="password"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    onClick={() => copyToClipboard(formData.consumerSecret)}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500">From WooCommerce REST API (Admin Generated)</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* WordPress Admin Credentials */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-red-600" />
              WordPress Admin Credentials
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-800">
              <Lock className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800 dark:text-red-200">
                <strong>Admin Only:</strong> Only WordPress administrator username and password are accepted. 
                Vendor or editor credentials will be rejected.
              </AlertDescription>
            </Alert>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="adminUsername">Admin Username *</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="adminUsername"
                    placeholder="WordPress admin username"
                    value={formData.adminUsername}
                    onChange={handleInputChange('adminUsername')}
                    className="pl-10"
                    required
                  />
                </div>
                <p className="text-xs text-gray-500">Only allow WordPress admin username</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="adminPassword">Admin Password *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="adminPassword"
                    placeholder="WordPress admin password"
                    value={formData.adminPassword}
                    onChange={handleInputChange('adminPassword')}
                    type={showPassword ? 'text' : 'password'}
                    className="pl-10 pr-10"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="text-xs text-gray-500">Must not accept vendor-level credentials</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="jwtAuthUrl">JWT Auth URL *</Label>
              <div className="relative">
                <Link className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="jwtAuthUrl"
                  value={formData.jwtAuthUrl}
                  onChange={handleInputChange('jwtAuthUrl')}
                  className="pl-10"
                  required
                />
              </div>
              <p className="text-xs text-gray-500">Must be /wp-json/jwt-auth/v1/token</p>
            </div>
          </CardContent>
        </Card>

        {/* Webhook Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Webhook className="h-5 w-5 text-orange-600" />
              Webhook Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="webhookBaseUrl">Webhook Base URL *</Label>
              <div className="relative">
                <Database className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="webhookBaseUrl"
                  value={formData.webhookBaseUrl}
                  onChange={handleInputChange('webhookBaseUrl')}
                  className="pl-10"
                  required
                  readOnly
                />
              </div>
              <p className="text-xs text-gray-500">EliteQ backend URL (for webhook events)</p>
            </div>

            <div className="space-y-4">
              <Label>Webhook Events to Register</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {Object.entries(webhookEvents).map(([event, enabled]) => (
                  <div key={event} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Checkbox checked={enabled} disabled />
                      <div>
                        <div className="font-medium text-sm">{event}</div>
                        <div className="text-xs text-gray-500">
                          {event === 'dokan.vendor.updated' && '(Custom Dokan Event)'}
                        </div>
                      </div>
                    </div>
                    <Badge variant={enabled ? 'default' : 'secondary'}>
                      {enabled ? 'Enabled' : 'Disabled'}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Submit Button */}
        <div className="flex justify-end space-x-4">
          <Button type="button" variant="outline" disabled={isValidating}>
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={isValidating || !formData.storeName || !formData.storeUrl || !formData.adminUsername}
            className="bg-blue-600 hover:bg-blue-700 text-white min-w-[160px]"
          >
            {isValidating ? (
              <div className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4 animate-spin" />
                Integrating...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                Connect Store
              </div>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};