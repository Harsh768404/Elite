import React from 'react';
import { AlertTriangle, RefreshCw, Wifi, WifiOff, Server } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface EliteQErrorFallbackProps {
  errorType: 'api_failure' | 'no_data' | 'server_timeout' | 'payment_gateway' | 'network_error';
  title?: string;
  message?: string;
  onRetry?: () => void;
  showDetails?: boolean;
}

export function EliteQErrorFallback({ 
  errorType, 
  title,
  message,
  onRetry,
  showDetails = false 
}: EliteQErrorFallbackProps) {
  const errorConfigs = {
    api_failure: {
      icon: Server,
      color: 'text-red-500',
      bgColor: 'from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20',
      defaultTitle: 'API Connection Failed',
      defaultMessage: 'Unable to connect to the EliteQ servers. Please check your connection and try again.',
      badge: 'API Error'
    },
    no_data: {
      icon: AlertTriangle,
      color: 'text-yellow-500',
      bgColor: 'from-yellow-50 to-yellow-100 dark:from-yellow-900/20 dark:to-yellow-800/20',
      defaultTitle: 'No Data Available',
      defaultMessage: 'No data found for the current filters or time period. Try adjusting your selection.',
      badge: 'No Data'
    },
    server_timeout: {
      icon: Server,
      color: 'text-orange-500',
      bgColor: 'from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20',
      defaultTitle: 'Server Timeout',
      defaultMessage: 'The server is taking longer than expected to respond. Please wait a moment and try again.',
      badge: 'Timeout'
    },
    payment_gateway: {
      icon: AlertTriangle,
      color: 'text-purple-500',
      bgColor: 'from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20',
      defaultTitle: 'Payment Gateway Issue',
      defaultMessage: 'There seems to be an issue with the payment gateway. Payment data may be delayed.',
      badge: 'Payment Issue'
    },
    network_error: {
      icon: WifiOff,
      color: 'text-red-500',
      bgColor: 'from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20',
      defaultTitle: 'Network Connection Lost',
      defaultMessage: 'Unable to establish a stable connection. Check your internet connection and try again.',
      badge: 'Network Error'
    }
  };

  const config = errorConfigs[errorType];
  const Icon = config.icon;
  const displayTitle = title || config.defaultTitle;
  const displayMessage = message || config.defaultMessage;

  return (
    <Card className={`p-8 text-center bg-gradient-to-br ${config.bgColor} border-2 border-dashed border-gray-300 dark:border-gray-600`}>
      <div className="max-w-md mx-auto">
        {/* Error Icon */}
        <div className="mb-4">
          <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-white dark:bg-gray-800 shadow-lg`}>
            <Icon className={`w-8 h-8 ${config.color}`} />
          </div>
        </div>

        {/* Error Badge */}
        <div className="mb-4">
          <Badge variant="outline" className={`${config.color} border-current`}>
            {config.badge}
          </Badge>
        </div>

        {/* Error Title */}
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
          {displayTitle}
        </h3>

        {/* Error Message */}
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
          {displayMessage}
        </p>

        {/* Action Buttons */}
        <div className="space-y-3">
          {onRetry && (
            <Button onClick={onRetry} className="w-full">
              <RefreshCw className="w-4 h-4 mr-2" />
              Try Again
            </Button>
          )}

          {/* Additional Help */}
          <div className="flex items-center justify-center space-x-4 text-xs text-gray-500 dark:text-gray-400">
            <button className="hover:text-gray-700 dark:hover:text-gray-300 transition-colors">
              Contact Support
            </button>
            <span>•</span>
            <button className="hover:text-gray-700 dark:hover:text-gray-300 transition-colors">
              Check Status
            </button>
          </div>
        </div>

        {/* Technical Details (if requested) */}
        {showDetails && (
          <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
            <details className="text-left">
              <summary className="text-xs text-gray-500 dark:text-gray-400 cursor-pointer hover:text-gray-700 dark:hover:text-gray-300">
                Technical Details
              </summary>
              <div className="mt-2 p-3 bg-gray-100 dark:bg-gray-800 rounded-lg text-xs font-mono text-gray-600 dark:text-gray-400">
                <div>Error Type: {errorType}</div>
                <div>Timestamp: {new Date().toISOString()}</div>
                <div>User Agent: {navigator.userAgent.substring(0, 50)}...</div>
              </div>
            </details>
          </div>
        )}
      </div>
    </Card>
  );
}

// Pre-configured error components for common scenarios
export const APIFailureError = ({ onRetry }: { onRetry?: () => void }) => (
  <EliteQErrorFallback 
    errorType="api_failure" 
    onRetry={onRetry}
  />
);

export const NoDataError = ({ message }: { message?: string }) => (
  <EliteQErrorFallback 
    errorType="no_data" 
    message={message}
  />
);

export const ServerTimeoutError = ({ onRetry }: { onRetry?: () => void }) => (
  <EliteQErrorFallback 
    errorType="server_timeout" 
    onRetry={onRetry}
  />
);

export const PaymentGatewayError = ({ onRetry }: { onRetry?: () => void }) => (
  <EliteQErrorFallback 
    errorType="payment_gateway" 
    onRetry={onRetry}
  />
);

export const NetworkError = ({ onRetry }: { onRetry?: () => void }) => (
  <EliteQErrorFallback 
    errorType="network_error" 
    onRetry={onRetry}
  />
);