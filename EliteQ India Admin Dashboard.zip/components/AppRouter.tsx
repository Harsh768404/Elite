import React, { useEffect, useState } from 'react';
import { useAuth, AuthLoadingScreen, AccessRestrictedScreen } from '../contexts/AuthContext';
import EliteQLoginPage from './EliteQLoginPage';
import AdminDashboard from '../pages/AdminDashboard';
import VendorDashboard from '../pages/VendorDashboard';
import AccountDashboard from '../pages/AccountDashboard';
import NotFoundPage from './NotFoundPage';

export const AppRouter: React.FC = () => {
  const { 
    isAuthenticated, 
    isLoading, 
    isInitializing, 
    user, 
    error, 
    hasAccess,
    isAdmin,
    isShopManager,
    isVendor
  } = useAuth();
  
  const [currentRoute, setCurrentRoute] = useState(window.location.pathname);
  const [routeLoading, setRouteLoading] = useState(false);

  // Listen for URL changes (browser navigation, programmatic navigation)
  useEffect(() => {
    const handleLocationChange = () => {
      const newPath = window.location.pathname;
      console.log('🧭 Route changed to:', newPath);
      setCurrentRoute(newPath);
    };

    // Listen for popstate events (browser back/forward)
    window.addEventListener('popstate', handleLocationChange);

    // Override pushState and replaceState to catch programmatic navigation
    const originalPushState = window.history.pushState;
    const originalReplaceState = window.history.replaceState;

    window.history.pushState = function(...args) {
      originalPushState.apply(window.history, args);
      handleLocationChange();
    };

    window.history.replaceState = function(...args) {
      originalReplaceState.apply(window.history, args);
      handleLocationChange();
    };

    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.history.pushState = originalPushState;
      window.history.replaceState = originalReplaceState;
    };
  }, []);

  // ENHANCED: Handle authentication-based routing with corrected logic
  useEffect(() => {
    if (!isInitializing && !isLoading && isAuthenticated && user && hasAccess) {
      console.log('🧭 ===== ENHANCED ROLE-BASED ROUTING - ADMIN FIX =====');
      console.log('👤 Authenticated User:', user.display_name);
      console.log('📧 Email:', user.email);
      console.log('🎭 Primary Role:', user.primary_role);
      console.log('🎯 All Roles:', user.roles);
      console.log('🔐 Has Access:', hasAccess);
      console.log('📍 Current Route:', currentRoute);
      console.log('📊 Computed Role Flags:');
      console.log('  🔺 isAdmin:', isAdmin);
      console.log('  🏢 isShopManager:', isShopManager);
      console.log('  🏪 isVendor:', isVendor);

      // CRITICAL ADMIN ROUTING VERIFICATION
      if (user.roles.includes('administrator')) {
        console.log('👑 ===== ADMINISTRATOR ROUTING VERIFICATION =====');
        console.log('✅ Administrator role found in roles array');
        console.log('🎭 Primary role check:', user.primary_role === 'administrator' ? '✅ CORRECT' : '❌ CRITICAL ERROR');
        console.log('🧭 Expected route: /admin-dashboard');
        console.log('🔺 isAdmin flag:', isAdmin ? '✅ CORRECT' : '❌ CRITICAL ERROR');
        
        if (user.primary_role !== 'administrator' || !isAdmin) {
          console.error('🚨 CRITICAL ROUTING ERROR: Admin user has wrong classification!');
          console.error('🚨 This will cause admin to be treated as vendor!');
          console.error('🚨 Expected primary_role: administrator, Got:', user.primary_role);
          console.error('🚨 Expected isAdmin: true, Got:', isAdmin);
        }
      }

      // SHOP MANAGER ROUTING VERIFICATION
      if (user.roles.includes('shop_manager')) {
        console.log('🏢 ===== SHOP MANAGER ROUTING VERIFICATION =====');
        console.log('✅ Shop Manager role found in roles array');
        console.log('🎭 Primary role check:', user.primary_role === 'shop_manager' ? '✅ CORRECT' : '❌ CRITICAL ERROR');
        console.log('🧭 Expected route: /admin-dashboard');
        console.log('🏢 isShopManager flag:', isShopManager ? '✅ CORRECT' : '❌ CRITICAL ERROR');
      }

      // VENDOR ROUTING VERIFICATION
      if (user.roles.includes('seller')) {
        console.log('🏪 ===== VENDOR/SELLER ROUTING VERIFICATION =====');
        console.log('✅ Seller role found in roles array');
        console.log('🎭 Primary role check:', user.primary_role === 'vendor' ? '✅ CORRECT' : '❌ ERROR');
        console.log('🧭 Expected route: /vendor-dashboard');
        console.log('🏪 isVendor flag:', isVendor ? '✅ CORRECT' : '❌ ERROR');
      }

      const normalizedRoute = normalizeRoute(currentRoute);
      const expectedRoute = getExpectedRoute(user.primary_role, user.roles);

      console.log('🧭 Enhanced Route Calculation:');
      console.log('  📍 Original Route:', currentRoute);
      console.log('  📍 Normalized Route:', normalizedRoute);
      console.log('  🎯 Expected Route (corrected logic):', expectedRoute);

      // CRITICAL: Never let admin users access vendor dashboard
      if ((isAdmin || isShopManager) && normalizedRoute === '/vendor-dashboard') {
        console.error('🚨 EMERGENCY INTERVENTION: Admin/Shop Manager on vendor dashboard!');
        console.error('🚨 Forcing immediate redirect to admin dashboard');
        navigateToRoute('/admin-dashboard');
        return;
      }

      // If user is on login page or root, redirect to their dashboard
      if (currentRoute === '/' || currentRoute === '/login') {
        console.log('🔀 LOGIN REDIRECT: Redirecting from login to dashboard:', expectedRoute);
        
        // ADMIN REDIRECT VERIFICATION
        if ((isAdmin || isShopManager) && expectedRoute !== '/admin-dashboard') {
          console.error('🚨 ADMIN REDIRECT ERROR: Admin user not being redirected to admin dashboard!');
          console.error('🚨 Expected: /admin-dashboard, Got:', expectedRoute);
          console.error('🚨 Forcing admin dashboard redirect');
          navigateToRoute('/admin-dashboard');
          return;
        }
        
        navigateToRoute(expectedRoute);
        return;
      }

      // Check if user is on a valid route for their role
      const isValidRoute = isRouteValidForRole(normalizedRoute, user.primary_role, user.roles);
      
      console.log('🔍 Enhanced Route Validation:');
      console.log('  📍 Current normalized route:', normalizedRoute);
      console.log('  🎭 User primary role:', user.primary_role);
      console.log('  🎯 User roles array:', user.roles);
      console.log('  ✅ Is route valid for role:', isValidRoute);
      
      if (!isValidRoute) {
        console.log('🔀 INVALID ROUTE: Redirecting to correct dashboard:', expectedRoute);
        
        // ADMIN REDIRECT VERIFICATION
        if ((isAdmin || isShopManager) && expectedRoute !== '/admin-dashboard') {
          console.error('🚨 ADMIN REDIRECT ERROR: Admin user not being redirected to admin dashboard!');
          console.error('🚨 Expected: /admin-dashboard, Got:', expectedRoute);
          console.error('🚨 Forcing admin dashboard redirect');
          navigateToRoute('/admin-dashboard');
          return;
        }
        
        navigateToRoute(expectedRoute);
      } else {
        console.log('✅ ROUTE VALID: User is on correct dashboard for their role');
      }
    }
  }, [isInitializing, isLoading, isAuthenticated, user, hasAccess, currentRoute, isAdmin, isShopManager, isVendor]);

  // Update document title based on current route
  useEffect(() => {
    const title = getPageTitle(currentRoute, user?.primary_role);
    document.title = title;
  }, [currentRoute, user]);

  // Show loading screen during initialization
  if (isInitializing) {
    return <AuthLoadingScreen />;
  }

  // Show loading screen during login process or route changes
  if (isLoading || routeLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-blue-900/20 dark:to-indigo-900/30 flex items-center justify-center">
        <div className="text-center space-y-6">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-blue-200 dark:border-blue-800 rounded-full animate-spin">
              <div className="absolute top-0 left-0 w-full h-full border-4 border-transparent border-t-blue-600 rounded-full animate-spin"></div>
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h2 className="text-2xl font-semibold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
              {routeLoading ? 'Navigating to Dashboard' : 'Loading Dashboard'}
            </h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-md">
              {routeLoading 
                ? 'Taking you to the right place...' 
                : isLoading 
                ? 'Verifying your WordPress credentials...'
                : 'Loading your dashboard...'
              }
            </p>
            
            {user && (
              <div className="flex items-center justify-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span>Welcome back, {user.display_name}</span>
                <div className="w-1 h-1 bg-blue-500 rounded-full"></div>
                <span className="capitalize">{user.primary_role}</span>
              </div>
            )}
          </div>

          <div className="text-center space-y-2">
            <div className="text-lg font-bold bg-gradient-to-r from-blue-800 to-blue-600 bg-clip-text text-transparent">
              EliteQ<span className="text-orange-500">India</span>
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">
              WordPress Electronics Marketplace - Fixed Admin Routing
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Show authentication error screen
  if (error && !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 dark:from-gray-900 dark:to-red-900/20 flex items-center justify-center p-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.232 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
            WordPress Connection Error
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {error}
          </p>
          <div className="text-sm text-gray-500 mb-6">
            We couldn't verify your access level. Please try again or contact support.
          </div>
          <button 
            onClick={() => window.location.reload()}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  // Show login page if not authenticated
  if (!isAuthenticated || !user) {
    return <EliteQLoginPage />;
  }

  // Show access restricted screen if user doesn't have required permissions
  if (!hasAccess || user.primary_role === 'restricted') {
    console.log('🚨 ===== ACCESS RESTRICTED SCREEN TRIGGERED =====');
    console.log('🔐 hasAccess:', hasAccess);
    console.log('🎭 user.primary_role:', user.primary_role);
    console.log('👤 user.display_name:', user.display_name);
    console.log('📧 user.email:', user.email);
    console.log('🎯 user.roles:', user.roles);
    console.log('⚠️ This should only show for restricted users, not valid access roles!');
    return <AccessRestrictedScreen user={user} />;
  }

  // ENHANCED EMERGENCY ADMIN PROTECTION: Never let admin users see vendor dashboard
  if (user && (isAdmin || isShopManager || user.roles.includes('administrator') || user.roles.includes('shop_manager'))) {
    const normalizedRoute = normalizeRoute(currentRoute);
    if (normalizedRoute === '/vendor-dashboard') {
      console.error('🚨 EMERGENCY OVERRIDE: Admin/Shop Manager user on vendor dashboard - redirecting to admin dashboard!');
      navigateToRoute('/admin-dashboard');
      return null;
    }
  }

  // Render appropriate component based on current route
  return renderRouteComponent(currentRoute, user);

  // ENHANCED Helper functions with corrected logic
  function normalizeRoute(route: string): string {
    // Remove trailing slash and convert to lowercase
    const normalized = route.replace(/\/$/, '').toLowerCase();
    
    // Handle route aliases
    const routeAliases: { [key: string]: string } = {
      '/admin': '/admin-dashboard',
      '/administrator': '/admin-dashboard',
      '/vendor': '/vendor-dashboard',
      '/seller': '/vendor-dashboard',
      '/shop-manager': '/admin-dashboard', // CRITICAL: Shop managers get admin dashboard
      '/dashboard': '/account-dashboard'
    };

    return routeAliases[normalized] || normalized;
  }

  function getExpectedRoute(primaryRole: string, userRoles: string[]): string {
    console.log('🧭 Getting expected route for primary role:', primaryRole);
    console.log('🎯 User roles array:', userRoles);
    
    // CRITICAL: Double-check for admin roles to prevent misrouting
    if (userRoles.includes('administrator') || primaryRole === 'administrator') {
      console.log('✅ Administrator detected → /admin-dashboard');
      return '/admin-dashboard';
    }
    
    if (userRoles.includes('shop_manager') || primaryRole === 'shop_manager') {
      console.log('✅ Shop Manager detected → /admin-dashboard');
      return '/admin-dashboard';
    }
    
    switch (primaryRole) {
      case 'administrator':
        console.log('✅ Administrator role → /admin-dashboard');
        return '/admin-dashboard';
      case 'shop_manager':
        console.log('✅ Shop Manager role → /admin-dashboard');
        return '/admin-dashboard';
      case 'vendor':
        console.log('✅ Vendor role → /vendor-dashboard');
        return '/vendor-dashboard';
      default:
        console.log('⚠️ Unknown/restricted role → /account-dashboard');
        return '/account-dashboard';
    }
  }

  function isRouteValidForRole(route: string, primaryRole: string, userRoles: string[]): boolean {
    console.log('🔍 Checking route validity:', route, 'for role:', primaryRole);
    
    // CRITICAL: Admin/Shop Manager users can NEVER access vendor dashboard
    if ((userRoles.includes('administrator') || userRoles.includes('shop_manager') || 
         primaryRole === 'administrator' || primaryRole === 'shop_manager') && 
        route === '/vendor-dashboard') {
      console.log('🚨 CRITICAL: Admin/Shop Manager attempting to access vendor dashboard - INVALID');
      return false;
    }
    
    const validRoutes: { [key: string]: string[] } = {
      'administrator': ['/admin-dashboard', '/account-dashboard'],
      'shop_manager': ['/admin-dashboard', '/account-dashboard'],
      'vendor': ['/vendor-dashboard', '/account-dashboard'],
      'restricted': []
    };

    return validRoutes[primaryRole]?.includes(route) || false;
  }

  function navigateToRoute(route: string): void {
    if (window.location.pathname !== route) {
      console.log('🧭 Navigating to route:', route);
      setRouteLoading(true);
      window.history.pushState({}, '', route);
      setCurrentRoute(route);
      setTimeout(() => setRouteLoading(false), 300);
    }
  }

  function getPageTitle(route: string, userRole?: string): string {
    const titles: { [key: string]: string } = {
      '/admin-dashboard': 'EliteQ India - Admin Dashboard',
      '/vendor-dashboard': 'EliteQ India - Vendor Dashboard',
      '/account-dashboard': 'EliteQ India - Account Dashboard',
      '/': 'EliteQ India - WordPress Login'
    };

    return titles[route] || 'EliteQ India - WordPress Electronics Marketplace';
  }

  function renderRouteComponent(route: string, user: any): React.ReactNode {
    const normalizedRoute = normalizeRoute(route);
    
    console.log('🎨 ===== RENDERING ROUTE COMPONENT WITH ENHANCED CHECKS =====');
    console.log('📍 Original Route:', route);
    console.log('📍 Normalized Route:', normalizedRoute);
    console.log('👤 User Role:', user.primary_role);
    console.log('🎯 User Roles:', user.roles);
    console.log('🔐 Has Access:', hasAccess);
    console.log('🔺 isAdmin:', isAdmin);
    console.log('🏢 isShopManager:', isShopManager);
    console.log('🏪 isVendor:', isVendor);

    switch (normalizedRoute) {
      case '/admin-dashboard':
        // ENHANCED: Check if user should have admin access
        if (!isAdmin && !isShopManager && 
            user.primary_role !== 'administrator' && user.primary_role !== 'shop_manager' &&
            !user.roles.includes('administrator') && !user.roles.includes('shop_manager')) {
          return (
            <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 dark:from-gray-900 dark:to-red-900/20 flex items-center justify-center p-4">
              <div className="text-center max-w-md">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.232 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                </div>
                <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
                  Admin Access Required
                </h2>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  You need WordPress administrator or shop manager privileges to access this area.
                </p>
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 mb-6 text-left">
                  <div className="text-sm space-y-1">
                    <div><strong>Your Primary Role:</strong> {user.primary_role}</div>
                    <div><strong>Your Roles:</strong> {user.roles.join(', ')}</div>
                    <div><strong>Required Roles:</strong> administrator, shop_manager</div>
                    <div><strong>Your Email:</strong> {user.email}</div>
                  </div>
                </div>
                <button 
                  onClick={() => navigateToRoute(getExpectedRoute(user.primary_role, user.roles))}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Go to Your Dashboard
                </button>
              </div>
            </div>
          );
        }
        console.log('✅ Rendering AdminDashboard for authorized user');
        return <AdminDashboard />;

      case '/vendor-dashboard':
        // CRITICAL: Ensure admin/shop_manager users NEVER see vendor dashboard
        if (isAdmin || isShopManager || 
            user.roles.includes('administrator') || user.roles.includes('shop_manager')) {
          console.error('🚨 CRITICAL: Admin/Shop Manager user attempting to access vendor dashboard!');
          console.error('🚨 Redirecting to admin dashboard immediately');
          navigateToRoute('/admin-dashboard');
          return null;
        }
        
        if (!isVendor && user.primary_role !== 'vendor') {
          return (
            <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 dark:from-gray-900 dark:to-red-900/20 flex items-center justify-center p-4">
              <div className="text-center max-w-md">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.232 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                </div>
                <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
                  Vendor Access Required
                </h2>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  You need WordPress vendor privileges to access this area.
                </p>
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 mb-6 text-left">
                  <div className="text-sm space-y-1">
                    <div><strong>Your Primary Role:</strong> {user.primary_role}</div>
                    <div><strong>Your Roles:</strong> {user.roles.join(', ')}</div>
                    <div><strong>Required Roles:</strong> vendor, seller</div>
                    <div><strong>Your Email:</strong> {user.email}</div>
                  </div>
                </div>
                <button 
                  onClick={() => navigateToRoute(getExpectedRoute(user.primary_role, user.roles))}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Go to Your Dashboard
                </button>
              </div>
            </div>
          );
        }
        console.log('✅ Rendering VendorDashboard for authorized vendor user');
        return <VendorDashboard />;

      case '/account-dashboard':
        console.log('✅ Rendering AccountDashboard');
        return <AccountDashboard />;

      case '':
      case '/':
        // Redirect authenticated users to their dashboard
        console.log('🔀 Root route - redirecting to user dashboard');
        navigateToRoute(getExpectedRoute(user.primary_role, user.roles));
        return null;

      default:
        console.log('🚫 Unknown route, showing 404');
        return <NotFoundPage currentRoute={route} user={user} />;
    }
  }
};

// Enhanced Router utilities with admin protection
export const RouterUtils = {
  navigateToUserDashboard: (userRole: string, userRoles: string[] = []) => {
    console.log('🧭 RouterUtils.navigateToUserDashboard:', userRole, userRoles);
    
    // CRITICAL: Check actual roles array for admin/shop_manager
    if (userRoles.includes('administrator') || userRole === 'administrator') {
      console.log('👑 Administrator detected - navigating to admin dashboard');
      window.history.pushState({}, '', '/admin-dashboard');
      window.dispatchEvent(new PopStateEvent('popstate'));
      return;
    }
    
    if (userRoles.includes('shop_manager') || userRole === 'shop_manager') {
      console.log('🏢 Shop Manager detected - navigating to admin dashboard');
      window.history.pushState({}, '', '/admin-dashboard');
      window.dispatchEvent(new PopStateEvent('popstate'));
      return;
    }
    
    const routes = {
      'administrator': '/admin-dashboard',
      'shop_manager': '/admin-dashboard',
      'vendor': '/vendor-dashboard',
      'default': '/account-dashboard'
    };
    
    const route = routes[userRole as keyof typeof routes] || routes.default;
    console.log('🧭 Navigating to:', route);
    window.history.pushState({}, '', route);
    window.dispatchEvent(new PopStateEvent('popstate'));
  },

  getDashboardUrl: (userRole: string, userRoles: string[] = []): string => {
    // CRITICAL: Check actual roles array for admin/shop_manager
    if (userRoles.includes('administrator') || userRole === 'administrator') {
      return '/admin-dashboard';
    }
    
    if (userRoles.includes('shop_manager') || userRole === 'shop_manager') {
      return '/admin-dashboard';
    }
    
    switch (userRole) {
      case 'administrator':
      case 'shop_manager':
        return '/admin-dashboard';
      case 'vendor':
        return '/vendor-dashboard';
      default:
        return '/account-dashboard';
    }
  },

  getPageTitle: (path: string, userRole?: string | null): string => {
    const titles: { [key: string]: string } = {
      '/admin-dashboard': 'EliteQ India - Admin Dashboard',
      '/admin': 'EliteQ India - Admin Dashboard',
      '/vendor-dashboard': 'EliteQ India - Vendor Dashboard', 
      '/vendor': 'EliteQ India - Vendor Dashboard',
      '/account-dashboard': 'EliteQ India - Account Dashboard',
      '/dashboard': 'EliteQ India - Account Dashboard',
      '/': 'EliteQ India - WordPress Login'
    };

    return titles[path] || 'EliteQ India - WordPress Electronics Marketplace';
  },

  redirectToLogin: () => {
    window.history.pushState({}, '', '/login');
    window.dispatchEvent(new PopStateEvent('popstate'));
  },

  // Handle different route variations
  normalizeRoute: (route: string): string => {
    const normalized = route.replace(/\/$/, '').toLowerCase();
    
    const routeAliases: { [key: string]: string } = {
      '/admin': '/admin-dashboard',
      '/administrator': '/admin-dashboard',
      '/vendor': '/vendor-dashboard',
      '/seller': '/vendor-dashboard',
      '/shop-manager': '/admin-dashboard', // CRITICAL: Shop managers get admin dashboard
      '/dashboard': '/account-dashboard'
    };

    return routeAliases[normalized] || normalized;
  }
};

export default AppRouter;