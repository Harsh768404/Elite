import React, { useState } from 'react';
import { Shield, User, Clock, Database, CheckCircle, AlertCircle, ArrowRight, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { useAuth } from '../contexts/AuthContext';

export const AuthStatusDisplay: React.FC = () => {
  const { 
    isAuthenticated, 
    isLoading, 
    token, 
    user, 
    dashboardRole, 
    hasRole, 
    hasRawRole,
    isAdmin, 
    isVendor,
    isUser,
    refreshAuth
  } = useAuth();

  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefreshAuth = async () => {
    setIsRefreshing(true);
    try {
      console.log('🔄 Manual auth refresh triggered by user');
      await refreshAuth();
      console.log('✅ Auth refresh completed successfully');
    } catch (error) {
      console.error('❌ Auth refresh failed:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  const getLocalStorageInfo = () => {
    const items = [
      { key: 'eliteq_jwt_token', label: 'JWT Token' },
      { key: 'eliteq_user_role', label: 'Dashboard Role' },
      { key: 'eliteq_user_info', label: 'User Info' },
      { key: 'token', label: 'Legacy Token' },
      { key: 'user_info', label: 'Legacy User Info' },
    ];

    return items.map(item => ({
      ...item,
      value: localStorage.getItem(item.key),
      exists: !!localStorage.getItem(item.key)
    }));
  };

  const localStorageData = getLocalStorageInfo();

  // Helper to get role mapping explanation
  const getRoleMappingExplanation = () => {
    if (!user) return null;

    const mappings = [];
    user.raw_roles.forEach(rawRole => {
      let mapped = 'user'; // default
      
      if (['administrator', 'admin', 'site_admin', 'super_admin'].includes(rawRole.toLowerCase())) {
        mapped = 'admin';
      } else if (['dokan_vendor', 'vendor', 'seller', 'shop_manager', 'store_manager', 'wcfm_vendor'].includes(rawRole.toLowerCase())) {
        mapped = 'vendor';
      }
      
      mappings.push({ raw: rawRole, mapped });
    });

    return mappings;
  };

  if (isLoading) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 animate-spin text-blue-600" />
            Authentication Loading...
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 dark:text-gray-400">
            Reading JWT token, validating user data, and mapping roles from localStorage...
          </p>
        </CardContent>
      </Card>
    );
  }

  const roleMappings = getRoleMappingExplanation();

  return (
    <Card className="mb-6 border-blue-200 bg-blue-50 dark:bg-blue-950 dark:border-blue-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-600" />
            Professional JWT Authentication Status with Live Data
          </CardTitle>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleRefreshAuth}
            disabled={isRefreshing}
            className="gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? 'Refreshing...' : 'Refresh from WordPress API'}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Real Data Source Notice */}
        <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <h4 className="font-medium text-green-900 dark:text-green-100">
              ✅ Live Data from WordPress API
            </h4>
          </div>
          <p className="text-sm text-green-800 dark:text-green-200">
            All user data shown below is fetched from the live WordPress installation at eliteq.in using authenticated API calls. 
            No dummy or hardcoded values are used. Click "Refresh" to fetch the latest data from WordPress.
          </p>
        </div>
        
        {/* Authentication Status */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="font-medium text-gray-900 dark:text-white">Authentication State</h4>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                {isAuthenticated ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-red-600" />
                )}
                <span className="text-sm">
                  Status: <strong>{isAuthenticated ? 'Authenticated' : 'Not Authenticated'}</strong>
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <Database className="h-4 w-4 text-blue-600" />
                <span className="text-sm">
                  Token: <strong>{token ? 'Present' : 'Missing'}</strong>
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-purple-600" />
                <span className="text-sm">
                  Dashboard Role: <strong>{dashboardRole || 'None'}</strong>
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium text-gray-900 dark:text-white">Role Permissions</h4>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Badge variant={isAdmin ? "default" : "outline"}>
                  Administrator: {isAdmin ? 'Yes' : 'No'}
                </Badge>
              </div>
              
              <div className="flex items-center gap-2">
                <Badge variant={isVendor ? "default" : "outline"}>
                  Vendor: {isVendor ? 'Yes' : 'No'}
                </Badge>
              </div>

              <div className="flex items-center gap-2">
                <Badge variant={isUser ? "default" : "outline"}>
                  User: {isUser ? 'Yes' : 'No'}
                </Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Role Mapping Information */}
        {user && (
          <div className="space-y-4">
            <div className="bg-white dark:bg-gray-900 p-4 rounded-lg border">
              <h4 className="font-medium text-gray-900 dark:text-white mb-3">🎭 Role Mapping Details (Live from WordPress)</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="text-center p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <div className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-1">
                    WordPress Roles (Real)
                  </div>
                  <div className="flex flex-wrap gap-1 justify-center">
                    {user.raw_roles.map(role => (
                      <Badge key={role} variant="outline" className="text-xs">
                        {role}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-center">
                  <ArrowRight className="h-6 w-6 text-gray-400" />
                </div>

                <div className="text-center p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                  <div className="text-sm font-medium text-green-900 dark:text-green-100 mb-1">
                    Mapped Role
                  </div>
                  <Badge variant="default" className="bg-green-600">
                    {user.role}
                  </Badge>
                </div>
              </div>

              {/* Role Mapping Explanation */}
              {roleMappings && (
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Mapping Process:
                  </div>
                  {roleMappings.map((mapping, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                      <Badge variant="outline" className="text-xs">{mapping.raw}</Badge>
                      <ArrowRight className="h-3 w-3" />
                      <Badge 
                        variant={mapping.mapped === 'admin' ? 'default' : mapping.mapped === 'vendor' ? 'secondary' : 'outline'} 
                        className="text-xs"
                      >
                        {mapping.mapped}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* User Information - Real Data from WordPress */}
            <div className="space-y-2">
              <h4 className="font-medium text-gray-900 dark:text-white">Real User Information from WordPress API</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="space-y-1">
                  <div className="text-sm">
                    <strong>ID:</strong> {user.id} <Badge variant="outline" className="ml-2 text-xs">WordPress ID</Badge>
                  </div>
                  <div className="text-sm">
                    <strong>Username:</strong> {user.username} <Badge variant="outline" className="ml-2 text-xs">Real Username</Badge>
                  </div>
                  <div className="text-sm">
                    <strong>Display Name:</strong> {user.display_name} <Badge variant="outline" className="ml-2 text-xs">Real Display Name</Badge>
                  </div>
                  <div className="text-sm">
                    <strong>Email:</strong> {user.email} <Badge variant="outline" className="ml-2 text-xs">Real Email</Badge>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <div className="text-sm">
                    <strong>User Type:</strong> {user.user_type}
                  </div>
                  <div className="text-sm">
                    <strong>Mapped Role:</strong> 
                    <Badge variant="default" className="ml-2">{user.role}</Badge>
                  </div>
                  <div className="text-sm">
                    <strong>Dashboard Role:</strong>
                    <Badge variant="secondary" className="ml-2">{dashboardRole}</Badge>
                  </div>
                  <div className="text-sm">
                    <strong>Data Source:</strong>
                    <Badge variant="outline" className="ml-2 text-xs bg-green-100 text-green-800">WordPress API</Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* localStorage Information */}
        <div className="space-y-2">
          <h4 className="font-medium text-gray-900 dark:text-white">localStorage Data</h4>
          <div className="space-y-2">
            {localStorageData.map(item => (
              <div key={item.key} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded">
                <div className="flex items-center gap-2">
                  {item.exists ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-gray-400" />
                  )}
                  <span className="text-sm font-medium">{item.label}</span>
                </div>
                <Badge variant={item.exists ? "default" : "outline"}>
                  {item.exists ? 'Present' : 'Missing'}
                </Badge>
              </div>
            ))}
          </div>
        </div>

        {/* Role-based Routing Information */}
        <div className="space-y-2">
          <h4 className="font-medium text-gray-900 dark:text-white">Routing Logic</h4>
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700">
            <div className="space-y-2 text-sm">
              <div>
                <strong>Current Route Decision:</strong>
                {!isAuthenticated && <span className="ml-2 text-red-600">→ Login Page</span>}
                {isAuthenticated && dashboardRole === 'admin' && <span className="ml-2 text-blue-600">→ Admin Dashboard</span>}
                {isAuthenticated && dashboardRole === 'vendor' && <span className="ml-2 text-green-600">→ Vendor Dashboard</span>}
                {isAuthenticated && dashboardRole === 'user' && <span className="ml-2 text-purple-600">→ User Dashboard (Vendor UI)</span>}
                {isAuthenticated && !dashboardRole && <span className="ml-2 text-orange-600">→ Unauthorized</span>}
              </div>
              
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-2">
                <strong>Enhanced Routing Rules:</strong><br/>
                • admin mapped role → /admin-dashboard<br/>
                • vendor mapped role → /vendor-dashboard<br/>
                • user mapped role → /vendor-dashboard (with user permissions)<br/>
                • No valid mapped role → Unauthorized message<br/>
                • No authentication → Login page
              </div>
            </div>
          </div>
        </div>

        {/* Role Checking Examples */}
        {isAuthenticated && (
          <div className="space-y-2">
            <h4 className="font-medium text-gray-900 dark:text-white">Role Checking Examples</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="p-2 bg-gray-50 dark:bg-gray-800 rounded text-center">
                <div className="text-xs font-medium mb-1">hasRole('admin')</div>
                <Badge variant={hasRole('admin') ? "default" : "outline"} className="text-xs">
                  {hasRole('admin') ? 'Yes' : 'No'}
                </Badge>
              </div>
              
              <div className="p-2 bg-gray-50 dark:bg-gray-800 rounded text-center">
                <div className="text-xs font-medium mb-1">hasRole('vendor')</div>
                <Badge variant={hasRole('vendor') ? "default" : "outline"} className="text-xs">
                  {hasRole('vendor') ? 'Yes' : 'No'}
                </Badge>
              </div>

              <div className="p-2 bg-gray-50 dark:bg-gray-800 rounded text-center">
                <div className="text-xs font-medium mb-1">hasRole('user')</div>
                <Badge variant={hasRole('user') ? "default" : "outline"} className="text-xs">
                  {hasRole('user') ? 'Yes' : 'No'}
                </Badge>
              </div>
              
              <div className="p-2 bg-gray-50 dark:bg-gray-800 rounded text-center">
                <div className="text-xs font-medium mb-1">hasRawRole('seller')</div>
                <Badge variant={hasRawRole('seller') ? "default" : "outline"} className="text-xs">
                  {hasRawRole('seller') ? 'Yes' : 'No'}
                </Badge>
              </div>
            </div>
          </div>
        )}

        {/* Role Mapping Rules Reference */}
        <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-700">
          <h4 className="font-medium text-yellow-900 dark:text-yellow-100 mb-2">
            🎯 Role Mapping Rules Reference
          </h4>
          <div className="text-sm text-yellow-800 dark:text-yellow-200 space-y-1">
            <div><strong>admin:</strong> administrator, admin, site_admin, super_admin</div>
            <div><strong>vendor:</strong> dokan_vendor, vendor, seller, shop_manager, store_manager, wcfm_vendor</div>
            <div><strong>user:</strong> user, customer, subscriber, contributor, author, editor</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AuthStatusDisplay;