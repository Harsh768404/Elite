import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import * as kv from './kv_store.tsx';
import wordpressProxy from './wordpress-proxy.tsx';
import woocommerceWebhook from './woocommerce-webhook.tsx';

const app = new Hono();

// Middleware
app.use('*', logger(console.log));
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// Health check
app.get('/make-server-4a0fd44c/health', async (c) => {
  return c.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    services: ['kv-store', 'wordpress-proxy', 'woocommerce-webhook']
  });
});

// KV Store endpoints
app.get('/make-server-4a0fd44c/kv/:key', async (c) => {
  try {
    const key = c.req.param('key');
    const value = await kv.get(key);
    return c.json({ key, value });
  } catch (error: any) {
    console.log('KV get error:', error.message);
    return c.json({ error: error.message }, 500);
  }
});

app.post('/make-server-4a0fd44c/kv/:key', async (c) => {
  try {
    const key = c.req.param('key');
    const { value } = await c.req.json();
    await kv.set(key, value);
    return c.json({ success: true, key, value });
  } catch (error: any) {
    console.log('KV set error:', error.message);
    return c.json({ error: error.message }, 500);
  }
});

app.delete('/make-server-4a0fd44c/kv/:key', async (c) => {
  try {
    const key = c.req.param('key');
    await kv.del(key);
    return c.json({ success: true, key });
  } catch (error: any) {
    console.log('KV delete error:', error.message);
    return c.json({ error: error.message }, 500);
  }
});

// WordPress proxy routes
app.route('/make-server-4a0fd44c', wordpressProxy);

// WooCommerce webhook routes
app.route('/make-server-4a0fd44c', woocommerceWebhook);

// WordPress configuration endpoints
app.post('/make-server-4a0fd44c/wp-config', async (c) => {
  try {
    const config = await c.req.json();
    await kv.set('wp_config', config);
    return c.json({ success: true, message: 'WordPress configuration saved' });
  } catch (error: any) {
    console.log('WordPress config save error:', error.message);
    return c.json({ error: error.message }, 500);
  }
});

app.get('/make-server-4a0fd44c/wp-config', async (c) => {
  try {
    const config = await kv.get('wp_config');
    return c.json({ config });
  } catch (error: any) {
    console.log('WordPress config get error:', error.message);
    return c.json({ error: error.message }, 500);
  }
});

// Test WordPress connection endpoint
app.post('/make-server-4a0fd44c/test-wp-connection', async (c) => {
  try {
    const { wpBaseUrl } = await c.req.json();
    
    if (!wpBaseUrl) {
      return c.json({ error: 'WordPress base URL is required' }, 400);
    }

    console.log('Testing WordPress connection to:', wpBaseUrl);
    
    const response = await fetch(`${wpBaseUrl}/wp-json/wp/v2/posts?per_page=1`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'EliteQ-Admin-Panel/1.0',
      },
    });

    const responseData = await response.json();

    return c.json({
      success: response.ok,
      status: response.status,
      message: response.ok ? 'WordPress connection successful' : 'WordPress connection failed',
      data: responseData
    });
    
  } catch (error: any) {
    console.log('WordPress connection test error:', error.message);
    return c.json({
      success: false,
      error: error.message,
      message: 'WordPress connection test failed'
    }, 500);
  }
});

// Export the app
export default {
  fetch: app.fetch,
};

// Start the server if running directly
if (import.meta.main) {
  Deno.serve(app.fetch);
}