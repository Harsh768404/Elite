// WooCommerce Webhook Handler for EliteQ India
import { Hono } from "npm:hono";
import * as kv from "./kv_store.tsx";

const webhookApp = new Hono();

// Webhook signature verification (optional for now)
const verifyWebhookSignature = (payload: string, signature: string, secret: string): boolean => {
  try {
    // In a production environment, you would verify the webhook signature
    // For now, we'll skip this verification but log the attempt
    console.log('Webhook signature verification skipped for development');
    return true;
  } catch (error) {
    console.error('Webhook signature verification error:', error);
    return false;
  }
};

// Order webhook handler
webhookApp.post("/order", async (c) => {
  try {
    const payload = await c.req.text();
    console.log('Received order webhook payload');
    
    let orderData;
    try {
      orderData = JSON.parse(payload);
    } catch (parseError) {
      console.error('Invalid JSON in order webhook:', parseError);
      return c.json({ error: 'Invalid JSON payload' }, 400);
    }
    
    // Validate required fields
    if (!orderData.id) {
      console.error('Order webhook missing required ID field');
      return c.json({ error: 'Order ID is required' }, 400);
    }
    
    // Store order update in KV store for real-time dashboard updates
    const orderUpdate = {
      id: orderData.id,
      number: orderData.number || orderData.id,
      status: orderData.status || 'unknown',
      total: orderData.total || '0',
      currency: orderData.currency || 'INR',
      customer: {
        id: orderData.customer_id || null,
        first_name: orderData.billing?.first_name || '',
        last_name: orderData.billing?.last_name || '',
        email: orderData.billing?.email || ''
      },
      date_created: orderData.date_created || new Date().toISOString(),
      line_items_count: orderData.line_items?.length || 0,
      updated_at: new Date().toISOString(),
      webhook_received: true
    };
    
    // Store in KV for real-time updates
    const updateKey = `order_update_${orderData.id}_${Date.now()}`;
    const stored = await kv.set(updateKey, JSON.stringify(orderUpdate));
    
    if (!stored) {
      console.error('Failed to store order update in KV store');
    }
    
    console.log(`Order webhook processed successfully: Order ${orderData.id} - Status: ${orderData.status}`);
    
    return c.json({ 
      success: true, 
      message: 'Order webhook processed successfully',
      order_id: orderData.id,
      status: orderData.status,
      processed_at: new Date().toISOString()
    });
    
  } catch (error) {
    console.error(`Order webhook processing error:`, error);
    return c.json({ 
      error: 'Failed to process order webhook',
      message: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

// Product webhook handler
webhookApp.post("/product", async (c) => {
  try {
    const payload = await c.req.text();
    console.log('Received product webhook payload');
    
    let productData;
    try {
      productData = JSON.parse(payload);
    } catch (parseError) {
      console.error('Invalid JSON in product webhook:', parseError);
      return c.json({ error: 'Invalid JSON payload' }, 400);
    }
    
    // Validate required fields
    if (!productData.id) {
      console.error('Product webhook missing required ID field');
      return c.json({ error: 'Product ID is required' }, 400);
    }
    
    // Store product update
    const productUpdate = {
      id: productData.id,
      name: productData.name || 'Unnamed Product',
      status: productData.status || 'unknown',
      stock_quantity: productData.stock_quantity || 0,
      stock_status: productData.stock_status || 'unknown',
      price: productData.price || '0',
      regular_price: productData.regular_price || '0',
      sale_price: productData.sale_price || '',
      sku: productData.sku || '',
      type: productData.type || 'simple',
      featured: productData.featured || false,
      date_modified: productData.date_modified || new Date().toISOString(),
      updated_at: new Date().toISOString(),
      webhook_received: true
    };
    
    const updateKey = `product_update_${productData.id}_${Date.now()}`;
    const stored = await kv.set(updateKey, JSON.stringify(productUpdate));
    
    if (!stored) {
      console.error('Failed to store product update in KV store');
    }
    
    console.log(`Product webhook processed successfully: Product ${productData.id} - ${productData.name}`);
    
    return c.json({ 
      success: true, 
      message: 'Product webhook processed successfully',
      product_id: productData.id,
      name: productData.name,
      status: productData.status,
      processed_at: new Date().toISOString()
    });
    
  } catch (error) {
    console.error(`Product webhook processing error:`, error);
    return c.json({ 
      error: 'Failed to process product webhook',
      message: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

// Customer webhook handler
webhookApp.post("/customer", async (c) => {
  try {
    const payload = await c.req.text();
    console.log('Received customer webhook payload');
    
    let customerData;
    try {
      customerData = JSON.parse(payload);
    } catch (parseError) {
      console.error('Invalid JSON in customer webhook:', parseError);
      return c.json({ error: 'Invalid JSON payload' }, 400);
    }
    
    // Validate required fields
    if (!customerData.id) {
      console.error('Customer webhook missing required ID field');
      return c.json({ error: 'Customer ID is required' }, 400);
    }
    
    // Store customer update
    const customerUpdate = {
      id: customerData.id,
      email: customerData.email || '',
      first_name: customerData.first_name || '',
      last_name: customerData.last_name || '',
      role: customerData.role || 'customer',
      date_created: customerData.date_created || new Date().toISOString(),
      date_modified: customerData.date_modified || new Date().toISOString(),
      updated_at: new Date().toISOString(),
      webhook_received: true
    };
    
    const updateKey = `customer_update_${customerData.id}_${Date.now()}`;
    const stored = await kv.set(updateKey, JSON.stringify(customerUpdate));
    
    if (!stored) {
      console.error('Failed to store customer update in KV store');
    }
    
    console.log(`Customer webhook processed successfully: Customer ${customerData.id} - ${customerData.email}`);
    
    return c.json({ 
      success: true, 
      message: 'Customer webhook processed successfully',
      customer_id: customerData.id,
      email: customerData.email,
      processed_at: new Date().toISOString()
    });
    
  } catch (error) {
    console.error(`Customer webhook processing error:`, error);
    return c.json({ 
      error: 'Failed to process customer webhook',
      message: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

// Get recent updates endpoint
webhookApp.get("/updates", async (c) => {
  try {
    const type = c.req.query('type') || 'all';
    const limit = Math.min(parseInt(c.req.query('limit') || '10'), 100); // Max 100 items
    
    let updates: any[] = [];
    
    if (type === 'orders' || type === 'all') {
      try {
        const orderUpdates = await kv.getByPrefix('order_update_');
        const parsedOrderUpdates = orderUpdates
          .map(update => {
            try {
              return { ...JSON.parse(update), type: 'order' };
            } catch {
              return null;
            }
          })
          .filter(update => update !== null);
        updates.push(...parsedOrderUpdates);
      } catch (error) {
        console.error('Error fetching order updates:', error);
      }
    }
    
    if (type === 'products' || type === 'all') {
      try {
        const productUpdates = await kv.getByPrefix('product_update_');
        const parsedProductUpdates = productUpdates
          .map(update => {
            try {
              return { ...JSON.parse(update), type: 'product' };
            } catch {
              return null;
            }
          })
          .filter(update => update !== null);
        updates.push(...parsedProductUpdates);
      } catch (error) {
        console.error('Error fetching product updates:', error);
      }
    }
    
    if (type === 'customers' || type === 'all') {
      try {
        const customerUpdates = await kv.getByPrefix('customer_update_');
        const parsedCustomerUpdates = customerUpdates
          .map(update => {
            try {
              return { ...JSON.parse(update), type: 'customer' };
            } catch {
              return null;
            }
          })
          .filter(update => update !== null);
        updates.push(...parsedCustomerUpdates);
      } catch (error) {
        console.error('Error fetching customer updates:', error);
      }
    }
    
    // Sort by updated_at and limit results
    updates.sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
    updates = updates.slice(0, limit);
    
    return c.json({
      success: true,
      updates,
      count: updates.length,
      last_updated: updates[0]?.updated_at || null,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error(`Updates fetch error:`, error);
    return c.json({ 
      error: 'Failed to fetch updates',
      message: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

// Webhook health check
webhookApp.get("/health", (c) => {
  return c.json({
    status: "ok",
    service: "WooCommerce Webhook Handler",
    endpoints: ["/order", "/product", "/customer", "/updates"],
    timestamp: new Date().toISOString()
  });
});

// Clear old updates (cleanup endpoint)
webhookApp.delete("/cleanup", async (c) => {
  try {
    const days = parseInt(c.req.query('days') || '7');
    const cutoffDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    
    const allKeys = await kv.keys();
    let deleted = 0;
    
    for (const key of allKeys) {
      if (key.includes('_update_')) {
        try {
          const data = await kv.get(key);
          if (data) {
            const parsed = JSON.parse(data);
            if (parsed.updated_at && new Date(parsed.updated_at) < cutoffDate) {
              await kv.del(key);
              deleted++;
            }
          }
        } catch (error) {
          console.error(`Error cleaning up key ${key}:`, error);
        }
      }
    }
    
    return c.json({
      success: true,
      message: `Cleaned up ${deleted} old update records`,
      cutoff_date: cutoffDate.toISOString(),
      deleted_count: deleted
    });
  } catch (error) {
    console.error('Cleanup error:', error);
    return c.json({
      error: 'Failed to cleanup old records',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500);
  }
});

console.log('📡 WooCommerce Webhook Handler initialized');
console.log('🔗 Endpoints: /order, /product, /customer, /updates');

export default webhookApp;