/**
 * EliteQ India Real Data Service
 * Comprehensive data fetching from live EliteQ.in WordPress/WooCommerce installation
 * Handles all dashboard data requirements with real WordPress integration
 */

import { wordpressAPI } from './comprehensive-wordpress-api';

// Types for EliteQ data structures
export interface EliteQProduct {
  id: number;
  name: string;
  slug: string;
  status: 'publish' | 'draft' | 'private';
  featured: boolean;
  catalog_visibility: string;
  description: string;
  short_description: string;
  sku: string;
  price: string;
  regular_price: string;
  sale_price: string;
  on_sale: boolean;
  total_sales: number;
  stock_quantity: number | null;
  stock_status: 'instock' | 'outofstock' | 'onbackorder';
  manage_stock: boolean;
  categories: Array<{ id: number; name: string; slug: string }>;
  tags: Array<{ id: number; name: string; slug: string }>;
  images: Array<{ id: number; src: string; alt: string }>;
  vendor?: {
    id: number;
    name: string;
    store_name: string;
  };
  date_created: string;
  date_modified: string;
}

export interface EliteQOrder {
  id: number;
  number: string;
  status: string;
  currency: string;
  total: string;
  total_tax: string;
  subtotal: string;
  shipping_total: string;
  customer: {
    id: number;
    email: string;
    first_name: string;
    last_name: string;
  };
  billing: {
    first_name: string;
    last_name: string;
    company: string;
    address_1: string;
    address_2: string;
    city: string;
    state: string;
    postcode: string;
    country: string;
    email: string;
    phone: string;
  };
  shipping: {
    first_name: string;
    last_name: string;
    company: string;
    address_1: string;
    address_2: string;
    city: string;
    state: string;
    postcode: string;
    country: string;
  };
  line_items: Array<{
    id: number;
    name: string;
    product_id: number;
    quantity: number;
    total: string;
    price: string;
  }>;
  vendor?: {
    id: number;
    name: string;
    store_name: string;
  };
  date_created: string;
  date_modified: string;
}

export interface EliteQCustomer {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  username: string;
  date_created: string;
  date_modified: string;
  total_spent: string;
  orders_count: number;
  avatar_url: string;
  billing: any;
  shipping: any;
  role: string;
}

export interface EliteQVendor {
  id: number;
  store_name: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  show_email: boolean;
  address: {
    street_1: string;
    street_2: string;
    city: string;
    zip: string;
    country: string;
    state: string;
  };
  location: string;
  banner: string;
  icon: string;
  gravatar: string;
  shop_url: string;
  products_per_page: number;
  show_more_product_tab: boolean;
  toc_enabled: boolean;
  store_toc: string;
  featured: boolean;
  rating: {
    rating: number;
    count: number;
  };
  enabled: boolean;
  registered: string;
  last_sale: string;
  total_sales: number;
  total_orders: number;
}

export interface EliteQDashboardStats {
  products: {
    total: number;
    published: number;
    draft: number;
    pending: number;
    recent: EliteQProduct[];
  };
  orders: {
    total: number;
    pending: number;
    processing: number;
    completed: number;
    revenue: number;
    recent: EliteQOrder[];
  };
  customers: {
    total: number;
    new_this_month: number;
    recent: EliteQCustomer[];
  };
  vendors: {
    total: number;
    active: number;
    pending: number;
    recent: EliteQVendor[];
  };
  categories: Array<{ id: number; name: string; count: number }>;
  performance: {
    sales_this_month: number;
    sales_last_month: number;
    growth_rate: number;
    best_selling_products: EliteQProduct[];
  };
}

class EliteQRealDataService {
  private cache: Map<string, { data: any; timestamp: number; ttl: number }> = new Map();
  private readonly CACHE_TTL = 5 * 60 * 1000; // 5 minutes default cache

  constructor() {
    console.log('🏪 EliteQ Real Data Service initialized for live data from eliteq.in');
  }

  // Cache management
  private setCache(key: string, data: any, ttl: number = this.CACHE_TTL): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  private getCache(key: string): any | null {
    const cached = this.cache.get(key);
    if (!cached) return null;

    const now = Date.now();
    if (now - cached.timestamp > cached.ttl) {
      this.cache.delete(key);
      return null;
    }

    return cached.data;
  }

  private clearCache(): void {
    this.cache.clear();
    console.log('🗑️ EliteQ data cache cleared');
  }

  // PRODUCTS: Real EliteQ product data
  async getProducts(params: {
    per_page?: number;
    page?: number;
    status?: string;
    vendor?: number;
    category?: number;
    search?: string;
    orderby?: string;
    order?: string;
  } = {}): Promise<EliteQProduct[]> {
    const cacheKey = `products_${JSON.stringify(params)}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('📦 Fetching real products from EliteQ.in...', params);
      
      const products = await wordpressAPI.getProducts({
        per_page: 20,
        ...params
      });

      console.log(`✅ Real products fetched: ${products.length} items`);
      
      this.setCache(cacheKey, products);
      return products;
    } catch (error) {
      console.error('❌ Failed to fetch real products:', error);
      throw error;
    }
  }

  async getProduct(id: number): Promise<EliteQProduct> {
    const cacheKey = `product_${id}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('📦 Fetching real product from EliteQ.in:', id);
      
      const product = await wordpressAPI.getProduct(id);
      
      console.log(`✅ Real product fetched: ${product.name}`);
      
      this.setCache(cacheKey, product);
      return product;
    } catch (error) {
      console.error('❌ Failed to fetch real product:', error);
      throw error;
    }
  }

  // ORDERS: Real EliteQ order data
  async getOrders(params: {
    per_page?: number;
    page?: number;
    status?: string;
    customer?: number;
    vendor?: number;
    after?: string;
    before?: string;
    orderby?: string;
    order?: string;
  } = {}): Promise<EliteQOrder[]> {
    const cacheKey = `orders_${JSON.stringify(params)}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('🛒 Fetching real orders from EliteQ.in...', params);
      
      const orders = await wordpressAPI.getOrders({
        per_page: 20,
        ...params
      });

      console.log(`✅ Real orders fetched: ${orders.length} items`);
      
      this.setCache(cacheKey, orders);
      return orders;
    } catch (error) {
      console.error('❌ Failed to fetch real orders:', error);
      throw error;
    }
  }

  async getOrder(id: number): Promise<EliteQOrder> {
    const cacheKey = `order_${id}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('🛒 Fetching real order from EliteQ.in:', id);
      
      const order = await wordpressAPI.getOrder(id);
      
      console.log(`✅ Real order fetched: #${order.number}`);
      
      this.setCache(cacheKey, order);
      return order;
    } catch (error) {
      console.error('❌ Failed to fetch real order:', error);
      throw error;
    }
  }

  // CUSTOMERS: Real EliteQ customer data
  async getCustomers(params: {
    per_page?: number;
    page?: number;
    search?: string;
    orderby?: string;
    order?: string;
  } = {}): Promise<EliteQCustomer[]> {
    const cacheKey = `customers_${JSON.stringify(params)}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('👥 Fetching real customers from EliteQ.in...', params);
      
      const customers = await wordpressAPI.getCustomers({
        per_page: 20,
        ...params
      });

      console.log(`✅ Real customers fetched: ${customers.length} items`);
      
      this.setCache(cacheKey, customers);
      return customers;
    } catch (error) {
      console.error('❌ Failed to fetch real customers:', error);
      throw error;
    }
  }

  async getCustomer(id: number): Promise<EliteQCustomer> {
    const cacheKey = `customer_${id}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('👤 Fetching real customer from EliteQ.in:', id);
      
      const customer = await wordpressAPI.getCustomer(id);
      
      console.log(`✅ Real customer fetched: ${customer.email}`);
      
      this.setCache(cacheKey, customer);
      return customer;
    } catch (error) {
      console.error('❌ Failed to fetch real customer:', error);
      throw error;
    }
  }

  // VENDORS: Real EliteQ vendor data (Dokan)
  async getVendors(params: {
    per_page?: number;
    page?: number;
    status?: string;
    search?: string;
    orderby?: string;
    order?: string;
  } = {}): Promise<EliteQVendor[]> {
    const cacheKey = `vendors_${JSON.stringify(params)}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('🏪 Fetching real vendors from EliteQ.in...', params);
      
      const vendors = await wordpressAPI.getVendors({
        per_page: 20,
        ...params
      });

      console.log(`✅ Real vendors fetched: ${vendors.length} items`);
      
      this.setCache(cacheKey, vendors);
      return vendors;
    } catch (error) {
      console.error('❌ Failed to fetch real vendors:', error);
      throw error;
    }
  }

  async getStores(params: {
    per_page?: number;
    page?: number;
    status?: string;
    search?: string;
    orderby?: string;
    order?: string;
  } = {}): Promise<any[]> {
    const cacheKey = `stores_${JSON.stringify(params)}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('🏬 Fetching real stores from EliteQ.in...', params);
      
      const stores = await wordpressAPI.getStores({
        per_page: 20,
        ...params
      });

      console.log(`✅ Real stores fetched: ${stores.length} items`);
      
      this.setCache(cacheKey, stores);
      return stores;
    } catch (error) {
      console.error('❌ Failed to fetch real stores:', error);
      throw error;
    }
  }

  // CATEGORIES: Real EliteQ category data
  async getProductCategories(params: {
    per_page?: number;
    page?: number;
    search?: string;
    orderby?: string;
    order?: string;
  } = {}): Promise<any[]> {
    const cacheKey = `categories_${JSON.stringify(params)}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('📂 Fetching real categories from EliteQ.in...', params);
      
      const categories = await wordpressAPI.getProductCategories({
        per_page: 50,
        ...params
      });

      console.log(`✅ Real categories fetched: ${categories.length} items`);
      
      this.setCache(cacheKey, categories);
      return categories;
    } catch (error) {
      console.error('❌ Failed to fetch real categories:', error);
      throw error;
    }
  }

  // ANALYTICS & REPORTS: Real EliteQ analytics data
  async getSalesReport(params: {
    period?: 'week' | 'month' | 'year';
    after?: string;
    before?: string;
  } = {}): Promise<any> {
    const cacheKey = `sales_report_${JSON.stringify(params)}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('📊 Fetching real sales report from EliteQ.in...', params);
      
      const report = await wordpressAPI.getSalesReport(params);
      
      console.log('✅ Real sales report fetched');
      
      this.setCache(cacheKey, report);
      return report;
    } catch (error) {
      console.error('❌ Failed to fetch real sales report:', error);
      throw error;
    }
  }

  async getTopSellers(params: {
    period?: 'week' | 'month' | 'year';
    limit?: number;
  } = {}): Promise<any[]> {
    const cacheKey = `top_sellers_${JSON.stringify(params)}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('🏆 Fetching real top sellers from EliteQ.in...', params);
      
      const topSellers = await wordpressAPI.getTopSellers(params);
      
      console.log(`✅ Real top sellers fetched: ${topSellers.length} items`);
      
      this.setCache(cacheKey, topSellers);
      return topSellers;
    } catch (error) {
      console.error('❌ Failed to fetch real top sellers:', error);
      throw error;
    }
  }

  // COMPREHENSIVE DASHBOARD DATA: Real EliteQ dashboard statistics
  async getDashboardStats(): Promise<EliteQDashboardStats> {
    const cacheKey = 'dashboard_stats';
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('📊 Fetching comprehensive real dashboard stats from EliteQ.in...');
      
      // Fetch all data in parallel for better performance
      const [
        allProducts,
        recentProducts,
        allOrders,
        recentOrders,
        allCustomers,
        recentCustomers,
        allVendors,
        categories,
        salesReport,
        topSellers
      ] = await Promise.allSettled([
        this.getProducts({ per_page: 100, orderby: 'date', order: 'desc' }),
        this.getProducts({ per_page: 5, orderby: 'date', order: 'desc' }),
        this.getOrders({ per_page: 100, orderby: 'date', order: 'desc' }),
        this.getOrders({ per_page: 5, orderby: 'date', order: 'desc' }),
        this.getCustomers({ per_page: 100, orderby: 'registered_date', order: 'desc' }),
        this.getCustomers({ per_page: 5, orderby: 'registered_date', order: 'desc' }),
        this.getVendors({ per_page: 50 }),
        this.getProductCategories({ per_page: 20 }),
        this.getSalesReport({ period: 'month' }),
        this.getTopSellers({ period: 'month', limit: 5 })
      ]);

      // Process results
      const products = allProducts.status === 'fulfilled' ? allProducts.value : [];
      const orders = allOrders.status === 'fulfilled' ? allOrders.value : [];
      const customers = allCustomers.status === 'fulfilled' ? allCustomers.value : [];
      const vendors = allVendors.status === 'fulfilled' ? allVendors.value : [];

      // Calculate statistics
      const totalRevenue = orders.reduce((sum, order) => sum + parseFloat(order.total || '0'), 0);
      const completedOrders = orders.filter(order => order.status === 'completed');
      const pendingOrders = orders.filter(order => order.status === 'pending');
      const processingOrders = orders.filter(order => order.status === 'processing');

      const publishedProducts = products.filter(product => product.status === 'publish');
      const draftProducts = products.filter(product => product.status === 'draft');
      const pendingProducts = products.filter(product => product.status === 'pending');

      // Calculate new customers this month
      const thisMonth = new Date();
      thisMonth.setDate(1);
      const newCustomersThisMonth = customers.filter(customer => 
        new Date(customer.date_created) >= thisMonth
      );

      const dashboardStats: EliteQDashboardStats = {
        products: {
          total: products.length,
          published: publishedProducts.length,
          draft: draftProducts.length,
          pending: pendingProducts.length,
          recent: recentProducts.status === 'fulfilled' ? recentProducts.value : []
        },
        orders: {
          total: orders.length,
          pending: pendingOrders.length,
          processing: processingOrders.length,
          completed: completedOrders.length,
          revenue: totalRevenue,
          recent: recentOrders.status === 'fulfilled' ? recentOrders.value : []
        },
        customers: {
          total: customers.length,
          new_this_month: newCustomersThisMonth.length,
          recent: recentCustomers.status === 'fulfilled' ? recentCustomers.value : []
        },
        vendors: {
          total: vendors.length,
          active: vendors.filter(vendor => vendor.enabled).length,
          pending: vendors.filter(vendor => !vendor.enabled).length,
          recent: vendors.slice(0, 5)
        },
        categories: categories.status === 'fulfilled' ? categories.value : [],
        performance: {
          sales_this_month: totalRevenue,
          sales_last_month: 0, // Would need historical data
          growth_rate: 0, // Would need historical data
          best_selling_products: topSellers.status === 'fulfilled' ? topSellers.value : []
        }
      };

      console.log('✅ ===== REAL ELITEQ DASHBOARD STATS COMPILED =====');
      console.log('📦 Products:', dashboardStats.products.total);
      console.log('🛒 Orders:', dashboardStats.orders.total);
      console.log('👥 Customers:', dashboardStats.customers.total);
      console.log('🏪 Vendors:', dashboardStats.vendors.total);
      console.log('💰 Revenue:', dashboardStats.orders.revenue);
      console.log('📂 Categories:', dashboardStats.categories.length);

      this.setCache(cacheKey, dashboardStats, 10 * 60 * 1000); // Cache for 10 minutes
      return dashboardStats;
    } catch (error) {
      console.error('❌ Failed to fetch real dashboard stats:', error);
      throw error;
    }
  }

  // VENDOR-SPECIFIC DATA: Real vendor dashboard data
  async getVendorDashboardData(vendorId: number): Promise<{
    products: EliteQProduct[];
    orders: EliteQOrder[];
    stats: {
      total_products: number;
      total_orders: number;
      total_sales: number;
      pending_orders: number;
    };
  }> {
    const cacheKey = `vendor_dashboard_${vendorId}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      console.log('🏪 Fetching real vendor dashboard data from EliteQ.in...', vendorId);
      
      const [products, orders] = await Promise.allSettled([
        this.getProducts({ vendor: vendorId, per_page: 50 }),
        this.getOrders({ vendor: vendorId, per_page: 50 })
      ]);

      const vendorProducts = products.status === 'fulfilled' ? products.value : [];
      const vendorOrders = orders.status === 'fulfilled' ? orders.value : [];

      const totalSales = vendorOrders.reduce((sum, order) => sum + parseFloat(order.total || '0'), 0);
      const pendingOrders = vendorOrders.filter(order => order.status === 'pending');

      const vendorData = {
        products: vendorProducts,
        orders: vendorOrders,
        stats: {
          total_products: vendorProducts.length,
          total_orders: vendorOrders.length,
          total_sales: totalSales,
          pending_orders: pendingOrders.length
        }
      };

      console.log('✅ Real vendor dashboard data compiled');
      
      this.setCache(cacheKey, vendorData, 5 * 60 * 1000); // Cache for 5 minutes
      return vendorData;
    } catch (error) {
      console.error('❌ Failed to fetch real vendor dashboard data:', error);
      throw error;
    }
  }

  // UTILITY METHODS
  async searchProducts(query: string, limit: number = 10): Promise<EliteQProduct[]> {
    try {
      return await this.getProducts({
        search: query,
        per_page: limit
      });
    } catch (error) {
      console.error('❌ Failed to search products:', error);
      throw error;
    }
  }

  async getRecentActivity(limit: number = 10): Promise<{
    recent_orders: EliteQOrder[];
    recent_products: EliteQProduct[];
    recent_customers: EliteQCustomer[];
  }> {
    try {
      const [orders, products, customers] = await Promise.allSettled([
        this.getOrders({ per_page: limit, orderby: 'date', order: 'desc' }),
        this.getProducts({ per_page: limit, orderby: 'date', order: 'desc' }),
        this.getCustomers({ per_page: limit, orderby: 'registered_date', order: 'desc' })
      ]);

      return {
        recent_orders: orders.status === 'fulfilled' ? orders.value : [],
        recent_products: products.status === 'fulfilled' ? products.value : [],
        recent_customers: customers.status === 'fulfilled' ? customers.value : []
      };
    } catch (error) {
      console.error('❌ Failed to fetch recent activity:', error);
      throw error;
    }
  }

  // Health check for EliteQ connection
  async healthCheck(): Promise<{
    status: 'healthy' | 'degraded' | 'unhealthy';
    checks: {
      wordpress: boolean;
      woocommerce: boolean;
      products: boolean;
      orders: boolean;
    };
    response_time: number;
  }> {
    const startTime = Date.now();
    
    try {
      console.log('🏥 Performing EliteQ health check...');
      
      const [wpHealth, productTest, orderTest] = await Promise.allSettled([
        wordpressAPI.healthCheck(),
        this.getProducts({ per_page: 1 }),
        this.getOrders({ per_page: 1 })
      ]);

      const responseTime = Date.now() - startTime;
      
      const checks = {
        wordpress: wpHealth.status === 'fulfilled' && wpHealth.value.wordpress,
        woocommerce: wpHealth.status === 'fulfilled' && wpHealth.value.woocommerce,
        products: productTest.status === 'fulfilled',
        orders: orderTest.status === 'fulfilled'
      };

      const healthyChecks = Object.values(checks).filter(Boolean).length;
      const totalChecks = Object.values(checks).length;

      let status: 'healthy' | 'degraded' | 'unhealthy';
      if (healthyChecks === totalChecks) {
        status = 'healthy';
      } else if (healthyChecks >= totalChecks / 2) {
        status = 'degraded';
      } else {
        status = 'unhealthy';
      }

      console.log(`✅ EliteQ health check complete: ${status} (${responseTime}ms)`);

      return {
        status,
        checks,
        response_time: responseTime
      };
    } catch (error) {
      console.error('❌ EliteQ health check failed:', error);
      return {
        status: 'unhealthy',
        checks: {
          wordpress: false,
          woocommerce: false,
          products: false,
          orders: false
        },
        response_time: Date.now() - startTime
      };
    }
  }

  // Clear all cached data
  clearAllCache(): void {
    this.clearCache();
  }

  // Get cache statistics
  getCacheStats(): {
    size: number;
    keys: string[];
    oldest_entry: number | null;
    newest_entry: number | null;
  } {
    const now = Date.now();
    const entries = Array.from(this.cache.entries());
    
    const timestamps = entries.map(([_, data]) => data.timestamp);
    
    return {
      size: this.cache.size,
      keys: entries.map(([key]) => key),
      oldest_entry: timestamps.length > 0 ? Math.min(...timestamps) : null,
      newest_entry: timestamps.length > 0 ? Math.max(...timestamps) : null
    };
  }
}

// Export singleton instance
export const eliteqDataService = new EliteQRealDataService();

// Export class for custom instances
export { EliteQRealDataService };

export default eliteqDataService;