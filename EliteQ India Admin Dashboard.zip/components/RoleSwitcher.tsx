import React from 'react';
import { User, Shield, ChevronDown } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface RoleSwitcherProps {
  currentRole: 'vendor' | 'admin';
  onRoleChange: (role: 'vendor' | 'admin') => void;
  darkMode?: boolean;
}

export function RoleSwitcher({ currentRole, onRoleChange, darkMode }: RoleSwitcherProps) {
  const roles = [
    {
      id: 'vendor' as const,
      label: 'Vendor Dashboard',
      description: 'Manage your store and products',
      icon: User,
      color: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300'
    },
    {
      id: 'admin' as const,
      label: 'Admin Dashboard',
      description: 'Platform administration',
      icon: Shield,
      color: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300'
    }
  ];

  const currentRoleData = roles.find(role => role.id === currentRole);
  const CurrentIcon = currentRoleData?.icon || User;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="flex items-center gap-3 px-4 py-2 rounded-lg border border-gray-600 hover:bg-gray-700 text-white"
        >
          <div className={`p-2 rounded-lg ${currentRoleData?.color}`}>
            <CurrentIcon className="h-4 w-4" />
          </div>
          <div className="text-left hidden sm:block">
            <div className="font-medium text-white">
              {currentRoleData?.label}
            </div>
            <div className="text-xs text-gray-400">
              {currentRoleData?.description}
            </div>
          </div>
          <ChevronDown className="h-4 w-4 text-gray-400" />
        </Button>
      </DropdownMenuTrigger>
      
      <DropdownMenuContent align="start" className="w-64">
        {roles.map((role) => {
          const RoleIcon = role.icon;
          return (
            <DropdownMenuItem
              key={role.id}
              onClick={() => onRoleChange(role.id)}
              className="flex items-center gap-3 p-3 cursor-pointer"
            >
              <div className={`p-2 rounded-lg ${role.color}`}>
                <RoleIcon className="h-4 w-4" />
              </div>
              <div className="flex-1">
                <div className="font-medium flex items-center gap-2">
                  {role.label}
                  {currentRole === role.id && (
                    <Badge variant="secondary" className="text-xs">
                      Active
                    </Badge>
                  )}
                </div>
                <div className="text-xs text-gray-500">
                  {role.description}
                </div>
              </div>
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}