import { useState, useEffect, useCallback } from 'react';
import { kycService, KYCStatus, KYCDocument } from '../utils/kyc-service';

interface UseKYCReturn {
  kycStatus: KYCStatus | null;
  isLoading: boolean;
  error: string | null;
  submitDocuments: (documents: KYCDocument[]) => Promise<void>;
  refreshStatus: () => Promise<void>;
  dismissBanner: () => void;
  showBanner: boolean;
}

export const useKYC = (): UseKYCReturn => {
  const [kycStatus, setKycStatus] = useState<KYCStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showBanner, setShowBanner] = useState(true);

  // Fetch KYC status on component mount
  const fetchKYCStatus = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const status = await kycService.getKYCStatus();
      setKycStatus(status);
      
      // Only show banner if status is pending and user hasn't dismissed it
      const bannerDismissed = localStorage.getItem('kyc-banner-dismissed');
      setShowBanner(status.status === 'pending' && !bannerDismissed);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch KYC status');
      console.error('Error fetching KYC status:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Submit KYC documents
  const submitDocuments = useCallback(async (documents: KYCDocument[]) => {
    try {
      setError(null);
      const result = await kycService.uploadDocuments(documents);
      
      if (result.success) {
        // Refresh status after successful submission
        await fetchKYCStatus();
        
        // Show success message
        // You might want to use a toast notification here
        alert(result.message);
        
        // Hide banner after successful submission
        setShowBanner(false);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit documents');
      throw err; // Re-throw to allow component to handle UI feedback
    }
  }, [fetchKYCStatus]);

  // Refresh KYC status
  const refreshStatus = useCallback(async () => {
    await fetchKYCStatus();
  }, [fetchKYCStatus]);

  // Dismiss banner (user can manually close it)
  const dismissBanner = useCallback(() => {
    setShowBanner(false);
    // Store dismissal in localStorage to prevent showing again in this session
    localStorage.setItem('kyc-banner-dismissed', 'true');
  }, []);

  // Clear dismissal on status change
  useEffect(() => {
    if (kycStatus?.status !== 'pending') {
      localStorage.removeItem('kyc-banner-dismissed');
    }
  }, [kycStatus?.status]);

  // Fetch status on mount
  useEffect(() => {
    fetchKYCStatus();
  }, [fetchKYCStatus]);

  // Auto-refresh KYC status periodically (optional)
  useEffect(() => {
    const interval = setInterval(() => {
      if (kycStatus?.status === 'pending') {
        fetchKYCStatus();
      }
    }, 300000); // Check every 5 minutes if status is pending

    return () => clearInterval(interval);
  }, [kycStatus?.status, fetchKYCStatus]);

  return {
    kycStatus,
    isLoading,
    error,
    submitDocuments,
    refreshStatus,
    dismissBanner,
    showBanner: showBanner && kycStatus?.status === 'pending'
  };
};