import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';

const app = new Hono();

// Enable CORS for all routes
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

interface WordPressProxyRequest {
  method: string;
  endpoint: string;
  wpBaseUrl: string;
  headers?: Record<string, string>;
  body?: string;
}

// WordPress proxy endpoint
app.post('/wordpress-proxy', async (c) => {
  try {
    const requestData: WordPressProxyRequest = await c.req.json();
    
    console.log('WordPress proxy request:', {
      method: requestData.method,
      endpoint: requestData.endpoint,
      wpBaseUrl: requestData.wpBaseUrl
    });

    // Validate request
    if (!requestData.wpBaseUrl || !requestData.endpoint) {
      return c.json({ 
        status: 400,
        statusText: 'Bad Request',
        data: { error: 'Missing required fields: wpBaseUrl and endpoint' }
      }, 400);
    }

    // Construct full URL
    const fullUrl = `${requestData.wpBaseUrl}${requestData.endpoint}`;
    
    // Prepare headers
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'User-Agent': 'EliteQ-Admin-Panel/1.0',
      ...requestData.headers
    };

    // Make request to WordPress
    const fetchOptions: RequestInit = {
      method: requestData.method || 'GET',
      headers,
    };

    if (requestData.body && requestData.method !== 'GET') {
      fetchOptions.body = requestData.body;
    }

    console.log('Making WordPress request to:', fullUrl);
    console.log('Request options:', fetchOptions);
    
    const response = await fetch(fullUrl, fetchOptions);
    
    console.log('WordPress response status:', response.status);
    console.log('WordPress response headers:', Object.fromEntries(response.headers.entries()));
    
    // Get response data
    let responseData;
    const contentType = response.headers.get('content-type');
    
    if (contentType && contentType.includes('application/json')) {
      responseData = await response.json();
    } else {
      const textData = await response.text();
      console.log('Non-JSON response received:', textData);
      
      // Try to parse as JSON anyway
      try {
        responseData = JSON.parse(textData);
      } catch {
        responseData = { message: textData };
      }
    }

    console.log('WordPress response data:', responseData);

    // Return proxied response in a consistent format
    return c.json({
      status: response.status,
      statusText: response.statusText,
      headers: Object.fromEntries(response.headers.entries()),
      data: responseData
    }, 200); // Always return 200 from proxy, let client handle actual status

  } catch (error: any) {
    console.error('WordPress proxy error:', error);
    
    return c.json({
      status: 500,
      statusText: 'Internal Server Error',
      headers: {},
      data: {
        error: 'WordPress proxy request failed',
        message: error.message,
        details: error.stack
      }
    }, 200); // Return 200 from proxy with error details
  }
});

// Health check endpoint
app.get('/wordpress-proxy/health', async (c) => {
  return c.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'wordpress-proxy'
  });
});

// Test WordPress connection endpoint
app.post('/wordpress-proxy/test', async (c) => {
  try {
    const { wpBaseUrl } = await c.req.json();
    
    if (!wpBaseUrl) {
      return c.json({ error: 'WordPress base URL is required' }, 400);
    }

    console.log('Testing WordPress connection to:', wpBaseUrl);
    
    const response = await fetch(`${wpBaseUrl}/wp-json/wp/v2/posts?per_page=1`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'EliteQ-Admin-Panel/1.0',
      },
    });

    let responseData;
    try {
      responseData = await response.json();
    } catch {
      responseData = await response.text();
    }

    return c.json({
      success: response.ok,
      status: response.status,
      statusText: response.statusText,
      message: response.ok ? 'WordPress connection successful' : 'WordPress connection failed',
      data: responseData
    });
    
  } catch (error: any) {
    console.log('WordPress connection test error:', error.message);
    return c.json({
      success: false,
      status: 500,
      error: error.message,
      message: 'WordPress connection test failed'
    }, 500);
  }
});

export default app;