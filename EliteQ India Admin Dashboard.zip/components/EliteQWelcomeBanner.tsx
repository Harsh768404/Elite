import React, { useState, useEffect } from 'react';
import { CheckCircle, Calendar, TrendingUp, Award, Star } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useAuth } from '../contexts/AuthContext';
import { eliteqDataService } from '../utils/eliteq-real-data-service';
import { wooCommerceApi } from '../utils/woocommerce-api';

interface EliteQWelcomeBannerProps {
  userRole: 'admin' | 'vendor';
  userName?: string;
  userAvatar?: string;
  isVerified?: boolean;
}

export function EliteQWelcomeBanner({ 
  userRole, 
  userName = 'Admin User', 
  userAvatar,
  isVerified = true 
}: EliteQWelcomeBannerProps) {
  const { user } = useAuth();
  const [todaysEarnings, setTodaysEarnings] = useState('₹0.00');
  const [isLoadingEarnings, setIsLoadingEarnings] = useState(true);

  const currentDate = new Date();
  const formattedDate = currentDate.toLocaleDateString('en-IN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  // Get real user data from auth context
  const realUserName = user?.display_name || userName || 'User';
  const realUserAvatar = user?.avatar_url || userAvatar;
  const realIsVerified = user?.isRealData || isVerified;
  const lastLoginTime = user?.authenticated_at ? 
    new Date(user.authenticated_at).toLocaleString('en-IN', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    }) : 'Recently';

  console.log('👋 ===== WELCOME BANNER WITH REAL USER DATA =====');
  console.log('👤 Real User Name:', realUserName);
  console.log('🖼️ Real User Avatar:', realUserAvatar);
  console.log('✅ Real Is Verified:', realIsVerified);
  console.log('🕐 Real Last Login:', lastLoginTime);

  // Fetch today's earnings based on user role
  useEffect(() => {
    const fetchTodaysEarnings = async () => {
      if (!user) return;

      try {
        setIsLoadingEarnings(true);
        console.log('💰 Fetching today\'s real earnings for role:', userRole);

        const today = new Date();
        const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
        const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000 - 1);

        let earnings = 0;

        if (userRole === 'admin') {
          // Admin: Get today's marketplace revenue
          try {
            const ordersResponse = await wooCommerceApi.getOrders({
              after: todayStart.toISOString(),
              before: todayEnd.toISOString(),
              status: 'completed',
              per_page: 100
            });

            if (ordersResponse.data && Array.isArray(ordersResponse.data)) {
              ordersResponse.data.forEach((order: any) => {
                if (order.total) {
                  earnings += parseFloat(order.total);
                }
              });
            }

            console.log('💰 Admin today\'s earnings from completed orders:', earnings);

          } catch (adminError) {
            console.warn('⚠️ Error fetching admin earnings:', adminError);
          }

        } else if (userRole === 'vendor') {
          // Vendor: Get today's vendor-specific earnings
          try {
            const vendorData = await eliteqDataService.getVendorDashboardData(user.id);
            
            if (vendorData && vendorData.todaysEarnings) {
              earnings = vendorData.todaysEarnings;
            }

            console.log('💰 Vendor today\'s earnings:', earnings);

          } catch (vendorError) {
            console.warn('⚠️ Error fetching vendor earnings:', vendorError);
          }
        }

        const formattedEarnings = `₹${earnings.toLocaleString('en-IN', { 
          minimumFractionDigits: 2, 
          maximumFractionDigits: 2 
        })}`;

        setTodaysEarnings(formattedEarnings);
        console.log('✅ Today\'s earnings formatted:', formattedEarnings);

      } catch (error) {
        console.error('❌ Failed to fetch today\'s earnings:', error);
        setTodaysEarnings('₹0.00');
      } finally {
        setIsLoadingEarnings(false);
      }
    };

    fetchTodaysEarnings();
  }, [user, userRole]);

  const getGreeting = () => {
    const hour = currentDate.getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const getInitials = (name: string): string => {
    if (!name) return 'U';
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Card className="relative overflow-hidden mb-8 bg-gradient-to-br from-blue-50 via-white to-indigo-50 dark:from-blue-900/10 dark:via-gray-900 dark:to-indigo-900/10 border-blue-200 dark:border-blue-800">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-4 -right-4 w-24 h-24 bg-blue-100 dark:bg-blue-900/20 rounded-full opacity-50"></div>
        <div className="absolute top-8 -right-8 w-16 h-16 bg-indigo-100 dark:bg-indigo-900/20 rounded-full opacity-30"></div>
        <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-gradient-to-br from-blue-200 to-indigo-200 dark:from-blue-800/20 dark:to-indigo-800/20 rounded-full opacity-20"></div>
        
        {/* Geometric Pattern */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <div 
                key={i} 
                className="w-1 h-1 bg-blue-300 dark:bg-blue-700 rounded-full opacity-40"
                style={{ 
                  animationDelay: `${i * 0.2}s`,
                  animation: 'pulse 2s infinite'
                }}
              ></div>
            ))}
          </div>
        </div>
      </div>

      <div className="relative p-6 lg:p-8">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between space-y-4 lg:space-y-0">
          {/* Left Side - Welcome Message with Real User Data */}
          <div className="flex items-center space-x-4">
            {/* User Avatar */}
            <div className="relative">
              <div className="w-16 h-16 lg:w-20 lg:h-20 rounded-full border-4 border-white dark:border-gray-800 shadow-lg overflow-hidden bg-gradient-to-br from-blue-500 to-indigo-600">
                {realUserAvatar ? (
                  <ImageWithFallback
                    src={realUserAvatar}
                    alt={realUserName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-white text-2xl font-bold">
                    {getInitials(realUserName)}
                  </div>
                )}
              </div>
              
              {/* Status Badge */}
              {realIsVerified && (
                <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 border-2 border-white dark:border-gray-800 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-3 h-3 text-white" />
                </div>
              )}
            </div>

            {/* Welcome Text */}
            <div>
              <div className="flex items-center space-x-2 mb-1">
                <h1 className="text-xl lg:text-2xl font-bold text-gray-900 dark:text-white">
                  {getGreeting()}, {realUserName}!
                </h1>
                {realIsVerified && (
                  <Badge variant="default" className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400 border-green-200 dark:border-green-800">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Verified {userRole === 'admin' ? 'Admin' : 'Vendor'}
                  </Badge>
                )}
              </div>
              
              <div className="flex items-center space-x-3 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>{formattedDate}</span>
                </div>
                <div className="hidden sm:flex items-center space-x-1">
                  <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                  <span>EliteQ India Dashboard</span>
                </div>
              </div>

              {/* Quick Status Badges */}
              <div className="flex items-center space-x-2 mt-2">
                <Badge variant="secondary" className="text-xs">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  Active
                </Badge>
                {userRole === 'admin' && (
                  <Badge variant="secondary" className="text-xs">
                    <Award className="w-3 h-3 mr-1" />
                    Full Access
                  </Badge>
                )}
                {userRole === 'vendor' && (
                  <Badge variant="secondary" className="text-xs">
                    <Star className="w-3 h-3 mr-1" />
                    Premium Seller
                  </Badge>
                )}
                {user?.roles && user.roles.length > 0 && (
                  <Badge variant="outline" className="text-xs">
                    Roles: {user.roles.slice(0, 2).join(', ')}
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {/* Right Side - Real Quick Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 w-full lg:w-auto">
            <div className="text-center p-3 bg-white/50 dark:bg-gray-800/50 rounded-lg border border-white/20 dark:border-gray-700/20">
              <div className="text-lg lg:text-xl font-bold text-blue-600 dark:text-blue-400">
                99%
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">
                Uptime
              </div>
            </div>
            
            <div className="text-center p-3 bg-white/50 dark:bg-gray-800/50 rounded-lg border border-white/20 dark:border-gray-700/20">
              <div className="text-lg lg:text-xl font-bold text-green-600 dark:text-green-400">
                24/7
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">
                Support
              </div>
            </div>

            <div className="col-span-2 lg:col-span-1 text-center p-3 bg-white/50 dark:bg-gray-800/50 rounded-lg border border-white/20 dark:border-gray-700/20">
              <div className="text-lg lg:text-xl font-bold text-purple-600 dark:text-purple-400">
                {isLoadingEarnings ? '₹---.--' : todaysEarnings}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">
                Today's Earnings
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section - Security Badge with Real Data */}
        <div className="mt-6 pt-4 border-t border-blue-200/50 dark:border-blue-800/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span>Secure connection to EliteQ.in</span>
              <Badge variant="outline" className="text-xs border-green-200 text-green-700 dark:border-green-800 dark:text-green-400">
                SSL Protected
              </Badge>
            </div>
            
            <div className="hidden lg:flex items-center space-x-4 text-xs text-gray-500 dark:text-gray-400">
              <span>Last login: {lastLoginTime}</span>
              <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
              <span>User ID: {user?.id || 'N/A'}</span>
              {user?.email && (
                <>
                  <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                  <span>{user.email}</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}