import React, { useEffect } from 'react';
import { ModernEliteQDashboard } from '../components/ModernEliteQDashboard';
import { EliteQErrorFallback } from '../components/EliteQErrorFallback';

export default function VendorDashboard() {
  useEffect(() => {
    // Set page title for vendor dashboard
    document.title = 'Vendor Dashboard - EliteQ India Marketplace';
    
    // Log vendor dashboard access
    console.log('🎯 Vendor Dashboard loaded');
    console.log('🏪 User Role: Vendor');
    console.log('🔐 Access Level: Store Management');
    console.log('📊 Dashboard Type: Vendor Control Panel');
    
    // Vendor-specific initialization
    const initializeVendorDashboard = () => {
      try {
        // Set vendor-specific environment flags
        if (typeof window !== 'undefined') {
          (window as any).ELITEQ_USER_ROLE = 'vendor';
          (window as any).ELITEQ_ACCESS_LEVEL = 'store';
          (window as any).ELITEQ_DASHBOARD_TYPE = 'vendor';
        }
        
        console.log('✅ Vendor dashboard initialized successfully');
      } catch (error) {
        console.error('❌ Error initializing vendor dashboard:', error);
      }
    };

    initializeVendorDashboard();

    // Cleanup on unmount
    return () => {
      if (typeof window !== 'undefined') {
        delete (window as any).ELITEQ_USER_ROLE;
        delete (window as any).ELITEQ_ACCESS_LEVEL;
        delete (window as any).ELITEQ_DASHBOARD_TYPE;
      }
    };
  }, []);

  try {
    return (
      <div className="vendor-dashboard-container">
        {/* Vendor-specific header meta information */}
        <div className="sr-only">
          <h1>EliteQ India Vendor Dashboard</h1>
          <p>WordPress + WooCommerce + Dokan Pro Vendor Management</p>
          <p>Manage your store, products, orders, and customer interactions</p>
        </div>

        {/* Modern Vendor Dashboard */}
        <ModernEliteQDashboard userRole="vendor" />
      </div>
    );
  } catch (error) {
    console.error('❌ Vendor Dashboard render error:', error);
    return (
      <EliteQErrorFallback 
        error={error as Error}
        resetError={() => window.location.reload()}
        context="Vendor Dashboard"
      />
    );
  }
}