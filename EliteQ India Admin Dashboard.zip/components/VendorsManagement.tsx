import React, { useState, useEffect } from 'react';
import { 
  Store, Search, Filter, Eye, Edit, AlertTriangle, 
  UserCheck, Mail, Calendar, MapPin, Phone, Shield,
  Star, Package, ShoppingCart, DollarSign, Loader2,
  ChevronDown, ChevronUp, MoreVertical, Ban, CheckCircle,
  Download, RefreshCw, Globe, Award, Activity
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import { Alert, AlertDescription } from './ui/alert';
import { Skeleton } from './ui/skeleton';
import { Progress } from './ui/progress';

interface Vendor {
  id: number;
  store_name: string;
  shop_name?: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  show_email: boolean;
  address: {
    street_1: string;
    street_2: string;
    city: string;
    zip: string;
    country: string;
    state: string;
  };
  location: string;
  banner: string;
  icon: string;
  gravatar: string;
  shop_url: string;
  products_per_page: number;
  show_more_product_tab: boolean;
  toc_enabled: boolean;
  store_toc: string;
  featured: boolean;
  rating: {
    rating: number;
    count: number;
  };
  enabled: boolean;
  registered: string;
  last_login?: string;
  social?: {
    fb?: string;
    twitter?: string;
    pinterest?: string;
    linkedin?: string;
    youtube?: string;
    instagram?: string;
    flickr?: string;
  };
  payment?: {
    bank?: any;
    paypal?: any;
    skrill?: any;
  };
  admin_commission_type: string;
  admin_additional_fee: number;
  admin_commission: number;
}

interface VendorStats {
  total: number;
  active: number;
  inactive: number;
  pending: number;
  featured: number;
}

const VendorsManagement: React.FC = () => {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState<VendorStats>({
    total: 0,
    active: 0,
    inactive: 0,
    pending: 0,
    featured: 0
  });

  const vendorsPerPage = 20;

  // Fetch vendors from WordPress/Dokan API
  const fetchVendors = async (page = 1, search = '', status = 'all') => {
    try {
      setLoading(page === 1);
      setError(null);

      // Get WordPress base URL and credentials
      const baseUrl = (window as any).ENV?.WORDPRESS_BASE_URL || 'https://eliteq.in';
      const consumerKey = (window as any).ENV?.WOOCOMMERCE_CONSUMER_KEY;
      const consumerSecret = (window as any).ENV?.WOOCOMMERCE_CONSUMER_SECRET;

      if (!consumerKey || !consumerSecret) {
        throw new Error('WooCommerce credentials not found');
      }

      // Build API URL for vendors (Dokan endpoint)
      const params = new URLSearchParams({
        consumer_key: consumerKey,
        consumer_secret: consumerSecret,
        page: page.toString(),
        per_page: vendorsPerPage.toString(),
        orderby: 'registered',
        order: 'desc'
      });

      if (search.trim()) {
        params.append('search', search.trim());
      }

      if (status !== 'all') {
        params.append('status', status);
      }

      // Try Dokan API first, fallback to WooCommerce customers with shop_manager role
      let response;
      try {
        response = await fetch(`${baseUrl}/wp-json/dokan/v1/stores?${params}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }
        });

        if (!response.ok && response.status === 404) {
          // Fallback to WooCommerce customers API filtering for vendors
          const customerParams = new URLSearchParams({
            consumer_key: consumerKey,
            consumer_secret: consumerSecret,
            role: 'shop_manager,vendor,dokan_vendor',
            page: page.toString(),
            per_page: vendorsPerPage.toString(),
            orderby: 'date_registered',
            order: 'desc'
          });

          if (search.trim()) {
            customerParams.append('search', search.trim());
          }

          response = await fetch(`${baseUrl}/wp-json/wc/v3/customers?${customerParams}`, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json'
            }
          });
        }
      } catch (dokanError) {
        console.warn('⚠️ Dokan API not available, falling back to WooCommerce customers');
        
        // Fallback to WooCommerce customers API
        const customerParams = new URLSearchParams({
          consumer_key: consumerKey,
          consumer_secret: consumerSecret,
          role: 'shop_manager',
          page: page.toString(),
          per_page: vendorsPerPage.toString(),
          orderby: 'date_registered',
          order: 'desc'
        });

        if (search.trim()) {
          customerParams.append('search', search.trim());
        }

        response = await fetch(`${baseUrl}/wp-json/wc/v3/customers?${customerParams}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }
        });
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const totalVendors = parseInt(response.headers.get('X-WP-Total') || '0');
      const totalPagesCount = parseInt(response.headers.get('X-WP-TotalPages') || '1');

      // Transform data if it's from customers API
      const transformedData = data.map((item: any) => {
        if (item.store_name) {
          // Already Dokan vendor format
          return item;
        } else {
          // Transform customer to vendor-like format
          return {
            id: item.id,
            store_name: item.username || `${item.first_name} ${item.last_name}`.trim() || `Store #${item.id}`,
            first_name: item.first_name || '',
            last_name: item.last_name || '',
            email: item.email,
            phone: item.billing?.phone || '',
            address: {
              street_1: item.billing?.address_1 || '',
              street_2: item.billing?.address_2 || '',
              city: item.billing?.city || '',
              zip: item.billing?.postcode || '',
              country: item.billing?.country || '',
              state: item.billing?.state || ''
            },
            location: `${item.billing?.city || ''}, ${item.billing?.state || ''}`.trim().replace(/^,|,$/, ''),
            shop_url: `${baseUrl}/store/${item.username || item.id}`,
            enabled: true, // Assume active if they're shop managers
            registered: item.date_created,
            last_login: item.date_modified,
            rating: { rating: 0, count: 0 },
            featured: false,
            admin_commission_type: 'percentage',
            admin_commission: 10
          };
        }
      });

      setVendors(transformedData);
      setTotalPages(totalPagesCount);

      // Calculate stats
      const newStats: VendorStats = {
        total: totalVendors,
        active: transformedData.filter((v: Vendor) => v.enabled).length,
        inactive: transformedData.filter((v: Vendor) => !v.enabled).length,
        pending: 0, // Would need additional API call to determine
        featured: transformedData.filter((v: Vendor) => v.featured).length
      };
      setStats(newStats);

      console.log('✅ Vendors loaded successfully:', {
        count: transformedData.length,
        total: totalVendors,
        pages: totalPagesCount,
        stats: newStats
      });

    } catch (error) {
      console.error('❌ Failed to fetch vendors:', error);
      setError(error instanceof Error ? error.message : 'Failed to fetch vendors');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchVendors(currentPage, searchTerm, statusFilter);
  }, [currentPage, statusFilter]);

  // Search handler with debouncing
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchTerm !== '') {
        setCurrentPage(1);
        fetchVendors(1, searchTerm, statusFilter);
      } else if (searchTerm === '') {
        fetchVendors(currentPage, '', statusFilter);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchTerm]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchVendors(currentPage, searchTerm, statusFilter);
  };

  const handleVendorAction = async (vendorId: number, action: 'view' | 'edit' | 'suspend') => {
    console.log(`🎯 Vendor ${action} action for ID:`, vendorId);
    
    switch (action) {
      case 'view':
        // In a real implementation, this would open a detailed view
        alert(`View vendor details for ID: ${vendorId}`);
        break;
      case 'edit':
        // In a real implementation, this would open edit form
        alert(`Edit vendor for ID: ${vendorId}`);
        break;
      case 'suspend':
        // In a real implementation, this would suspend/unsuspend the vendor
        if (window.confirm('Are you sure you want to suspend this vendor?')) {
          alert(`Suspend vendor action for ID: ${vendorId}`);
        }
        break;
    }
  };

  const getStatusBadge = (vendor: Vendor) => {
    if (vendor.enabled) {
      return (
        <Badge variant="default" className="bg-green-100 text-green-700 border-green-300">
          <CheckCircle className="w-3 h-3 mr-1" />
          Active
        </Badge>
      );
    } else {
      return (
        <Badge variant="secondary" className="bg-red-100 text-red-700 border-red-300">
          <Ban className="w-3 h-3 mr-1" />
          Inactive
        </Badge>
      );
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return 'Invalid date';
    }
  };

  const getRatingStars = (rating: number) => {
    return [...Array(5)].map((_, i) => (
      <Star 
        key={i} 
        className={`w-3 h-3 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
      />
    ));
  };

  if (loading && vendors.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Vendors Management</h2>
            <p className="text-muted-foreground">Manage your marketplace vendors</p>
          </div>
          <Skeleton className="h-10 w-32" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>

        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48" />
          </CardHeader>
          <CardContent className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Store className="w-6 h-6 text-green-600" />
            Vendors Management
          </h2>
          <p className="text-muted-foreground">
            Manage your marketplace vendors and their stores
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleRefresh}
            disabled={refreshing}
          >
            {refreshing ? (
              <Loader2 className="w-4 h-4 animate-spin mr-1" />
            ) : (
              <RefreshCw className="w-4 h-4 mr-1" />
            )}
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-1" />
            Export
          </Button>
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription>
            <strong>Error loading vendors:</strong> {error}
          </AlertDescription>
        </Alert>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Store className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm text-muted-foreground">Total Vendors</p>
                <p className="text-2xl font-bold">{stats.total.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm text-muted-foreground">Active</p>
                <p className="text-2xl font-bold">{stats.active.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Ban className="w-5 h-5 text-red-600" />
              <div>
                <p className="text-sm text-muted-foreground">Inactive</p>
                <p className="text-2xl font-bold">{stats.inactive.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-orange-600" />
              <div>
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold">{stats.pending.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-sm text-muted-foreground">Featured</p>
                <p className="text-2xl font-bold">{stats.featured.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search vendors by name, email, or store name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Vendors Table */}
      <Card>
        <CardHeader>
          <CardTitle>Vendors List</CardTitle>
          <CardDescription>
            Showing {vendors.length} of {stats.total} vendors
          </CardDescription>
        </CardHeader>
        <CardContent>
          {vendors.length === 0 ? (
            <div className="text-center py-8">
              <Store className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground">No vendors found</p>
            </div>
          ) : (
            <div className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vendor</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Store</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Rating</TableHead>
                    <TableHead>Commission</TableHead>
                    <TableHead>Registered</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vendors.map((vendor) => (
                    <TableRow key={vendor.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center text-white font-medium">
                            {(vendor.store_name || vendor.first_name || 'S')[0].toUpperCase()}
                          </div>
                          <div>
                            <div className="font-medium">{vendor.store_name}</div>
                            <div className="text-sm text-muted-foreground">
                              {vendor.first_name} {vendor.last_name} (ID: {vendor.id})
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Mail className="w-3 h-3 text-muted-foreground" />
                            <span className="text-sm">{vendor.email}</span>
                          </div>
                          {vendor.phone && (
                            <div className="flex items-center gap-2">
                              <Phone className="w-3 h-3 text-muted-foreground" />
                              <span className="text-sm">{vendor.phone}</span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {vendor.shop_url && (
                            <div className="flex items-center gap-2">
                              <Globe className="w-3 h-3 text-muted-foreground" />
                              <a 
                                href={vendor.shop_url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-sm text-blue-600 hover:underline"
                              >
                                Visit Store
                              </a>
                            </div>
                          )}
                          {vendor.location && (
                            <div className="flex items-center gap-2">
                              <MapPin className="w-3 h-3 text-muted-foreground" />
                              <span className="text-xs text-muted-foreground">{vendor.location}</span>
                            </div>
                          )}
                          {vendor.featured && (
                            <Badge variant="outline" className="text-xs">
                              <Award className="w-3 h-3 mr-1" />
                              Featured
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(vendor)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {getRatingStars(vendor.rating?.rating || 0)}
                          <span className="text-xs text-muted-foreground ml-1">
                            ({vendor.rating?.count || 0})
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {vendor.admin_commission}% {vendor.admin_commission_type}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">{formatDate(vendor.registered)}</div>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleVendorAction(vendor.id, 'view')}>
                              <Eye className="w-4 h-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleVendorAction(vendor.id, 'edit')}>
                              <Edit className="w-4 h-4 mr-2" />
                              Edit Vendor
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleVendorAction(vendor.id, 'suspend')}
                              className="text-red-600"
                            >
                              <Ban className="w-4 h-4 mr-2" />
                              {vendor.enabled ? 'Suspend' : 'Activate'}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    Page {currentPage} of {totalPages}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1 || loading}
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                      disabled={currentPage === totalPages || loading}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default VendorsManagement;