import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Alert, AlertDescription } from './ui/alert';
import { 
  CheckCircle, XCircle, AlertCircle, RefreshCw, Settings, Globe, 
  Database, ShoppingCart, Users, Package, Zap, Key, Shield 
} from 'lucide-react';
import { wooCommerceApi, WooCommerceApiError } from '../utils/woocommerce-api';
import { wordPressAuth } from '../utils/wordpress-auth';
import { envHelpers } from '../utils/env-config';

interface SystemCheck {
  name: string;
  description: string;
  status: 'checking' | 'success' | 'error' | 'warning';
  details?: string;
  icon: React.ComponentType<any>;
}

export const EliteQSystemVerification: React.FC = () => {
  const [checks, setChecks] = useState<SystemCheck[]>([
    {
      name: 'Environment Configuration',
      description: 'Verify environment variables are loaded',
      status: 'checking',
      icon: Settings
    },
    {
      name: 'EliteQ.in Connectivity',
      description: 'Test connection to eliteq.in WordPress site',
      status: 'checking',
      icon: Globe
    },
    {
      name: 'WooCommerce API Access',
      description: 'Verify WooCommerce REST API credentials',
      status: 'checking',
      icon: ShoppingCart
    },
    {
      name: 'Products Data Fetch',
      description: 'Fetch real products from EliteQ store',
      status: 'checking',
      icon: Package
    },
    {
      name: 'Orders Data Fetch',
      description: 'Fetch real orders from EliteQ store',
      status: 'checking',
      icon: Database
    },
    {
      name: 'Customers Data Fetch',
      description: 'Fetch real customers from EliteQ store',
      status: 'checking',
      icon: Users
    }
  ]);

  const [isRunning, setIsRunning] = useState(false);
  const [testResults, setTestResults] = useState<any>({});

  const updateCheckStatus = (index: number, status: SystemCheck['status'], details?: string) => {
    setChecks(prev => prev.map((check, i) => 
      i === index ? { ...check, status, details } : check
    ));
  };

  const runSystemVerification = async () => {
    setIsRunning(true);
    const results: any = {};

    try {
      // Check 1: Environment Configuration
      console.log('🔄 Running system verification for EliteQ India...');
      updateCheckStatus(0, 'checking');
      
      try {
        const envStatus = envHelpers.testEnvAccess();
        const hasWooCommerce = envHelpers.hasWooCommerceCredentials();
        const hasJWT = envHelpers.hasWordPressJWTCredentials();
        
        if (envStatus.success && hasWooCommerce && hasJWT) {
          updateCheckStatus(0, 'success', `Environment ready: ${envStatus.details.variablesFound} variables loaded`);
          results.environment = { success: true, ...envStatus.details };
        } else {
          updateCheckStatus(0, 'error', `Missing credentials: WC=${hasWooCommerce}, JWT=${hasJWT}`);
          results.environment = { success: false, error: 'Missing credentials' };
        }
      } catch (error) {
        updateCheckStatus(0, 'error', `Environment check failed: ${error}`);
        results.environment = { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
      }

      // Check 2: EliteQ.in Connectivity
      updateCheckStatus(1, 'checking');
      
      try {
        const connectivityTest = await fetch('https://eliteq.in/wp-json/wp/v2/', {
          method: 'GET',
          headers: { 'Accept': 'application/json' }
        });
        
        if (connectivityTest.ok) {
          updateCheckStatus(1, 'success', `EliteQ.in responding (${connectivityTest.status})`);
          results.connectivity = { success: true, status: connectivityTest.status };
        } else {
          updateCheckStatus(1, 'error', `EliteQ.in unreachable (${connectivityTest.status})`);
          results.connectivity = { success: false, status: connectivityTest.status };
        }
      } catch (error) {
        updateCheckStatus(1, 'error', `Network error: ${error}`);
        results.connectivity = { success: false, error: error instanceof Error ? error.message : 'Network error' };
      }

      // Check 3: WooCommerce API Access
      updateCheckStatus(2, 'checking');
      
      try {
        const connectionTest = await wooCommerceApi.testConnection();
        
        if (connectionTest.isConnected) {
          updateCheckStatus(2, 'success', `WooCommerce API connected (${connectionTest.latency}ms)`);
          results.woocommerce = { success: true, latency: connectionTest.latency };
        } else {
          updateCheckStatus(2, 'error', `WooCommerce API failed: ${connectionTest.error}`);
          results.woocommerce = { success: false, error: connectionTest.error };
        }
      } catch (error) {
        updateCheckStatus(2, 'error', `WooCommerce test failed: ${error}`);
        results.woocommerce = { success: false, error: error instanceof Error ? error.message : 'API test failed' };
      }

      // Check 4: Products Data Fetch
      updateCheckStatus(3, 'checking');
      
      try {
        const productsResponse = await wooCommerceApi.getProducts({ per_page: 5 });
        
        if (productsResponse.data && Array.isArray(productsResponse.data)) {
          updateCheckStatus(3, 'success', `Fetched ${productsResponse.data.length} products from EliteQ store`);
          results.products = { success: true, count: productsResponse.data.length, sample: productsResponse.data[0]?.name };
        } else {
          updateCheckStatus(3, 'warning', 'Products API responded but no data');
          results.products = { success: false, error: 'No product data' };
        }
      } catch (error) {
        updateCheckStatus(3, 'error', `Products fetch failed: ${error instanceof WooCommerceApiError ? error.message : error}`);
        results.products = { success: false, error: error instanceof Error ? error.message : 'Products fetch failed' };
      }

      // Check 5: Orders Data Fetch
      updateCheckStatus(4, 'checking');
      
      try {
        const ordersResponse = await wooCommerceApi.getOrders({ per_page: 5 });
        
        if (ordersResponse.data && Array.isArray(ordersResponse.data)) {
          updateCheckStatus(4, 'success', `Fetched ${ordersResponse.data.length} orders from EliteQ store`);
          results.orders = { success: true, count: ordersResponse.data.length };
        } else {
          updateCheckStatus(4, 'warning', 'Orders API responded but no data');
          results.orders = { success: false, error: 'No order data' };
        }
      } catch (error) {
        updateCheckStatus(4, 'error', `Orders fetch failed: ${error instanceof WooCommerceApiError ? error.message : error}`);
        results.orders = { success: false, error: error instanceof Error ? error.message : 'Orders fetch failed' };
      }

      // Check 6: Customers Data Fetch
      updateCheckStatus(5, 'checking');
      
      try {
        const customersResponse = await wooCommerceApi.getCustomers({ per_page: 5 });
        
        if (customersResponse.data && Array.isArray(customersResponse.data)) {
          updateCheckStatus(5, 'success', `Fetched ${customersResponse.data.length} customers from EliteQ store`);
          results.customers = { success: true, count: customersResponse.data.length };
        } else {
          updateCheckStatus(5, 'warning', 'Customers API responded but no data');
          results.customers = { success: false, error: 'No customer data' };
        }
      } catch (error) {
        updateCheckStatus(5, 'error', `Customers fetch failed: ${error instanceof WooCommerceApiError ? error.message : error}`);
        results.customers = { success: false, error: error instanceof Error ? error.message : 'Customers fetch failed' };
      }

    } finally {
      setIsRunning(false);
      setTestResults(results);
      console.log('🏁 System verification completed for EliteQ India');
      console.log('📊 Results:', results);
    }
  };

  useEffect(() => {
    // Auto-run verification on component mount
    runSystemVerification();
  }, []);

  const getStatusIcon = (status: SystemCheck['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'warning':
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case 'checking':
        return <RefreshCw className="h-5 w-5 text-blue-500 animate-spin" />;
    }
  };

  const getStatusBadge = (status: SystemCheck['status']) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">Passed</Badge>;
      case 'error':
        return <Badge variant="destructive">Failed</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400">Warning</Badge>;
      case 'checking':
        return <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400">Testing...</Badge>;
    }
  };

  const overallStatus = () => {
    const errorCount = checks.filter(c => c.status === 'error').length;
    const successCount = checks.filter(c => c.status === 'success').length;
    const warningCount = checks.filter(c => c.status === 'warning').length;
    
    if (errorCount > 0) return 'error';
    if (warningCount > 0) return 'warning';
    if (successCount === checks.length) return 'success';
    return 'checking';
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-6 w-6 text-blue-600" />
          EliteQ India System Verification
        </CardTitle>
        <CardDescription>
          Comprehensive verification of EliteQ.in WordPress and WooCommerce integration
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Overall Status */}
        <Alert className={`${
          overallStatus() === 'success' ? 'border-green-200 bg-green-50 dark:bg-green-900/20' :
          overallStatus() === 'error' ? 'border-red-200 bg-red-50 dark:bg-red-900/20' :
          overallStatus() === 'warning' ? 'border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20' :
          'border-blue-200 bg-blue-50 dark:bg-blue-900/20'
        }`}>
          <div className="flex items-center gap-2">
            {getStatusIcon(overallStatus())}
            <AlertDescription className="font-medium">
              {overallStatus() === 'success' && 'All systems operational - EliteQ India integration ready'}
              {overallStatus() === 'error' && 'System issues detected - please review failed checks'}
              {overallStatus() === 'warning' && 'System operational with warnings - some features may be limited'}
              {overallStatus() === 'checking' && 'Running comprehensive system verification...'}
            </AlertDescription>
          </div>
        </Alert>

        {/* System Checks */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">System Checks</h3>
            <Button 
              onClick={runSystemVerification} 
              disabled={isRunning}
              variant="outline"
              size="sm"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                  Running Tests...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Rerun Tests
                </>
              )}
            </Button>
          </div>

          <div className="space-y-3">
            {checks.map((check, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <check.icon className="h-5 w-5 text-gray-500" />
                  <div>
                    <div className="font-medium">{check.name}</div>
                    <div className="text-sm text-gray-500">{check.description}</div>
                    {check.details && (
                      <div className="text-xs text-gray-400 mt-1 font-mono">
                        {check.details}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(check.status)}
                  {getStatusBadge(check.status)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Test Results Summary */}
        {Object.keys(testResults).length > 0 && (
          <>
            <Separator />
            <div>
              <h3 className="font-semibold mb-3">Detailed Test Results</h3>
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <pre className="text-xs text-gray-600 dark:text-gray-400 whitespace-pre-wrap">
                  {JSON.stringify(testResults, null, 2)}
                </pre>
              </div>
            </div>
          </>
        )}

        {/* Integration Status */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700">
            <div className="flex items-center gap-2 mb-2">
              <Globe className="h-4 w-4 text-blue-600" />
              <span className="font-medium text-blue-900 dark:text-blue-100">WordPress Site</span>
            </div>
            <p className="text-sm text-blue-800 dark:text-blue-200">eliteq.in</p>
          </div>

          <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-700">
            <div className="flex items-center gap-2 mb-2">
              <ShoppingCart className="h-4 w-4 text-green-600" />
              <span className="font-medium text-green-900 dark:text-green-100">WooCommerce API</span>
            </div>
            <p className="text-sm text-green-800 dark:text-green-200">
              {testResults.woocommerce?.success ? 'Connected' : 'Disconnected'}
            </p>
          </div>

          <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-700">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="h-4 w-4 text-purple-600" />
              <span className="font-medium text-purple-900 dark:text-purple-100">Real Data</span>
            </div>
            <p className="text-sm text-purple-800 dark:text-purple-200">
              {testResults.products?.success && testResults.orders?.success ? 'Available' : 'Limited'}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default EliteQSystemVerification;