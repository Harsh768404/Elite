import { useState, useEffect, useCallback, useRef } from 'react';
import { webhookService } from '../utils/webhook-service';
import { WooCommerceAPI } from '../utils/woocommerce-api';
import { jwtAuth } from '../utils/jwt-auth';

interface RealTimeUpdateState {
  isConnected: boolean;
  lastUpdate: string | null;
  updateCount: number;
  errors: string[];
  webhookStatus: any;
  jwtStatus: any;
  mode: 'webhook' | 'polling' | 'jwt';
}

interface UpdateEvent {
  type: 'order' | 'product' | 'customer' | 'webhook' | 'jwt' | 'data';
  action: 'created' | 'updated' | 'deleted' | 'connected' | 'disconnected' | 'refreshed';
  data: any;
  timestamp: string;
}

export const useRealTimeUpdates = () => {
  const [state, setState] = useState<RealTimeUpdateState>({
    isConnected: false,
    lastUpdate: null,
    updateCount: 0,
    errors: [],
    webhookStatus: null,
    jwtStatus: null,
    mode: 'jwt'
  });

  const [recentUpdates, setRecentUpdates] = useState<UpdateEvent[]>([]);
  const updateCallbacksRef = useRef<Map<string, Array<(event: UpdateEvent) => void>>>(new Map());
  const maxRecentUpdates = 50;
  const initializationRef = useRef<boolean>(false);

  // Add update event
  const addUpdateEvent = useCallback((event: UpdateEvent) => {
    setRecentUpdates(prev => {
      const newUpdates = [event, ...prev].slice(0, maxRecentUpdates);
      return newUpdates;
    });

    setState(prev => ({
      ...prev,
      lastUpdate: event.timestamp,
      updateCount: prev.updateCount + 1
    }));

    // Notify specific event listeners
    const listeners = updateCallbacksRef.current.get(event.type) || [];
    listeners.forEach(callback => {
      try {
        callback(event);
      } catch (error) {
        console.error(`Error in real-time update callback for ${event.type}:`, error);
      }
    });

    // Notify general listeners
    const generalListeners = updateCallbacksRef.current.get('*') || [];
    generalListeners.forEach(callback => {
      try {
        callback(event);
      } catch (error) {
        console.error('Error in general real-time update callback:', error);
      }
    });
  }, []);

  // Subscribe to specific update types
  const subscribe = useCallback((type: string, callback: (event: UpdateEvent) => void) => {
    if (!updateCallbacksRef.current.has(type)) {
      updateCallbacksRef.current.set(type, []);
    }
    updateCallbacksRef.current.get(type)!.push(callback);

    return () => {
      const listeners = updateCallbacksRef.current.get(type);
      if (listeners) {
        const index = listeners.indexOf(callback);
        if (index > -1) {
          listeners.splice(index, 1);
        }
      }
    };
  }, []);

  // Initialize real-time updates with JWT and webhook integration
  const initialize = useCallback(async () => {
    if (initializationRef.current) {
      console.log('🔄 Real-time updates already initialized');
      return;
    }

    try {
      console.log('🚀 Initializing real-time updates for EliteQ India with JWT + Webhooks...');
      initializationRef.current = true;

      // Initialize JWT authentication
      let jwtInitialized = false;
      try {
        await jwtAuth.generateToken();
        jwtInitialized = true;
        setState(prev => ({ ...prev, mode: 'jwt', isConnected: true }));
        console.log('✅ JWT authentication initialized');
        
        addUpdateEvent({
          type: 'jwt',
          action: 'connected',
          data: { method: 'jwt', status: 'active' },
          timestamp: new Date().toISOString()
        });
      } catch (jwtError) {
        console.log('⚠️ JWT initialization failed:', jwtError);
        setState(prev => ({ 
          ...prev, 
          errors: [...prev.errors, 'JWT authentication failed - using Basic Auth fallback']
        }));
      }

      // Initialize webhook service
      let webhookInitialized = false;
      try {
        await webhookService.startListening();
        const webhookStatus = webhookService.getStatus();
        
        if (webhookStatus.isListening) {
          webhookInitialized = true;
          setState(prev => ({ ...prev, mode: 'webhook', isConnected: true }));
          console.log('✅ Webhook service initialized');
          
          addUpdateEvent({
            type: 'webhook',
            action: 'connected',
            data: { listening: true, events: webhookStatus.subscribedEvents.length },
            timestamp: new Date().toISOString()
          });
        }
      } catch (webhookError) {
        console.log('⚠️ Webhook initialization failed:', webhookError);
        setState(prev => ({ 
          ...prev, 
          errors: [...prev.errors, 'Webhook service failed - using polling fallback']
        }));
      }

      // Set connection status based on what we have
      if (webhookInitialized || jwtInitialized) {
        setState(prev => ({ 
          ...prev, 
          isConnected: true,
          mode: webhookInitialized ? 'webhook' : 'jwt'
        }));
      } else {
        setState(prev => ({ 
          ...prev, 
          isConnected: false,
          mode: 'polling',
          errors: [...prev.errors, 'Both JWT and Webhook initialization failed - using basic polling']
        }));
      }

      // Subscribe to webhook events if available
      if (webhookInitialized) {
        // Order events
        webhookService.subscribe('order.created', (order) => {
          addUpdateEvent({
            type: 'order',
            action: 'created',
            data: order,
            timestamp: new Date().toISOString()
          });
        });

        webhookService.subscribe('order.updated', (order) => {
          addUpdateEvent({
            type: 'order',
            action: 'updated',
            data: order,
            timestamp: new Date().toISOString()
          });
        });

        // Product events
        webhookService.subscribe('product.created', (product) => {
          addUpdateEvent({
            type: 'product',
            action: 'created',
            data: product,
            timestamp: new Date().toISOString()
          });
        });

        webhookService.subscribe('product.updated', (product) => {
          addUpdateEvent({
            type: 'product',
            action: 'updated',
            data: product,
            timestamp: new Date().toISOString()
          });
        });

        // Customer events
        webhookService.subscribe('customer.created', (customer) => {
          addUpdateEvent({
            type: 'customer',
            action: 'created',
            data: customer,
            timestamp: new Date().toISOString()
          });
        });

        webhookService.subscribe('customer.updated', (customer) => {
          addUpdateEvent({
            type: 'customer',
            action: 'updated',
            data: customer,
            timestamp: new Date().toISOString()
          });
        });

        // General data refresh events
        webhookService.subscribe('data.refresh', () => {
          addUpdateEvent({
            type: 'data',
            action: 'refreshed',
            data: { source: 'webhook' },
            timestamp: new Date().toISOString()
          });
        });

        console.log('✅ Webhook event subscriptions configured');
      }

      // JWT token refresh scheduling
      if (jwtInitialized) {
        const scheduleTokenRefresh = () => {
          const tokenInfo = jwtAuth.getTokenInfo();
          if (tokenInfo.hasToken && tokenInfo.expiresIn > 0) {
            // Schedule refresh 5 minutes before expiry
            const refreshTime = Math.max(tokenInfo.expiresIn - (5 * 60 * 1000), 30000);
            
            setTimeout(async () => {
              try {
                await jwtAuth.refreshToken();
                addUpdateEvent({
                  type: 'jwt',
                  action: 'refreshed',
                  data: { method: 'jwt', status: 'refreshed' },
                  timestamp: new Date().toISOString()
                });
                scheduleTokenRefresh(); // Schedule next refresh
              } catch (error) {
                console.error('JWT token refresh failed:', error);
                setState(prev => ({ 
                  ...prev, 
                  errors: [...prev.errors, 'JWT token refresh failed']
                }));
              }
            }, refreshTime);
          }
        };
        
        scheduleTokenRefresh();
      }

      // Set up periodic status updates
      const statusInterval = setInterval(() => {
        try {
          setState(prev => ({
            ...prev,
            webhookStatus: webhookService.getStatus(),
            jwtStatus: jwtAuth.getTokenInfo()
          }));
        } catch (error) {
          console.error('Status update error:', error);
        }
      }, 60000); // Every minute

      console.log('✅ Real-time updates initialized successfully');

      return () => {
        try {
          webhookService.stopListening();
          clearInterval(statusInterval);
          initializationRef.current = false;
        } catch (error) {
          console.error('Cleanup error:', error);
        }
      };

    } catch (error) {
      console.error('❌ Failed to initialize real-time updates:', error);
      setState(prev => ({
        ...prev,
        errors: [...prev.errors, error instanceof Error ? error.message : 'Initialization failed'],
        isConnected: false,
        mode: 'polling'
      }));
      initializationRef.current = false;
    }
  }, [addUpdateEvent]);

  // Manually trigger data refresh
  const refreshData = useCallback(async (resource?: string) => {
    try {
      console.log(`🔄 Manually refreshing${resource ? ` ${resource}` : ' all'} data...`);
      
      // Try webhook trigger if available
      const webhookStatus = webhookService.getStatus();
      if (webhookStatus.isListening) {
        try {
          await webhookService.triggerSync(resource);
          console.log('✅ Webhook sync triggered');
        } catch (webhookError) {
          console.log('⚠️ Webhook trigger failed:', webhookError);
        }
      }

      // Try JWT token refresh if needed
      const jwtInfo = jwtAuth.getTokenInfo();
      if (jwtInfo.hasToken && jwtInfo.isExpired) {
        try {
          await jwtAuth.refreshToken();
          console.log('✅ JWT token refreshed');
        } catch (jwtError) {
          console.log('⚠️ JWT refresh failed:', jwtError);
        }
      }
      
      addUpdateEvent({
        type: 'data',
        action: 'refreshed',
        data: { resource: resource || 'all', source: 'manual', method: state.mode },
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      console.error('❌ Manual refresh failed:', error);
      setState(prev => ({
        ...prev,
        errors: [...prev.errors.slice(-4), error instanceof Error ? error.message : 'Refresh failed']
      }));
    }
  }, [addUpdateEvent, state.mode]);

  // Clear errors
  const clearErrors = useCallback(() => {
    setState(prev => ({ ...prev, errors: [] }));
  }, []);

  // Get update statistics
  const getStatistics = useCallback(() => {
    const now = Date.now();
    const last24h = recentUpdates.filter(update => 
      now - new Date(update.timestamp).getTime() < 24 * 60 * 60 * 1000
    );
    
    const byType = last24h.reduce((acc, update) => {
      acc[update.type] = (acc[update.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const byAction = last24h.reduce((acc, update) => {
      acc[update.action] = (acc[update.action] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total24h: last24h.length,
      totalAllTime: state.updateCount,
      byType,
      byAction,
      lastUpdate: state.lastUpdate,
      isConnected: state.isConnected,
      mode: state.mode,
      jwtActive: state.jwtStatus?.hasToken && !state.jwtStatus?.isExpired,
      webhookActive: state.webhookStatus?.isListening
    };
  }, [recentUpdates, state]);

  // Initialize on mount
  useEffect(() => {
    let cleanup: (() => void) | undefined;

    const init = async () => {
      cleanup = await initialize();
    };

    init();

    return () => {
      if (cleanup) {
        try {
          cleanup();
        } catch (error) {
          console.error('Cleanup error:', error);
        }
      }
    };
  }, [initialize]);

  return {
    // State
    isConnected: state.isConnected,
    lastUpdate: state.lastUpdate,
    updateCount: state.updateCount,
    errors: state.errors,
    webhookStatus: state.webhookStatus,
    jwtStatus: state.jwtStatus,
    mode: state.mode,
    recentUpdates: recentUpdates.slice(0, 10), // Return only last 10 for UI

    // Actions
    subscribe,
    refreshData,
    clearErrors,
    getStatistics,

    // Status
    status: {
      webhook: webhookService.getStatus(),
      jwt: jwtAuth.getTokenInfo(),
      mode: state.mode,
      connected: state.isConnected
    }
  };
};

// Convenience hooks for specific update types
export const useOrderUpdates = () => {
  const { subscribe } = useRealTimeUpdates();
  const [orders, setOrders] = useState<any[]>([]);

  useEffect(() => {
    const unsubscribe = subscribe('order', (event) => {
      setOrders(prev => {
        if (event.action === 'created') {
          return [event.data, ...prev];
        } else if (event.action === 'updated') {
          return prev.map(order => 
            order.id === event.data.id ? event.data : order
          );
        } else if (event.action === 'deleted') {
          return prev.filter(order => order.id !== event.data.id);
        }
        return prev;
      });
    });

    return unsubscribe;
  }, [subscribe]);

  return orders;
};

export const useProductUpdates = () => {
  const { subscribe } = useRealTimeUpdates();
  const [products, setProducts] = useState<any[]>([]);

  useEffect(() => {
    const unsubscribe = subscribe('product', (event) => {
      setProducts(prev => {
        if (event.action === 'created') {
          return [event.data, ...prev];
        } else if (event.action === 'updated') {
          return prev.map(product => 
            product.id === event.data.id ? event.data : product
          );
        } else if (event.action === 'deleted') {
          return prev.filter(product => product.id !== event.data.id);
        }
        return prev;
      });
    });

    return unsubscribe;
  }, [subscribe]);

  return products;
};

export const useCustomerUpdates = () => {
  const { subscribe } = useRealTimeUpdates();
  const [customers, setCustomers] = useState<any[]>([]);

  useEffect(() => {
    const unsubscribe = subscribe('customer', (event) => {
      setCustomers(prev => {
        if (event.action === 'created') {
          return [event.data, ...prev];
        } else if (event.action === 'updated') {
          return prev.map(customer => 
            customer.id === event.data.id ? event.data : customer
          );
        } else if (event.action === 'deleted') {
          return prev.filter(customer => customer.id !== event.data.id);
        }
        return prev;
      });
    });

    return unsubscribe;
  }, [subscribe]);

  return customers;
};

export default useRealTimeUpdates;