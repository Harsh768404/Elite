import { useState, useEffect } from 'react';
import { UserInfo } from '../types/app-types';
import { authService } from '../utils/jwt-auth';

export const useAuthManager = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [jwtToken, setJwtToken] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<'administrator' | 'vendor'>('administrator');
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);

  // CRITICAL: Enhanced login handler with STRICT role validation - NO FALLBACKS
  const handleLogin = async (token: string, role: 'administrator' | 'vendor') => {
    console.log('🚀 ===== APP LOGIN HANDLER STARTED (STRICT MODE) =====');
    console.log('🔑 Token received:', !!token);
    console.log('🎭 Initial role assigned:', role);
    console.log('⚠️ STRICT MODE: No fallback data will be used');
    
    try {
      // Fetch complete user profile immediately after login with STRICT validation
      console.log('📊 Fetching complete user profile for session setup with STRICT validation...');
      const completeProfile = await authService.getCurrentUser(token);
      
      console.log('✅ Complete user profile fetched for app session');
      console.log('👤 User Profile Summary:');
      console.log('   - ID:', completeProfile.id);
      console.log('   - Username:', completeProfile.username);
      console.log('   - Email:', completeProfile.user_email);
      console.log('   - Display Name:', completeProfile.display_name);
      console.log('   - User Type:', completeProfile.user_type);
      console.log('   - VALIDATED WordPress Roles:', completeProfile.roles);
      console.log('   - Profile Complete:', completeProfile.profile_complete);
      console.log('   - Role Validation:', completeProfile.role_validation);
      console.log('   - Is Vendor:', !!completeProfile.vendor_data);
      console.log('   - Has WooCommerce Data:', !!completeProfile.billing_address);
      
      // CRITICAL: STRICT validation - NO FALLBACKS
      if (!completeProfile.profile_complete) {
        console.error('❌ CRITICAL: User profile is incomplete from backend');
        throw new Error('User profile is incomplete. Cannot proceed with login. Please contact administrator.');
      }
      
      if (!completeProfile.roles || completeProfile.roles.length === 0) {
        console.error('❌ CRITICAL: No validated roles found for user');
        throw new Error('No user roles found. User must have a valid role assigned in WordPress.');
      }
      
      if (completeProfile.user_type === 'unknown') {
        console.error('❌ CRITICAL: Cannot determine user type from validated roles');
        throw new Error(`Cannot determine user type from roles: ${completeProfile.roles.join(', ')}. Please contact administrator.`);
      }
      
      // CRITICAL: Build user info with ONLY validated data - NO FALLBACKS
      const userInfo: UserInfo = {
        id: completeProfile.id,
        username: completeProfile.username,
        display_name: completeProfile.display_name,
        user_email: completeProfile.user_email,
        user_type: completeProfile.user_type,
        roles: completeProfile.roles, // VALIDATED roles only
        avatar_urls: completeProfile.avatar_urls || {},
        vendor_data: completeProfile.vendor_data || null,
        billing_address: completeProfile.billing_address || null,
        profile_complete: completeProfile.profile_complete,
        last_fetched: completeProfile.last_fetched
      };
      
      // CRITICAL: Verify role assignment matches backend data - STRICT
      const expectedRole = completeProfile.user_type === 'administrator' ? 'administrator' : 'vendor';
      if (role !== expectedRole) {
        console.warn('⚠️ Role assignment mismatch detected:');
        console.warn('   - Backend user type:', completeProfile.user_type);
        console.warn('   - Assigned dashboard role:', role);
        console.warn('   - Expected role:', expectedRole);
        console.warn('   - VALIDATED Roles:', completeProfile.roles);
        
        // Use backend data as the authoritative source
        role = expectedRole;
        console.log('✅ Using backend-determined role:', role);
      }
      
      // CRITICAL: Additional validation for admin users
      if (completeProfile.user_type === 'administrator') {
        if (!completeProfile.roles.includes('administrator')) {
          console.error('❌ CRITICAL: User type is administrator but roles do not include administrator');
          console.error('   - User Type:', completeProfile.user_type);
          console.error('   - Validated Roles:', completeProfile.roles);
          throw new Error('Inconsistent administrator role data from backend. Please contact administrator.');
        }
      }
      
      // Set application state with VALIDATED data
      setJwtToken(token);
      setUserRole(role);
      setUserInfo(userInfo);
      setIsLoggedIn(true);
      
      // Store login info in localStorage with VALIDATED data
      localStorage.setItem('eliteq_jwt_token', token);
      localStorage.setItem('eliteq_user_role', role);
      localStorage.setItem('eliteq_user_info', JSON.stringify(userInfo));
      
      console.log('✅ ===== APP LOGIN COMPLETED SUCCESSFULLY (STRICT MODE) =====');
      console.log('🎯 User session established with VALIDATED backend profile');
      console.log('🏛️ Dashboard access:', role === 'administrator' ? 'Admin Panel' : 'Vendor Dashboard');
      console.log('👤 User display name:', userInfo.display_name);
      console.log('📧 User email:', userInfo.user_email);
      console.log('🎭 VALIDATED roles:', userInfo.roles);
      console.log('🔍 Role validation source:', completeProfile.role_validation?.source);
      console.log('📊 Role validation confidence:', completeProfile.role_validation?.confidence);
      
    } catch (error) {
      console.error('🚨 ===== APP LOGIN FAILED (STRICT MODE) =====');
      console.error('Failed to fetch or validate complete user profile:', error);
      
      // CRITICAL: In strict mode, we DO NOT fallback to basic login
      // If profile fetch fails, the login must fail completely
      console.error('⚠️ STRICT MODE: Login failed due to profile validation issues');
      console.error('   - No fallback data will be used');
      console.error('   - User must have complete and valid profile data');
      
      // Re-throw the error to prevent login
      throw error;
    }
  };

  const handleLogout = () => {
    console.log('🚪 ===== LOGGING OUT USER =====');
    
    setJwtToken(null);
    setUserRole('administrator');
    setUserInfo(null);
    setIsLoggedIn(false);
    
    // Clear all stored data
    localStorage.removeItem('eliteq_jwt_token');
    localStorage.removeItem('eliteq_user_role');
    localStorage.removeItem('eliteq_user_info');
    localStorage.removeItem('eliteq_remember_token');
    
    console.log('✅ User logged out successfully');
    console.log('🧹 All session data cleared');
  };

  // CRITICAL: Enhanced auto-login with STRICT profile restoration - NO FALLBACKS
  useEffect(() => {
    const attemptAutoLogin = async () => {
      const storedToken = localStorage.getItem('eliteq_jwt_token') || localStorage.getItem('eliteq_remember_token');
      const storedRole = localStorage.getItem('eliteq_user_role') as 'administrator' | 'vendor';
      const storedUserInfo = localStorage.getItem('eliteq_user_info');
      
      console.log('🔄 ===== AUTO-LOGIN ATTEMPT (STRICT MODE) =====');
      console.log('   - Stored token found:', !!storedToken);
      console.log('   - Stored role found:', storedRole);
      console.log('   - Stored user info found:', !!storedUserInfo);
      console.log('   - STRICT MODE: Will validate all stored data');
      
      if (storedToken && storedRole) {
        try {
          console.log('🔍 Validating stored token with backend...');
          
          // Validate token with backend
          const isValidToken = await authService.validateToken(storedToken);
          
          if (isValidToken) {
            console.log('✅ Stored token is valid');
            
            // CRITICAL: Always fetch fresh profile data in strict mode
            // Do not trust localStorage data for roles
            console.log('📊 Fetching fresh user profile from backend for validation...');
            const completeProfile = await authService.getCurrentUser(storedToken);
            
            // STRICT validation of fresh profile data
            if (!completeProfile.profile_complete) {
              console.error('❌ Fresh profile data is incomplete');
              throw new Error('Profile incomplete');
            }
            
            if (!completeProfile.roles || completeProfile.roles.length === 0) {
              console.error('❌ No validated roles in fresh profile data');
              throw new Error('No valid roles found');
            }
            
            if (completeProfile.user_type === 'unknown') {
              console.error('❌ Cannot determine user type from fresh profile data');
              throw new Error('Cannot determine user type');
            }
            
            // Build fresh user info with VALIDATED data
            const userInfo: UserInfo = {
              id: completeProfile.id,
              username: completeProfile.username,
              display_name: completeProfile.display_name,
              user_email: completeProfile.user_email,
              user_type: completeProfile.user_type,
              roles: completeProfile.roles, // VALIDATED roles only
              avatar_urls: completeProfile.avatar_urls || {},
              vendor_data: completeProfile.vendor_data || null,
              billing_address: completeProfile.billing_address || null,
              profile_complete: completeProfile.profile_complete,
              last_fetched: completeProfile.last_fetched
            };
            
            // Update role if backend data indicates different role
            const backendRole = completeProfile.user_type === 'administrator' ? 'administrator' : 'vendor';
            
            // CRITICAL: Validate role consistency
            if (backendRole === 'administrator' && !completeProfile.roles.includes('administrator')) {
              console.error('❌ Backend role inconsistency detected');
              throw new Error('Administrator role inconsistency');
            }
            
            setJwtToken(storedToken);
            setUserRole(backendRole);
            setUserInfo(userInfo);
            setIsLoggedIn(true);
            
            // Update localStorage with fresh VALIDATED data
            localStorage.setItem('eliteq_user_role', backendRole);
            localStorage.setItem('eliteq_user_info', JSON.stringify(userInfo));
            
            console.log('✅ Auto-login successful with fresh VALIDATED backend profile');
            console.log('👤 User:', userInfo.display_name);
            console.log('🎭 Role:', backendRole);
            console.log('🔍 VALIDATED Roles:', userInfo.roles);
            console.log('📊 Role Validation:', completeProfile.role_validation);
            
          } else {
            console.log('❌ Stored token is invalid, clearing session');
            localStorage.removeItem('eliteq_jwt_token');
            localStorage.removeItem('eliteq_user_role');
            localStorage.removeItem('eliteq_user_info');
            localStorage.removeItem('eliteq_remember_token');
          }
          
        } catch (error) {
          console.error('🚨 Auto-login failed (STRICT MODE):', error);
          console.log('🧹 Clearing invalid session data');
          localStorage.removeItem('eliteq_jwt_token');
          localStorage.removeItem('eliteq_user_role');
          localStorage.removeItem('eliteq_user_info');
          localStorage.removeItem('eliteq_remember_token');
        }
      } else {
        console.log('❌ Auto-login failed - missing token or role');
      }
      
      console.log('🔄 ===== AUTO-LOGIN COMPLETED (STRICT MODE) =====');
    };

    attemptAutoLogin();
  }, []);

  return {
    isLoggedIn,
    jwtToken,
    userRole,
    userInfo,
    handleLogin,
    handleLogout
  };
};