import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Eye, Activity, PieChart, TrendingUp } from 'lucide-react';

interface NavigationItem {
  id: string;
  label: string;
  description: string;
  icon: React.ElementType;
  color: string;
  roles: ('vendor' | 'admin')[];
}

const navigationItems: NavigationItem[] = [
  {
    id: 'overview',
    label: 'Overview',
    description: 'Get a comprehensive view of your store performance',
    icon: Eye,
    color: 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800',
    roles: ['vendor', 'admin']
  },
  {
    id: 'performance',
    label: 'Performance',
    description: 'Monitor key metrics and business performance',
    icon: Activity,
    color: 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800',
    roles: ['vendor', 'admin']
  },
  {
    id: 'charts',
    label: 'Charts & Graphs',
    description: 'Visualize your data with interactive charts',
    icon: PieChart,
    color: 'bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800',
    roles: ['vendor', 'admin']
  },
  {
    id: 'analytics',
    label: 'Advanced Analytics',
    description: 'Deep dive into your business analytics',
    icon: TrendingUp,
    color: 'bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800',
    roles: ['vendor', 'admin']
  }
];

interface DashboardNavigationProps {
  onNavigate: (id: string) => void;
  currentRole: 'vendor' | 'admin';
}

export const DashboardNavigation: React.FC<DashboardNavigationProps> = ({
  onNavigate,
  currentRole
}) => {
  // Filter navigation items based on current role
  const visibleItems = navigationItems.filter(item => 
    item.roles.includes(currentRole)
  );

  return (
    <Card className="bg-white dark:bg-gray-900 border-0 shadow-lg mb-6">
      <CardHeader className="border-b border-gray-100 dark:border-gray-800">
        <CardTitle className="text-lg font-bold flex items-center gap-2">
          <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></div>
          Dashboard Navigation
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {visibleItems.map((item) => (
            <Button
              key={item.id}
              className={`${item.color} text-white border-0 h-auto p-4 flex flex-col items-center gap-3 group transition-all duration-300 hover:scale-105 hover:shadow-lg`}
              onClick={() => onNavigate(item.id)}
            >
              <item.icon className="h-6 w-6 group-hover:scale-110 transition-transform duration-300" />
              <div className="text-center">
                <div className="font-semibold">{item.label}</div>
                <div className="text-xs opacity-90 mt-1">{item.description}</div>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default DashboardNavigation;