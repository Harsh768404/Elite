import React, { useState, useEffect } from 'react';
import {
  Package, Plus, Upload, Download, Search, Filter, Calendar,
  Edit, Trash2, Eye, Copy, Settings, MoreHorizontal,
  CheckCircle, XCircle, AlertCircle, Star, TrendingUp,
  Tag, Grid, List, RefreshCw, Loader2, Wifi, WifiOff
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from './ui/dropdown-menu';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Alert, AlertDescription } from './ui/alert';
import { WooCommerceAPI } from '../utils/woocommerce-api';

interface WooCommerceProduct {
  id: number;
  name: string;
  status: string;
  sku: string;
  stock_quantity: number;
  stock_status: string;
  price: string;
  regular_price: string;
  sale_price: string;
  image: string;
  date_created: string;
  type: string;
  featured: boolean;
  catalog_visibility: string;
}

interface Product {
  id: string;
  name: string;
  image: string;
  status: 'online' | 'draft' | 'pending';
  sku: string;
  stock: {
    status: 'in-stock' | 'out-of-stock' | 'low-stock';
    quantity: number;
  };
  price: {
    regular: number;
    sale?: number;
  };
  earning: number;
  type: string;
  views: number;
  publishDate: string;
  category: string;
  brand: string;
}

// Mock fallback data
const mockProducts: Product[] = [
  {
    id: '1',
    name: 'iPhone 15 Pro Max - 256GB Natural Titanium',
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=100&h=100&fit=crop',
    status: 'online',
    sku: 'IP15PM-256-NT',
    stock: { status: 'in-stock', quantity: 25 },
    price: { regular: 134900, sale: 129900 },
    earning: 15000,
    type: 'Variable',
    views: 1247,
    publishDate: '2024-01-15',
    category: 'Electronics',
    brand: 'Apple'
  },
  {
    id: '2',
    name: 'Samsung Galaxy S24 Ultra - 512GB Titanium Black',
    image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=100&h=100&fit=crop',
    status: 'online',
    sku: 'SGS24U-512-TB',
    stock: { status: 'low-stock', quantity: 3 },
    price: { regular: 124999, sale: 119999 },
    earning: 12000,
    type: 'Variable',
    views: 892,
    publishDate: '2024-01-12',
    category: 'Electronics',
    brand: 'Samsung'
  }
];

export function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dataSource, setDataSource] = useState<'woocommerce' | 'mock'>('mock');
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [brandFilter, setBrandFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');

  // Transform WooCommerce product data
  const transformWooCommerceProduct = (wcProduct: WooCommerceProduct): Product => {
    const regularPrice = parseFloat(wcProduct.regular_price || wcProduct.price || '0');
    const salePrice = wcProduct.sale_price ? parseFloat(wcProduct.sale_price) : undefined;
    
    // Calculate earning as 10% of price (example calculation)
    const earning = Math.round((salePrice || regularPrice) * 0.1);
    
    // Map WooCommerce status to our status
    let status: 'online' | 'draft' | 'pending' = 'draft';
    if (wcProduct.status === 'publish') status = 'online';
    else if (wcProduct.status === 'pending') status = 'pending';
    
    // Map stock status
    let stockStatus: 'in-stock' | 'out-of-stock' | 'low-stock' = 'out-of-stock';
    if (wcProduct.stock_status === 'instock') {
      stockStatus = wcProduct.stock_quantity > 10 ? 'in-stock' : 'low-stock';
    }
    
    return {
      id: wcProduct.id.toString(),
      name: wcProduct.name,
      image: wcProduct.image || `https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=100&fit=crop`,
      status,
      sku: wcProduct.sku || `SKU-${wcProduct.id}`,
      stock: {
        status: stockStatus,
        quantity: wcProduct.stock_quantity || 0
      },
      price: {
        regular: regularPrice,
        sale: salePrice
      },
      earning,
      type: wcProduct.type || 'Simple',
      views: Math.floor(Math.random() * 1000) + 100, // Mock views data
      publishDate: wcProduct.date_created || new Date().toISOString(),
      category: 'Electronics', // Default category since WooCommerce might not provide this directly
      brand: 'Unknown' // Default brand
    };
  };

  // Fetch products from WooCommerce
  const fetchProducts = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('🔄 Fetching products from WooCommerce...');
      
      const wcProducts = await WooCommerceAPI.products.getAll({
        per_page: 50,
        orderby: 'date',
        order: 'desc',
        status: 'any'
      });
      
      if (Array.isArray(wcProducts) && wcProducts.length > 0) {
        const transformedProducts = wcProducts.map(transformWooCommerceProduct);
        setProducts(transformedProducts);
        setDataSource('woocommerce');
        console.log(`✅ Loaded ${transformedProducts.length} products from WooCommerce`);
      } else {
        throw new Error('No products found or invalid response');
      }
      
    } catch (error) {
      console.warn('⚠️ Failed to fetch WooCommerce products, using fallback data:', error);
      setProducts(mockProducts);
      setDataSource('mock');
      setError('Using demo data - WooCommerce API connection unavailable');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || product.category === categoryFilter;
    const matchesType = typeFilter === 'all' || product.type === typeFilter;
    const matchesBrand = brandFilter === 'all' || product.brand === brandFilter;
    const matchesStatus = statusFilter === 'all' || product.status === statusFilter;
    
    return matchesSearch && matchesCategory && matchesType && matchesBrand && matchesStatus;
  });

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedProducts(filteredProducts.map(p => p.id));
    } else {
      setSelectedProducts([]);
    }
  };

  const handleSelectProduct = (productId: string, checked: boolean) => {
    if (checked) {
      setSelectedProducts([...selectedProducts, productId]);
    } else {
      setSelectedProducts(selectedProducts.filter(id => id !== productId));
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      online: { label: 'Online', className: 'product-status-online' },
      draft: { label: 'Draft', className: 'product-status-draft' },
      pending: { label: 'Pending', className: 'product-status-pending' }
    };
    const config = statusConfig[status as keyof typeof statusConfig];
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const getStockBadge = (stock: { status: string; quantity: number }) => {
    const stockConfig = {
      'in-stock': { label: 'In Stock', className: 'stock-in-stock' },
      'low-stock': { label: 'Low Stock', className: 'stock-low-stock' },
      'out-of-stock': { label: 'Out of Stock', className: 'stock-out-of-stock' }
    };
    const config = stockConfig[stock.status as keyof typeof stockConfig];
    return (
      <div className={config.className}>
        <div className="font-medium">{config.label}</div>
        <div className="text-xs opacity-75">({stock.quantity} units)</div>
      </div>
    );
  };

  const formatPrice = (price: { regular: number; sale?: number }) => {
    return (
      <div className="text-right">
        {price.sale ? (
          <>
            <div className="price-strikethrough">₹{price.regular.toLocaleString()}</div>
            <div className="price-sale">₹{price.sale.toLocaleString()}</div>
          </>
        ) : (
          <div className="font-medium">₹{price.regular.toLocaleString()}</div>
        )}
      </div>
    );
  };

  const resetFilters = () => {
    setDateFilter('all');
    setCategoryFilter('all');
    setTypeFilter('all');
    setBrandFilter('all');
    setStatusFilter('all');
    setSearchTerm('');
  };

  const refreshProducts = () => {
    fetchProducts();
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="p-8">
            <div className="flex items-center justify-center space-x-2">
              <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
              <span className="text-lg">Loading products...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Connection Status Alert */}
      {error && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            <span>{error}</span>
            <Button variant="outline" size="sm" onClick={refreshProducts}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry Connection
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Data Source Indicator */}
      <Card className="border-l-4 border-l-blue-500">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {dataSource === 'woocommerce' ? (
                <Wifi className="h-5 w-5 text-green-500" />
              ) : (
                <WifiOff className="h-5 w-5 text-orange-500" />
              )}
              <div>
                <p className="font-medium">
                  {dataSource === 'woocommerce' ? 'Live WooCommerce Data' : 'Demo Data Mode'}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {dataSource === 'woocommerce' 
                    ? 'Products are synced with your WooCommerce store'
                    : 'Using sample data - Connect to WooCommerce for live data'
                  }
                </p>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={refreshProducts}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Header */}
      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-lg p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-3 mb-2">
              <Package className="h-6 w-6 text-blue-600" />
              Products
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Manage your product inventory, pricing, and stock levels
            </p>
          </div>
          
          {/* Top Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <Button className="bg-purple-600 hover:bg-purple-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Add New Product
            </Button>
            <Button variant="outline">
              <Upload className="h-4 w-4 mr-2" />
              Import
            </Button>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            
            {/* View Mode Toggle */}
            <div className="flex border rounded-lg overflow-hidden">
              <Button
                variant={viewMode === 'table' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('table')}
                className="rounded-none"
              >
                <List className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-none"
              >
                <Grid className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <Card>
        <CardContent className="p-4">
          <div className="products-filters grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-4 items-end">
            {/* Date Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Date</label>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger>
                  <Calendar className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="All Dates" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Dates</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                  <SelectItem value="year">This Year</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Category Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Category</label>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger>
                  <Tag className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Electronics">Electronics</SelectItem>
                  <SelectItem value="Fashion">Fashion</SelectItem>
                  <SelectItem value="Home">Home & Garden</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Product Type Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Product Type</label>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger>
                  <Package className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="simple">Simple</SelectItem>
                  <SelectItem value="variable">Variable</SelectItem>
                  <SelectItem value="grouped">Grouped</SelectItem>
                  <SelectItem value="external">External</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Brand Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Brand</label>
              <Select value={brandFilter} onValueChange={setBrandFilter}>
                <SelectTrigger>
                  <Star className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="All Brands" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Brands</SelectItem>
                  <SelectItem value="Apple">Apple</SelectItem>
                  <SelectItem value="Samsung">Samsung</SelectItem>
                  <SelectItem value="Sony">Sony</SelectItem>
                  <SelectItem value="Dell">Dell</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Status Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="online">Online</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Button variant="default" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Button variant="outline" size="sm" onClick={resetFilters}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Reset
              </Button>
            </div>

            {/* Search Box */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bulk Actions */}
      {selectedProducts.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium">
                  {selectedProducts.length} product{selectedProducts.length !== 1 ? 's' : ''} selected
                </span>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm">
                      Bulk Actions
                      <MoreHorizontal className="h-4 w-4 ml-2" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Selected
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Copy className="h-4 w-4 mr-2" />
                      Duplicate Selected
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Download className="h-4 w-4 mr-2" />
                      Export Selected
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-red-600">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete Selected
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Button variant="outline" size="sm" onClick={() => setSelectedProducts([])}>
                  Clear Selection
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Products ({filteredProducts.length})</span>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <TrendingUp className="h-4 w-4" />
              Showing {filteredProducts.length} of {products.length} products
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table className="products-table">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedProducts.length === filteredProducts.length && filteredProducts.length > 0}
                      onCheckedChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead className="w-20">Image</TableHead>
                  <TableHead className="min-w-[250px]">Product Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>SKU</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead className="text-right">Price</TableHead>
                  <TableHead className="text-right">Earning</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Views</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>
                      <Checkbox
                        checked={selectedProducts.includes(product.id)}
                        onCheckedChange={(checked) => handleSelectProduct(product.id, checked as boolean)}
                      />
                    </TableCell>
                    <TableCell>
                      <Avatar className="h-12 w-12 rounded-lg">
                        <AvatarImage src={product.image} alt={product.name} />
                        <AvatarFallback className="rounded-lg">
                          <Package className="h-6 w-6" />
                        </AvatarFallback>
                      </Avatar>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium text-sm mb-1">{product.name}</div>
                        <div className="product-actions flex items-center gap-2 text-xs text-gray-500">
                          <a href="#" className="hover:text-blue-600 transition-colors">Edit</a>
                          <span>|</span>
                          <a href="#" className="hover:text-red-600 transition-colors">Delete</a>
                          <span>|</span>
                          <a href="#" className="hover:text-green-600 transition-colors">View</a>
                          <span>|</span>
                          <a href="#" className="hover:text-purple-600 transition-colors">Quick Edit</a>
                          <span>|</span>
                          <a href="#" className="hover:text-orange-600 transition-colors">Duplicate</a>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(product.status)}</TableCell>
                    <TableCell className="font-mono text-sm">{product.sku}</TableCell>
                    <TableCell>{getStockBadge(product.stock)}</TableCell>
                    <TableCell>{formatPrice(product.price)}</TableCell>
                    <TableCell className="earning-display text-right">
                      ₹{product.earning.toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {product.type}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">{product.views.toLocaleString()}</TableCell>
                    <TableCell className="text-sm text-gray-500">
                      {new Date(product.publishDate).toLocaleDateString('en-IN')}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-600 mb-2">No products found</h3>
              <p className="text-gray-500 mb-4">
                {searchTerm || dateFilter !== 'all' || categoryFilter !== 'all' || typeFilter !== 'all' || brandFilter !== 'all' || statusFilter !== 'all'
                  ? 'Try adjusting your filters or search terms'
                  : 'Get started by adding your first product'
                }
              </p>
              {searchTerm || dateFilter !== 'all' || categoryFilter !== 'all' || typeFilter !== 'all' || brandFilter !== 'all' || statusFilter !== 'all' ? (
                <Button variant="outline" onClick={resetFilters}>
                  Clear Filters
                </Button>
              ) : (
                <Button className="bg-purple-600 hover:bg-purple-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Add New Product
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}