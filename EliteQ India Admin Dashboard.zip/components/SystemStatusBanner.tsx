import React, { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, WifiOff, X, Info } from 'lucide-react';
import { gracefulErrorHandler } from '../utils/graceful-error-handler';
import { networkManager } from '../utils/network-connectivity-manager';

export function SystemStatusBanner() {
  const [systemHealth, setSystemHealth] = useState(gracefulErrorHandler.getSystemHealth());
  const [dismissed, setDismissed] = useState(false);
  const [lastDismissedStatus, setLastDismissedStatus] = useState<string | null>(
    localStorage.getItem('eliteq_dismissed_status')
  );

  useEffect(() => {
    // Update system health periodically
    const interval = setInterval(() => {
      const newHealth = gracefulErrorHandler.getSystemHealth();
      setSystemHealth(newHealth);
      
      // Reset dismissed state if status changes
      if (newHealth.status !== lastDismissedStatus) {
        setDismissed(false);
      }
    }, 15000); // Check every 15 seconds

    // Listen for network status changes
    const unsubscribe = networkManager.onStatusChange(() => {
      const newHealth = gracefulErrorHandler.getSystemHealth();
      setSystemHealth(newHealth);
      
      // Reset dismissed state if status changes
      if (newHealth.status !== lastDismissedStatus) {
        setDismissed(false);
      }
    });

    return () => {
      clearInterval(interval);
      unsubscribe();
    };
  }, [lastDismissedStatus]);

  const handleDismiss = () => {
    setDismissed(true);
    setLastDismissedStatus(systemHealth.status);
    localStorage.setItem('eliteq_dismissed_status', systemHealth.status);
  };

  // Don't show banner if system is healthy or if dismissed for current status
  if (systemHealth.status === 'healthy' || dismissed) {
    return null;
  }

  const getBannerConfig = () => {
    switch (systemHealth.status) {
      case 'critical':
        return {
          icon: systemHealth.networkConnected ? AlertTriangle : WifiOff,
          bgColor: 'bg-red-50 dark:bg-red-900/20',
          borderColor: 'border-red-200 dark:border-red-800',
          textColor: 'text-red-800 dark:text-red-200',
          iconColor: 'text-red-500',
          title: systemHealth.networkConnected ? 'Server Connection Issues' : 'No Internet Connection',
          description: systemHealth.networkConnected 
            ? 'WordPress server is unreachable. Dashboard is displaying cached data to maintain functionality.'
            : 'Internet connection lost. Please check your network settings.'
        };
      case 'degraded':
        return {
          icon: AlertTriangle,
          bgColor: 'bg-yellow-50 dark:bg-yellow-900/20',
          borderColor: 'border-yellow-200 dark:border-yellow-800',
          textColor: 'text-yellow-800 dark:text-yellow-200',
          iconColor: 'text-yellow-500',
          title: 'Limited Connectivity',
          description: 'Some services are experiencing issues. Dashboard functionality may be limited.'
        };
      default:
        return {
          icon: Info,
          bgColor: 'bg-blue-50 dark:bg-blue-900/20',
          borderColor: 'border-blue-200 dark:border-blue-800',
          textColor: 'text-blue-800 dark:text-blue-200',
          iconColor: 'text-blue-500',
          title: 'System Information',
          description: systemHealth.message
        };
    }
  };

  const config = getBannerConfig();
  const Icon = config.icon;

  return (
    <div className={`${config.bgColor} border ${config.borderColor} rounded-lg p-4 mb-6`}>
      <div className="flex items-start space-x-3">
        <Icon className={`w-5 h-5 ${config.iconColor} flex-shrink-0 mt-0.5`} />
        
        <div className="flex-1">
          <h3 className={`font-medium ${config.textColor} mb-1`}>
            {config.title}
          </h3>
          <p className={`text-sm ${config.textColor} opacity-90 mb-3`}>
            {config.description}
          </p>

          {/* Status Details */}
          <div className="flex items-center space-x-6 text-xs">
            <div className="flex items-center space-x-1">
              <div className={`w-2 h-2 rounded-full ${systemHealth.networkConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className={config.textColor}>
                Internet: {systemHealth.networkConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>
            
            <div className="flex items-center space-x-1">
              <div className={`w-2 h-2 rounded-full ${systemHealth.wordpressReachable ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className={config.textColor}>
                WordPress: {systemHealth.wordpressReachable ? 'Online' : 'Offline'}
              </span>
            </div>
            
            <div className="flex items-center space-x-1">
              <div className={`w-2 h-2 rounded-full ${systemHealth.woocommerceReachable ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className={config.textColor}>
                WooCommerce: {systemHealth.woocommerceReachable ? 'Online' : 'Offline'}
              </span>
            </div>

            {systemHealth.recentErrorCount > 0 && (
              <div className="flex items-center space-x-1">
                <AlertTriangle className="w-3 h-3" />
                <span className={config.textColor}>
                  {systemHealth.recentErrorCount} recent errors
                </span>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-3 mt-3">
            {systemHealth.status === 'critical' && !systemHealth.networkConnected && (
              <button
                onClick={() => window.location.reload()}
                className={`text-sm font-medium ${config.textColor} hover:opacity-80 underline`}
              >
                Retry Connection
              </button>
            )}
            
            <button
              onClick={() => {
                // Show network status details
                console.log('Network Status:', networkManager.getConnectionStatus());
                console.log('Error Summary:', gracefulErrorHandler.getErrorSummary());
              }}
              className={`text-sm font-medium ${config.textColor} hover:opacity-80 underline`}
            >
              View Details
            </button>
          </div>
        </div>

        {/* Dismiss Button */}
        <button
          onClick={handleDismiss}
          className={`${config.iconColor} hover:opacity-80 flex-shrink-0`}
          title="Dismiss this notification"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}