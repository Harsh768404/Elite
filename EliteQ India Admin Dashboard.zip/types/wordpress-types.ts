// Comprehensive WordPress and WooCommerce API response types for EliteQ India
export interface WordPressBaseResponse {
  id: number;
  date: string;
  date_gmt: string;
  modified: string;
  modified_gmt: string;
  slug: string;
  status: string;
  type: string;
  link: string;
}

// WordPress Core Types
export interface WordPressPost extends WordPressBaseResponse {
  title: {
    rendered: string;
  };
  content: {
    rendered: string;
    protected: boolean;
  };
  excerpt: {
    rendered: string;
    protected: boolean;
  };
  author: number;
  featured_media: number;
  comment_status: string;
  ping_status: string;
  sticky: boolean;
  template: string;
  format: string;
  meta: Record<string, any>;
  categories: number[];
  tags: number[];
}

export interface WordPressPage extends WordPressBaseResponse {
  title: {
    rendered: string;
  };
  content: {
    rendered: string;
    protected: boolean;
  };
  author: number;
  featured_media: number;
  parent: number;
  menu_order: number;
  comment_status: string;
  ping_status: string;
  template: string;
  meta: Record<string, any>;
}

export interface WordPressMedia extends WordPressBaseResponse {
  title: {
    rendered: string;
  };
  description: {
    rendered: string;
  };
  caption: {
    rendered: string;
  };
  alt_text: string;
  media_type: string;
  mime_type: string;
  media_details: {
    width: number;
    height: number;
    file: string;
    sizes: Record<string, {
      file: string;
      width: number;
      height: number;
      mime_type: string;
      source_url: string;
    }>;
  };
  source_url: string;
  post: number;
}

export interface WordPressUser {
  id: number;
  username: string;
  name: string;
  first_name: string;
  last_name: string;
  email: string;
  url: string;
  description: string;
  link: string;
  locale: string;
  nickname: string;
  slug: string;
  roles: string[];
  registered_date: string;
  capabilities: Record<string, boolean>;
  extra_capabilities: Record<string, boolean>;
  avatar_urls: Record<string, string>;
  meta: Record<string, any>;
}

export interface WordPressTaxonomy {
  id: number;
  count: number;
  description: string;
  link: string;
  name: string;
  slug: string;
  taxonomy: string;
  parent: number;
  meta: Record<string, any>;
}

// WooCommerce Types
export interface WooCommerceProduct extends WordPressBaseResponse {
  name: string;
  slug: string;
  permalink: string;
  description: string;
  short_description: string;
  sku: string;
  price: string;
  regular_price: string;
  sale_price: string;
  date_on_sale_from: string | null;
  date_on_sale_to: string | null;
  price_html: string;
  on_sale: boolean;
  purchasable: boolean;
  total_sales: number;
  virtual: boolean;
  downloadable: boolean;
  downloads: any[];
  download_limit: number;
  download_expiry: number;
  external_url: string;
  button_text: string;
  tax_status: string;
  tax_class: string;
  manage_stock: boolean;
  stock_quantity: number | null;
  stock_status: string;
  backorders: string;
  backorders_allowed: boolean;
  backordered: boolean;
  sold_individually: boolean;
  weight: string;
  dimensions: {
    length: string;
    width: string;
    height: string;
  };
  shipping_required: boolean;
  shipping_taxable: boolean;
  shipping_class: string;
  shipping_class_id: number;
  reviews_allowed: boolean;
  average_rating: string;
  rating_count: number;
  related_ids: number[];
  upsell_ids: number[];
  cross_sell_ids: number[];
  parent_id: number;
  purchase_note: string;
  categories: WooCommerceProductCategory[];
  tags: WooCommerceProductTag[];
  images: WooCommerceProductImage[];
  attributes: WooCommerceProductAttribute[];
  default_attributes: any[];
  variations: number[];
  grouped_products: number[];
  menu_order: number;
  meta_data: WooCommerceMetaData[];
}

export interface WooCommerceProductCategory {
  id: number;
  name: string;
  slug: string;
}

export interface WooCommerceProductTag {
  id: number;
  name: string;
  slug: string;
}

export interface WooCommerceProductImage {
  id: number;
  date_created: string;
  date_created_gmt: string;
  date_modified: string;
  date_modified_gmt: string;
  src: string;
  name: string;
  alt: string;
}

export interface WooCommerceProductAttribute {
  id: number;
  name: string;
  position: number;
  visible: boolean;
  variation: boolean;
  options: string[];
}

export interface WooCommerceMetaData {
  id: number;
  key: string;
  value: any;
}

export interface WooCommerceOrder extends WordPressBaseResponse {
  parent_id: number;
  number: string;
  order_key: string;
  created_via: string;
  version: string;
  status: string;
  currency: string;
  date_created: string;
  date_created_gmt: string;
  date_modified: string;
  date_modified_gmt: string;
  discount_total: string;
  discount_tax: string;
  shipping_total: string;
  shipping_tax: string;
  cart_tax: string;
  total: string;
  total_tax: string;
  prices_include_tax: boolean;
  customer_id: number;
  customer_ip_address: string;
  customer_user_agent: string;
  customer_note: string;
  billing: WooCommerceAddress;
  shipping: WooCommerceAddress;
  payment_method: string;
  payment_method_title: string;
  transaction_id: string;
  date_paid: string | null;
  date_paid_gmt: string | null;
  date_completed: string | null;
  date_completed_gmt: string | null;
  cart_hash: string;
  meta_data: WooCommerceMetaData[];
  line_items: WooCommerceLineItem[];
  tax_lines: WooCommerceTaxLine[];
  shipping_lines: WooCommerceShippingLine[];
  fee_lines: WooCommerceFee[];
  coupon_lines: WooCommerceCoupon[];
  refunds: WooCommerceRefund[];
}

export interface WooCommerceAddress {
  first_name: string;
  last_name: string;
  company: string;
  address_1: string;
  address_2: string;
  city: string;
  state: string;
  postcode: string;
  country: string;
  email?: string;
  phone?: string;
}

export interface WooCommerceLineItem {
  id: number;
  name: string;
  product_id: number;
  variation_id: number;
  quantity: number;
  tax_class: string;
  subtotal: string;
  subtotal_tax: string;
  total: string;
  total_tax: string;
  taxes: any[];
  meta_data: WooCommerceMetaData[];
  sku: string;
  price: number;
}

export interface WooCommerceTaxLine {
  id: number;
  rate_code: string;
  rate_id: number;
  label: string;
  compound: boolean;
  tax_total: string;
  shipping_tax_total: string;
  meta_data: WooCommerceMetaData[];
}

export interface WooCommerceShippingLine {
  id: number;
  method_title: string;
  method_id: string;
  total: string;
  total_tax: string;
  taxes: any[];
  meta_data: WooCommerceMetaData[];
}

export interface WooCommerceFee {
  id: number;
  name: string;
  tax_class: string;
  tax_status: string;
  total: string;
  total_tax: string;
  taxes: any[];
  meta_data: WooCommerceMetaData[];
}

export interface WooCommerceCoupon {
  id: number;
  code: string;
  discount: string;
  discount_tax: string;
  meta_data: WooCommerceMetaData[];
}

export interface WooCommerceRefund {
  id: number;
  reason: string;
  total: string;
}

// Dokan Pro Types
export interface DokanStore {
  id: number;
  store_name: string;
  first_name: string;
  last_name: string;
  email: string;
  social: Record<string, string>;
  payment: Record<string, any>;
  phone: string;
  show_email: boolean;
  address: {
    street_1: string;
    street_2: string;
    city: string;
    zip: string;
    country: string;
    state: string;
  };
  location: string;
  banner: string;
  banner_id: number;
  gravatar: string;
  gravatar_id: number;
  shop_url: string;
  products_per_page: number;
  show_more_product_tab: boolean;
  toc_enabled: boolean;
  store_toc: string;
  featured: boolean;
  rating: {
    rating: number;
    count: number;
  };
  enabled: boolean;
  registered: string;
  store_open_close: {
    enabled: boolean;
    time: any[];
  };
  disable_vendor_shipping: boolean;
}

export interface DokanVendor extends WordPressUser {
  store_info: DokanStore;
  total_sales: number;
  orders_count: number;
  vendor_commission: number;
}

// Elementor Types
export interface ElementorTemplate {
  id: number;
  title: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  template_type: string;
  elementor_data: any[];
  elementor_edit_mode: string;
  elementor_version: string;
  meta: Record<string, any>;
}

// WoodMart Theme Types
export interface WoodMartLayout {
  id: number;
  title: {
    rendered: string;
  };
  layout_type: string;
  layout_conditions: any[];
  elementor_data: any[];
  meta: Record<string, any>;
}

export interface WoodMartSlide {
  id: number;
  title: {
    rendered: string;
  };
  bg_color: string;
  bg_image_desktop: string;
  content: {
    rendered: string;
  };
  meta: Record<string, any>;
}

// API Response wrapper
export interface WordPressAPIResponse<T> {
  data: T[];
  total: number;
  total_pages: number;
  headers: Record<string, string>;
}

// API Endpoints Configuration
export interface APIEndpointConfig {
  posts: string;
  pages: string;
  media: string;
  users: string;
  products: string;
  orders: string;
  customers: string;
  coupons: string;
  categories: string;
  tags: string;
  product_categories: string;
  product_tags: string;
  dokan_stores: string;
  dokan_vendors: string;
  elementor_templates: string;
  woodmart_layouts: string;
  woodmart_slides: string;
  [key: string]: string;
}

// Query Parameters
export interface WordPressQueryParams {
  page?: number;
  per_page?: number;
  search?: string;
  author?: number;
  exclude?: number[];
  include?: number[];
  offset?: number;
  order?: 'asc' | 'desc';
  orderby?: string;
  slug?: string;
  status?: string;
  categories?: number[];
  tags?: number[];
  before?: string;
  after?: string;
  [key: string]: any;
}

// API Error Response
export interface WordPressAPIError {
  code: string;
  message: string;
  data: {
    status: number;
    params?: Record<string, any>;
    details?: Record<string, any>;
  };
}

// Authentication Types
export interface JWTAuthResponse {
  token: string;
  user_email: string;
  user_nicename: string;
  user_display_name: string;
  token_expires?: number;
}

export interface WooCommerceAuthConfig {
  consumer_key: string;
  consumer_secret: string;
  version: string;
  queryStringAuth: boolean;
}

// Webhook Types
export interface WooCommerceWebhookPayload {
  id: number;
  name: string;
  delivery_url: string;
  secret: string;
  topic: string;
  resource: string;
  event: string;
  hooks: string[];
  created_at: string;
  updated_at: string;
}

// System Status
export interface WooCommerceSystemStatus {
  environment: {
    home_url: string;
    site_url: string;
    version: string;
    log_directory: string;
    log_directory_writable: boolean;
    wp_version: string;
    wp_multisite: boolean;
    wp_memory_limit: number;
    wp_debug_mode: boolean;
    wp_cron: boolean;
    language: string;
    external_object_cache: any;
    server_info: string;
    php_version: string;
    php_post_max_size: number;
    php_max_execution_time: number;
    php_max_input_vars: number;
    curl_version: string;
    suhosin_installed: boolean;
    max_upload_size: number;
    mysql_version: string;
    mysql_version_string: string;
    default_timezone: string;
    fsockopen_or_curl_enabled: boolean;
    soapclient_enabled: boolean;
    domdocument_enabled: boolean;
    gzip_enabled: boolean;
    mbstring_enabled: boolean;
    remote_post_successful: boolean;
    remote_post_response: string;
    remote_get_successful: boolean;
    remote_get_response: string;
  };
  database: {
    wc_database_version: string;
    database_prefix: string;
    maxmind_geoip_database: string;
    database_tables: Record<string, any>;
  };
  active_plugins: any[];
  inactive_plugins: any[];
  dropins_mu_plugins: any[];
  theme: {
    name: string;
    version: string;
    version_latest: string;
    author_url: string;
    is_child_theme: boolean;
    has_woocommerce_support: boolean;
    has_woocommerce_file: boolean;
    has_outdated_templates: boolean;
    overrides: string[];
    parent_name: string;
    parent_version: string;
    parent_version_latest: string;
    parent_author_url: string;
  };
  settings: Record<string, any>;
  security: Record<string, any>;
  pages: any[];
}