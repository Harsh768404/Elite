import React, { useEffect } from 'react';

// Component to initialize environment variables early in app lifecycle
export const EnvironmentInitializer: React.FC = () => {
  useEffect(() => {
    console.log('🔧 ===== ELITEQ ENVIRONMENT INITIALIZER =====');
    
    // Ensure window.ENV exists
    if (typeof window !== 'undefined') {
      if (!(window as any).ENV) {
        (window as any).ENV = {};
        console.log('🌐 Created window.ENV object');
      }
      
      // EliteQ India Production Credentials
      const eliteqCredentials = {
        WOOCOMMERCE_CONSUMER_KEY: 'ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9',
        WOOCOMMERCE_CONSUMER_SECRET: 'cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3',
        WORDPRESS_BASE_URL: 'https://eliteq.in',
        JWT_AUTH_SECRET_KEY: '9=<QX7=<(iLPhXh[G21AjCh#x-{%z)jA;FK]bRFpQT4jx?x+3l${m,IGCcVx&}Hm',
        WOOCOMMERCE_WEBHOOK_SECRET: 'Du83&G.64ti/5a#plclUwhF;WIjsQEHy_>hdFQ-/pv/CLJ$s#0',
        WOOCOMMERCE_WEBHOOK_API_KEY: 'w7mcvsqva35rns5bchiwnn4alrcg4jymowrmcox99kyg3n1zxwvsjuxix7ikrsdw'
      };
      
      // Set credentials with multiple key formats for compatibility
      Object.entries(eliteqCredentials).forEach(([key, value]) => {
        (window as any).ENV[key] = value;
        
        // Add aliases for different naming conventions
        if (key.startsWith('WOOCOMMERCE_')) {
          const shortKey = key.replace('WOOCOMMERCE_', 'WC_');
          (window as any).ENV[shortKey] = value;
        }
        
        if (key === 'WORDPRESS_BASE_URL') {
          (window as any).ENV.WORDPRESS_URL = value;
          (window as any).ENV.REACT_APP_WORDPRESS_URL = value;
        }
        
        if (key === 'WOOCOMMERCE_CONSUMER_KEY') {
          (window as any).ENV.CONSUMER_KEY = value;
          (window as any).ENV.REACT_APP_WC_CONSUMER_KEY = value;
        }
        
        if (key === 'WOOCOMMERCE_CONSUMER_SECRET') {
          (window as any).ENV.CONSUMER_SECRET = value;
          (window as any).ENV.REACT_APP_WC_CONSUMER_SECRET = value;
        }
        
        if (key === 'JWT_AUTH_SECRET_KEY') {
          (window as any).ENV.REACT_APP_JWT_SECRET_KEY = value;
        }
      });
      
      console.log('✅ EliteQ India credentials initialized in window.ENV');
      console.log('🔑 Available environment keys:', Object.keys((window as any).ENV).length);
      console.log('📋 Key preview:', Object.keys((window as any).ENV).slice(0, 5));
      
      // Debug log (with masked credentials)
      const debugInfo = {
        WOOCOMMERCE_CONSUMER_KEY: (window as any).ENV.WOOCOMMERCE_CONSUMER_KEY?.substring(0, 10) + '...',
        WOOCOMMERCE_CONSUMER_SECRET: (window as any).ENV.WOOCOMMERCE_CONSUMER_SECRET?.substring(0, 10) + '...',
        WORDPRESS_BASE_URL: (window as any).ENV.WORDPRESS_BASE_URL,
        JWT_AUTH_SECRET_KEY: (window as any).ENV.JWT_AUTH_SECRET_KEY ? 'Set' : 'Not set',
        totalKeys: Object.keys((window as any).ENV).length
      };
      
      console.log('🔍 Environment debug info:', debugInfo);
    }
  }, []);
  
  return null; // This component doesn't render anything
};

export default EnvironmentInitializer;