import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { CheckCircle, XCircle, RefreshCw, Zap } from 'lucide-react';
import { wooCommerceApi } from '../utils/woocommerce-api';

export const QuickAPITest: React.FC = () => {
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<{
    success: boolean;
    message: string;
    details?: any;
  } | null>(null);

  const runQuickTest = async () => {
    setTesting(true);
    setResult(null);
    
    try {
      console.log('🚀 Running quick API test...');
      
      // Test WooCommerce connection
      const connectionTest = await wooCommerceApi.testConnection();
      
      if (connectionTest.isConnected) {
        // Try to fetch a small amount of data
        const productsResponse = await wooCommerceApi.getProducts({ per_page: 1 });
        
        setResult({
          success: true,
          message: `WooCommerce API connected successfully! Found ${productsResponse.data?.length || 0} products.`,
          details: {
            latency: connectionTest.latency,
            endpoint: 'https://eliteq.in/wp-json/wc/v3',
            status: 'Connected'
          }
        });
      } else {
        setResult({
          success: false,
          message: `Connection failed: ${connectionTest.error}`,
          details: connectionTest.details
        });
      }
    } catch (error: any) {
      console.error('Quick test failed:', error);
      setResult({
        success: false,
        message: `API test failed: ${error.message || 'Unknown error'}`,
        details: {
          error: error.name,
          status: error.status || 'Unknown'
        }
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-green-600" />
          Quick API Test
        </CardTitle>
        <CardDescription>
          Instantly test WooCommerce API connection with EliteQ.in
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        
        <div className="flex items-center gap-3">
          <Button 
            onClick={runQuickTest} 
            disabled={testing}
            className="flex-shrink-0"
          >
            {testing ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                Testing...
              </>
            ) : (
              <>
                <Zap className="h-4 w-4 mr-2" />
                Test API Now
              </>
            )}
          </Button>
          
          <div className="text-sm text-gray-500">
            This will test the connection to eliteq.in WooCommerce API
          </div>
        </div>

        {result && (
          <Alert className={result.success ? 
            'border-green-200 bg-green-50 dark:bg-green-900/20' : 
            'border-red-200 bg-red-50 dark:bg-red-900/20'
          }>
            <div className="flex items-start gap-2">
              {result.success ? (
                <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
              ) : (
                <XCircle className="h-4 w-4 text-red-500 mt-0.5" />
              )}
              <div className="flex-1">
                <AlertDescription className="font-medium mb-2">
                  {result.message}
                </AlertDescription>
                
                {result.details && (
                  <div className="text-xs space-y-1">
                    {Object.entries(result.details).map(([key, value]) => (
                      <div key={key} className="flex justify-between">
                        <span className="capitalize">{key.replace(/_/g, ' ')}:</span>
                        <span className="font-mono">{String(value)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </Alert>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <div className="font-medium text-blue-900 dark:text-blue-100">Endpoint</div>
            <div className="text-blue-600 dark:text-blue-400 font-mono text-xs">
              eliteq.in/wp-json/wc/v3
            </div>
          </div>
          
          <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <div className="font-medium text-green-900 dark:text-green-100">Method</div>
            <div className="text-green-600 dark:text-green-400">Basic Auth</div>
          </div>
          
          <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
            <div className="font-medium text-purple-900 dark:text-purple-100">Test Type</div>
            <div className="text-purple-600 dark:text-purple-400">Live Connection</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickAPITest;