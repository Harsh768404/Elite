import React from 'react';
import { 
  ShoppingCart, DollarSign, CreditCard, TrendingUp, Eye, Package, 
  Users, Shield, BarChart3, Activity, AlertCircle
} from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { useRealTimeUpdates } from '../hooks/useRealTimeUpdates';

interface DashboardCardProps {
  currentRole: 'vendor' | 'admin';
  orderSummary: {
    newOrders: number;
    deliveredOrders: number;
    cancelledOrders: number;
    paidOrders: number;
    pendingOrders: number;
    productsInStock: number;
  };
}

const CardComponent = ({ title, value, icon: Icon, color, trend, subtitle, hasUpdate = false }) => (
  <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-white to-gray-50/50 border-0 shadow-sm relative">
    <CardContent className="p-6">
      {hasUpdate && (
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-red-500 rounded-full animate-pulse">
          <div className="absolute inset-0 bg-red-500 rounded-full animate-ping"></div>
        </div>
      )}
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <p className="text-sm font-medium text-gray-600">{title}</p>
            {hasUpdate && (
              <AlertCircle className="h-4 w-4 text-orange-500 animate-pulse" />
            )}
          </div>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-bold text-gray-900">{value}</h3>
            {trend && (
              <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                trend > 0 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-red-100 text-red-700'
              }`}>
                <TrendingUp className={`h-3 w-3 ${trend < 0 ? 'rotate-180' : ''}`} />
                {Math.abs(trend)}%
              </div>
            )}
          </div>
          {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
        </div>
        <div className={`p-4 rounded-2xl ${color} group-hover:scale-110 transition-transform duration-300`}>
          <Icon className="h-7 w-7 text-white" />
        </div>
      </div>
    </CardContent>
  </Card>
);

export function DashboardCard({ currentRole, orderSummary }: DashboardCardProps) {
  const { hasNewOrders, hasNewProducts, orderUpdates, productUpdates } = useRealTimeUpdates();
  const vendorCards = [
    {
      title: "Total Orders",
      value: orderSummary.newOrders + orderSummary.deliveredOrders + orderSummary.pendingOrders,
      icon: ShoppingCart,
      color: "bg-gradient-to-r from-blue-600 to-blue-700",
      trend: 12,
      subtitle: "This month",
      hasUpdate: hasNewOrders
    },
    {
      title: "Total Earnings",
      value: "₹1,24,500",
      icon: DollarSign,
      color: "bg-gradient-to-r from-green-600 to-green-700",
      trend: 8,
      subtitle: "This month"
    },
    {
      title: "Commission Paid",
      value: "₹12,450",
      icon: CreditCard,
      color: "bg-gradient-to-r from-purple-600 to-purple-700",
      trend: -2,
      subtitle: "This month"
    },
    {
      title: "Net Profit",
      value: "₹1,12,050",
      icon: TrendingUp,
      color: "bg-gradient-to-r from-emerald-600 to-emerald-700",
      trend: 15,
      subtitle: "This month"
    },
    {
      title: "Store Visitors",
      value: "2,847",
      icon: Eye,
      color: "bg-gradient-to-r from-indigo-600 to-indigo-700",
      trend: 22,
      subtitle: "This week"
    },
    {
      title: "Products In Stock",
      value: orderSummary.productsInStock,
      icon: Package,
      color: "bg-gradient-to-r from-orange-600 to-orange-700",
      trend: 5,
      subtitle: "Available products",
      hasUpdate: hasNewProducts
    }
  ];

  const adminCards = [
    {
      title: "Total Platform Revenue",
      value: "₹45,67,890",
      icon: DollarSign,
      color: "bg-gradient-to-r from-green-600 to-green-700",
      trend: 18,
      subtitle: "This month"
    },
    {
      title: "Active Vendors",
      value: "67",
      icon: Users,
      color: "bg-gradient-to-r from-blue-600 to-blue-700",
      trend: 8,
      subtitle: "Verified vendors"
    },
    {
      title: "Platform Orders",
      value: orderSummary.newOrders + orderSummary.deliveredOrders + orderSummary.pendingOrders,
      icon: ShoppingCart,
      color: "bg-gradient-to-r from-purple-600 to-purple-700",
      trend: 25,
      subtitle: "This month",
      hasUpdate: hasNewOrders
    },
    {
      title: "Commission Earned",
      value: "₹4,56,789",
      icon: CreditCard,
      color: "bg-gradient-to-r from-indigo-600 to-indigo-700",
      trend: 12,
      subtitle: "This month"
    },
    {
      title: "KYC Pending",
      value: "12",
      icon: Shield,
      color: "bg-gradient-to-r from-amber-600 to-amber-700",
      trend: -15,
      subtitle: "Vendors awaiting approval"
    },
    {
      title: "Platform Growth",
      value: "23.5%",
      icon: BarChart3,
      color: "bg-gradient-to-r from-emerald-600 to-emerald-700",
      trend: 5,
      subtitle: "Monthly growth rate"
    }
  ];

  const cards = currentRole === 'admin' ? adminCards : vendorCards;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-6 gap-6">
      {cards.map((card, index) => (
        <CardComponent key={index} {...card} />
      ))}
    </div>
  );
}