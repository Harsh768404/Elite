/**
 * Comprehensive WordPress/WooCommerce API Service
 * EliteQ India - Real Data Integration with Live Credentials
 * Handles all WordPress REST API endpoints with real authentication and data fetching
 */

import { ALL_ENDPOINTS, buildAuthenticatedUrl, ELITEQ_API_CONFIG, getRealDataEndpoint, getAuthHeaders } from '../config/wordpress-endpoints';

// Enhanced API Configuration for Real Data with improved timeouts
const API_CONFIG = {
  ...ELITEQ_API_CONFIG,
  timeout: 30000, // 30 seconds for real API calls (increased from 15s)
  backgroundTimeout: 20000, // 20 seconds for background operations (increased from 8s)
  jwtTimeout: 25000, // 25 seconds specifically for JWT operations
  retryAttempts: 3, // Increased retry attempts
  cacheTimeout: 300000, // 5 minutes cache for real data
};

// Cache implementation
interface CacheEntry {
  data: any;
  timestamp: number;
  expires: number;
}

class APICache {
  private cache = new Map<string, CacheEntry>();

  set(key: string, data: any, ttl: number = API_CONFIG.cacheTimeout): void {
    const now = Date.now();
    this.cache.set(key, {
      data,
      timestamp: now,
      expires: now + ttl,
    });
  }

  get(key: string): any | null {
    const entry = this.cache.get(key);
    if (!entry) return null;

    if (Date.now() > entry.expires) {
      this.cache.delete(key);
      return null;
    }

    return entry.data;
  }

  clear(): void {
    this.cache.clear();
  }

  getStats(): { size: number; keys: string[] } {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys()),
    };
  }
}

// Enhanced Request Options for Real Data
interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  headers?: Record<string, string>;
  body?: any;
  auth?: 'jwt' | 'consumer' | 'none';
  cache?: boolean;
  timeout?: number;
  isBackground?: boolean;
  useRealData?: boolean; // Flag to force real data fetching
}

class WordPressAPIService {
  private cache = new APICache();
  private jwtToken: string | null = null;
  private failureCount = 0;
  private lastFailureTime = 0;
  private maxFailures = 5;
  private isLiveConnection = true; // Flag to track if we're connected to live site

  constructor() {
    // Try to get JWT token from localStorage
    if (typeof window !== 'undefined') {
      this.jwtToken = localStorage.getItem('eliteq_jwt_token');
    }
    
    console.log('🔗 WordPress API Service initialized for EliteQ.in');
    console.log('🌐 Base URL:', API_CONFIG.baseUrl);
    console.log('🔑 Consumer Key:', API_CONFIG.consumerKey.substring(0, 10) + '...');
  }

  // Authentication Methods with Real WordPress
  async authenticate(username: string, password: string): Promise<any> {
    const maxRetries = 2;
    let lastError;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`🔐 Authentication attempt ${attempt}/${maxRetries} with real WordPress at eliteq.in...`);
        console.log('👤 Username:', username);
        console.log('🔒 Password length:', password ? password.length : 0, 'characters');
        
        // Validate input parameters
        if (!username || !password) {
          throw new Error('Username and password are required');
        }
        
        if (!username.trim()) {
          throw new Error('Username cannot be empty');
        }
        
        if (!password.trim()) {
          throw new Error('Password cannot be empty');
        }
        
        const requestBody = {
          username: username.trim(),
          password: password.trim()
        };
        
        console.log('📤 Sending authentication request body:', { username: requestBody.username, password: '***' });
        
        const response = await this.makeRequest(ALL_ENDPOINTS.users.jwtAuth, {
          method: 'POST',
          body: requestBody,
          auth: 'none',
          useRealData: true,
          timeout: API_CONFIG.jwtTimeout,
        });

        if (response.token) {
          this.jwtToken = response.token;
          if (typeof window !== 'undefined') {
            localStorage.setItem('eliteq_jwt_token', response.token);
            localStorage.setItem('eliteq_user_data', JSON.stringify(response.user || {}));
          }
          // Reset failure count on successful auth
          this.failureCount = 0;
          this.isLiveConnection = true;
          
          console.log('✅ Real WordPress authentication successful');
          console.log('👤 User roles:', response.user?.roles || 'Unknown');
        }

        return response;
      } catch (error) {
        lastError = error;
        console.error(`❌ Authentication attempt ${attempt} failed:`, error);
        
        if (attempt < maxRetries && error.message?.includes('timeout')) {
          console.log(`⏳ Retrying authentication in 2 seconds...`);
          await new Promise(resolve => setTimeout(resolve, 2000));
        } else {
          console.error('❌ Real WordPress authentication failed after all retries:', error);
          throw error;
        }
      }
    }

    throw lastError;
  }

  async validateToken(): Promise<boolean> {
    if (!this.jwtToken) return false;

    try {
      console.log('🔐 Validating JWT token with increased timeout...');
      await this.makeRequest(ALL_ENDPOINTS.users.jwtValidate, {
        method: 'POST',
        auth: 'jwt',
        timeout: API_CONFIG.jwtTimeout, // Use longer timeout for JWT validation
        useRealData: true,
      });
      this.failureCount = 0;
      console.log('✅ JWT token validated against real WordPress');
      return true;
    } catch (error) {
      console.error('❌ JWT token validation failed:', error);
      
      // Don't logout immediately on timeout - could be temporary network issue
      if (error.message?.includes('timeout')) {
        console.warn('⚠️ JWT validation timeout - keeping token for retry');
        return false; // Return false but don't logout
      }
      
      // Only logout on actual auth failures
      console.log('🚪 Logging out due to authentication failure');
      this.logout();
      return false;
    }
  }

  logout(): void {
    this.jwtToken = null;
    if (typeof window !== 'undefined') {
      localStorage.removeItem('eliteq_jwt_token');
      localStorage.removeItem('eliteq_user_data');
    }
    this.cache.clear();
  }

  // Enhanced request method for real data fetching with improved timeout handling
  private async makeRequest(url: string, options: RequestOptions = {}): Promise<any> {
    const {
      method = 'GET',
      headers = {},
      body,
      auth = 'consumer',
      cache = method === 'GET',
      timeout = options.isBackground ? API_CONFIG.backgroundTimeout : API_CONFIG.timeout,
      isBackground = false,
      useRealData = true,
    } = options;

    // Use JWT-specific timeout for JWT operations
    const effectiveTimeout = url.includes('jwt-auth') ? API_CONFIG.jwtTimeout : timeout;

    // Skip background requests if we're experiencing issues
    if (this.shouldSkipRequest(isBackground)) {
      throw new Error('Skipping request due to repeated failures');
    }

    // Check cache for GET requests
    const cacheKey = `${url}:${JSON.stringify(body || {})}`;
    if (cache && method === 'GET') {
      const cachedData = this.cache.get(cacheKey);
      if (cachedData) {
        return cachedData;
      }
    }

    // Build authenticated URL for WooCommerce endpoints
    let finalUrl = url;
    if (auth === 'consumer' && (url.includes('/wc/v3/') || url.includes('/dokan/v1/'))) {
      finalUrl = buildAuthenticatedUrl(url);
    } else if (auth === 'consumer' && useRealData) {
      // Add consumer credentials to other endpoints too
      const separator = url.includes('?') ? '&' : '?';
      finalUrl += `${separator}consumer_key=${API_CONFIG.consumerKey}&consumer_secret=${API_CONFIG.consumerSecret}`;
    }

    // Prepare request options
    const requestOptions: RequestInit = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'EliteQ-Admin-Panel/1.0',
        ...headers,
      },
    };

    // Add JWT authentication if available
    if (auth === 'jwt' && this.jwtToken) {
      requestOptions.headers = {
        ...requestOptions.headers,
        'Authorization': `Bearer ${this.jwtToken}`,
      };
    }

    // Add body for non-GET requests
    if (body && method !== 'GET') {
      if (body instanceof FormData) {
        // Remove Content-Type for FormData
        delete (requestOptions.headers as any)['Content-Type'];
        requestOptions.body = body;
      } else {
        requestOptions.body = JSON.stringify(body);
      }
    }

    // Create timeout promise with better error messaging
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => {
        const timeoutError = new Error(`Request timeout after ${effectiveTimeout}ms for ${url.split('?')[0]}`);
        reject(timeoutError);
      }, effectiveTimeout);
    });

    try {
      if (!isBackground) {
        console.log(`🌐 Making ${method} request to EliteQ:`, finalUrl.replace(API_CONFIG.consumerKey, 'ck_***').replace(API_CONFIG.consumerSecret, 'cs_***'));
      }
      
      const response = await Promise.race([
        fetch(finalUrl, requestOptions),
        timeoutPromise,
      ]) as Response;

      if (!response.ok) {
        let errorText = `HTTP ${response.status}`;
        try {
          const errorData = await response.text();
          errorText = `HTTP ${response.status}: ${errorData}`;
        } catch {
          // Ignore JSON parsing errors for error messages
        }
        throw new Error(errorText);
      }

      const data = await response.json();

      // Cache successful GET requests
      if (cache && method === 'GET') {
        this.cache.set(cacheKey, data);
      }

      // Reset failure count on success
      if (isBackground) {
        this.failureCount = Math.max(0, this.failureCount - 1);
      }

      if (!isBackground) {
        console.log(`✅ Real data received from EliteQ:`, Array.isArray(data) ? `${data.length} items` : 'Single item');
      }

      return data;
    } catch (error) {
      // Track failures for background requests
      if (isBackground) {
        this.failureCount++;
        this.lastFailureTime = Date.now();
      }

      if (!isBackground) {
        console.error(`❌ Request failed for EliteQ:`, error.message);
      }
      
      throw error;
    }
  }

  // Check if we should skip requests due to repeated failures
  private shouldSkipRequest(isBackground: boolean = false): boolean {
    if (!isBackground) return false;
    
    const now = Date.now();
    const timeSinceLastFailure = now - this.lastFailureTime;
    
    if (this.failureCount >= this.maxFailures && timeSinceLastFailure < 60000) {
      return true;
    }
    
    if (timeSinceLastFailure > 300000) {
      this.failureCount = 0;
    }
    
    return false;
  }

  // Real WordPress Core Content Methods
  async getPosts(params: any = {}): Promise<any[]> {
    const url = getRealDataEndpoint('posts', { per_page: 10, ...params });
    return this.makeRequest(url, { useRealData: true });
  }

  async getPost(id: number): Promise<any> {
    return this.makeRequest(`${ALL_ENDPOINTS.core.posts}/${id}`, { useRealData: true });
  }

  async getPages(params: any = {}): Promise<any[]> {
    const url = getRealDataEndpoint('pages', { per_page: 10, ...params });
    return this.makeRequest(url, { useRealData: true });
  }

  async getMedia(params: any = {}): Promise<any[]> {
    return this.makeRequest(buildAuthenticatedUrl(ALL_ENDPOINTS.core.media, params), { useRealData: true });
  }

  // Real WooCommerce Products Methods
  async getProducts(params: any = {}): Promise<any[]> {
    const url = getRealDataEndpoint('products', { per_page: 20, ...params });
    return this.makeRequest(url, { useRealData: true });
  }

  async getProduct(id: number): Promise<any> {
    const url = buildAuthenticatedUrl(`${ALL_ENDPOINTS.woocommerce.products}/${id}`);
    return this.makeRequest(url, { useRealData: true });
  }

  async createProduct(productData: any): Promise<any> {
    const url = buildAuthenticatedUrl(ALL_ENDPOINTS.woocommerce.products);
    return this.makeRequest(url, {
      method: 'POST',
      body: productData,
      auth: 'consumer',
      useRealData: true,
    });
  }

  async updateProduct(id: number, productData: any): Promise<any> {
    const url = buildAuthenticatedUrl(`${ALL_ENDPOINTS.woocommerce.products}/${id}`);
    return this.makeRequest(url, {
      method: 'PUT',
      body: productData,
      auth: 'consumer',
      useRealData: true,
    });
  }

  // Real WooCommerce Orders Methods
  async getOrders(params: any = {}): Promise<any[]> {
    const url = getRealDataEndpoint('orders', { per_page: 20, ...params });
    return this.makeRequest(url, { useRealData: true });
  }

  async getOrder(id: number): Promise<any> {
    const url = buildAuthenticatedUrl(`${ALL_ENDPOINTS.woocommerce.orders}/${id}`);
    return this.makeRequest(url, { useRealData: true });
  }

  async createOrder(orderData: any): Promise<any> {
    const url = buildAuthenticatedUrl(ALL_ENDPOINTS.woocommerce.orders);
    return this.makeRequest(url, {
      method: 'POST',
      body: orderData,
      auth: 'consumer',
      useRealData: true,
    });
  }

  async updateOrder(id: number, orderData: any): Promise<any> {
    const url = buildAuthenticatedUrl(`${ALL_ENDPOINTS.woocommerce.orders}/${id}`);
    return this.makeRequest(url, {
      method: 'PUT',
      body: orderData,
      auth: 'consumer',
      useRealData: true,
    });
  }

  // Real WooCommerce Customers Methods
  async getCustomers(params: any = {}): Promise<any[]> {
    const url = getRealDataEndpoint('customers', { per_page: 20, ...params });
    return this.makeRequest(url, { useRealData: true });
  }

  async getCustomer(id: number): Promise<any> {
    const url = buildAuthenticatedUrl(`${ALL_ENDPOINTS.woocommerce.customers}/${id}`);
    return this.makeRequest(url, { useRealData: true });
  }

  async createCustomer(customerData: any): Promise<any> {
    const url = buildAuthenticatedUrl(ALL_ENDPOINTS.woocommerce.customers);
    return this.makeRequest(url, {
      method: 'POST',
      body: customerData,
      auth: 'consumer',
      useRealData: true,
    });
  }

  // Real Coupons Methods
  async getCoupons(params: any = {}): Promise<any[]> {
    const url = getRealDataEndpoint('coupons', { per_page: 20, ...params });
    return this.makeRequest(url, { useRealData: true });
  }

  async createCoupon(couponData: any): Promise<any> {
    const url = buildAuthenticatedUrl(ALL_ENDPOINTS.woocommerce.coupons);
    return this.makeRequest(url, {
      method: 'POST',
      body: couponData,
      auth: 'consumer',
      useRealData: true,
    });
  }

  // Real Taxonomies Methods
  async getCategories(params: any = {}): Promise<any[]> {
    return this.makeRequest(buildAuthenticatedUrl(ALL_ENDPOINTS.taxonomies.categories, params), { useRealData: true });
  }

  async getTags(params: any = {}): Promise<any[]> {
    return this.makeRequest(buildAuthenticatedUrl(ALL_ENDPOINTS.taxonomies.tags, params), { useRealData: true });
  }

  async getProductCategories(params: any = {}): Promise<any[]> {
    const url = getRealDataEndpoint('categories', { per_page: 50, ...params });
    return this.makeRequest(url, { useRealData: true });
  }

  async getProductTags(params: any = {}): Promise<any[]> {
    return this.makeRequest(buildAuthenticatedUrl(ALL_ENDPOINTS.woocommerce.productTags, params), { useRealData: true });
  }

  // Real Dokan Methods
  async getStores(params: any = {}): Promise<any[]> {
    const url = getRealDataEndpoint('stores', { per_page: 20, ...params });
    return this.makeRequest(url, { useRealData: true });
  }

  async getVendors(params: any = {}): Promise<any[]> {
    const url = getRealDataEndpoint('vendors', { per_page: 20, ...params });
    return this.makeRequest(url, { useRealData: true });
  }

  async getAnnouncements(params: any = {}): Promise<any[]> {
    return this.makeRequest(buildAuthenticatedUrl(ALL_ENDPOINTS.dokan.announcements, params), { useRealData: true });
  }

  // Real Users Methods
  async getUsers(params: any = {}): Promise<any[]> {
    const url = getRealDataEndpoint('users', { per_page: 20, ...params });
    return this.makeRequest(url, { auth: 'jwt', useRealData: true });
  }

  async getCurrentUser(): Promise<any> {
    return this.makeRequest(ALL_ENDPOINTS.users.me, { auth: 'jwt', useRealData: true });
  }

  // Enhanced User Role Detection for Real WordPress
  async getUserWithRoles(userId?: number): Promise<any> {
    try {
      const endpoint = userId ? `${ALL_ENDPOINTS.users.users}/${userId}` : ALL_ENDPOINTS.users.me;
      const user = await this.makeRequest(endpoint, { auth: 'jwt', useRealData: true });
      
      if (user && user.roles) {
        console.log('👤 Real user roles detected:', user.roles);
        
        // Store user data and roles in localStorage
        if (typeof window !== 'undefined') {
          localStorage.setItem('eliteq_user_roles', JSON.stringify(user.roles));
          localStorage.setItem('eliteq_user_data', JSON.stringify(user));
          
          // Determine primary role for routing
          const primaryRole = this.determinePrimaryRole(user.roles);
          localStorage.setItem('eliteq_primary_role', primaryRole);
        }
      }
      
      return user;
    } catch (error) {
      console.error('❌ Failed to fetch user roles:', error);
      throw error;
    }
  }

  // Determine primary role from WordPress roles array with proper administrator mapping
  private determinePrimaryRole(roles: string[]): string {
    console.log('🎯 Determining primary role from:', roles);
    
    // Role priority mapping for EliteQ - FIXED: administrator should map to administrator, not admin
    const rolePriority = {
      'administrator': 'administrator', // FIXED: Keep as administrator for routing system
      'editor': 'administrator', // Editors also get admin access
      'author': 'administrator', // Authors also get admin access  
      'dokan_vendor': 'vendor',
      'vendor': 'vendor',
      'seller': 'vendor',
      'shop_manager': 'vendor',
      'wcfm_vendor': 'vendor',
      'wc_product_vendors_admin_vendor': 'vendor',
      'customer': 'customer',
      'subscriber': 'customer',
    };

    // Find the highest priority role
    for (const role of roles) {
      if (rolePriority[role]) {
        const mappedRole = rolePriority[role];
        console.log(`✅ Primary role determined: ${mappedRole} (from WordPress role: ${role})`);
        console.log(`🔍 Role mapping: WordPress "${role}" → System "${mappedRole}"`);
        return mappedRole;
      }
    }

    // Default to customer if no specific role found
    console.log('⚠️ No specific role found, defaulting to customer');
    return 'customer';
  }

  // Real WordPress Capabilities Check
  async getUserCapabilities(): Promise<string[]> {
    try {
      const user = await this.getCurrentUser();
      if (user && user.capabilities) {
        const capabilities = Object.keys(user.capabilities).filter(cap => user.capabilities[cap]);
        console.log('🔑 User capabilities:', capabilities);
        return capabilities;
      }
      return [];
    } catch (error) {
      console.error('❌ Failed to fetch user capabilities:', error);
      return [];
    }
  }

  // Real WordPress User Meta
  async getUserMeta(userId?: number): Promise<any> {
    try {
      const user = await this.getUserWithRoles(userId);
      return user.meta || {};
    } catch (error) {
      console.error('❌ Failed to fetch user meta:', error);
      return {};
    }
  }

  // Real Vendor-specific data (for Dokan/WooCommerce vendors)
  async getVendorData(vendorId?: number): Promise<any> {
    try {
      const user = await this.getUserWithRoles(vendorId);
      
      // If user is a vendor, fetch vendor-specific data
      if (user && user.roles && this.determinePrimaryRole(user.roles) === 'vendor') {
        const [vendorInfo, vendorOrders, vendorProducts] = await Promise.allSettled([
          this.getEndpointData(`/wp-json/dokan/v1/stores/${user.id}`).catch(() => null),
          this.getOrders({ vendor: user.id, per_page: 5 }).catch(() => []),
          this.getProducts({ vendor: user.id, per_page: 5 }).catch(() => []),
        ]);

        return {
          user,
          vendorInfo: vendorInfo.status === 'fulfilled' ? vendorInfo.value : null,
          recentOrders: vendorOrders.status === 'fulfilled' ? vendorOrders.value : [],
          recentProducts: vendorProducts.status === 'fulfilled' ? vendorProducts.value : [],
          isVendor: true,
        };
      }

      return { user, isVendor: false };
    } catch (error) {
      console.error('❌ Failed to fetch vendor data:', error);
      throw error;
    }
  }

  // Reports and Analytics with Real Data
  async getSalesReport(params: any = {}): Promise<any> {
    const url = buildAuthenticatedUrl(ALL_ENDPOINTS.woocommerce.reportsSales, params);
    return this.makeRequest(url, { useRealData: true });
  }

  async getTopSellers(params: any = {}): Promise<any[]> {
    const url = buildAuthenticatedUrl(ALL_ENDPOINTS.woocommerce.reportsTopSellers, params);
    return this.makeRequest(url, { useRealData: true });
  }

  async getCustomerReports(params: any = {}): Promise<any> {
    const url = buildAuthenticatedUrl(ALL_ENDPOINTS.woocommerce.reportsCustomers, params);
    return this.makeRequest(url, { useRealData: true });
  }

  // Health Check with Real EliteQ Connection
  async healthCheck(isBackground: boolean = false): Promise<any> {
    try {
      const results = await Promise.allSettled([
        this.makeRequest(`${API_CONFIG.baseUrl}/wp-json/`, { 
          isBackground,
          timeout: isBackground ? 5000 : 10000,
          useRealData: true,
        }),
        this.makeRequest(buildAuthenticatedUrl(`${API_CONFIG.baseUrl}/wp-json/wc/v3/`), { 
          isBackground,
          timeout: isBackground ? 5000 : 10000,
          useRealData: true,
        }),
        this.getProducts({ per_page: 1 }).catch(() => null),
      ]);

      const healthStatus = {
        wordpress: results[0].status === 'fulfilled',
        woocommerce: results[1].status === 'fulfilled',
        api: results[2].status === 'fulfilled',
        timestamp: new Date().toISOString(),
        failureCount: this.failureCount,
        isLive: this.isLiveConnection,
        site: 'eliteq.in',
      };

      if (!isBackground) {
        console.log('🏥 EliteQ.in Health Check:', healthStatus);
      }

      return healthStatus;
    } catch (error) {
      if (!isBackground) {
        console.error('🏥 EliteQ.in health check failed:', error);
      }
      return {
        wordpress: false,
        woocommerce: false,
        api: false,
        error: error.message,
        timestamp: new Date().toISOString(),
        failureCount: this.failureCount,
        isLive: false,
        site: 'eliteq.in',
      };
    }
  }

  // Utility Methods
  async getEndpointData(endpoint: string, params: any = {}): Promise<any> {
    const url = buildAuthenticatedUrl(endpoint, params);
    return this.makeRequest(url, { useRealData: true });
  }

  async postToEndpoint(endpoint: string, data: any): Promise<any> {
    const url = buildAuthenticatedUrl(endpoint);
    return this.makeRequest(url, {
      method: 'POST',
      body: data,
      auth: 'consumer',
      useRealData: true,
    });
  }

  // Cache Management
  clearCache(): void {
    this.cache.clear();
    console.log('🗑️ API cache cleared');
  }

  getCacheStats(): any {
    return {
      ...this.cache.getStats(),
      failureCount: this.failureCount,
      isLive: this.isLiveConnection,
      lastFailure: this.lastFailureTime,
    };
  }

  // Batch Operations with Real Data
  async batchRequest(requests: Array<{ endpoint: string; method?: string; data?: any }>, isBackground: boolean = false): Promise<any[]> {
    const promises = requests.map(req => {
      const url = buildAuthenticatedUrl(req.endpoint);
      return this.makeRequest(url, {
        method: (req.method as any) || 'GET',
        body: req.data,
        auth: 'consumer',
        isBackground,
        useRealData: true,
      }).catch(error => ({ error: error.message }));
    });

    return Promise.all(promises);
  }

  // Get failure statistics
  getFailureStats(): { count: number; lastFailure: number; shouldSkip: boolean; isLive: boolean } {
    return {
      count: this.failureCount,
      lastFailure: this.lastFailureTime,
      shouldSkip: this.shouldSkipRequest(true),
      isLive: this.isLiveConnection,
    };
  }

  // Real Dashboard Data Aggregation
  async getRealDashboardData(): Promise<any> {
    try {
      console.log('📊 Fetching real dashboard data from EliteQ.in...');
      
      const [
        products,
        orders,
        customers,
        stores,
        categories,
        salesReport,
      ] = await Promise.allSettled([
        this.getProducts({ per_page: 5, orderby: 'date', order: 'desc' }),
        this.getOrders({ per_page: 5, orderby: 'date', order: 'desc' }),
        this.getCustomers({ per_page: 5, orderby: 'registered_date', order: 'desc' }),
        this.getStores({ per_page: 5 }),
        this.getProductCategories({ per_page: 10 }),
        this.getSalesReport({ period: 'week' }).catch(() => ({})),
      ]);

      const dashboardData = {
        products: {
          recent: products.status === 'fulfilled' ? products.value : [],
          total: products.status === 'fulfilled' ? products.value.length : 0,
        },
        orders: {
          recent: orders.status === 'fulfilled' ? orders.value : [],
          total: orders.status === 'fulfilled' ? orders.value.length : 0,
        },
        customers: {
          recent: customers.status === 'fulfilled' ? customers.value : [],
          total: customers.status === 'fulfilled' ? customers.value.length : 0,
        },
        stores: {
          list: stores.status === 'fulfilled' ? stores.value : [],
          total: stores.status === 'fulfilled' ? stores.value.length : 0,
        },
        categories: categories.status === 'fulfilled' ? categories.value : [],
        sales: salesReport.status === 'fulfilled' ? salesReport.value : {},
        lastUpdated: new Date().toISOString(),
        source: 'eliteq.in',
        isRealData: true,
      };

      console.log('✅ Real dashboard data fetched:', {
        products: dashboardData.products.total,
        orders: dashboardData.orders.total,
        customers: dashboardData.customers.total,
        stores: dashboardData.stores.total,
        categories: dashboardData.categories.length,
      });

      return dashboardData;
    } catch (error) {
      console.error('❌ Failed to fetch real dashboard data:', error);
      throw error;
    }
  }
}

// Export singleton instance configured for EliteQ.in
export const wordpressAPI = new WordPressAPIService();

// Export class for custom instances
export { WordPressAPIService };

export default wordpressAPI;