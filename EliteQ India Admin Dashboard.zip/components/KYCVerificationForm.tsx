import React, { useState } from 'react';
import { 
  ShieldCheck, Upload, FileText, Save, User, Phone, Mail, MapPin, 
  CheckCircle, AlertCircle, Download, X, Eye
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';

interface DocumentUpload {
  id: string;
  name: string;
  required: boolean;
  file?: File;
  uploaded: boolean;
  status: 'pending' | 'approved' | 'rejected';
  uploadProgress?: number;
}

interface KYCFormData {
  fullName: string;
  mobileNumber: string;
  emailAddress: string;
  address: string;
}

const requiredDocuments: DocumentUpload[] = [
  { id: 'aadhaar', name: 'Aadhaar Card', required: true, uploaded: false, status: 'pending' },
  { id: 'pan', name: 'PAN Card', required: true, uploaded: false, status: 'pending' },
  { id: 'bank', name: 'Bank Statement', required: true, uploaded: false, status: 'pending' },
  { id: 'gst', name: 'GST Certificate', required: false, uploaded: false, status: 'pending' },
  { id: 'udyam', name: 'Udyam Aadhar', required: true, uploaded: false, status: 'pending' }
];

export function KYCVerificationForm() {
  const [formData, setFormData] = useState<KYCFormData>({
    fullName: '',
    mobileNumber: '',
    emailAddress: '',
    address: ''
  });
  
  const [documents, setDocuments] = useState<DocumentUpload[]>(requiredDocuments);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [formErrors, setFormErrors] = useState<Partial<KYCFormData>>({});

  const handleInputChange = (field: keyof KYCFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (formErrors[field]) {
      setFormErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const errors: Partial<KYCFormData> = {};

    if (!formData.fullName.trim()) errors.fullName = 'Full name is required';
    if (!formData.mobileNumber.trim()) errors.mobileNumber = 'Mobile number is required';
    if (!formData.emailAddress.trim()) errors.emailAddress = 'Email address is required';
    if (!formData.address.trim()) errors.address = 'Address is required';

    // Validate mobile number format
    if (formData.mobileNumber && !/^\d{10}$/.test(formData.mobileNumber.replace(/\D/g, ''))) {
      errors.mobileNumber = 'Please enter a valid 10-digit mobile number';
    }

    // Validate email format
    if (formData.emailAddress && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.emailAddress)) {
      errors.emailAddress = 'Please enter a valid email address';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleFileUpload = async (documentId: string, file: File) => {
    // Validate file size (2MB limit)
    if (file.size > 2 * 1024 * 1024) {
      alert('File size must be under 2MB');
      return;
    }

    // Validate file type
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!allowedTypes.includes(file.type)) {
      alert('Only PDF, JPEG, and PNG files are allowed');
      return;
    }

    // Start upload simulation
    setDocuments(prev => prev.map(doc => 
      doc.id === documentId 
        ? { ...doc, uploadProgress: 0 }
        : doc
    ));

    // Simulate upload progress
    for (let i = 0; i <= 100; i += 10) {
      await new Promise(resolve => setTimeout(resolve, 100));
      setDocuments(prev => prev.map(doc => 
        doc.id === documentId 
          ? { ...doc, uploadProgress: i }
          : doc
      ));
    }

    // Mark as uploaded
    setDocuments(prev => prev.map(doc => 
      doc.id === documentId 
        ? { ...doc, uploaded: true, file, status: 'pending' as const, uploadProgress: undefined }
        : doc
    ));
  };

  const removeDocument = (documentId: string) => {
    setDocuments(prev => prev.map(doc => 
      doc.id === documentId 
        ? { ...doc, uploaded: false, file: undefined, status: 'pending' as const }
        : doc
    ));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    const requiredDocs = documents.filter(doc => doc.required);
    const uploadedRequiredDocs = requiredDocs.filter(doc => doc.uploaded);
    
    if (uploadedRequiredDocs.length !== requiredDocs.length) {
      alert('Please upload all required documents before submitting');
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate API call to backend
      const kycData = {
        personalInfo: formData,
        documents: documents.filter(doc => doc.uploaded).map(doc => ({
          type: doc.id,
          fileName: doc.file?.name,
          fileSize: doc.file?.size
        }))
      };

      console.log('Submitting KYC data:', kycData);
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setSubmitSuccess(true);
    } catch (error) {
      console.error('Failed to submit KYC data:', error);
      alert('Failed to submit KYC verification. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const uploadedCount = documents.filter(doc => doc.uploaded).length;
  const totalDocuments = documents.length;
  const requiredUploadedCount = documents.filter(doc => doc.required && doc.uploaded).length;
  const totalRequiredDocuments = documents.filter(doc => doc.required).length;

  if (submitSuccess) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-6 text-center">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-green-800 mb-2">
              KYC Verification Submitted Successfully!
            </h3>
            <p className="text-green-700 mb-4">
              Your KYC verification has been submitted for review. Our team will process your application within 2-3 business days.
            </p>
            <Button 
              onClick={() => setSubmitSuccess(false)}
              className="bg-green-600 hover:bg-green-700"
            >
              View Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
          <ShieldCheck className="h-6 w-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">KYC Verification</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Complete your verification to activate your EliteQ India vendor account
          </p>
        </div>
      </div>

      {/* Progress Indicator */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Verification Progress
            </span>
            <span className="text-sm text-gray-500">
              {requiredUploadedCount}/{totalRequiredDocuments} required documents
            </span>
          </div>
          <Progress 
            value={(requiredUploadedCount / totalRequiredDocuments) * 100} 
            className="h-2"
          />
        </CardContent>
      </Card>

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5 text-blue-600" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">
                  Full Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="fullName"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  placeholder="Enter your full name"
                  className={formErrors.fullName ? 'border-red-500' : ''}
                />
                {formErrors.fullName && (
                  <p className="text-sm text-red-600">{formErrors.fullName}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="mobileNumber">
                  Mobile Number <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="mobileNumber"
                    value={formData.mobileNumber}
                    onChange={(e) => handleInputChange('mobileNumber', e.target.value)}
                    placeholder="Enter your mobile number"
                    className={`pl-10 ${formErrors.mobileNumber ? 'border-red-500' : ''}`}
                  />
                </div>
                {formErrors.mobileNumber && (
                  <p className="text-sm text-red-600">{formErrors.mobileNumber}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="emailAddress">
                  Email Address <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="emailAddress"
                    type="email"
                    value={formData.emailAddress}
                    onChange={(e) => handleInputChange('emailAddress', e.target.value)}
                    placeholder="Enter your email address"
                    className={`pl-10 ${formErrors.emailAddress ? 'border-red-500' : ''}`}
                  />
                </div>
                {formErrors.emailAddress && (
                  <p className="text-sm text-red-600">{formErrors.emailAddress}</p>
                )}
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="address">
                  Address <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Textarea
                    id="address"
                    value={formData.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    placeholder="Enter your complete address"
                    className={`pl-10 min-h-[80px] ${formErrors.address ? 'border-red-500' : ''}`}
                  />
                </div>
                {formErrors.address && (
                  <p className="text-sm text-red-600">{formErrors.address}</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Document Uploads */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-green-600" />
              Document Uploads
            </CardTitle>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Upload clear, readable documents in PDF, JPEG, or PNG format (max 2MB each)
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {documents.map((document) => (
                <div key={document.id} className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 hover:border-blue-400 transition-colors">
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-3">
                      <FileText className="h-8 w-8 text-gray-400" />
                    </div>
                    
                    <h4 className="font-medium text-gray-900 dark:text-white mb-1">
                      {document.name}
                      {document.required && <span className="text-red-500 ml-1">*</span>}
                    </h4>

                    {document.uploaded ? (
                      <div className="space-y-3">
                        <Badge variant="secondary" className="text-green-700 bg-green-100">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Uploaded
                        </Badge>
                        
                        <div className="text-xs text-gray-500 break-all px-2">
                          {document.file?.name}
                        </div>
                        
                        <div className="flex gap-2 justify-center">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => removeDocument(document.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <X className="h-3 w-3 mr-1" />
                            Remove
                          </Button>
                        </div>
                      </div>
                    ) : document.uploadProgress !== undefined ? (
                      <div className="space-y-2">
                        <div className="text-sm text-blue-600">Uploading...</div>
                        <Progress value={document.uploadProgress} className="h-2" />
                        <div className="text-xs text-gray-500">
                          {document.uploadProgress}%
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <input
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleFileUpload(document.id, file);
                          }}
                          className="hidden"
                          id={`file-${document.id}`}
                        />
                        <label
                          htmlFor={`file-${document.id}`}
                          className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 rounded-lg cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-900/70 transition-colors"
                        >
                          <Upload className="h-4 w-4" />
                          Choose File
                        </label>
                        <p className="text-xs text-gray-500">
                          PDF, JPEG, PNG (max 2MB)
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Upload Summary */}
            <Separator className="my-6" />
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-4">
                <span className="text-gray-600 dark:text-gray-400">
                  Documents uploaded: {uploadedCount}/{totalDocuments}
                </span>
                <span className="text-gray-600 dark:text-gray-400">
                  Required: {requiredUploadedCount}/{totalRequiredDocuments}
                </span>
              </div>
              
              {requiredUploadedCount === totalRequiredDocuments ? (
                <div className="flex items-center gap-2 text-green-700">
                  <CheckCircle className="h-4 w-4" />
                  Ready to submit
                </div>
              ) : (
                <div className="flex items-center gap-2 text-amber-700">
                  <AlertCircle className="h-4 w-4" />
                  {totalRequiredDocuments - requiredUploadedCount} required remaining
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Submit Button */}
        <div className="flex justify-end">
          <Button
            type="submit"
            disabled={isSubmitting || requiredUploadedCount !== totalRequiredDocuments}
            className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 px-8 py-3"
          >
            {isSubmitting ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                Submitting for Review...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Save className="h-4 w-4" />
                Submit for Review
              </div>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}