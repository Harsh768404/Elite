// Webhook Service for EliteQ India WordPress Integration
// WordPress + WooCommerce + Dokan Pro Webhook Management

const ELITEQ_WEBHOOK_CONFIG = {
  baseUrl: 'https://eliteq.in',
  webhookUrl: 'https://eliteq.in/?wpwhpro_action=main_9798',
  apiKey: 'w7mcvsqva35rns5bchiwnn4alrcg4jymowrmcox99kyg3n1zxwvsjuxix7ikrsdw',
  secret: 'Du83&G.64ti/5a#plclUwhF;WIjsQEHy_>hdFQ-/pv/CLJ$s#0'
};

interface WebhookPayload {
  id?: string;
  event: string;
  timestamp: string;
  source: 'wordpress' | 'woocommerce' | 'dokan';
  data: any;
  signature?: string;
}

interface WebhookLog {
  id: string;
  timestamp: string;
  event: string;
  source: string;
  status: 'success' | 'failed' | 'pending';
  payload: any;
  response?: any;
  error?: string;
  retryCount?: number;
  processingTime?: number;
}

interface WebhookStats {
  total: number;
  success: number;
  failed: number;
  pending: number;
  lastActivity: string;
  averageProcessingTime: number;
  eventTypes: { [key: string]: number };
}

class WebhookService {
  private logs: WebhookLog[] = [];
  private maxLogs = 1000; // Keep last 1000 logs in memory
  private retryAttempts = 3;
  private retryDelay = 1000; // 1 second

  constructor() {
    this.loadLogsFromStorage();
    this.startCleanupTimer();
  }

  // Load logs from localStorage
  private loadLogsFromStorage(): void {
    try {
      const savedLogs = localStorage.getItem('eliteq_webhook_logs');
      if (savedLogs) {
        this.logs = JSON.parse(savedLogs);
        console.log(`📊 Loaded ${this.logs.length} webhook logs from storage`);
      }
    } catch (error) {
      console.error('Failed to load webhook logs from storage:', error);
    }
  }

  // Save logs to localStorage
  private saveLogsToStorage(): void {
    try {
      // Keep only the most recent logs
      const logsToSave = this.logs.slice(-this.maxLogs);
      localStorage.setItem('eliteq_webhook_logs', JSON.stringify(logsToSave));
    } catch (error) {
      console.error('Failed to save webhook logs to storage:', error);
    }
  }

  // Clean up old logs periodically
  private startCleanupTimer(): void {
    setInterval(() => {
      const cutoffTime = Date.now() - (7 * 24 * 60 * 60 * 1000); // 7 days
      const initialCount = this.logs.length;
      
      this.logs = this.logs.filter(log => 
        new Date(log.timestamp).getTime() > cutoffTime
      );
      
      if (this.logs.length < initialCount) {
        console.log(`🧹 Cleaned up ${initialCount - this.logs.length} old webhook logs`);
        this.saveLogsToStorage();
      }
    }, 60 * 60 * 1000); // Run every hour
  }

  // Generate webhook signature
  private generateSignature(payload: string): string {
    // In a real implementation, you would use HMAC-SHA256 with the secret
    // For this example, we'll use a simple hash
    return btoa(ELITEQ_WEBHOOK_CONFIG.secret + payload).substring(0, 32);
  }

  // Verify webhook signature
  private verifySignature(payload: string, signature: string): boolean {
    const expectedSignature = this.generateSignature(payload);
    return signature === expectedSignature;
  }

  // Send webhook to EliteQ
  async sendWebhook(payload: WebhookPayload): Promise<WebhookLog> {
    const startTime = Date.now();
    const logId = `webhook_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Add signature to payload
    const payloadString = JSON.stringify(payload);
    payload.signature = this.generateSignature(payloadString);

    const log: WebhookLog = {
      id: logId,
      timestamp: new Date().toISOString(),
      event: payload.event,
      source: payload.source,
      status: 'pending',
      payload: payload,
      retryCount: 0
    };

    this.addLog(log);

    try {
      console.log(`🔗 Sending webhook: ${payload.event} from ${payload.source}`);
      
      const response = await fetch(
        `${ELITEQ_WEBHOOK_CONFIG.webhookUrl}&wpwhpro_api_key=${ELITEQ_WEBHOOK_CONFIG.apiKey}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Webhook-Secret': ELITEQ_WEBHOOK_CONFIG.secret,
            'X-WP-Webhook-Signature': payload.signature,
            'User-Agent': 'EliteQ-Admin-Panel/1.0'
          },
          body: payloadString
        }
      );

      const processingTime = Date.now() - startTime;
      const responseData = await response.text();

      if (response.ok) {
        log.status = 'success';
        log.response = responseData;
        log.processingTime = processingTime;
        console.log(`✅ Webhook sent successfully: ${payload.event}`);
      } else {
        log.status = 'failed';
        log.error = `HTTP ${response.status}: ${responseData}`;
        log.processingTime = processingTime;
        console.error(`❌ Webhook failed: ${payload.event} - ${log.error}`);
      }
    } catch (error) {
      const processingTime = Date.now() - startTime;
      log.status = 'failed';
      log.error = error instanceof Error ? error.message : 'Unknown error';
      log.processingTime = processingTime;
      console.error(`🚨 Webhook error: ${payload.event}`, error);
    }

    this.updateLog(log);
    return log;
  }

  // Send webhook with retry logic
  async sendWebhookWithRetry(payload: WebhookPayload): Promise<WebhookLog> {
    let lastLog = await this.sendWebhook(payload);
    
    // Retry failed webhooks
    while (lastLog.status === 'failed' && (lastLog.retryCount || 0) < this.retryAttempts) {
      await new Promise(resolve => setTimeout(resolve, this.retryDelay * Math.pow(2, lastLog.retryCount || 0)));
      
      lastLog.retryCount = (lastLog.retryCount || 0) + 1;
      console.log(`🔄 Retrying webhook (attempt ${lastLog.retryCount}): ${payload.event}`);
      
      lastLog = await this.sendWebhook(payload);
    }

    return lastLog;
  }

  // Handle incoming webhook from WordPress
  async handleIncomingWebhook(data: any, signature?: string): Promise<boolean> {
    const payload = JSON.stringify(data);
    
    // Verify signature if provided
    if (signature && !this.verifySignature(payload, signature)) {
      console.error('❌ Invalid webhook signature');
      return false;
    }

    try {
      const log: WebhookLog = {
        id: `incoming_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        timestamp: new Date().toISOString(),
        event: data.event || 'unknown',
        source: data.source || 'wordpress',
        status: 'success',
        payload: data,
        processingTime: 0
      };

      this.addLog(log);
      
      // Process the webhook data based on event type
      await this.processWebhookEvent(data);
      
      console.log(`✅ Processed incoming webhook: ${log.event}`);
      return true;
    } catch (error) {
      console.error('🚨 Failed to process incoming webhook:', error);
      return false;
    }
  }

  // Process webhook events
  private async processWebhookEvent(data: any): Promise<void> {
    switch (data.event) {
      case 'woocommerce.order.created':
      case 'woocommerce.order.updated':
        console.log('📦 Processing order webhook:', data.data?.id);
        // Trigger UI updates for order management
        this.notifySubscribers('order_updated', data.data);
        break;

      case 'woocommerce.product.created':
      case 'woocommerce.product.updated':
        console.log('🛍️ Processing product webhook:', data.data?.id);
        // Trigger UI updates for product management
        this.notifySubscribers('product_updated', data.data);
        break;

      case 'woocommerce.customer.created':
      case 'woocommerce.customer.updated':
        console.log('👤 Processing customer webhook:', data.data?.id);
        // Trigger UI updates for customer management
        this.notifySubscribers('customer_updated', data.data);
        break;

      case 'dokan.vendor.created':
      case 'dokan.vendor.updated':
        console.log('🏪 Processing vendor webhook:', data.data?.id);
        // Trigger UI updates for vendor management
        this.notifySubscribers('vendor_updated', data.data);
        break;

      case 'dokan.vendor.enabled':
      case 'dokan.vendor.disabled':
        console.log('🏪 Processing vendor status webhook:', data.data?.id);
        // Trigger UI updates for vendor status changes
        this.notifySubscribers('vendor_status_changed', data.data);
        break;

      default:
        console.log(`📋 Processing generic webhook: ${data.event}`);
        this.notifySubscribers('webhook_received', data);
        break;
    }
  }

  // Subscriber pattern for real-time updates
  private subscribers: { [key: string]: Array<(data: any) => void> } = {};

  subscribe(event: string, callback: (data: any) => void): void {
    if (!this.subscribers[event]) {
      this.subscribers[event] = [];
    }
    this.subscribers[event].push(callback);
  }

  unsubscribe(event: string, callback: (data: any) => void): void {
    if (this.subscribers[event]) {
      this.subscribers[event] = this.subscribers[event].filter(cb => cb !== callback);
    }
  }

  private notifySubscribers(event: string, data: any): void {
    if (this.subscribers[event]) {
      this.subscribers[event].forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error(`Error in webhook subscriber for ${event}:`, error);
        }
      });
    }
  }

  // Log management
  private addLog(log: WebhookLog): void {
    this.logs.unshift(log); // Add to beginning
    
    // Keep only the most recent logs
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(0, this.maxLogs);
    }
    
    this.saveLogsToStorage();
  }

  private updateLog(updatedLog: WebhookLog): void {
    const index = this.logs.findIndex(log => log.id === updatedLog.id);
    if (index !== -1) {
      this.logs[index] = updatedLog;
      this.saveLogsToStorage();
    }
  }

  // Get logs with filtering
  getLogs(filter?: {
    status?: 'success' | 'failed' | 'pending';
    source?: string;
    event?: string;
    limit?: number;
    since?: string;
  }): WebhookLog[] {
    let filteredLogs = [...this.logs];

    if (filter) {
      if (filter.status) {
        filteredLogs = filteredLogs.filter(log => log.status === filter.status);
      }
      
      if (filter.source) {
        filteredLogs = filteredLogs.filter(log => log.source === filter.source);
      }
      
      if (filter.event) {
        filteredLogs = filteredLogs.filter(log => log.event.includes(filter.event));
      }
      
      if (filter.since) {
        const sinceTime = new Date(filter.since).getTime();
        filteredLogs = filteredLogs.filter(log => 
          new Date(log.timestamp).getTime() >= sinceTime
        );
      }
      
      if (filter.limit) {
        filteredLogs = filteredLogs.slice(0, filter.limit);
      }
    }

    return filteredLogs;
  }

  // Get webhook statistics
  getStats(): WebhookStats {
    const total = this.logs.length;
    const success = this.logs.filter(log => log.status === 'success').length;
    const failed = this.logs.filter(log => log.status === 'failed').length;
    const pending = this.logs.filter(log => log.status === 'pending').length;
    
    const lastActivity = this.logs.length > 0 ? this.logs[0].timestamp : '';
    
    const processingTimes = this.logs
      .filter(log => log.processingTime !== undefined)
      .map(log => log.processingTime!);
    
    const averageProcessingTime = processingTimes.length > 0
      ? processingTimes.reduce((sum, time) => sum + time, 0) / processingTimes.length
      : 0;

    const eventTypes: { [key: string]: number } = {};
    this.logs.forEach(log => {
      eventTypes[log.event] = (eventTypes[log.event] || 0) + 1;
    });

    return {
      total,
      success,
      failed,
      pending,
      lastActivity,
      averageProcessingTime,
      eventTypes
    };
  }

  // Test webhook connection
  async testConnection(): Promise<boolean> {
    const testPayload: WebhookPayload = {
      event: 'test.connection',
      timestamp: new Date().toISOString(),
      source: 'wordpress',
      data: {
        test: true,
        message: 'EliteQ Admin Panel connection test',
        timestamp: new Date().toISOString()
      }
    };

    try {
      const result = await this.sendWebhook(testPayload);
      return result.status === 'success';
    } catch (error) {
      console.error('🚨 Webhook connection test failed:', error);
      return false;
    }
  }

  // Clear all logs
  clearLogs(): void {
    this.logs = [];
    this.saveLogsToStorage();
    console.log('🧹 All webhook logs cleared');
  }

  // Export logs for debugging
  exportLogs(): string {
    return JSON.stringify(this.logs, null, 2);
  }

  // Simulate webhook events for testing
  async simulateWebhook(event: string, source: string, data: any): Promise<void> {
    const payload: WebhookPayload = {
      event,
      timestamp: new Date().toISOString(),
      source: source as any,
      data
    };

    await this.sendWebhookWithRetry(payload);
  }
}

// Webhook event helpers
export const webhookEvents = {
  // WooCommerce events
  orderCreated: (orderData: any) => ({
    event: 'woocommerce.order.created',
    source: 'woocommerce' as const,
    data: orderData
  }),

  orderUpdated: (orderData: any) => ({
    event: 'woocommerce.order.updated',
    source: 'woocommerce' as const,
    data: orderData
  }),

  productCreated: (productData: any) => ({
    event: 'woocommerce.product.created',
    source: 'woocommerce' as const,
    data: productData
  }),

  productUpdated: (productData: any) => ({
    event: 'woocommerce.product.updated',
    source: 'woocommerce' as const,
    data: productData
  }),

  customerCreated: (customerData: any) => ({
    event: 'woocommerce.customer.created',
    source: 'woocommerce' as const,
    data: customerData
  }),

  // Dokan events
  vendorCreated: (vendorData: any) => ({
    event: 'dokan.vendor.created',
    source: 'dokan' as const,
    data: vendorData
  }),

  vendorUpdated: (vendorData: any) => ({
    event: 'dokan.vendor.updated',
    source: 'dokan' as const,
    data: vendorData
  }),

  vendorEnabled: (vendorData: any) => ({
    event: 'dokan.vendor.enabled',
    source: 'dokan' as const,
    data: vendorData
  }),

  vendorDisabled: (vendorData: any) => ({
    event: 'dokan.vendor.disabled',
    source: 'dokan' as const,
    data: vendorData
  })
};

// Create and export singleton instance
export const webhookService = new WebhookService();

// Export types
export type { WebhookPayload, WebhookLog, WebhookStats };

// Export configuration for debugging
export const webhookConfig = {
  baseUrl: ELITEQ_WEBHOOK_CONFIG.baseUrl,
  webhookUrl: ELITEQ_WEBHOOK_CONFIG.webhookUrl,
  apiKey: ELITEQ_WEBHOOK_CONFIG.apiKey.substring(0, 10) + '...',
  secret: ELITEQ_WEBHOOK_CONFIG.secret.substring(0, 10) + '...'
};