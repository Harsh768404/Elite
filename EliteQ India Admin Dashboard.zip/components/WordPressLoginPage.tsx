import React, { useState } from 'react';
import { Shield, Eye, EyeOff, Lock, User, AlertCircle, CheckCircle, Globe, Database } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { EliteQLogo } from './EliteQLogo';

interface WordPressLoginPageProps {
  onLogin: (token: string) => void;
}

export const WordPressLoginPage: React.FC<WordPressLoginPageProps> = ({ onLogin }) => {
  const [credentials, setCredentials] = useState({
    username: '',
    password: '',
    siteUrl: 'https://eliteq.in'
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [connectionTest, setConnectionTest] = useState<{
    status: 'idle' | 'testing' | 'success' | 'error';
    details?: any;
  }>({ status: 'idle' });

  const testWordPressConnection = async () => {
    setConnectionTest({ status: 'testing' });
    
    try {
      // Test WordPress site accessibility
      const testUrl = `${credentials.siteUrl}/wp-json/wp/v2/posts?per_page=1`;
      
      // Simulate connection test
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockSuccess = Math.random() > 0.2;
      if (mockSuccess) {
        setConnectionTest({
          status: 'success',
          details: {
            wordpress: true,
            woocommerce: true,
            dokan: true,
            jwt_auth: true
          }
        });
      } else {
        setConnectionTest({
          status: 'error',
          details: { error: 'WordPress site not accessible or plugins missing' }
        });
      }
    } catch (error) {
      setConnectionTest({
        status: 'error',
        details: { error: 'Connection failed' }
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      // Check for vendor/non-admin keywords
      const vendorKeywords = ['vendor', 'seller', 'shop', 'store', 'merchant', 'author', 'editor'];
      const isVendorAccount = vendorKeywords.some(keyword => 
        credentials.username.toLowerCase().includes(keyword)
      );

      if (isVendorAccount) {
        setError('🚫 Access Denied — Only WordPress Admin credentials are allowed. Vendor or editor accounts cannot access this system.');
        setIsLoading(false);
        return;
      }

      // Simulate JWT authentication
      const jwtEndpoint = `${credentials.siteUrl}/wp-json/jwt-auth/v1/token`;
      
      // Mock JWT response
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Simulate authentication
      if (credentials.username === 'admin' && credentials.password === 'admin123') {
        const mockToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2VsaXRlcS5pbiIsImlhdCI6MTcwNTc2NDAwMCwiZXhwIjoxNzA1ODUwNDAwLCJkYXRhIjp7InVzZXIiOnsiaWQiOjEsInVzZXJfbG9naW4iOiJhZG1pbiIsInVzZXJfZW1haWwiOiJhZG1pbkBlbGl0ZXEuaW4iLCJ1c2VyX3JvbGUiOiJhZG1pbmlzdHJhdG9yIn19fQ.MockTokenSignature';
        localStorage.setItem('wp_jwt_token', mockToken);
        onLogin(mockToken);
      } else {
        setError('Invalid WordPress admin credentials. Please verify your administrator username and password.');
      }
    } catch (error) {
      setError('Failed to connect to WordPress. Please check your site URL and credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: 'username' | 'password' | 'siteUrl') => (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setCredentials(prev => ({
      ...prev,
      [field]: e.target.value
    }));
    if (error) setError('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 dark:from-gray-950 dark:via-gray-900 dark:to-blue-950 flex items-center justify-center p-4">
      <div className="w-full max-w-lg space-y-8">
        
        {/* Logo and Header */}
        <div className="text-center space-y-6">
          <div className="flex justify-center">
            <div className="p-4 bg-white dark:bg-gray-800 rounded-2xl shadow-lg">
              <EliteQLogo size="lg" animated={true} />
            </div>
          </div>
          
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              WordPress Admin Login
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Connect to your WooCommerce + Dokan Pro store
            </p>
          </div>
        </div>

        {/* Connection Test Results */}
        {connectionTest.status !== 'idle' && (
          <Alert className={
            connectionTest.status === 'success' ? 'border-green-200 bg-green-50 dark:bg-green-900/20' :
            connectionTest.status === 'error' ? 'border-red-200 bg-red-50 dark:bg-red-900/20' :
            'border-blue-200 bg-blue-50 dark:bg-blue-900/20'
          }>
            {connectionTest.status === 'success' ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : connectionTest.status === 'error' ? (
              <AlertCircle className="h-4 w-4 text-red-600" />
            ) : (
              <Database className="h-4 w-4 text-blue-600 animate-spin" />
            )}
            <AlertDescription>
              {connectionTest.status === 'testing' && 'Testing WordPress connection...'}
              {connectionTest.status === 'success' && (
                <div className="space-y-2">
                  <div className="font-semibold text-green-800 dark:text-green-200">✅ WordPress Site Accessible</div>
                  <div className="flex flex-wrap gap-2">
                    <Badge className="bg-green-100 text-green-800 text-xs">WordPress</Badge>
                    <Badge className="bg-blue-100 text-blue-800 text-xs">WooCommerce</Badge>
                    <Badge className="bg-purple-100 text-purple-800 text-xs">Dokan Pro</Badge>
                    <Badge className="bg-orange-100 text-orange-800 text-xs">JWT Auth</Badge>
                  </div>
                </div>
              )}
              {connectionTest.status === 'error' && (
                <div className="text-red-800 dark:text-red-200">
                  <strong>Connection Failed:</strong> {connectionTest.details?.error}
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}

        {/* Security Notice */}
        <Alert className="border-orange-200 bg-orange-50 dark:bg-orange-900/20 dark:border-orange-800">
          <Shield className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-800 dark:text-orange-200">
            <div className="space-y-1">
              <div className="font-semibold">🔐 Administrator Access Required</div>
              <div className="text-sm">
                Only WordPress <strong>administrator credentials</strong> are accepted. 
                Vendor, editor, or author accounts will be automatically rejected.
              </div>
            </div>
          </AlertDescription>
        </Alert>

        {/* Login Form */}
        <Card className="shadow-xl border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-2xl text-center flex items-center justify-center gap-2">
              <Globe className="h-6 w-6 text-blue-600" />
              WordPress Connection
            </CardTitle>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Error Alert */}
              {error && (
                <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-800">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-700 dark:text-red-400">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              {/* Site URL Field */}
              <div className="space-y-2">
                <Label htmlFor="siteUrl" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  WordPress Site URL
                </Label>
                <div className="relative">
                  <Globe className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="siteUrl"
                    type="url"
                    placeholder="https://yourstore.com"
                    value={credentials.siteUrl}
                    onChange={handleInputChange('siteUrl')}
                    className="pl-10 h-12 bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    onClick={testWordPressConnection}
                    disabled={connectionTest.status === 'testing' || !credentials.siteUrl}
                  >
                    <Database className={`h-4 w-4 ${connectionTest.status === 'testing' ? 'animate-spin' : ''}`} />
                  </Button>
                </div>
                <p className="text-xs text-gray-500">
                  Your WordPress site URL (must be accessible)
                </p>
              </div>

              {/* Username Field */}
              <div className="space-y-2">
                <Label htmlFor="username" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  WordPress Admin Username
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="admin"
                    value={credentials.username}
                    onChange={handleInputChange('username')}
                    className="pl-10 h-12 bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <p className="text-xs text-gray-500">
                  Only WordPress administrator usernames accepted
                </p>
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  WordPress Admin Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter admin password"
                    value={credentials.password}
                    onChange={handleInputChange('password')}
                    className="pl-10 pr-10 h-12 bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Login Button */}
              <Button
                type="submit"
                disabled={isLoading || !credentials.username || !credentials.password || !credentials.siteUrl}
                className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white font-medium transition-all duration-200 disabled:opacity-50"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Authenticating via JWT...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Connect to WordPress
                  </div>
                )}
              </Button>

              {/* Demo Credentials */}
              <div className="text-center">
                <div className="text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 rounded-lg p-3">
                  <strong>Demo Credentials:</strong><br />
                  Site: <code>https://eliteq.in</code><br />
                  Username: <code>admin</code><br />
                  Password: <code>admin123</code>
                </div>
              </div>

              {/* API Features */}
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Connected APIs:</h4>
                <div className="grid grid-cols-2 gap-2 text-xs text-gray-600 dark:text-gray-400">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span>WordPress REST API</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span>WooCommerce API</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span>Dokan Pro API</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span>JWT Authentication</span>
                  </div>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-gray-500 dark:text-gray-400">
          <p>© 2024 EliteQ India. All rights reserved.</p>
          <p className="mt-1">WordPress + WooCommerce + Dokan Pro Integration</p>
          <p className="mt-1 text-xs">🔐 JWT Authentication | Admin Access Only</p>
        </div>
      </div>
    </div>
  );
};