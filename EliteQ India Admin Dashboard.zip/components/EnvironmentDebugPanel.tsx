import React, { useState } from 'react';
import { 
  Settings, 
  Eye, 
  EyeOff, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Info,
  RefreshCw,
  Monitor,
  Server
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { envHelpers, envConfig } from '../utils/env-config';

export const EnvironmentDebugPanel: React.FC = () => {
  const [showDetails, setShowDetails] = useState(false);
  const [envTestResult, setEnvTestResult] = useState<any>(null);

  const runEnvironmentTest = () => {
    try {
      const result = envHelpers.testEnvAccess();
      setEnvTestResult(result);
      console.log('🧪 Environment test completed:', result);
    } catch (error) {
      setEnvTestResult({
        success: false,
        details: { error: error instanceof Error ? error.message : 'Unknown error' }
      });
      console.error('❌ Environment test failed:', error);
    }
  };

  React.useEffect(() => {
    runEnvironmentTest();
  }, []);

  const environmentInfo = envHelpers.getEnvironmentInfo();
  const maskedCredentials = envHelpers.getMaskedCredentials();

  const getStatusIcon = (isSet: boolean) => {
    return isSet ? (
      <CheckCircle className="h-4 w-4 text-green-500" />
    ) : (
      <XCircle className="h-4 w-4 text-red-500" />
    );
  };

  const getEnvironmentBadge = () => {
    if (environmentInfo.isBrowser) {
      return (
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
          <Monitor className="h-3 w-3 mr-1" />
          Browser
        </Badge>
      );
    } else {
      return (
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
          <Server className="h-3 w-3 mr-1" />
          Server
        </Badge>
      );
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Environment Configuration
          </CardTitle>
          <div className="flex items-center gap-2">
            {getEnvironmentBadge()}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowDetails(!showDetails)}
            >
              {showDetails ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              {showDetails ? 'Hide' : 'Show'} Details
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        
        {/* Environment Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Monitor className="h-4 w-4 text-blue-500" />
              <span className="text-sm font-medium">Browser Environment</span>
            </div>
            <div className="flex items-center gap-2">
              {getStatusIcon(environmentInfo.isBrowser)}
              <span className="text-sm">{environmentInfo.isBrowser ? 'Active' : 'Not Available'}</span>
            </div>
          </div>

          <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Server className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium">Node.js Environment</span>
            </div>
            <div className="flex items-center gap-2">
              {getStatusIcon(environmentInfo.isNode)}
              <span className="text-sm">{environmentInfo.isNode ? 'Available' : 'Not Available'}</span>
            </div>
          </div>

          <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Info className="h-4 w-4 text-purple-500" />
              <span className="text-sm font-medium">Configuration Status</span>
            </div>
            <div className="flex items-center gap-2">
              {getStatusIcon(environmentInfo.configuredVariables > 0)}
              <span className="text-sm">{environmentInfo.configuredVariables}/{Object.keys(envConfig).length} Variables</span>
            </div>
          </div>
        </div>

        {/* Environment Variables Status */}
        <div className="space-y-4">
          <h3 className="font-medium flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Environment Variables Status
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {Object.entries(maskedCredentials).map(([key, value]) => {
              const isConfigured = value !== 'Not configured';
              return (
                <div key={key} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(isConfigured)}
                    <div>
                      <div className="font-medium text-sm">{key.replace(/_/g, ' ')}</div>
                      <div className="text-xs text-gray-600 dark:text-gray-400 font-mono">
                        {showDetails ? value : (isConfigured ? 'Configured' : 'Not configured')}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Test Results */}
        {envTestResult && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium flex items-center gap-2">
                <RefreshCw className="h-4 w-4" />
                Environment Test Results
              </h3>
              <Button variant="outline" size="sm" onClick={runEnvironmentTest}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Retest
              </Button>
            </div>

            {envTestResult.success ? (
              <Alert className="border-green-200 bg-green-50 dark:bg-green-900/20">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription className="ml-2">
                  Environment configuration test passed successfully.
                </AlertDescription>
              </Alert>
            ) : (
              <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20">
                <XCircle className="h-4 w-4" />
                <AlertDescription className="ml-2">
                  Environment configuration test failed: {envTestResult.details?.error || 'Unknown error'}
                </AlertDescription>
              </Alert>
            )}

            {showDetails && envTestResult.details && (
              <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                <div className="text-sm font-medium mb-2">Technical Details:</div>
                <pre className="text-xs overflow-auto bg-white dark:bg-gray-900 p-3 rounded border">
                  {JSON.stringify(envTestResult.details, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}

        {/* Configuration Instructions */}
        {environmentInfo.configuredVariables === 0 && (
          <Alert className="border-orange-200 bg-orange-50 dark:bg-orange-900/20">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="ml-2">
              <div className="space-y-2">
                <div className="font-medium">No environment variables configured</div>
                <div className="text-sm">
                  To configure your EliteQ India platform properly, please set the following environment variables:
                </div>
                <ul className="text-sm list-disc list-inside space-y-1 ml-2">
                  <li><code>WOOCOMMERCE_CONSUMER_KEY</code></li>
                  <li><code>WOOCOMMERCE_CONSUMER_SECRET</code></li>
                  <li><code>JWT_AUTH_SECRET_KEY</code></li>
                </ul>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* WooCommerce Specific Status */}
        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700">
          <div className="flex items-center gap-2 mb-3">
            <Info className="h-5 w-5 text-blue-600" />
            <h3 className="font-medium text-blue-900 dark:text-blue-100">WooCommerce Integration Status</h3>
          </div>
          
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span>WooCommerce Credentials:</span>
              <div className="flex items-center gap-1">
                {getStatusIcon(envHelpers.hasWooCommerceCredentials())}
                <span>{envHelpers.hasWooCommerceCredentials() ? 'Ready' : 'Missing'}</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span>WordPress JWT:</span>
              <div className="flex items-center gap-1">
                {getStatusIcon(envHelpers.hasWordPressJWTCredentials())}
                <span>{envHelpers.hasWordPressJWTCredentials() ? 'Ready' : 'Missing'}</span>
              </div>
            </div>
          </div>
        </div>

      </CardContent>
    </Card>
  );
};

export default EnvironmentDebugPanel;