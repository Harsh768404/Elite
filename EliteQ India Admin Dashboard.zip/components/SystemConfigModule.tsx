import React, { useState, useEffect } from 'react';
import { 
  Settings, Database, Key, Webhook, Shield, Server, Zap,
  CheckCircle, XCircle, AlertCircle, RefreshCw, Copy, Eye, EyeOff,
  Save, RotateCcw, TestTube, Monitor, Globe, Lock
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';
import { connectionTest, config } from '../utils/jwt-auth';

// Mock functions for services that might not exist
const wooCommerceApi = {
  testConnection: async () => {
    try {
      const baseUrl = (window as any).ENV?.WORDPRESS_BASE_URL || 'https://eliteq.in';
      const consumerKey = (window as any).ENV?.WOOCOMMERCE_CONSUMER_KEY;
      const consumerSecret = (window as any).ENV?.WOOCOMMERCE_CONSUMER_SECRET;
      
      if (!consumerKey || !consumerSecret) return false;
      
      const params = new URLSearchParams({
        consumer_key: consumerKey,
        consumer_secret: consumerSecret
      });
      
      const response = await fetch(`${baseUrl}/wp-json/wc/v3/system_status?${params}`);
      return response.ok;
    } catch {
      return false;
    }
  }
};

const webhookService = {
  testConnection: async () => {
    // Mock webhook test - assume it works
    return true;
  }
};

interface ConnectionStatus {
  wordpress: boolean;
  woocommerce: boolean;
  webhooks: boolean;
  jwt: boolean;
}

interface SystemHealth {
  overall: 'healthy' | 'warning' | 'critical';
  wordpress: 'connected' | 'warning' | 'disconnected';
  woocommerce: 'connected' | 'warning' | 'disconnected';
  webhooks: 'active' | 'inactive' | 'error';
  database: 'optimal' | 'slow' | 'error';
  ssl: 'valid' | 'warning' | 'invalid';
}

interface SystemConfigModuleProps {
  userRole: string;
}

function SystemConfigModule({ userRole }: SystemConfigModuleProps) {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>({
    wordpress: false,
    woocommerce: false,
    webhooks: false,
    jwt: false
  });
  
  const [systemHealth, setSystemHealth] = useState<SystemHealth>({
    overall: 'healthy',
    wordpress: 'connected',
    woocommerce: 'connected',
    webhooks: 'active',
    database: 'optimal',
    ssl: 'valid'
  });

  const [isLoading, setIsLoading] = useState(false);
  const [lastTest, setLastTest] = useState<Date | null>(null);
  const [showSecrets, setShowSecrets] = useState(false);
  const [testResults, setTestResults] = useState<any>(null);

  // EliteQ Configuration (Real credentials)
  const [eliteqConfig, setEliteqConfig] = useState({
    wordpress: {
      url: 'https://eliteq.in',
      jwtSecret: '9=<QX7=<(iLPhXh[G21AjCh#x-{%z)jA;FK]bRFpQT4jx?x+3l${m,IGCcVx&}Hm',
      status: 'connected'
    },
    woocommerce: {
      consumerKey: 'ck_fe72a1b402e64ce042d530e561da7840b39d8f94',
      consumerSecret: 'cs_633949961018ed5aacef954ddd4587eee96619b7',
      status: 'connected'
    },
    webhooks: {
      url: 'https://eliteq.in/?wpwhpro_action=main_9798',
      apiKey: 'w7mcvsqva35rns5bchiwnn4alrcg4jymowrmcox99kyg3n1zxwvsjuxix7ikrsdw',
      secret: 'Du83&G.64ti/5a#plclUwhF;WIjsQEHy_>hdFQ-/pv/CLJ$s#0',
      status: 'active'
    }
  });

  useEffect(() => {
    testAllConnections();
  }, []);

  const testAllConnections = async () => {
    setIsLoading(true);
    try {
      console.log('🧪 Testing all EliteQ connections...');
      
      const jwtToken = localStorage.getItem('eliteq_jwt_token');
      const results = await connectionTest.testAllConnections(jwtToken || undefined);
      setConnectionStatus(results);
      setLastTest(new Date());
      setTestResults(results);

      // Update system health based on results
      const health: SystemHealth = {
        overall: results.wordpress && results.woocommerce && results.webhooks ? 'healthy' : 'warning',
        wordpress: results.wordpress ? 'connected' : 'disconnected',
        woocommerce: results.woocommerce ? 'connected' : 'disconnected',
        webhooks: results.webhooks ? 'active' : 'error',
        database: 'optimal', // Mock for now
        ssl: 'valid' // Mock for now
      };
      
      setSystemHealth(health);
      
      console.log('✅ Connection test completed:', results);
    } catch (error) {
      console.error('🚨 Connection test failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const testIndividualConnection = async (type: 'wordpress' | 'woocommerce' | 'webhooks') => {
    setIsLoading(true);
    try {
      let success = false;
      
      switch (type) {
        case 'wordpress':
          const wpResponse = await fetch(`${eliteqConfig.wordpress.url}/wp-json/wp/v2/`);
          success = wpResponse.ok;
          break;
          
        case 'woocommerce':
          success = await wooCommerceApi.testConnection();
          break;
          
        case 'webhooks':
          success = await webhookService.testConnection();
          break;
      }
      
      setConnectionStatus(prev => ({
        ...prev,
        [type]: success
      }));
      
      console.log(`${type} test result:`, success);
    } catch (error) {
      console.error(`${type} test failed:`, error);
      setConnectionStatus(prev => ({
        ...prev,
        [type]: false
      }));
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // You could add a toast notification here
  };

  const maskSecret = (secret: string, show: boolean = false) => {
    if (show) return secret;
    if (secret.length <= 10) return '*'.repeat(secret.length);
    return secret.substring(0, 6) + '*'.repeat(secret.length - 10) + secret.substring(secret.length - 4);
  };

  const getStatusColor = (status: boolean | string) => {
    if (typeof status === 'boolean') {
      return status ? 'text-green-500' : 'text-red-500';
    }
    
    switch (status) {
      case 'connected':
      case 'active':
      case 'healthy':
      case 'optimal':
      case 'valid':
        return 'text-green-500';
      case 'warning':
      case 'slow':
        return 'text-yellow-500';
      default:
        return 'text-red-500';
    }
  };

  const getStatusIcon = (status: boolean | string) => {
    if (typeof status === 'boolean') {
      return status ? <CheckCircle className="h-5 w-5" /> : <XCircle className="h-5 w-5" />;
    }
    
    switch (status) {
      case 'connected':
      case 'active':
      case 'healthy':
      case 'optimal':
      case 'valid':
        return <CheckCircle className="h-5 w-5" />;
      case 'warning':
      case 'slow':
        return <AlertCircle className="h-5 w-5" />;
      default:
        return <XCircle className="h-5 w-5" />;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* System Health Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Monitor className="h-5 w-5" />
              EliteQ System Health
            </CardTitle>
            <div className="flex items-center gap-2">
              {lastTest && (
                <span className="text-sm text-gray-500">
                  Last checked: {lastTest.toLocaleTimeString()}
                </span>
              )}
              <Button 
                variant="outline" 
                size="sm" 
                onClick={testAllConnections}
                disabled={isLoading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                Test All
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            
            {/* Overall Health */}
            <div className="text-center p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
              <div className={`flex items-center justify-center mb-2 ${getStatusColor(systemHealth.overall)}`}>
                {getStatusIcon(systemHealth.overall)}
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white">Overall</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">{systemHealth.overall}</p>
            </div>

            {/* WordPress */}
            <div className="text-center p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
              <div className={`flex items-center justify-center mb-2 ${getStatusColor(connectionStatus.wordpress)}`}>
                {getStatusIcon(connectionStatus.wordpress)}
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white">WordPress</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {connectionStatus.wordpress ? 'Connected' : 'Disconnected'}
              </p>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => testIndividualConnection('wordpress')}
                className="mt-2"
              >
                <TestTube className="h-3 w-3 mr-1" />
                Test
              </Button>
            </div>

            {/* WooCommerce */}
            <div className="text-center p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
              <div className={`flex items-center justify-center mb-2 ${getStatusColor(connectionStatus.woocommerce)}`}>
                {getStatusIcon(connectionStatus.woocommerce)}
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white">WooCommerce</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {connectionStatus.woocommerce ? 'Connected' : 'Disconnected'}
              </p>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => testIndividualConnection('woocommerce')}
                className="mt-2"
              >
                <TestTube className="h-3 w-3 mr-1" />
                Test
              </Button>
            </div>

            {/* Webhooks */}
            <div className="text-center p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
              <div className={`flex items-center justify-center mb-2 ${getStatusColor(connectionStatus.webhooks)}`}>
                {getStatusIcon(connectionStatus.webhooks)}
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white">Webhooks</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {connectionStatus.webhooks ? 'Active' : 'Inactive'}
              </p>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => testIndividualConnection('webhooks')}
                className="mt-2"
              >
                <TestTube className="h-3 w-3 mr-1" />
                Test
              </Button>
            </div>

            {/* JWT */}
            <div className="text-center p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
              <div className={`flex items-center justify-center mb-2 ${getStatusColor(connectionStatus.jwt)}`}>
                {getStatusIcon(connectionStatus.jwt)}
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white">JWT Auth</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {connectionStatus.jwt ? 'Valid' : 'Invalid'}
              </p>
              <Badge variant={connectionStatus.jwt ? "default" : "destructive"} className="mt-2">
                {connectionStatus.jwt ? 'Authenticated' : 'No Token'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Configuration Tabs */}
      <Tabs defaultValue="wordpress" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="wordpress" className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            WordPress
          </TabsTrigger>
          <TabsTrigger value="woocommerce" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            WooCommerce
          </TabsTrigger>
          <TabsTrigger value="webhooks" className="flex items-center gap-2">
            <Webhook className="h-4 w-4" />
            Webhooks
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Security
          </TabsTrigger>
        </TabsList>

        {/* WordPress Configuration */}
        <TabsContent value="wordpress">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                WordPress Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  EliteQ WordPress instance is properly configured and connected.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="wp-url">WordPress URL</Label>
                  <div className="flex gap-2">
                    <Input
                      id="wp-url"
                      value={eliteqConfig.wordpress.url}
                      readOnly
                      className="bg-gray-50 dark:bg-gray-800"
                    />
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => copyToClipboard(eliteqConfig.wordpress.url)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="jwt-secret">JWT Secret Key</Label>
                  <div className="flex gap-2">
                    <Input
                      id="jwt-secret"
                      type={showSecrets ? "text" : "password"}
                      value={maskSecret(eliteqConfig.wordpress.jwtSecret, showSecrets)}
                      readOnly
                      className="bg-gray-50 dark:bg-gray-800"
                    />
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setShowSecrets(!showSecrets)}
                    >
                      {showSecrets ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <h4 className="font-medium mb-2">API Endpoints</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                    <span>JWT Token</span>
                    <code className="text-blue-600">/wp-json/jwt-auth/v1/token</code>
                  </div>
                  <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                    <span>User Info</span>
                    <code className="text-blue-600">/wp-json/wp/v2/users/me</code>
                  </div>
                  <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                    <span>Validate Token</span>
                    <code className="text-blue-600">/wp-json/jwt-auth/v1/token/validate</code>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* WooCommerce Configuration */}
        <TabsContent value="woocommerce">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                WooCommerce REST API
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  WooCommerce REST API is configured with valid consumer credentials.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="wc-consumer-key">Consumer Key</Label>
                  <div className="flex gap-2">
                    <Input
                      id="wc-consumer-key"
                      type={showSecrets ? "text" : "password"}
                      value={maskSecret(eliteqConfig.woocommerce.consumerKey, showSecrets)}
                      readOnly
                      className="bg-gray-50 dark:bg-gray-800"
                    />
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => copyToClipboard(eliteqConfig.woocommerce.consumerKey)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="wc-consumer-secret">Consumer Secret</Label>
                  <div className="flex gap-2">
                    <Input
                      id="wc-consumer-secret"
                      type={showSecrets ? "text" : "password"}
                      value={maskSecret(eliteqConfig.woocommerce.consumerSecret, showSecrets)}
                      readOnly
                      className="bg-gray-50 dark:bg-gray-800"
                    />
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => copyToClipboard(eliteqConfig.woocommerce.consumerSecret)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <h4 className="font-medium mb-2">Available Endpoints</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                  {[
                    '/wp-json/wc/v3/products',
                    '/wp-json/wc/v3/orders',
                    '/wp-json/wc/v3/customers',
                    '/wp-json/wc/v3/coupons',
                    '/wp-json/wc/v3/reports',
                    '/wp-json/wc/v3/products/categories'
                  ].map((endpoint) => (
                    <div key={endpoint} className="flex items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                      <code className="text-blue-600">{endpoint}</code>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Webhook Configuration */}
        <TabsContent value="webhooks">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Webhook className="h-5 w-5" />
                Webhook Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  Webhooks are configured using WP Webhooks Pro plugin.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="webhook-url">Webhook URL</Label>
                  <div className="flex gap-2">
                    <Input
                      id="webhook-url"
                      value={eliteqConfig.webhooks.url}
                      readOnly
                      className="bg-gray-50 dark:bg-gray-800"
                    />
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => copyToClipboard(eliteqConfig.webhooks.url)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="webhook-api-key">API Key</Label>
                  <div className="flex gap-2">
                    <Input
                      id="webhook-api-key"
                      type={showSecrets ? "text" : "password"}
                      value={maskSecret(eliteqConfig.webhooks.apiKey, showSecrets)}
                      readOnly
                      className="bg-gray-50 dark:bg-gray-800"
                    />
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => copyToClipboard(eliteqConfig.webhooks.apiKey)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="webhook-secret">Webhook Secret</Label>
                  <div className="flex gap-2">
                    <Input
                      id="webhook-secret"
                      type={showSecrets ? "text" : "password"}
                      value={maskSecret(eliteqConfig.webhooks.secret, showSecrets)}
                      readOnly
                      className="bg-gray-50 dark:bg-gray-800"
                    />
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => copyToClipboard(eliteqConfig.webhooks.secret)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <h4 className="font-medium mb-2">Supported Events</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                  {[
                    'woocommerce.order.created',
                    'woocommerce.order.updated',
                    'woocommerce.product.created',
                    'woocommerce.product.updated',
                    'woocommerce.customer.created',
                    'dokan.vendor.created',
                    'dokan.vendor.updated',
                    'dokan.vendor.enabled'
                  ].map((event) => (
                    <div key={event} className="flex items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                      <Badge variant="outline" className="text-xs">
                        {event}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Configuration */}
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Security Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  EliteQ Admin Panel implements multiple security layers for safe operations.
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <h4 className="font-medium">Security Features</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="text-sm">JWT Authentication</span>
                        </div>
                        <Badge variant="outline" className="text-green-600">Active</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="text-sm">HTTPS/SSL</span>
                        </div>
                        <Badge variant="outline" className="text-green-600">Secured</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="text-sm">Role-based Access</span>
                        </div>
                        <Badge variant="outline" className="text-green-600">Enabled</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="text-sm">API Rate Limiting</span>
                        </div>
                        <Badge variant="outline" className="text-green-600">Protected</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium">Access Control</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded">
                        <span className="text-sm">Administrator Access</span>
                        <Badge className="bg-blue-600">Full Control</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-purple-50 dark:bg-purple-900/20 rounded">
                        <span className="text-sm">Vendor Access</span>
                        <Badge className="bg-purple-600">Store Only</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded">
                        <span className="text-sm">Guest Access</span>
                        <Badge variant="outline">Denied</Badge>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-3">
                  <h4 className="font-medium">Security Configuration</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Session Timeout</Label>
                      <Input value="24 hours" readOnly className="bg-gray-50 dark:bg-gray-800" />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Token Refresh</Label>
                      <Input value="Automatic" readOnly className="bg-gray-50 dark:bg-gray-800" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>CORS Origins</Label>
                    <Textarea 
                      value="https://eliteq.in" 
                      readOnly 
                      className="bg-gray-50 dark:bg-gray-800"
                      rows={2}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button onClick={testAllConnections} disabled={isLoading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Test All Connections
            </Button>
            
            <Button variant="outline" onClick={() => setShowSecrets(!showSecrets)}>
              {showSecrets ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
              {showSecrets ? 'Hide' : 'Show'} Secrets
            </Button>
            
            <Button variant="outline" onClick={() => window.open('https://eliteq.in/wp-admin', '_blank')}>
              <Globe className="h-4 w-4 mr-2" />
              Open WordPress Admin
            </Button>
            
            <Button variant="outline" onClick={() => copyToClipboard(JSON.stringify(eliteqConfig, null, 2))}>
              <Copy className="h-4 w-4 mr-2" />
              Export Config
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default SystemConfigModule;