import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { RefreshCw, AlertTriangle, CheckCircle, XCircle, Eye, EyeOff } from 'lucide-react';
import { apiService } from '../utils/comprehensive-api-service';

interface RoleDebugInfo {
  currentRoles: string[];
  primaryRole: string;
  lastResolution: any;
  validation: any;
  jwtToken: string;
  userId: number | undefined;
  error?: string;
}

interface HealthCheckInfo {
  status: string;
  timestamp: string;
  services: Record<string, boolean>;
  userInfo: {
    authenticated: boolean;
    roles: string[];
    primaryRole: string;
    dashboardRoute: string;
    capabilities: string[];
  };
  permissions: {
    canListProducts: boolean;
    canListOrders: boolean;
    canListUsers: boolean;
    canViewReports: boolean;
  };
  roleDebug?: any;
}

export const RoleDetectionDebugPanel: React.FC = () => {
  const [debugInfo, setDebugInfo] = useState<RoleDebugInfo | null>(null);
  const [healthInfo, setHealthInfo] = useState<HealthCheckInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showSensitiveData, setShowSensitiveData] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchDebugInfo = async () => {
    setIsLoading(true);
    try {
      console.log('🔧 Fetching role detection debug info...');
      
      // Get role debug info
      const roleDebug = await apiService.debugRoleDetection();
      setDebugInfo(roleDebug);
      
      // Get health check info
      const health = await apiService.healthCheck();
      setHealthInfo(health);
      
      setLastUpdated(new Date());
      console.log('✅ Debug info fetched successfully');
    } catch (error) {
      console.error('❌ Failed to fetch debug info:', error);
      setDebugInfo({ 
        error: error instanceof Error ? error.message : 'Unknown error',
        currentRoles: [],
        primaryRole: 'unknown',
        lastResolution: null,
        validation: null,
        jwtToken: 'error',
        userId: undefined
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDebugInfo();
  }, []);

  const getRoleStatusIcon = (role: string) => {
    switch (role) {
      case 'administrator':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'shop_manager':
        return <CheckCircle className="w-4 h-4 text-blue-600" />;
      case 'vendor':
        return <CheckCircle className="w-4 h-4 text-purple-600" />;
      case 'subscriber':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'restricted':
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-gray-600" />;
    }
  };

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case 'administrator':
        return 'default';
      case 'shop_manager':
        return 'secondary';
      case 'vendor':
        return 'outline';
      case 'subscriber':
        return 'secondary';
      case 'restricted':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const formatResolutionMethod = (method: string) => {
    const methods: { [key: string]: string } = {
      'users_me_endpoint': 'WordPress /users/me API',
      'users_by_id_endpoint': 'WordPress /users/{id} API',
      'users_me_edit_context': 'WordPress /users/me?context=edit API',
      'woocommerce_customers_me': 'WooCommerce Customers API',
      'jwt_token_parsing': 'JWT Token Payload',
      'jwt_login_data': 'JWT Login Response',
      'fallback_restricted': 'Fallback (All methods failed)'
    };
    return methods[method] || method;
  };

  if (!debugInfo && !isLoading) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            Role Detection Debug Panel
          </CardTitle>
          <CardDescription>
            Failed to load debug information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={fetchDebugInfo} className="w-full">
            <RefreshCw className="w-4 h-4 mr-2" />
            Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                🔧 Role Detection Debug Panel
              </CardTitle>
              <CardDescription>
                Diagnostic information for WordPress user role detection issues
                {lastUpdated && (
                  <span className="block text-xs text-gray-500 mt-1">
                    Last updated: {lastUpdated.toLocaleTimeString()}
                  </span>
                )}
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowSensitiveData(!showSensitiveData)}
              >
                {showSensitiveData ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                {showSensitiveData ? 'Hide' : 'Show'} Sensitive Data
              </Button>
              <Button
                onClick={fetchDebugInfo}
                disabled={isLoading}
                size="sm"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Error Display */}
      {debugInfo?.error && (
        <Alert variant="destructive">
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription>
            <strong>Error:</strong> {debugInfo.error}
          </AlertDescription>
        </Alert>
      )}

      {/* Current Role Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            🎭 Current Role Status
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Primary Role
              </label>
              <div className="flex items-center gap-2 mt-1">
                {getRoleStatusIcon(debugInfo?.primaryRole || 'unknown')}
                <Badge variant={getRoleBadgeVariant(debugInfo?.primaryRole || 'unknown')}>
                  {debugInfo?.primaryRole || 'Unknown'}
                </Badge>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                All Roles
              </label>
              <div className="flex flex-wrap gap-1 mt-1">
                {debugInfo?.currentRoles && debugInfo.currentRoles.length > 0 ? (
                  debugInfo.currentRoles.map((role, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {role}
                    </Badge>
                  ))
                ) : (
                  <span className="text-sm text-gray-500">No roles detected</span>
                )}
              </div>
            </div>
          </div>

          {/* Issue Detection */}
          {debugInfo?.currentRoles && debugInfo.currentRoles.length === 1 && 
           debugInfo.currentRoles[0] === 'subscriber' && (
            <Alert variant="destructive">
              <AlertTriangle className="w-4 h-4" />
              <AlertDescription>
                <strong>🚨 Issue Detected:</strong> User is showing as 'subscriber' only. 
                This may indicate a role detection problem if the user should have higher privileges.
              </AlertDescription>
            </Alert>
          )}

          {debugInfo?.primaryRole === 'restricted' && (
            <Alert variant="destructive">
              <AlertTriangle className="w-4 h-4" />
              <AlertDescription>
                <strong>🚨 Access Restricted:</strong> User is marked as 'restricted' which means 
                role detection failed. This should be investigated.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Resolution Method */}
      {debugInfo?.lastResolution && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              🔍 Role Resolution Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Resolution Method
                </label>
                <div className="mt-1">
                  <Badge variant="secondary">
                    {formatResolutionMethod(debugInfo.lastResolution.resolution_method)}
                  </Badge>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Dashboard Route
                </label>
                <div className="mt-1 text-sm font-mono bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                  {debugInfo.lastResolution.dashboard_route}
                </div>
              </div>
            </div>

            {/* Attempts Made */}
            {debugInfo.lastResolution.debug_info?.attempts && (
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Resolution Attempts
                </label>
                <div className="mt-1 space-y-1">
                  {debugInfo.lastResolution.debug_info.attempts.map((attempt: string, index: number) => (
                    <div key={index} className="text-xs bg-gray-50 dark:bg-gray-800 px-2 py-1 rounded">
                      {index + 1}. {attempt}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Validation Results */}
      {debugInfo?.validation && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              ✅ Validation Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2">
              {debugInfo.validation.isValid ? (
                <CheckCircle className="w-5 h-5 text-green-600" />
              ) : (
                <XCircle className="w-5 h-5 text-red-600" />
              )}
              <span className="font-medium">
                {debugInfo.validation.isValid ? 'Role detection is working correctly' : 'Issues detected with role detection'}
              </span>
            </div>

            {debugInfo.validation.issues && debugInfo.validation.issues.length > 0 && (
              <div>
                <label className="text-sm font-medium text-red-700 dark:text-red-400">
                  Issues Found
                </label>
                <ul className="mt-1 space-y-1">
                  {debugInfo.validation.issues.map((issue: string, index: number) => (
                    <li key={index} className="text-sm text-red-600 dark:text-red-400">
                      • {issue}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {debugInfo.validation.recommendations && debugInfo.validation.recommendations.length > 0 && (
              <div>
                <label className="text-sm font-medium text-blue-700 dark:text-blue-400">
                  Recommendations
                </label>
                <ul className="mt-1 space-y-1">
                  {debugInfo.validation.recommendations.map((rec: string, index: number) => (
                    <li key={index} className="text-sm text-blue-600 dark:text-blue-400">
                      • {rec}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* System Health */}
      {healthInfo && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              🏥 System Health & Permissions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  {healthInfo.services.wordpress ? (
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-600" />
                  )}
                  <span className="text-sm font-medium">WordPress</span>
                </div>
                <Badge variant={healthInfo.services.wordpress ? 'default' : 'destructive'}>
                  {healthInfo.services.wordpress ? 'Connected' : 'Failed'}
                </Badge>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  {healthInfo.services.woocommerce ? (
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-600" />
                  )}
                  <span className="text-sm font-medium">WooCommerce</span>
                </div>
                <Badge variant={healthInfo.services.woocommerce ? 'default' : 'destructive'}>
                  {healthInfo.services.woocommerce ? 'Connected' : 'Failed'}
                </Badge>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  {healthInfo.services.authentication ? (
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-600" />
                  )}
                  <span className="text-sm font-medium">Auth</span>
                </div>
                <Badge variant={healthInfo.services.authentication ? 'default' : 'destructive'}>
                  {healthInfo.services.authentication ? 'Valid' : 'Invalid'}
                </Badge>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <span className="text-sm font-medium">Status</span>
                </div>
                <Badge variant={healthInfo.status === 'healthy' ? 'default' : 'secondary'}>
                  {healthInfo.status}
                </Badge>
              </div>
            </div>

            <Separator />

            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                API Permissions
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <div className="flex items-center gap-2">
                  {healthInfo.permissions.canListProducts ? (
                    <CheckCircle className="w-3 h-3 text-green-600" />
                  ) : (
                    <XCircle className="w-3 h-3 text-red-600" />
                  )}
                  <span className="text-xs">Products</span>
                </div>
                <div className="flex items-center gap-2">
                  {healthInfo.permissions.canListOrders ? (
                    <CheckCircle className="w-3 h-3 text-green-600" />
                  ) : (
                    <XCircle className="w-3 h-3 text-red-600" />
                  )}
                  <span className="text-xs">Orders</span>
                </div>
                <div className="flex items-center gap-2">
                  {healthInfo.permissions.canListUsers ? (
                    <CheckCircle className="w-3 h-3 text-green-600" />
                  ) : (
                    <XCircle className="w-3 h-3 text-red-600" />
                  )}
                  <span className="text-xs">Users</span>
                </div>
                <div className="flex items-center gap-2">
                  {healthInfo.permissions.canViewReports ? (
                    <CheckCircle className="w-3 h-3 text-green-600" />
                  ) : (
                    <XCircle className="w-3 h-3 text-red-600" />
                  )}
                  <span className="text-xs">Reports</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Sensitive Debug Data */}
      {showSensitiveData && debugInfo?.lastResolution?.debug_info && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              🔒 Sensitive Debug Data
            </CardTitle>
            <CardDescription>
              Raw API responses and debug information (only shown when requested)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-4 rounded-lg overflow-auto max-h-96">
              {JSON.stringify(debugInfo.lastResolution.debug_info, null, 2)}
            </pre>
          </CardContent>
        </Card>
      )}

      {/* Help Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            💡 Troubleshooting Guide
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2">
            <h4 className="font-medium">If user is showing as 'subscriber' but should be admin/vendor:</h4>
            <ul className="text-sm space-y-1 ml-4">
              <li>• Check if the WordPress user has the correct role assigned in wp-admin</li>
              <li>• Verify Dokan plugin is properly assigning vendor roles during registration</li>
              <li>• Ensure JWT token has proper scope and isn't restricted</li>
              <li>• Check WordPress REST API permissions for the user</li>
            </ul>
          </div>
          <div className="space-y-2">
            <h4 className="font-medium">If role detection is failing entirely:</h4>
            <ul className="text-sm space-y-1 ml-4">
              <li>• Verify WordPress REST API is accessible at /wp-json/wp/v2/</li>
              <li>• Check if JWT token is valid and not expired</li>
              <li>• Ensure user has permission to access /users/me endpoint</li>
              <li>• Check network connectivity and CORS settings</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RoleDetectionDebugPanel;