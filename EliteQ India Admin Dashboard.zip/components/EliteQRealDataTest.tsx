import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { LoaderIcon, ShoppingCart, Package, Users, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';
import { wooCommerceApi, WooCommerceApiError } from '../utils/woocommerce-api';
import { envHelpers } from '../utils/env-config';

interface Product {
  id: number;
  name: string;
  price: string;
  regular_price: string;
  sale_price: string;
  status: string;
  stock_status: string;
  manage_stock: boolean;
  stock_quantity: number;
  images: Array<{ src: string; alt: string }>;
  categories: Array<{ id: number; name: string }>;
  type: string;
  date_created: string;
}

interface Order {
  id: number;
  status: string;
  total: string;
  currency: string;
  date_created: string;
  billing: {
    first_name: string;
    last_name: string;
    email: string;
  };
  line_items: Array<{
    name: string;
    quantity: number;
    total: string;
  }>;
}

interface Customer {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  date_created: string;
  total_spent: string;
  orders_count: number;
}

export const EliteQRealDataTest: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<'unknown' | 'connected' | 'failed'>('unknown');
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalOrders: 0,
    totalCustomers: 0,
    totalRevenue: 0
  });
  const [refreshing, setRefreshing] = useState(false);

  const fetchRealData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('🔄 Starting EliteQ India real data fetch...');
      
      // Test connection first
      console.log('🔍 Testing WooCommerce connection...');
      const connectionTest = await wooCommerceApi.testConnection();
      if (!connectionTest.isConnected) {
        throw new Error(connectionTest.error || 'Connection failed');
      }
      
      setConnectionStatus('connected');
      console.log('✅ WooCommerce connection successful!');

      // Fetch products
      console.log('📦 Fetching products from EliteQ.in...');
      const productsResponse = await wooCommerceApi.getProducts({
        per_page: 10,
        status: 'publish',
        orderby: 'date',
        order: 'desc'
      });
      
      setProducts(productsResponse.data);
      console.log(`✅ Loaded ${productsResponse.data.length} products`);

      // Fetch orders  
      console.log('🛒 Fetching orders from EliteQ.in...');
      const ordersResponse = await wooCommerceApi.getOrders({
        per_page: 10,
        orderby: 'date',
        order: 'desc'
      });
      
      setOrders(ordersResponse.data);
      console.log(`✅ Loaded ${ordersResponse.data.length} orders`);

      // Fetch customers
      console.log('👥 Fetching customers from EliteQ.in...');
      const customersResponse = await wooCommerceApi.getCustomers({
        per_page: 10,
        orderby: 'registered_date',
        order: 'desc'
      });
      
      setCustomers(customersResponse.data);
      console.log(`✅ Loaded ${customersResponse.data.length} customers`);

      // Calculate stats
      const totalRevenue = ordersResponse.data.reduce((sum, order) => {
        return sum + parseFloat(order.total || '0');
      }, 0);

      setStats({
        totalProducts: productsResponse.data.length,
        totalOrders: ordersResponse.data.length, 
        totalCustomers: customersResponse.data.length,
        totalRevenue
      });

      console.log('🎉 EliteQ India data fetch completed successfully!');
      
    } catch (err) {
      console.error('❌ Failed to fetch EliteQ India data:', err);
      setConnectionStatus('failed');
      
      if (err instanceof WooCommerceApiError) {
        setError(`WooCommerce API Error: ${err.message} (Status: ${err.status})`);
        
        if (err.status === 401) {
          setError('Authentication failed. Please verify your WooCommerce API credentials are correctly configured.');
        }
      } else {
        setError(err instanceof Error ? err.message : 'Unknown error occurred');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchRealData();
    setRefreshing(false);
  };

  useEffect(() => {
    fetchRealData();
  }, []);

  const formatCurrency = (amount: string | number): string => {
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 2
    }).format(numAmount);
  };

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusBadgeColor = (status: string): string => {
    switch (status) {
      case 'publish': case 'completed': case 'processing':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'pending': case 'on-hold':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'cancelled': case 'refunded': case 'failed':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      case 'draft': case 'private':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="flex items-center justify-center p-8">
            <div className="text-center">
              <LoaderIcon className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
              <p className="text-lg font-medium mb-2">Loading EliteQ India Data...</p>
              <p className="text-sm text-muted-foreground">
                Connecting to WooCommerce API and fetching real data from eliteq.in
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card className="border-destructive">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertCircle className="h-5 w-5" />
              EliteQ India Connection Error
            </CardTitle>
            <CardDescription>
              Failed to connect to the EliteQ India WooCommerce API
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg mb-4">
              <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
            </div>
            
            <div className="space-y-2 text-sm">
              <h4 className="font-medium">Environment Configuration:</h4>
              <div className="bg-gray-50 dark:bg-gray-900/50 p-3 rounded-lg">
                <pre className="text-xs">
                  {JSON.stringify(envHelpers.getMaskedCredentials(), null, 2)}
                </pre>
              </div>
            </div>

            <Button onClick={handleRefresh} className="mt-4" disabled={refreshing}>
              {refreshing ? (
                <>
                  <LoaderIcon className="h-4 w-4 animate-spin mr-2" />
                  Retrying...
                </>
              ) : (
                'Retry Connection'
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">EliteQ India - Real Data Dashboard</h1>
          <p className="text-muted-foreground">Live data from your WooCommerce store at eliteq.in</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-500" />
            <span className="text-sm font-medium text-green-700 dark:text-green-400">Connected</span>
          </div>
          <Button onClick={handleRefresh} disabled={refreshing} variant="outline">
            {refreshing ? (
              <LoaderIcon className="h-4 w-4 animate-spin" />
            ) : (
              'Refresh Data'
            )}
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Package className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Products</p>
                <p className="text-2xl font-bold">{stats.totalProducts}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <ShoppingCart className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Orders</p>
                <p className="text-2xl font-bold">{stats.totalOrders}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Customers</p>
                <p className="text-2xl font-bold">{stats.totalCustomers}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Revenue</p>
                <p className="text-2xl font-bold">{formatCurrency(stats.totalRevenue)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Products Section */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Products</CardTitle>
          <CardDescription>Latest products from your EliteQ India store</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {products.slice(0, 6).map((product) => (
              <div key={product.id} className="border rounded-lg p-4 space-y-3">
                {product.images && product.images.length > 0 && (
                  <img
                    src={product.images[0].src}
                    alt={product.images[0].alt || product.name}
                    className="w-full h-32 object-cover rounded-md"
                  />
                )}
                <div>
                  <h4 className="font-medium truncate">{product.name}</h4>
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex flex-col">
                      {product.sale_price ? (
                        <>
                          <span className="text-sm text-muted-foreground line-through">
                            {formatCurrency(product.regular_price)}
                          </span>
                          <span className="font-bold text-green-600">
                            {formatCurrency(product.sale_price)}
                          </span>
                        </>
                      ) : (
                        <span className="font-bold">
                          {formatCurrency(product.price || product.regular_price)}
                        </span>
                      )}
                    </div>
                    <Badge className={getStatusBadgeColor(product.status)}>
                      {product.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatDate(product.date_created)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Orders Section */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
          <CardDescription>Latest orders from your EliteQ India store</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {orders.slice(0, 5).map((order) => (
              <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <span className="font-medium">Order #{order.id}</span>
                    <Badge className={getStatusBadgeColor(order.status)}>
                      {order.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {order.billing.first_name} {order.billing.last_name} • {order.billing.email}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(order.date_created)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold">{formatCurrency(order.total)} {order.currency}</p>
                  <p className="text-sm text-muted-foreground">
                    {order.line_items.length} item(s)
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Customers Section */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Customers</CardTitle>
          <CardDescription>Latest customers registered on your EliteQ India store</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {customers.slice(0, 5).map((customer) => (
              <div key={customer.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <p className="font-medium">
                    {customer.first_name} {customer.last_name}
                  </p>
                  <p className="text-sm text-muted-foreground">{customer.email}</p>
                  <p className="text-xs text-muted-foreground">
                    Joined: {formatDate(customer.date_created)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold">{formatCurrency(customer.total_spent)}</p>
                  <p className="text-sm text-muted-foreground">
                    {customer.orders_count} order(s)
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EliteQRealDataTest;