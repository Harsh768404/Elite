import React, { useState, useEffect } from 'react';
import { Eye, EyeOff, Lock, Mail, AlertCircle, Loader2, Shield, Sparkles, Zap, CheckCircle, XCircle, Crown, User } from 'lucide-react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { useAuth } from '../contexts/AuthContext';
import { LoginCredentials } from '../utils/wordpress-auth';
import { EliteQIndiaLogo } from './EliteQIndiaLogo';

interface EliteQLoginPageProps {
  onLoginSuccess?: () => void;
}

export const EliteQLoginPage: React.FC<EliteQLoginPageProps> = ({ onLoginSuccess }) => {
  const { login, isLoading, error } = useAuth();
  const [credentials, setCredentials] = useState<LoginCredentials>({
    username: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationErrors, setValidationErrors] = useState<{[key: string]: string}>({});
  const [hasInteracted, setHasInteracted] = useState({ username: false, password: false });

  // Clear error when credentials change
  useEffect(() => {
    if (error) {
      // Clear error when user starts typing
      const timeoutId = setTimeout(() => {
        // This will be handled by the AuthContext internally
      }, 100);
      return () => clearTimeout(timeoutId);
    }
  }, [credentials.username, credentials.password, error]);

  // Handle input changes
  const handleInputChange = (field: keyof LoginCredentials, value: string) => {
    setCredentials(prev => ({
      ...prev,
      [field]: value
    }));

    setHasInteracted(prev => ({
      ...prev,
      [field]: true
    }));

    // Clear validation error
    if (validationErrors[field]) {
      setValidationErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }

    // Real-time email validation
    if (field === 'username' && value.trim() && hasInteracted.username) {
      if (value.includes('@') && !isValidEmail(value)) {
        setValidationErrors(prev => ({
          ...prev,
          username: 'Please enter a valid email address'
        }));
      }
    }
  };

  // Email validation
  const isValidEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Form validation
  const validateForm = (): boolean => {
    const errors: {[key: string]: string} = {};

    if (!credentials.username.trim()) {
      errors.username = 'Username or email is required';
    } else if (credentials.username.includes('@') && !isValidEmail(credentials.username)) {
      errors.username = 'Please enter a valid email address';
    }

    if (!credentials.password) {
      errors.password = 'Password is required';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    setHasInteracted({ username: true, password: true });
    
    if (!validateForm()) {
      return;
    }

    // Additional validation to ensure we have valid credentials
    if (!credentials.username.trim() || !credentials.password.trim()) {
      console.error('❌ Form validation failed: Empty credentials detected');
      setValidationErrors({
        username: !credentials.username.trim() ? 'Username is required' : '',
        password: !credentials.password.trim() ? 'Password is required' : ''
      });
      return;
    }

    setIsSubmitting(true);
    console.log('🔐 ===== WORDPRESS LOGIN SUBMISSION =====');
    console.log('👤 Username/Email:', credentials.username);
    console.log('🔒 Password length:', credentials.password.length, 'characters');

    try {
      // Pass the credentials object as expected by AuthContext
      await login({
        username: credentials.username.trim(),
        password: credentials.password.trim()
      });
      
      console.log('✅ Login successful - user will be redirected by router');
      
      if (onLoginSuccess) {
        onLoginSuccess();
      }
    } catch (error) {
      console.error('❌ Login submission failed:', error);
      // Error is handled by AuthContext and displayed automatically
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle input blur
  const handleBlur = (field: keyof LoginCredentials) => {
    setHasInteracted(prev => ({
      ...prev,
      [field]: true
    }));
    
    if (field === 'username' && credentials.username.trim()) {
      if (credentials.username.includes('@') && !isValidEmail(credentials.username)) {
        setValidationErrors(prev => ({
          ...prev,
          username: 'Please enter a valid email address'
        }));
      }
    }
  };

  // Determine error type for styling
  const isCredentialError = error && (
    error.includes('Invalid username or password') || 
    error.includes('Authentication failed') ||
    error.includes('incorrect_password') ||
    error.includes('invalid_email') ||
    error.includes('empty_username') ||
    error.includes('empty_password')
  );

  const isAccessDeniedError = error && (
    error.includes('Access Denied') ||
    error.includes('not allowed') ||
    error.includes('restricted')
  );

  const isConnectionError = error && (
    error.includes('Failed to fetch') ||
    error.includes('Network') ||
    error.includes('Connection') ||
    error.includes('WordPress')
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-blue-900/20 dark:to-indigo-900/30 flex items-center justify-center p-4 relative overflow-hidden">
      
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-20 w-32 h-32 opacity-5">
          <div className="grid grid-cols-4 gap-1">
            {Array.from({ length: 16 }).map((_, i) => (
              <div key={i} className="w-6 h-6 bg-blue-600 rounded-sm"></div>
            ))}
          </div>
        </div>
        
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-blue-500/3 to-indigo-500/3 rounded-full blur-3xl"></div>
        
        <div className="absolute top-32 right-20 w-4 h-4 bg-orange-400/20 rounded-full animate-pulse"></div>
        <div className="absolute bottom-32 left-32 w-6 h-6 bg-blue-400/20 rounded-sm animate-pulse" style={{ animationDelay: '0.5s' }}></div>
        <div className="absolute top-2/3 right-1/3 w-3 h-3 bg-green-400/20 rounded-full animate-pulse" style={{ animationDelay: '1.5s' }}></div>
      </div>

      <div className="relative z-10 w-full max-w-md">
        
        {/* Header with Logo */}
        <div className="text-center mb-8">
          <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/20 p-8 mb-6">
            <div className="flex justify-center mb-6">
              <EliteQIndiaLogo size="lg" showTagline={true} />
            </div>
            
            {/* WordPress & Role indicators */}
            <div className="flex items-center justify-center gap-4 mb-4">
              <div className="flex items-center gap-1 text-xs text-gray-600 dark:text-gray-400 bg-white/50 dark:bg-gray-700/50 rounded-full px-3 py-1">
                <Shield className="h-3 w-3 text-green-500" />
                <span>WordPress JWT</span>
              </div>
              <div className="flex items-center gap-1 text-xs text-gray-600 dark:text-gray-400 bg-white/50 dark:bg-gray-700/50 rounded-full px-3 py-1">
                <Zap className="h-3 w-3 text-blue-500" />
                <span>Electronics</span>
              </div>
            </div>
            
            <div className="text-sm text-gray-600 dark:text-gray-400">
              WordPress Admin & Vendor Dashboard Access
            </div>
          </div>
        </div>

        {/* Login Form */}
        <Card className="shadow-2xl border-0 bg-white/90 dark:bg-gray-800/90 backdrop-blur-xl">
          <CardHeader className="space-y-4 pb-6">
            <div className="text-center space-y-2">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
                WordPress Login
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Admin & Vendor access with role verification
              </p>
            </div>

            {/* Required roles info */}
            <div className="flex items-center justify-center gap-4 pt-2">
              <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
                <Crown className="h-3 w-3 text-yellow-500" />
                <span>Administrator</span>
              </div>
              <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
                <Zap className="h-3 w-3 text-blue-500" />
                <span>Vendor</span>
              </div>
              <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
                <User className="h-3 w-3 text-green-500" />
                <span>Seller</span>
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Error Alert with proper categorization */}
            {error && (
              <Alert className={`animate-slide-in ${
                isAccessDeniedError 
                  ? 'border-red-200 bg-red-50 dark:bg-red-900/20' 
                  : isCredentialError
                  ? 'border-red-200 bg-red-50 dark:bg-red-900/20'
                  : isConnectionError
                  ? 'border-orange-200 bg-orange-50 dark:bg-orange-900/20'
                  : 'border-red-200 bg-red-50 dark:bg-red-900/20'
              }`}>
                <div className="flex items-center gap-2">
                  {isAccessDeniedError ? (
                    <Shield className="h-4 w-4 text-red-600 dark:text-red-400" />
                  ) : isConnectionError ? (
                    <AlertCircle className="h-4 w-4 text-orange-600 dark:text-orange-400" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
                  )}
                  <AlertDescription className={
                    isConnectionError 
                      ? 'text-orange-700 dark:text-orange-300 font-medium'
                      : 'text-red-700 dark:text-red-300 font-medium'
                  }>
                    {error}
                  </AlertDescription>
                </div>
                {isAccessDeniedError && (
                  <div className="mt-2 text-xs text-red-600 dark:text-red-400">
                    Only WordPress users with administrator, vendor, seller, or shop_manager roles can access this dashboard.
                  </div>
                )}
                {isConnectionError && (
                  <div className="mt-2 text-xs text-orange-600 dark:text-orange-400">
                    Please check your internet connection and try again. If the problem persists, contact support.
                  </div>
                )}
              </Alert>
            )}

            {/* Login Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Username/Email Field */}
              <div className="space-y-2">
                <Label htmlFor="username" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  WordPress Username or Email
                </Label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                    <Mail className="h-4 w-4" />
                  </div>
                  <Input
                    id="username"
                    type="text"
                    placeholder="Enter your WordPress username or email"
                    value={credentials.username}
                    onChange={(e) => handleInputChange('username', e.target.value)}
                    onBlur={() => handleBlur('username')}
                    className={`pl-10 h-12 transition-all duration-200 ${
                      validationErrors.username
                        ? 'border-red-300 focus:border-red-500 focus:ring-red-200'
                        : credentials.username && !validationErrors.username
                        ? 'border-green-300 focus:border-green-500 focus:ring-green-200'
                        : 'focus:border-blue-500 focus:ring-blue-200'
                    }`}
                    disabled={isSubmitting || isLoading}
                    autoComplete="username"
                    required
                  />
                  {credentials.username && !validationErrors.username && (
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    </div>
                  )}
                </div>
                {validationErrors.username && (
                  <p className="text-sm text-red-600 dark:text-red-400 animate-slide-in">
                    {validationErrors.username}
                  </p>
                )}
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  WordPress Password
                </Label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                    <Lock className="h-4 w-4" />
                  </div>
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your WordPress password"
                    value={credentials.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    onBlur={() => handleBlur('password')}
                    className={`pl-10 pr-10 h-12 transition-all duration-200 ${
                      validationErrors.password
                        ? 'border-red-300 focus:border-red-500 focus:ring-red-200'
                        : credentials.password && !validationErrors.password
                        ? 'border-green-300 focus:border-green-500 focus:ring-green-200'
                        : 'focus:border-blue-500 focus:ring-blue-200'
                    }`}
                    disabled={isSubmitting || isLoading}
                    autoComplete="current-password"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                    disabled={isSubmitting || isLoading}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {validationErrors.password && (
                  <p className="text-sm text-red-600 dark:text-red-400 animate-slide-in">
                    {validationErrors.password}
                  </p>
                )}
              </div>

              {/* Login Button */}
              <Button
                type="submit"
                className="w-full h-12 bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 hover:from-blue-700 hover:via-blue-800 hover:to-blue-900 text-white font-medium shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                disabled={isSubmitting || isLoading || !credentials.username.trim() || !credentials.password.trim()}
              >
                {isSubmitting || isLoading ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Authenticating with WordPress...</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4" />
                    <span>Sign In to Dashboard</span>
                  </div>
                )}
              </Button>
            </form>

            {/* Access Requirements Info */}
            <div className="text-center">
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-700">
                <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-2">
                  📋 WordPress Role Requirements
                </h4>
                <div className="text-xs text-blue-700 dark:text-blue-300 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex items-center justify-center gap-1 bg-white/50 dark:bg-gray-800/50 rounded px-2 py-1">
                      <Crown className="h-3 w-3 text-yellow-500" />
                      <span>Administrator</span>
                    </div>
                    <div className="flex items-center justify-center gap-1 bg-white/50 dark:bg-gray-800/50 rounded px-2 py-1">
                      <Zap className="h-3 w-3 text-blue-500" />
                      <span>Vendor</span>
                    </div>
                    <div className="flex items-center justify-center gap-1 bg-white/50 dark:bg-gray-800/50 rounded px-2 py-1">
                      <User className="h-3 w-3 text-green-500" />
                      <span>Seller</span>
                    </div>
                    <div className="flex items-center justify-center gap-1 bg-white/50 dark:bg-gray-800/50 rounded px-2 py-1">
                      <Shield className="h-3 w-3 text-purple-500" />
                      <span>Shop Manager</span>
                    </div>
                  </div>
                  <div className="mt-2 text-xs text-blue-600 dark:text-blue-400">
                    ⚠️ Other WordPress roles will see "Access Restricted"
                  </div>
                </div>
              </div>
            </div>

            {/* Security & Tech Info */}
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="text-center space-y-3">
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  🔒 Secure WordPress JWT authentication with real-time role verification
                </p>
                <div className="flex items-center justify-center gap-3 text-xs text-gray-400">
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>WordPress API</span>
                  </div>
                  <span>•</span>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>JWT Tokens</span>
                  </div>
                  <span>•</span>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span>Role Verification</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-6 text-sm text-gray-500 dark:text-gray-400">
          <p>© 2025 EliteQ India. WordPress electronics marketplace platform.</p>
          <p className="text-xs mt-1">Powered by WordPress with JWT authentication & role-based access control</p>
        </div>
      </div>
    </div>
  );
};

export default EliteQLoginPage;