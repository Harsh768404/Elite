import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Star, TrendingUp, Users, Package, ShoppingCart } from 'lucide-react';

interface PerformanceMetric {
  label: string;
  value: number;
  maxValue: number;
  status: 'excellent' | 'good' | 'average' | 'poor';
  icon: React.ElementType;
}

export const StorePerformance: React.FC = () => {
  const overallScore = 87;
  
  const metrics: PerformanceMetric[] = [
    {
      label: 'Product Quality',
      value: 92,
      maxValue: 100,
      status: 'excellent',
      icon: Package
    },
    {
      label: 'Customer Service',
      value: 89,
      maxValue: 100,
      status: 'excellent',
      icon: Users
    },
    {
      label: 'Delivery Speed',
      value: 78,
      maxValue: 100,
      status: 'good',
      icon: TrendingUp
    },
    {
      label: 'Order Fulfillment',
      value: 95,
      maxValue: 100,
      status: 'excellent',
      icon: ShoppingCart
    }
  ];

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getProgressColor = (score: number) => {
    if (score >= 90) return 'bg-green-500';
    if (score >= 80) return 'bg-blue-500';
    if (score >= 70) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      excellent: { variant: 'default' as const, color: 'bg-green-100 text-green-800' },
      good: { variant: 'secondary' as const, color: 'bg-blue-100 text-blue-800' },
      average: { variant: 'outline' as const, color: 'bg-yellow-100 text-yellow-800' },
      poor: { variant: 'destructive' as const, color: 'bg-red-100 text-red-800' }
    };
    
    return variants[status] || variants.average;
  };

  return (
    <Card className="bg-white dark:bg-gray-900 border-0 shadow-lg">
      <CardHeader className="border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg font-bold">
            <Star className="h-5 w-5 text-yellow-500" />
            Store Performance
          </CardTitle>
          <div className="flex items-center gap-2">
            <div className={`text-3xl font-bold ${getScoreColor(overallScore)}`}>
              {overallScore}
            </div>
            <div className="text-sm text-gray-500">/ 100</div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-6 space-y-6">
        {/* Overall Score Circle */}
        <div className="flex items-center justify-center">
          <div className="relative w-32 h-32">
            <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 120 120">
              {/* Background circle */}
              <circle
                cx="60"
                cy="60"
                r="54"
                stroke="currentColor"
                strokeWidth="8"
                fill="transparent"
                className="text-gray-200 dark:text-gray-700"
              />
              {/* Progress circle */}
              <circle
                cx="60"
                cy="60"
                r="54"
                stroke="currentColor"
                strokeWidth="8"
                fill="transparent"
                strokeDasharray={`${2 * Math.PI * 54}`}
                strokeDashoffset={`${2 * Math.PI * 54 * (1 - overallScore / 100)}`}
                className={getScoreColor(overallScore).replace('text-', 'text-')}
                style={{
                  transition: 'stroke-dashoffset 0.5s ease-in-out',
                }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className={`text-2xl font-bold ${getScoreColor(overallScore)}`}>
                  {overallScore}
                </div>
                <div className="text-xs text-gray-500">Score</div>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="space-y-4">
          <h4 className="font-semibold text-gray-900 dark:text-white">Performance Breakdown</h4>
          {metrics.map((metric, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <metric.icon className="h-4 w-4 text-gray-500" />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {metric.label}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-bold ${getScoreColor(metric.value)}`}>
                    {metric.value}%
                  </span>
                  <Badge 
                    className={`text-xs ${getStatusBadge(metric.status).color}`}
                    variant="secondary"
                  >
                    {metric.status}
                  </Badge>
                </div>
              </div>
              <div className="relative">
                <Progress 
                  value={metric.value} 
                  className="h-2"
                />
                <div 
                  className={`absolute top-0 left-0 h-2 rounded-full transition-all duration-500 ${getProgressColor(metric.value)}`}
                  style={{ width: `${metric.value}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Recommendations */}
        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <h5 className="font-medium text-blue-900 dark:text-blue-200 mb-2">
            💡 Recommendations
          </h5>
          <ul className="text-sm text-blue-800 dark:text-blue-300 space-y-1">
            <li>• Improve delivery speed to reach excellent rating</li>
            <li>• Maintain high product quality standards</li>
            <li>• Keep responding quickly to customer inquiries</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};

export default StorePerformance;