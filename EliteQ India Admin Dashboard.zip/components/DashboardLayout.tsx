import React, { useState, useEffect } from 'react';
import { 
  Bell, Moon, Sun, LogOut, User, Shield, Menu,
  Search, RefreshCw, CheckCircle, Package, ShoppingCart, Users,
  Key, Settings, Lock, Mail
} from 'lucide-react';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from './ui/dropdown-menu';
import { Sheet, SheetContent, SheetTrigger } from './ui/sheet';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Alert, AlertDescription } from './ui/alert';

// Import components
import { ModernVendorSidebar } from './ModernVendorSidebar';
import { EliteQLogo } from './EliteQLogo';
import { useAuth } from '../contexts/AuthContext';

interface DashboardLayoutProps {
  children: React.ReactNode;
  activeModule?: string;
  setActiveModule?: (module: string) => void;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ 
  children, 
  activeModule = 'dashboard', 
  setActiveModule 
}) => {
  const { user, dashboardRole, logout } = useAuth();
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifications] = useState(3);

  // Dark mode effect
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Helper functions for user display with role mapping support
  const isAdmin = dashboardRole === 'admin';
  const isVendor = dashboardRole === 'vendor';
  const isUser = dashboardRole === 'user';
  
  const getUserDisplayName = () => {
    return user?.display_name || user?.username || 'User';
  };

  const getUserRole = () => {
    switch (dashboardRole) {
      case 'admin':
        return 'Administrator';
      case 'vendor':
        return 'Vendor';
      case 'user':
        return 'User';
      default:
        return 'Unknown';
    }
  };

  const getAvatarFallback = () => {
    switch (dashboardRole) {
      case 'admin':
        return 'AD';
      case 'vendor':
        return 'VE';
      case 'user':
        return 'US';
      default:
        return 'U';
    }
  };

  const getRoleBadgeColor = () => {
    switch (dashboardRole) {
      case 'admin':
        return 'text-blue-600 border-blue-300 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-700 dark:text-blue-400';
      case 'vendor':
        return 'text-green-600 border-green-300 bg-green-50 dark:bg-green-900/20 dark:border-green-700 dark:text-green-400';
      case 'user':
        return 'text-purple-600 border-purple-300 bg-purple-50 dark:bg-purple-900/20 dark:border-purple-700 dark:text-purple-400';
      default:
        return 'text-gray-600 border-gray-300 bg-gray-50 dark:bg-gray-900/20 dark:border-gray-700 dark:text-gray-400';
    }
  };

  const getDashboardTitle = () => {
    switch (dashboardRole) {
      case 'admin':
        return 'EliteQ Admin Panel';
      case 'vendor':
        return 'EliteQ Vendor Dashboard';
      case 'user':
        return 'EliteQ User Dashboard';
      default:
        return 'EliteQ Dashboard';
    }
  };

  const getDashboardSubtitle = () => {
    switch (dashboardRole) {
      case 'admin':
        return 'Complete WordPress + WooCommerce + Dokan Pro Management @ eliteq.in';
      case 'vendor':
        return 'Live Store Management @ eliteq.in';
      case 'user':
        return 'Customer Account Management @ eliteq.in';
      default:
        return 'Dashboard Management @ eliteq.in';
    }
  };

  // Enhanced logout handler
  const handleLogout = () => {
    console.log('🚪 ===== DASHBOARD LOGOUT =====');
    console.log('👤 Logging out user:', getUserDisplayName());
    console.log('🎭 User role:', getUserRole());
    console.log('🎯 Mapped role:', user?.role);
    
    logout();
  };

  // Listen for navigation events from header announcements
  useEffect(() => {
    const handleNavigateToAnnouncements = () => {
      if (setActiveModule) {
        setActiveModule('announcements');
      }
    };

    window.addEventListener('navigate-to-announcements', handleNavigateToAnnouncements);
    return () => {
      window.removeEventListener('navigate-to-announcements', handleNavigateToAnnouncements);
    };
  }, [setActiveModule]);

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      darkMode ? 'bg-gray-950' : 'bg-gray-50'
    }`}>
      
      {/* Enhanced Header with Role Mapping Display */}
      <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 px-4 lg:px-6 py-4 sticky top-0 z-50 shadow-sm">
        <div className="flex items-center justify-between w-full">
          
          <div className="flex items-center gap-4">
            {/* Logo & Brand */}
            <div className="flex items-center min-w-0">
              <EliteQLogo darkMode={darkMode} size="sm" showText={false} animated={true} />
              <div className="hidden md:block ml-3 min-w-0">
                <div className="flex items-center gap-2">
                  <h1 className="text-lg font-bold text-gray-900 dark:text-white tracking-tight truncate">
                    {getDashboardTitle()}
                  </h1>
                  <Badge variant="outline" className={getRoleBadgeColor()}>
                    <Shield className="h-3 w-3 mr-1" />
                    {getUserRole()}
                  </Badge>
                  <Badge className="bg-green-100 text-green-700 border-green-300 dark:bg-green-900/20 dark:text-green-400">
                    🌐 Live Mode
                  </Badge>
                  {/* Role Mapping Indicator */}
                  {user?.role && (
                    <Badge variant="outline" className="text-xs text-orange-600 border-orange-300 bg-orange-50 dark:bg-orange-900/20">
                      Mapped: {user.role}
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
                  {getDashboardSubtitle()}
                </p>
              </div>
              
              {/* Mobile Brand */}
              <div className="md:hidden ml-2">
                <div className="flex items-center gap-2">
                  <h1 className="text-base font-bold text-gray-900 dark:text-white">
                    {getUserRole()}
                  </h1>
                  <Badge variant="outline" className="text-green-600 border-green-300 bg-green-50 text-xs">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Live
                  </Badge>
                </div>
              </div>
            </div>

            {/* Mobile Menu */}
            <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="lg:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="p-0 w-80">
                <ModernVendorSidebar
                  activeModule={activeModule}
                  setActiveModule={setActiveModule}
                  darkMode={darkMode}
                  userRole={dashboardRole || 'user'}
                  sidebarOpen={sidebarOpen}
                  setSidebarOpen={setSidebarOpen}
                />
              </SheetContent>
            </Sheet>
          </div>

          {/* Header Controls */}
          <div className="flex items-center gap-4">
            {/* Search Bar */}
            <div className="hidden md:flex relative max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search live products, orders, customers..."
                className="pl-10 w-64"
              />
            </div>

            {/* Theme Toggle */}
            <div className="flex items-center gap-2">
              <Sun className="h-4 w-4 text-gray-500" />
              <Switch 
                checked={darkMode} 
                onCheckedChange={setDarkMode}
                className="data-[state=checked]:bg-blue-600"
              />
              <Moon className="h-4 w-4 text-gray-500" />
            </div>

            {/* Notifications */}
            <Button variant="ghost" size="sm" className="relative">
              <Bell className="h-5 w-5" />
              {notifications > 0 && (
                <div className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 rounded-full flex items-center justify-center">
                  <span className="text-xs text-white font-medium">{notifications}</span>
                </div>
              )}
            </Button>

            {/* Enhanced User Profile Dropdown with Role Mapping */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-800">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar_url || undefined} />
                    <AvatarFallback className={`text-white ${
                      isAdmin ? 'bg-blue-600' : isVendor ? 'bg-green-600' : 'bg-purple-600'
                    }`}>
                      {getAvatarFallback()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden md:block text-left">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {getUserDisplayName()}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">
                      {getUserRole()} (Live)
                    </div>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64">
                <DropdownMenuItem onClick={() => setActiveModule && setActiveModule('settings')}>
                  <User className="h-4 w-4 mr-2" />
                  Live Profile Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveModule && setActiveModule('settings')}>
                  <Settings className="h-4 w-4 mr-2" />
                  Live Preferences
                </DropdownMenuItem>
                {isAdmin && (
                  <DropdownMenuItem onClick={() => setActiveModule && setActiveModule('tools')}>
                    <Key className="h-4 w-4 mr-2" />
                    Live Admin Tools
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                
                {/* Enhanced User Info Section with Role Mapping */}
                <div className="px-2 py-1.5">
                  <div className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">User Information</div>
                  <div className="space-y-1">
                    <div className="text-xs text-gray-600 dark:text-gray-300">
                      ID: {user?.id || 'N/A'}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-300">
                      Username: {user?.username || 'N/A'}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-300">
                      Email: {user?.email || 'N/A'}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-300">
                      Type: {user?.user_type || dashboardRole}
                    </div>
                  </div>
                </div>
                
                <DropdownMenuSeparator />
                
                {/* Role Mapping Display Section */}
                <div className="px-2 py-1.5">
                  <div className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">Role Mapping</div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">WordPress:</span>
                      <div className="flex flex-wrap gap-1">
                        {user?.raw_roles?.slice(0, 2).map(role => (
                          <Badge key={role} variant="outline" className="text-xs h-4 px-1">
                            {role}
                          </Badge>
                        ))}
                        {user?.raw_roles && user.raw_roles.length > 2 && (
                          <span className="text-xs text-gray-400">+{user.raw_roles.length - 2}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">Mapped to:</span>
                      <Badge 
                        variant={isAdmin ? "default" : "secondary"}
                        className="text-xs h-4"
                      >
                        {user?.role || 'unknown'}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">Dashboard:</span>
                      <Badge 
                        variant="outline"
                        className="text-xs h-4"
                      >
                        {dashboardRole || 'none'}
                      </Badge>
                    </div>
                  </div>
                </div>
                
                <DropdownMenuSeparator />
                
                {/* Role Mapping Info */}
                <div className="px-2 py-1.5">
                  <div className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">Source</div>
                  <div className="text-xs text-gray-600 dark:text-gray-300">
                    from localStorage JWT token
                  </div>
                </div>
                
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600 dark:text-red-400">
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Content Area with Sidebar and Main */}
      <div className="flex">
        {/* Desktop Sidebar */}
        <div className="hidden lg:block w-80 sticky top-20 h-[calc(100vh-5rem)] overflow-hidden">
          <ModernVendorSidebar
            activeModule={activeModule}
            setActiveModule={setActiveModule}
            darkMode={darkMode}
            userRole={dashboardRole || 'user'}
          />
        </div>

        {/* Main Content */}
        <main className="flex-1 p-6 space-y-6 overflow-auto min-w-0 max-w-7xl mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;