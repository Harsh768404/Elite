import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Plus, ShoppingCart, Package, HelpCircle, BarChart3, Star, Settings } from 'lucide-react';

interface QuickAction {
  id: string;
  label: string;
  icon: React.ElementType;
  color: string;
  description: string;
  onClick?: () => void;
}

const quickActions: QuickAction[] = [
  {
    id: 'add-product',
    label: 'Add Product',
    icon: Plus,
    color: 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800',
    description: 'Add new product to your store'
  },
  {
    id: 'view-orders',
    label: 'View Orders',
    icon: ShoppingCart,
    color: 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800',
    description: 'Manage your customer orders'
  },
  {
    id: 'inventory',
    label: 'Inventory',
    icon: Package,
    color: 'bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800',
    description: 'Check product stock levels'
  },
  {
    id: 'analytics',
    label: 'Analytics',
    icon: BarChart3,
    color: 'bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800',
    description: 'View sales reports'
  },
  {
    id: 'reviews',
    label: 'Reviews',
    icon: Star,
    color: 'bg-gradient-to-r from-yellow-600 to-yellow-700 hover:from-yellow-700 hover:to-yellow-800',
    description: 'Manage customer reviews'
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: Settings,
    color: 'bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800',
    description: 'Configure store settings'
  }
];

export const QuickActions: React.FC = () => {
  return (
    <Card className="bg-white dark:bg-gray-900 border-0 shadow-lg">
      <CardHeader className="border-b border-gray-100 dark:border-gray-800">
        <CardTitle className="text-lg font-bold flex items-center gap-2">
          <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></div>
          Quick Actions
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {quickActions.map((action) => (
            <Button
              key={action.id}
              className={`${action.color} text-white border-0 h-auto p-4 flex flex-col items-center gap-3 group transition-all duration-300 hover:scale-105 hover:shadow-lg`}
              onClick={action.onClick}
            >
              <action.icon className="h-6 w-6 group-hover:scale-110 transition-transform duration-300" />
              <div className="text-center">
                <div className="font-semibold">{action.label}</div>
                <div className="text-xs opacity-90 mt-1">{action.description}</div>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickActions;