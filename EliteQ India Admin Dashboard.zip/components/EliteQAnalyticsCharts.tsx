import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Calendar, 
  TrendingUp, 
  BarChart3, 
  Download, 
  RefreshCw,
  Filter
} from 'lucide-react';

interface ChartData {
  date: string;
  sales: number;
  orders: number;
}

interface EliteQAnalyticsChartsProps {
  userRole: 'admin' | 'vendor';
}

export function EliteQAnalyticsCharts({ userRole }: EliteQAnalyticsChartsProps) {
  const [selectedPeriod, setSelectedPeriod] = useState('7days');
  const [chartType, setChartType] = useState('line');
  const [isLoading, setIsLoading] = useState(false);

  // Sample data for Aug 1, 2, 3
  const chartData: ChartData[] = [
    { date: 'Aug 1', sales: 0, orders: 0 },
    { date: 'Aug 2', sales: 0, orders: 0 },
    { date: 'Aug 3', sales: 0, orders: 0 }
  ];

  const periods = [
    { key: '7days', label: '7 Days' },
    { key: '30days', label: '30 Days' },
    { key: '90days', label: '90 Days' },
    { key: 'year', label: 'Year' }
  ];

  const handleRefresh = async () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  };

  const handleExport = () => {
    console.log('Exporting chart data...');
    // Implementation for data export
  };

  // Simple Chart Component (since ApexCharts might not be available)
  const SimpleChart = ({ data, type, title }: { 
    data: ChartData[], 
    type: 'sales' | 'orders',
    title: string 
  }) => {
    const maxValue = Math.max(...data.map(d => type === 'sales' ? d.sales : d.orders));
    const dataKey = type === 'sales' ? 'sales' : 'orders';
    const color = type === 'sales' ? 'bg-blue-500' : 'bg-green-500';
    const lightColor = type === 'sales' ? 'bg-blue-100' : 'bg-green-100';

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">{title}</h3>
          <Badge variant="secondary" className="text-xs">
            {type === 'sales' ? '₹0' : '0 orders'} total
          </Badge>
        </div>

        {/* Chart Area */}
        <div className="h-64 flex items-end justify-center space-x-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
          {data.map((item, index) => {
            const value = item[dataKey];
            const height = maxValue > 0 ? (value / maxValue) * 200 : 20;
            
            return (
              <div key={index} className="flex flex-col items-center space-y-2">
                <div className="relative group">
                  <div 
                    className={`w-12 ${color} rounded-t-lg transition-all duration-300 hover:opacity-80`}
                    style={{ height: `${Math.max(height, 4)}px` }}
                  ></div>
                  
                  {/* Tooltip */}
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    <div className="bg-gray-900 dark:bg-white text-white dark:text-gray-900 text-xs px-2 py-1 rounded shadow-lg whitespace-nowrap">
                      {type === 'sales' ? `₹${value}` : `${value} orders`}
                    </div>
                  </div>
                </div>
                
                <span className="text-xs text-gray-600 dark:text-gray-400 font-medium">
                  {item.date}
                </span>
              </div>
            );
          })}
        </div>

        {/* Chart Summary */}
        <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-200 dark:border-gray-700">
          <div className="text-center">
            <div className="text-sm font-medium text-gray-900 dark:text-white">
              {type === 'sales' ? '₹0' : '0'}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Average</div>
          </div>
          <div className="text-center">
            <div className="text-sm font-medium text-gray-900 dark:text-white">
              {type === 'sales' ? '₹0' : '0'}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Peak</div>
          </div>
          <div className="text-center">
            <div className="text-sm font-medium text-gray-900 dark:text-white">
              +0%
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Growth</div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="mb-8">
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between mb-6 space-y-4 lg:space-y-0">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Analytics Dashboard
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            Track your {userRole === 'admin' ? 'marketplace' : 'store'} performance with detailed insights
          </p>
        </div>

        {/* Controls */}
        <div className="flex items-center space-x-3">
          {/* Period Selection */}
          <div className="flex items-center space-x-1">
            {periods.map((period) => (
              <Button
                key={period.key}
                variant={selectedPeriod === period.key ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPeriod(period.key)}
                className="text-xs"
              >
                {period.label}
              </Button>
            ))}
          </div>

          {/* Action Buttons */}
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isLoading}
          >
            <RefreshCw className={`w-4 h-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleExport}
          >
            <Download className="w-4 h-4 mr-1" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Net Sales Report Chart */}
        <Card className="p-6">
          <SimpleChart 
            data={chartData}
            type="sales"
            title="Net Sales Report"
          />
        </Card>

        {/* Orders Report Chart */}
        <Card className="p-6">
          <SimpleChart 
            data={chartData}
            type="orders"
            title="Orders Report"
          />
        </Card>
      </div>

      {/* Additional Insights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
        <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">Growth Rate</p>
              <p className="text-lg font-bold text-blue-600 dark:text-blue-400">+0%</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">Conversion</p>
              <p className="text-lg font-bold text-green-600 dark:text-green-400">0%</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">Avg Order Value</p>
              <p className="text-lg font-bold text-purple-600 dark:text-purple-400">₹0</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
              <Filter className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">Return Rate</p>
              <p className="text-lg font-bold text-orange-600 dark:text-orange-400">0%</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}