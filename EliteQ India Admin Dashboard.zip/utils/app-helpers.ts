import { UserInfo, CurrentUser, ConnectionStatus, ConnectionInfo } from '../types/app-types';

export const getCurrentUser = (userInfo: UserInfo | null, userRole: 'administrator' | 'vendor'): CurrentUser => {
  if (userInfo) {
    return {
      name: userInfo.display_name || userInfo.username,
      email: userInfo.user_email,
      role: userInfo.user_type,
      avatar: userInfo.avatar_urls?.['96'] || null,
      isVendor: userInfo.user_type === 'vendor' || userInfo.vendor_data,
      isAdmin: userInfo.user_type === 'administrator',
      profileComplete: userInfo.profile_complete
    };
  }
  
  // Fallback for legacy mode
  return {
    name: userRole === 'administrator' ? 'EliteQ Administrator' : 'EliteQ Vendor',
    email: userRole === 'administrator' ? 'admin@eliteq.in' : 'vendor@eliteq.in',
    role: userRole,
    avatar: null,
    isVendor: userRole === 'vendor',
    isAdmin: userRole === 'administrator',
    profileComplete: true
  };
};

export const getModuleTitle = (activeModule: string, isAdmin: boolean): string => {
  switch (activeModule) {
    case 'dashboard':
      return isAdmin ? 'Live Admin Dashboard' : 'Live Vendor Dashboard';
    case 'products':
      return 'Live Product Management';
    case 'orders':
      return 'Live Order Management';
    case 'coupon':
      return 'Live Coupon Management';
    case 'reports':
      return 'Live Reports & Analytics';
    case 'delivery-time':
      return 'Live Delivery Time Management';
    case 'reviews':
      return 'Live Customer Reviews';
    case 'withdraw':
      return 'Live Withdraw Funds';
    case 'badge':
      return 'Live Store Badges';
    case 'product-qa':
      return 'Live Product Q&A';
    case 'return-request':
      return 'Live Return Requests';
    case 'staff':
      return 'Live Staff Management';
    case 'followers':
      return 'Live Store Followers';
    case 'announcements':
      return 'Live Announcements';
    case 'store-stats':
      return 'Live Store Statistics';
    case 'tools':
      return 'Live Administrative Tools';
    case 'settings':
      return 'Live Settings';
    case 'customers':
      return 'Live Customer Management';
    case 'vendors':
      return 'Live Vendor & KYC Management';
    case 'webhooks':
      return 'Live Webhook Logs';
    default:
      return 'Live Dashboard';
  }
};

export const getModuleDescription = (activeModule: string, isVendor: boolean): string => {
  if (isVendor) {
    switch (activeModule) {
      case 'dashboard':
        return 'Monitor your live store performance from EliteQ.in';
      case 'products':
        return 'Manage your live product listings and inventory';
      case 'orders':
        return 'Process your live store orders and customer requests';
      case 'reviews':
        return 'Manage live customer reviews and ratings';
      case 'withdraw':
        return 'Withdraw your live earnings to your bank account';
      default:
        return 'Manage your live EliteQ vendor store';
    }
  }
  
  switch (activeModule) {
    case 'dashboard':
      return 'Live overview of your WooCommerce multivendor marketplace at EliteQ.in';
    case 'products':
      return 'Manage all live products across your marketplace';
    case 'orders':
      return 'Monitor and manage all live marketplace orders';
    case 'customers':
      return 'Manage live customers, profiles, and customer data';
    case 'vendors':
      return 'Manage live Dokan vendors, KYC approval, and vendor status';
    case 'webhooks':
      return 'Monitor live webhook events and API integration logs';
    case 'settings':
      return 'Configure live marketplace settings and system preferences';
    default:
      return 'Live WordPress + WooCommerce + Dokan Pro management';
  }
};

export const getOverallConnectionStatus = (connectionStatus: ConnectionStatus, isConnecting: boolean): ConnectionInfo => {
  if (isConnecting) {
    return {
      color: 'bg-blue-400 animate-pulse',
      text: 'Connecting',
      description: 'Testing connection to EliteQ.in'
    };
  }
  
  if (connectionStatus.wordpress && connectionStatus.jwt) {
    if (connectionStatus.woocommercePermissions) {
      return {
        color: 'bg-green-400 animate-pulse',
        text: 'Live',
        description: 'Full access to EliteQ.in WordPress + WooCommerce'
      };
    } else {
      return {
        color: 'bg-orange-400 animate-pulse',
        text: 'Limited',
        description: 'WordPress connected, WooCommerce permissions needed'
      };
    }
  }
  
  return {
    color: 'bg-red-400',
    text: 'Error',
    description: 'Connection to EliteQ.in failed'
  };
};