import React from 'react';
import { 
  DollarSign, 
  ShoppingCart, 
  Package, 
  TrendingUp, 
  Users, 
  Eye, 
  Percent,
  Award,
  BarChart3,
  Zap
} from 'lucide-react';
import { Card } from './ui/card';

interface PerformanceMetric {
  title: string;
  value: string;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: React.ElementType;
  color: string;
  bgGradient: string;
  description: string;
}

interface EliteQPerformanceCardsProps {
  userRole: 'admin' | 'vendor';
}

export function EliteQPerformanceCards({ userRole }: EliteQPerformanceCardsProps) {
  const performanceMetrics: PerformanceMetric[] = [
    {
      title: 'Total Sales',
      value: '₹0.00',
      change: '+0.00%',
      changeType: 'neutral',
      icon: DollarSign,
      color: 'from-blue-500 to-blue-600',
      bgGradient: 'from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20',
      description: 'Gross sales amount'
    },
    {
      title: 'Marketplace Commission',
      value: 'N/A',
      change: 'N/A',
      changeType: 'neutral',
      icon: Percent,
      color: 'from-purple-500 to-purple-600',
      bgGradient: 'from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20',
      description: 'Commission paid to marketplace'
    },
    {
      title: 'Net Sales',
      value: '₹0.00',
      change: '+0.00%',
      changeType: 'neutral',
      icon: TrendingUp,
      color: 'from-green-500 to-green-600',
      bgGradient: 'from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20',
      description: 'Sales after commissions'
    },
    {
      title: 'Orders',
      value: '0',
      change: '+0.00%',
      changeType: 'neutral',
      icon: ShoppingCart,
      color: 'from-orange-500 to-orange-600',
      bgGradient: 'from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20',
      description: 'Total orders received'
    },
    {
      title: 'Products Sold',
      value: '0',
      change: '+0.00%',
      changeType: 'neutral',
      icon: Package,
      color: 'from-indigo-500 to-indigo-600',
      bgGradient: 'from-indigo-50 to-indigo-100 dark:from-indigo-900/20 dark:to-indigo-800/20',
      description: 'Individual units sold'
    },
    {
      title: 'Total Earning',
      value: 'N/A',
      change: 'N/A',
      changeType: 'neutral',
      icon: Award,
      color: 'from-yellow-500 to-yellow-600',
      bgGradient: 'from-yellow-50 to-yellow-100 dark:from-yellow-900/20 dark:to-yellow-800/20',
      description: 'Total earnings after fees'
    },
    {
      title: 'Marketplace Discount',
      value: 'N/A',
      change: 'N/A',
      changeType: 'neutral',
      icon: BarChart3,
      color: 'from-red-500 to-red-600',
      bgGradient: 'from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20',
      description: 'Discounts provided by marketplace'
    },
    {
      title: 'Store Discount',
      value: 'N/A',
      change: 'N/A',
      changeType: 'neutral',
      icon: Percent,
      color: 'from-pink-500 to-pink-600',
      bgGradient: 'from-pink-50 to-pink-100 dark:from-pink-900/20 dark:to-pink-800/20',
      description: 'Store-specific discounts offered'
    },
    {
      title: 'Variations Sold',
      value: '0',
      change: '+0.00%',
      changeType: 'neutral',
      icon: Zap,
      color: 'from-cyan-500 to-cyan-600',
      bgGradient: 'from-cyan-50 to-cyan-100 dark:from-cyan-900/20 dark:to-cyan-800/20',
      description: 'Product variations sold'
    },
    {
      title: 'Visitors',
      value: '1,721',
      change: '+12.5%',
      changeType: 'positive',
      icon: Users,
      color: 'from-teal-500 to-teal-600',
      bgGradient: 'from-teal-50 to-teal-100 dark:from-teal-900/20 dark:to-teal-800/20',
      description: 'Unique store visitors'
    },
    {
      title: 'Views',
      value: '2,859',
      change: '+8.7%',
      changeType: 'positive',
      icon: Eye,
      color: 'from-violet-500 to-violet-600',
      bgGradient: 'from-violet-50 to-violet-100 dark:from-violet-900/20 dark:to-violet-800/20',
      description: 'Total page views'
    }
  ];

  const getChangeColor = (changeType: 'positive' | 'negative' | 'neutral') => {
    switch (changeType) {
      case 'positive':
        return 'text-green-600 dark:text-green-400';
      case 'negative':
        return 'text-red-600 dark:text-red-400';
      default:
        return 'text-gray-500 dark:text-gray-400';
    }
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Performance Overview
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            Key metrics for your {userRole === 'admin' ? 'marketplace' : 'store'} performance
          </p>
        </div>
        <div className="text-sm text-gray-500 dark:text-gray-400">
          Updated: {new Date().toLocaleTimeString()}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {performanceMetrics.map((metric, index) => {
          const Icon = metric.icon;
          
          return (
            <Card 
              key={index}
              className={`
                relative overflow-hidden p-6 hover:shadow-lg transition-all duration-300 cursor-pointer
                bg-gradient-to-br ${metric.bgGradient}
                border border-gray-200 dark:border-gray-700
                hover:scale-105 hover:-translate-y-1
                group
              `}
            >
              {/* Background Pattern */}
              <div className="absolute top-0 right-0 w-20 h-20 opacity-10">
                <div className={`w-full h-full bg-gradient-to-br ${metric.color} rounded-full transform translate-x-6 -translate-y-6`}></div>
              </div>

              {/* Icon */}
              <div className={`
                inline-flex items-center justify-center w-12 h-12 rounded-xl
                bg-gradient-to-br ${metric.color}
                mb-4 shadow-lg
                group-hover:scale-110 transition-transform duration-300
              `}>
                <Icon className="w-6 h-6 text-white" />
              </div>

              {/* Content */}
              <div>
                <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">
                  {metric.title}
                </h3>
                
                <div className="flex items-baseline space-x-2 mb-2">
                  <span className="text-2xl font-bold text-gray-900 dark:text-white">
                    {metric.value}
                  </span>
                  {metric.change !== 'N/A' && (
                    <span className={`text-sm font-medium ${getChangeColor(metric.changeType)}`}>
                      {metric.change}
                    </span>
                  )}
                </div>

                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {metric.description}
                </p>
              </div>

              {/* Hover Effect Overlay */}
              <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}