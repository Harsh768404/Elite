// EliteQ India WooCommerce API Proxy
// Server-side proxy to bypass CORS restrictions

export async function woocommerceProxy(request: Request): Promise<Response> {
  console.log('🔄 WooCommerce Proxy: Processing request');

  // CORS headers for all responses
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, X-API-Key, X-Endpoint',
    'Access-Control-Max-Age': '86400',
  };

  // Handle preflight OPTIONS request
  if (request.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    // Extract endpoint and API key from headers
    const endpoint = request.headers.get('X-Endpoint');
    const apiKey = request.headers.get('X-API-Key');

    if (!endpoint) {
      return new Response(
        JSON.stringify({ 
          error: 'Missing X-Endpoint header',
          code: 'MISSING_ENDPOINT'
        }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    console.log(`📡 Proxying request to: ${endpoint}`);

    // EliteQ India WooCommerce credentials - Updated to latest
    const ELITEQ_STORE_URL = Deno.env.get('WORDPRESS_BASE_URL') || 'https://eliteq.in';
    const CONSUMER_KEY = Deno.env.get('WOOCOMMERCE_CONSUMER_KEY') || 'ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9';
    const CONSUMER_SECRET = Deno.env.get('WOOCOMMERCE_CONSUMER_SECRET') || 'cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3';

    // Build full URL
    const fullUrl = `${ELITEQ_STORE_URL}/wp-json/wc/v3${endpoint}`;
    
    // Create Basic Auth header
    const auth = btoa(`${CONSUMER_KEY}:${CONSUMER_SECRET}`);
    
    // Prepare request options
    const proxyRequestInit: RequestInit = {
      method: request.method,
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'EliteQ-Proxy/1.0',
        'Cache-Control': 'no-cache',
      },
    };

    // Add body for POST/PUT requests
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      try {
        const body = await request.text();
        if (body) {
          proxyRequestInit.body = body;
        }
      } catch (bodyError) {
        console.error('Error reading request body:', bodyError);
      }
    }

    console.log(`🔐 Making authenticated request to EliteQ India: ${fullUrl}`);
    
    // Make the request to WooCommerce API
    const wooResponse = await fetch(fullUrl, proxyRequestInit);
    
    console.log(`📊 EliteQ API Response: ${wooResponse.status} ${wooResponse.statusText}`);

    // Get response data
    let responseData;
    const contentType = wooResponse.headers.get('content-type');
    
    if (contentType && contentType.includes('application/json')) {
      responseData = await wooResponse.json();
    } else {
      responseData = await wooResponse.text();
    }

    // Return response with CORS headers
    return new Response(
      JSON.stringify({
        success: wooResponse.ok,
        status: wooResponse.status,
        statusText: wooResponse.statusText,
        data: responseData,
        timestamp: new Date().toISOString(),
        endpoint: endpoint,
        source: 'eliteq_woocommerce_proxy'
      }),
      {
        status: 200, // Always return 200 to frontend, actual status in response body
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
          'X-Proxy-Status': wooResponse.status.toString(),
          'X-Proxy-Source': 'eliteq-woocommerce',
        },
      }
    );

  } catch (error) {
    console.error('❌ WooCommerce Proxy Error:', error);
    
    const errorMessage = error instanceof Error ? error.message : 'Unknown proxy error';
    
    return new Response(
      JSON.stringify({
        success: false,
        error: errorMessage,
        code: 'PROXY_ERROR',
        timestamp: new Date().toISOString(),
        source: 'eliteq_woocommerce_proxy'
      }),
      {
        status: 200, // Return 200 with error details in body
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
          'X-Proxy-Error': 'true',
        },
      }
    );
  }
}

// Health check endpoint
export async function woocommerceHealthCheck(): Promise<Response> {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  try {
    console.log('🏥 Performing WooCommerce health check...');
    
    const ELITEQ_STORE_URL = Deno.env.get('WORDPRESS_BASE_URL') || 'https://eliteq.in';
    const CONSUMER_KEY = Deno.env.get('WOOCOMMERCE_CONSUMER_KEY') || 'ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9';
    const CONSUMER_SECRET = Deno.env.get('WOOCOMMERCE_CONSUMER_SECRET') || 'cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3';
    
    const auth = btoa(`${CONSUMER_KEY}:${CONSUMER_SECRET}`);
    
    // Test connection with a simple endpoint
    const testUrl = `${ELITEQ_STORE_URL}/wp-json/wc/v3/system_status`;
    
    const response = await fetch(testUrl, {
      method: 'GET',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'EliteQ-HealthCheck/1.0',
      },
    });

    const isHealthy = response.ok;
    let healthData = null;
    
    try {
      healthData = await response.json();
    } catch (parseError) {
      console.warn('Could not parse health check response:', parseError);
    }

    return new Response(
      JSON.stringify({
        healthy: isHealthy,
        status: response.status,
        statusText: response.statusText,
        store: 'EliteQ India',
        url: ELITEQ_STORE_URL,
        timestamp: new Date().toISOString(),
        proxy: {
          available: true,
          version: '1.0',
          cors: 'enabled'
        },
        data: healthData
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );

  } catch (error) {
    console.error('❌ Health check failed:', error);
    
    return new Response(
      JSON.stringify({
        healthy: false,
        error: error instanceof Error ? error.message : 'Health check failed',
        store: 'EliteQ India',
        timestamp: new Date().toISOString(),
        proxy: {
          available: true,
          version: '1.0',
          cors: 'enabled'
        }
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
}