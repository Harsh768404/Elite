import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { 
  ShieldAlert, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  RefreshCw, 
  ShoppingCart,
  Users,
  Package,
  BarChart3,
  Settings,
  ExternalLink
} from 'lucide-react';
import { apiService } from '../utils/comprehensive-api-service';

interface WooCommercePermissionStatus {
  hasWooCommerceAccess: boolean;
  canViewOrders: boolean;
  canViewProducts: boolean;
  canViewReports: boolean;
  canManageCustomers: boolean;
  permissions: {
    canListProducts: boolean;
    canListOrders: boolean;
    canListUsers: boolean;
    canViewReports: boolean;
    canListCustomers: boolean;
  };
  woocommerceIssues: string[];
  userInfo: {
    roles: string[];
    primaryRole: string;
    capabilities: string[];
  };
}

export const WooCommercePermissionHelper: React.FC = () => {
  const [permissionStatus, setPermissionStatus] = useState<WooCommercePermissionStatus | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const checkPermissions = async () => {
    setIsLoading(true);
    try {
      console.log('🛒 Checking WooCommerce permissions...');
      
      // Get comprehensive health check
      const healthCheck = await apiService.healthCheck();
      
      const status: WooCommercePermissionStatus = {
        hasWooCommerceAccess: healthCheck.woocommerceCapabilities?.hasWooCommerceAccess || false,
        canViewOrders: healthCheck.woocommerceCapabilities?.canViewOrders || false,
        canViewProducts: healthCheck.woocommerceCapabilities?.canViewProducts || false,
        canViewReports: healthCheck.woocommerceCapabilities?.canViewReports || false,
        canManageCustomers: healthCheck.woocommerceCapabilities?.canManageCustomers || false,
        permissions: healthCheck.permissions,
        woocommerceIssues: healthCheck.woocommerceIssues || [],
        userInfo: healthCheck.userInfo
      };
      
      setPermissionStatus(status);
      setLastUpdated(new Date());
      console.log('✅ WooCommerce permissions checked successfully');
    } catch (error) {
      console.error('❌ Failed to check WooCommerce permissions:', error);
      setPermissionStatus({
        hasWooCommerceAccess: false,
        canViewOrders: false,
        canViewProducts: false,
        canViewReports: false,
        canManageCustomers: false,
        permissions: {
          canListProducts: false,
          canListOrders: false,
          canListUsers: false,
          canViewReports: false,
          canListCustomers: false
        },
        woocommerceIssues: [error instanceof Error ? error.message : 'Unknown error'],
        userInfo: {
          roles: [],
          primaryRole: 'unknown',
          capabilities: []
        }
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkPermissions();
  }, []);

  const getPermissionIcon = (hasPermission: boolean) => {
    return hasPermission ? (
      <CheckCircle className="w-4 h-4 text-green-600" />
    ) : (
      <XCircle className="w-4 h-4 text-red-600" />
    );
  };

  const getPermissionBadge = (hasPermission: boolean) => {
    return (
      <Badge variant={hasPermission ? 'default' : 'destructive'}>
        {hasPermission ? 'Allowed' : 'Denied'}
      </Badge>
    );
  };

  const getRoleRecommendations = (primaryRole: string, roles: string[]) => {
    const recommendations: string[] = [];
    
    if (roles.includes('administrator')) {
      recommendations.push('You are an administrator but may need WooCommerce permissions configured');
      recommendations.push('Check WooCommerce → Settings → Advanced → REST API permissions');
    } else if (roles.includes('shop_manager')) {
      recommendations.push('Shop managers should have most WooCommerce permissions');
      recommendations.push('Some restrictions may be intentional for security');
    } else if (roles.includes('vendor') || roles.includes('seller')) {
      recommendations.push('Vendors typically have limited WooCommerce access');
      recommendations.push('You may only see your own products and orders');
    } else {
      recommendations.push('Your WordPress role may not include WooCommerce permissions');
      recommendations.push('Contact your administrator to grant proper WooCommerce access');
    }
    
    return recommendations;
  };

  const getFixInstructions = () => {
    const instructions: Array<{ title: string; steps: string[] }> = [];
    
    instructions.push({
      title: 'For WordPress Administrators',
      steps: [
        'Go to WordPress Admin → Users → All Users',
        'Edit the user account that needs WooCommerce access',
        'Ensure the user has "Administrator" or "Shop Manager" role',
        'Check WooCommerce → Settings → Advanced → REST API',
        'Verify consumer key/secret have proper permissions'
      ]
    });
    
    instructions.push({
      title: 'For WooCommerce Settings',
      steps: [
        'Go to WooCommerce → Settings → Advanced → REST API',
        'Check existing API keys or create new ones',
        'Ensure permissions are set to "Read/Write" for full access',
        'Verify the consumer key matches what\'s configured in the app'
      ]
    });
    
    instructions.push({
      title: 'For Dokan Vendors',
      steps: [
        'Vendors have limited access by design',
        'Contact store administrator if you need additional permissions',
        'Some endpoints are restricted to prevent data access conflicts',
        'Use vendor-specific endpoints when available'
      ]
    });
    
    return instructions;
  };

  if (!permissionStatus && !isLoading) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-orange-500" />
            WooCommerce Permission Helper
          </CardTitle>
          <CardDescription>
            Failed to load permission information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={checkPermissions} className="w-full">
            <RefreshCw className="w-4 h-4 mr-2" />
            Check Permissions
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                🛒 WooCommerce Permission Helper
              </CardTitle>
              <CardDescription>
                Diagnose and resolve WooCommerce API permission issues
                {lastUpdated && (
                  <span className="block text-xs text-gray-500 mt-1">
                    Last checked: {lastUpdated.toLocaleTimeString()}
                  </span>
                )}
              </CardDescription>
            </div>
            <Button
              onClick={checkPermissions}
              disabled={isLoading}
              size="sm"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Check Permissions
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Permission Overview */}
      {permissionStatus && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              🎭 Your Access Level
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Primary Role
                </label>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline">
                    {permissionStatus.userInfo.primaryRole}
                  </Badge>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  All Roles
                </label>
                <div className="flex flex-wrap gap-1 mt-1">
                  {permissionStatus.userInfo.roles.map((role, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {role}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  WooCommerce Access
                </label>
                <div className="flex items-center gap-2 mt-1">
                  {getPermissionIcon(permissionStatus.hasWooCommerceAccess)}
                  {getPermissionBadge(permissionStatus.hasWooCommerceAccess)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Permission Details */}
      {permissionStatus && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              🔐 Detailed Permissions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-2">
                  <Package className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium">Products</span>
                </div>
                <div className="flex items-center gap-2">
                  {getPermissionIcon(permissionStatus.permissions.canListProducts)}
                  {getPermissionBadge(permissionStatus.permissions.canListProducts)}
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-medium">Orders</span>
                </div>
                <div className="flex items-center gap-2">
                  {getPermissionIcon(permissionStatus.permissions.canListOrders)}
                  {getPermissionBadge(permissionStatus.permissions.canListOrders)}
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium">Customers</span>
                </div>
                <div className="flex items-center gap-2">
                  {getPermissionIcon(permissionStatus.permissions.canListCustomers)}
                  {getPermissionBadge(permissionStatus.permissions.canListCustomers)}
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-orange-600" />
                  <span className="text-sm font-medium">Reports</span>
                </div>
                <div className="flex items-center gap-2">
                  {getPermissionIcon(permissionStatus.permissions.canViewReports)}
                  {getPermissionBadge(permissionStatus.permissions.canViewReports)}
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-gray-600" />
                  <span className="text-sm font-medium">Users</span>
                </div>
                <div className="flex items-center gap-2">
                  {getPermissionIcon(permissionStatus.permissions.canListUsers)}
                  {getPermissionBadge(permissionStatus.permissions.canListUsers)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Issues and Recommendations */}
      {permissionStatus && permissionStatus.woocommerceIssues.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              ⚠️ Detected Issues
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {permissionStatus.woocommerceIssues.map((issue, index) => (
              <Alert key={index} variant="destructive">
                <AlertTriangle className="w-4 h-4" />
                <AlertDescription>
                  {issue}
                </AlertDescription>
              </Alert>
            ))}
            
            <Separator />
            
            <div>
              <h4 className="font-medium mb-2">Recommendations for your role:</h4>
              <div className="space-y-1">
                {getRoleRecommendations(
                  permissionStatus.userInfo.primaryRole, 
                  permissionStatus.userInfo.roles
                ).map((rec, index) => (
                  <div key={index} className="text-sm text-blue-600 dark:text-blue-400">
                    • {rec}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Fix Instructions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            🔧 How to Fix Permission Issues
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {getFixInstructions().map((section, index) => (
            <div key={index} className="space-y-3">
              <h4 className="font-medium text-lg">{section.title}</h4>
              <ol className="space-y-2">
                {section.steps.map((step, stepIndex) => (
                  <li key={stepIndex} className="text-sm flex items-start gap-2">
                    <span className="flex-shrink-0 w-5 h-5 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-full flex items-center justify-center text-xs font-medium">
                      {stepIndex + 1}
                    </span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
              {index < getFixInstructions().length - 1 && <Separator />}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Quick Links */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            🔗 Quick Links
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button variant="outline" className="justify-start" asChild>
              <a href="https://eliteq.in/wp-admin/admin.php?page=wc-settings&tab=advanced&section=rest_api" target="_blank" rel="noopener noreferrer">
                <Settings className="w-4 h-4 mr-2" />
                WooCommerce REST API Settings
                <ExternalLink className="w-3 h-3 ml-auto" />
              </a>
            </Button>
            
            <Button variant="outline" className="justify-start" asChild>
              <a href="https://eliteq.in/wp-admin/users.php" target="_blank" rel="noopener noreferrer">
                <Users className="w-4 h-4 mr-2" />
                WordPress User Management
                <ExternalLink className="w-3 h-3 ml-auto" />
              </a>
            </Button>
            
            <Button variant="outline" className="justify-start" asChild>
              <a href="https://eliteq.in/wp-admin/admin.php?page=dokan" target="_blank" rel="noopener noreferrer">
                <ShoppingCart className="w-4 h-4 mr-2" />
                Dokan Settings
                <ExternalLink className="w-3 h-3 ml-auto" />
              </a>
            </Button>
            
            <Button variant="outline" className="justify-start" asChild>
              <a href="https://eliteq.in/wp-admin/admin.php?page=wc-settings" target="_blank" rel="noopener noreferrer">
                <Settings className="w-4 h-4 mr-2" />
                WooCommerce General Settings
                <ExternalLink className="w-3 h-3 ml-auto" />
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default WooCommercePermissionHelper;