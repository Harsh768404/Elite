import React, { useEffect } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import AppRouter from './components/AppRouter';
import { envHelpers } from './utils/env-config';
import EnvironmentInitializer from './components/EnvironmentInitializer';
import { backgroundDataSync } from './utils/api-integration-manager';
import { ModernEliteQDashboard } from './components/ModernEliteQDashboard';
import { gracefulErrorHandler, suppressConsoleErrors } from './utils/graceful-error-handler';
import { initializeNetworkErrorSuppression } from './utils/network-error-interceptor';

// Main App component with real EliteQ.in WordPress integration
// Initialize graceful error handling immediately
suppressConsoleErrors(true);
initializeNetworkErrorSuppression();

export default function App() {
  console.log('🚀 ===== ELITEQ APP STARTING WITH REAL WORDPRESS INTEGRATION =====');
  console.log('📦 Auth Provider: Enabled with real EliteQ.in authentication');
  console.log('🧭 Router: Professional role-based routing with URL handling');
  console.log('🔐 Auth Source: Real JWT tokens from EliteQ.in WordPress');
  console.log('🎭 Supported Roles: administrator | vendor (dokan_vendor, vendor, seller, shop_manager)');
  console.log('🌐 URL Routing: Enabled with 404 handling');
  console.log('🔗 API Integration: Live EliteQ.in WordPress/WooCommerce endpoints with increased timeouts');
  console.log('📊 Data Management: Real data caching and background sync');
  console.log('🎨 Modern Dashboard: Professional interface with real EliteQ data');
  console.log('🔇 Graceful error handling enabled - network errors suppressed');
  console.log('🔧 FIXED: Administrator role mapping corrected (admin → administrator)');
  
  // Initialize environment configuration with real EliteQ credentials
  try {
    // Explicitly set real EliteQ environment variables for browser access
    if (typeof window !== 'undefined') {
      if (!(window as any).ENV) {
        (window as any).ENV = {};
      }
      
      // Set real EliteQ.in credentials
      (window as any).ENV.WORDPRESS_BASE_URL = 'https://eliteq.in';
      (window as any).ENV.WOOCOMMERCE_CONSUMER_KEY = 'ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9';
      (window as any).ENV.WOOCOMMERCE_CONSUMER_SECRET = 'cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3';
      (window as any).ENV.JWT_AUTH_SECRET_KEY = '9=<QX7=<(iLPhXh[G21AjCh#x-{%z)jA;FK]bRFpQT4jx?x+3l${m,IGCcVx&}Hm';
      
      // Webhook configuration
      (window as any).ENV.WEBHOOK_URL = 'https://eliteq.in/?wpwhpro_action=main_9798&wpwhpro_api_key=w7mcvsqva35rns5bchiwnn4alrcg4jymowrmcox99kyg3n1zxwvsjuxix7ikrsdw';
      (window as any).ENV.WEBHOOK_API_KEY = 'w7mcvsqva35rns5bchiwnn4alrcg4jymowrmcox99kyg3n1zxwvsjuxix7ikrsdw';
      
      // Primary webhook secrets
      (window as any).ENV.WEBHOOK_SECRET_PRODUCT_CREATED = 'Du83&G.64ti/5a#plclUwhF;WIjsQEHy_>hdFQ-/pv/CLJ$s#0';
      (window as any).ENV.WEBHOOK_SECRET_ORDER_CREATED = '^Yzssk4<*N~P,mR8kfQ}fjQ-|VX-d>g/ICNY2W&MA/8o$Cy;3b';
      (window as any).ENV.WEBHOOK_SECRET_CUSTOMER_CREATED = 'A-%`*8U-t*9)8[lEm**/Xu#1N|ArGL*#^sS?Q!d`qbJHGMO[(w';
      
      // Database credentials (for reference, not used in frontend)
      (window as any).ENV.DB_NAME = 'u486691522_TeviK';
      (window as any).ENV.DB_USER = 'u486691522_laGJZ';
      (window as any).ENV.DB_HOST = '127.0.0.1';
      
      // Set aliases for compatibility
      (window as any).ENV.CONSUMER_KEY = (window as any).ENV.WOOCOMMERCE_CONSUMER_KEY;
      (window as any).ENV.CONSUMER_SECRET = (window as any).ENV.WOOCOMMERCE_CONSUMER_SECRET;
      
      console.log('🔧 Real EliteQ.in credentials configured in window.ENV');
      console.log('🌐 WordPress URL:', (window as any).ENV.WORDPRESS_BASE_URL);
      console.log('🔑 WooCommerce Consumer Key:', (window as any).ENV.WOOCOMMERCE_CONSUMER_KEY.substring(0, 10) + '...');
      console.log('🔐 WooCommerce Consumer Secret:', (window as any).ENV.WOOCOMMERCE_CONSUMER_SECRET.substring(0, 10) + '...');
      console.log('🎯 JWT Secret configured for real authentication');
      console.log('🪝 Webhook URL configured for real-time updates');
    }
    
    envHelpers.initializeWindowEnv();
    envHelpers.logEnvStatus();
  } catch (error) {
    console.error('⚠️ Environment initialization warning:', error);
    // Continue execution - this is not critical for app functionality
  }

  // Test real connection to EliteQ.in on app start
  useEffect(() => {
    const testRealConnection = async () => {
      try {
        console.log('🧪 Testing real connection to EliteQ.in...');
        
        // Test basic WordPress connection
        const wpResponse = await fetch('https://eliteq.in/wp-json/', {
          method: 'GET',
          headers: {
            'User-Agent': 'EliteQ-Admin-Panel/1.0',
          }
        });
        
        if (wpResponse.ok) {
          const wpData = await wpResponse.json();
          console.log('✅ WordPress connection successful:', wpData.name || 'EliteQ India');
          console.log('📝 WordPress description:', wpData.description || 'Electronics Marketplace');
          console.log('🔗 Site URL:', wpData.url || 'https://eliteq.in');
        }
        
        // Test WooCommerce connection with consumer key
        const wcUrl = `https://eliteq.in/wp-json/wc/v3/?consumer_key=ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9&consumer_secret=cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3`;
        const wcResponse = await fetch(wcUrl, {
          method: 'GET',
          headers: {
            'User-Agent': 'EliteQ-Admin-Panel/1.0',
          }
        });
        
        if (wcResponse.ok) {
          const wcData = await wcResponse.json();
          console.log('✅ WooCommerce API connection successful');
          console.log('🛍️ Available WooCommerce endpoints:', Object.keys(wcData.routes || {}).length);
        }
        
        // Test if we can fetch real products
        const productsUrl = `https://eliteq.in/wp-json/wc/v3/products?per_page=1&consumer_key=ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9&consumer_secret=cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3`;
        const productsResponse = await fetch(productsUrl, {
          method: 'GET',
          headers: {
            'User-Agent': 'EliteQ-Admin-Panel/1.0',
          }
        });
        
        if (productsResponse.ok) {
          const products = await productsResponse.json();
          console.log('✅ Real products fetched successfully:', products.length, 'items');
          if (products.length > 0) {
            console.log('📦 Sample product:', products[0].name || 'Unnamed Product');
          }
        }
        
      } catch (error) {
        console.warn('⚠️ Real connection test failed:', (error as Error)?.message || 'Unknown error');
        console.log('🔄 This is normal if the site is temporarily unavailable');
      }
    };

    // Test connection after a short delay
    setTimeout(testRealConnection, 2000);
  }, []);

  // Initialize background data synchronization with real EliteQ data
  useEffect(() => {
    console.log('🔄 Initializing real data synchronization with EliteQ.in...');
    
    let syncStarted = false;
    let retryCount = 0;
    const maxRetries = 3;
    
    const startSyncWithRetry = async () => {
      try {
        // Check if backgroundDataSync is available and has required methods
        if (!backgroundDataSync) {
          throw new Error('Background data sync service not available');
        }
        
        if (typeof backgroundDataSync.start !== 'function') {
          throw new Error('Background data sync service missing start method');
        }
        
        // Start the sync
        await backgroundDataSync.start();
        syncStarted = true;
        console.log('✅ Real data background sync started successfully');
        console.log('📊 Now syncing with live EliteQ.in WordPress data');
        
        // Reset retry count on success
        retryCount = 0;
        
      } catch (error) {
        retryCount++;
        console.warn(`⚠️ Real data sync attempt ${retryCount} failed:`, (error as Error)?.message || 'Unknown error');
        
        if (retryCount < maxRetries) {
          // Retry with exponential backoff
          const retryDelay = Math.pow(2, retryCount) * 2000; // 2s, 4s, 8s
          console.log(`🔄 Retrying real data sync in ${retryDelay/1000}s...`);
          setTimeout(startSyncWithRetry, retryDelay);
        } else {
          console.error('❌ Real data sync failed after maximum retries. Using cached data when available.');
        }
      }
    };

    // Start sync after app loads with initial delay
    const syncTimeout = setTimeout(() => {
      if (!syncStarted) {
        startSyncWithRetry();
      }
    }, 4000); // Longer delay for real API connections

    // Cleanup function
    return () => {
      clearTimeout(syncTimeout);
      
      if (syncStarted) {
        try {
          if (backgroundDataSync && typeof backgroundDataSync.stop === 'function') {
            backgroundDataSync.stop();
            console.log('🛑 Real data background sync stopped');
          }
        } catch (error) {
          console.warn('⚠️ Error stopping real data sync:', (error as Error)?.message || 'Unknown error');
        }
      }
    };
  }, []);

  // Update document title based on current route
  useEffect(() => {
    const updateTitle = () => {
      try {
        const getPageTitle = (path: string): string => {
          const titles: { [key: string]: string } = {
            '/admin-dashboard': 'EliteQ India - Admin Dashboard',
            '/admin': 'EliteQ India - Admin Dashboard',
            '/vendor-dashboard': 'EliteQ India - Vendor Dashboard', 
            '/vendor': 'EliteQ India - Vendor Dashboard',
            '/account-dashboard': 'EliteQ India - Account Dashboard',
            '/dashboard': 'EliteQ India - Account Dashboard',
            '/': 'EliteQ India - WordPress Login'
          };

          return titles[path] || 'EliteQ India - WordPress Electronics Marketplace';
        };
        
        const title = getPageTitle(window.location.pathname);
        document.title = title;
        console.log('📄 Document title updated:', title);
      } catch (error) {
        console.warn('⚠️ Failed to update document title:', error);
        document.title = 'EliteQ India - WordPress Electronics Marketplace';
      }
    };

    updateTitle();

    const handleLocationChange = () => {
      updateTitle();
    };

    window.addEventListener('popstate', handleLocationChange);

    const originalPushState = window.history.pushState;
    const originalReplaceState = window.history.replaceState;

    window.history.pushState = function(...args) {
      originalPushState.apply(window.history, args);
      handleLocationChange();
    };

    window.history.replaceState = function(...args) {
      originalReplaceState.apply(window.history, args);
      handleLocationChange();
    };

    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.history.pushState = originalPushState;
      window.history.replaceState = originalReplaceState;
    };
  }, []);

  // Initialize graceful error handling system
  useEffect(() => {
    suppressConsoleErrors(true);
    
    console.log('✅ Graceful error handling initialized for real API calls');
    console.log('🔇 Network and API errors will be suppressed to reduce console noise');
    console.log('📊 Error statistics available via gracefulErrorHandler.getErrorSummary()');
    
    return () => {
      suppressConsoleErrors(false);
    };
  }, []);

  // Performance monitoring
  useEffect(() => {
    const logPerformance = () => {
      try {
        // Use modern Navigation Timing API with fallback
        if ('performance' in window) {
          // Modern approach using PerformanceNavigationTiming
          const perfData = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
          if (perfData) {
            const loadTime = perfData.loadEventEnd - perfData.fetchStart;
            if (loadTime > 0) {
              console.log(`⚡ EliteQ Admin Panel loaded in ${Math.round(loadTime)}ms`);
            }
          } else if (performance.timing) {
            // Fallback to legacy timing API
            const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
            if (loadTime > 0) {
              console.log(`⚡ EliteQ Admin Panel loaded in ${loadTime}ms`);
            }
          }
          
          // Memory usage (if available)
          if ((performance as any).memory) {
            const memoryMB = Math.round((performance as any).memory.usedJSHeapSize / 1024 / 1024);
            console.log(`💾 Memory usage: ${memoryMB}MB used`);
          }
          
          // Navigation type with modern approach
          if (perfData && 'type' in perfData) {
            const navTypes = ['navigate', 'reload', 'back_forward', 'prerender'];
            console.log(`🧭 Navigation type: ${navTypes[perfData.type] || 'Unknown'}`);
          } else if (performance.navigation) {
            // Fallback to legacy navigation API
            const navType = performance.navigation.type;
            const navTypes = ['Navigate', 'Reload', 'Back/Forward', 'Reserved'];
            console.log(`🧭 Navigation type: ${navTypes[navType] || 'Unknown'}`);
          }
        }
      } catch (error) {
        console.warn('⚠️ Performance monitoring error:', (error as Error)?.message || 'Unknown error');
      }
    };

    setTimeout(logPerformance, 1000);
  }, []);

  // Add global app state and real data utilities
  useEffect(() => {
    // Set global app ready flag
    if (typeof window !== 'undefined') {
      (window as any).ELITEQ_APP_READY = true;
      (window as any).ELITEQ_APP_VERSION = '1.0.0';
      (window as any).ELITEQ_MODERN_DASHBOARD = true;
      (window as any).ELITEQ_REAL_DATA = true;
      (window as any).ELITEQ_SITE_URL = 'https://eliteq.in';
    }

    // Recovery function for common issues
    (window as any).recoverEliteQApp = () => {
      console.log('🔧 Attempting EliteQ app recovery...');
      try {
        // Clear potentially corrupted data
        const keysToCheck = [
          'eliteq_jwt_token',
          'eliteq_user_roles',
          'eliteq_primary_role',
          'eliteq_dashboard_route',
          'eliteq_user_data'
        ];
        
        keysToCheck.forEach(key => {
          try {
            const value = localStorage.getItem(key);
            if (value && key !== 'eliteq_dashboard_route') {
              JSON.parse(value); // Test if valid JSON
            }
          } catch {
            console.warn(`🔧 Removing corrupted storage key: ${key}`);
            localStorage.removeItem(key);
          }
        });
        
        // Reload page
        window.location.reload();
      } catch (error) {
        console.error('❌ Recovery failed:', error);
      }
    };

    // Test real API connection function
    (window as any).testEliteQConnection = async () => {
      console.log('🧪 Testing EliteQ.in connection...');
      try {
        // Test WordPress API
        const wpResponse = await fetch('https://eliteq.in/wp-json/');
        const wpData = await wpResponse.json();
        console.log('✅ WordPress API:', wpData.name);
        
        // Test WooCommerce API
        const wcUrl = `https://eliteq.in/wp-json/wc/v3/?consumer_key=ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9&consumer_secret=cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3`;
        const wcResponse = await fetch(wcUrl);
        const wcData = await wcResponse.json();
        console.log('✅ WooCommerce API:', Object.keys(wcData.routes || {}).length, 'endpoints');
        
        return { wordpress: true, woocommerce: true };
      } catch (error) {
        console.error('❌ Connection test failed:', error);
        return { wordpress: false, woocommerce: false, error: (error as Error)?.message || 'Unknown error' };
      }
    };

    // Demo function to quickly test modern dashboard with real data
    (window as any).showModernDashboard = (role = 'admin') => {
      console.log(`🎨 Displaying modern dashboard for role: ${role} with real EliteQ data`);
    };

    // Real data utilities
    (window as any).fetchRealEliteQData = async (type = 'products', limit = 5) => {
      const baseUrl = 'https://eliteq.in/wp-json/wc/v3/';
      const auth = 'consumer_key=ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9&consumer_secret=cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3';
      
      try {
        const response = await fetch(`${baseUrl}${type}?per_page=${limit}&${auth}`);
        const data = await response.json();
        console.log(`📊 Real ${type} data from EliteQ:`, data);
        return data;
      } catch (error) {
        console.error(`❌ Failed to fetch real ${type}:`, error);
        return null;
      }
    };

    // Background sync management functions for real data
    (window as any).resetBackgroundSync = () => {
      console.log('🔄 Resetting real data background sync...');
      try {
        if (backgroundDataSync && backgroundDataSync.reset) {
          backgroundDataSync.reset();
          console.log('✅ Real data background sync reset successful');
        }
      } catch (error) {
        console.error('❌ Real data background sync reset failed:', error);
      }
    };

    (window as any).getBackgroundSyncStats = async () => {
      try {
        if (backgroundDataSync && backgroundDataSync.getStats) {
          const stats = await backgroundDataSync.getStats();
          console.log('📊 Real data background sync stats:', stats);
          return stats;
        }
      } catch (error) {
        console.error('❌ Failed to get real data sync stats:', error);
      }
    };

    console.log('✅ EliteQ App initialization complete with real data integration');
    console.log('🔧 Recovery function available as window.recoverEliteQApp()');
    console.log('🧪 Connection test available as window.testEliteQConnection()');
    console.log('📊 Real data fetch available as window.fetchRealEliteQData(type, limit)');
    console.log('🎨 Modern dashboard demo available as window.showModernDashboard()');
    console.log('🔄 Background sync utilities: window.resetBackgroundSync(), window.getBackgroundSyncStats()');
    
    return () => {
      if (typeof window !== 'undefined') {
        delete (window as any).ELITEQ_APP_READY;
        delete (window as any).ELITEQ_APP_VERSION;
        delete (window as any).ELITEQ_MODERN_DASHBOARD;
        delete (window as any).ELITEQ_REAL_DATA;
        delete (window as any).ELITEQ_SITE_URL;
        delete (window as any).recoverEliteQApp;
        delete (window as any).testEliteQConnection;
        delete (window as any).showModernDashboard;
        delete (window as any).fetchRealEliteQData;
        delete (window as any).resetBackgroundSync;
        delete (window as any).getBackgroundSyncStats;
      }
    };
  }, []);

  // Check if we should show the modern dashboard directly (for demo purposes)
  const showDemoMode = window.location.search.includes('demo=modern');
  if (showDemoMode) {
    const role = new URLSearchParams(window.location.search).get('role') as 'admin' | 'vendor' || 'admin';
    return <ModernEliteQDashboard userRole={role} />;
  }

  return (
    <AuthProvider>
      <div className="app" id="eliteq-app-root">
        <EnvironmentInitializer />
        <AppRouter />
      </div>
    </AuthProvider>
  );
}