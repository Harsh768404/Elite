import React, { useState, useEffect } from 'react';
import { 
  Users, Search, Filter, MoreHorizontal, Eye, CheckCircle,
  XCircle, AlertTriangle, Clock, FileText, Download, Upload,
  Store, Mail, Phone, MapPin, Calendar, DollarSign, 
  CreditCard, User, Shield, Award, Ban, Star, RefreshCw,
  Trash2, UserCheck, UserX, ExternalLink
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from './ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from './ui/alert-dialog';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner@2.0.3';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Separator } from './ui/separator';
import { Alert, AlertDescription } from './ui/alert';

interface VendorKYCModuleProps {
  jwtToken: string | null;
}

interface Vendor {
  id: number;
  store_name: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  address: {
    street_1: string;
    street_2: string;
    city: string;
    zip: string;
    country: string;
    state: string;
  };
  banner: string;
  gravatar: string;
  shop_url: string;
  products_per_page: number;
  show_more_product_tab: boolean;
  toc_enabled: boolean;
  store_toc: string;
  featured: boolean;
  rating: {
    rating: number;
    count: number;
  };
  enabled: boolean;
  registered: string;
  last_login: string;
  kyc_status: 'pending' | 'approved' | 'rejected' | 'incomplete';
  kyc_documents: {
    aadhaar_card: { status: 'pending' | 'approved' | 'rejected'; url?: string; };
    pan_card: { status: 'pending' | 'approved' | 'rejected'; url?: string; };
    bank_statement: { status: 'pending' | 'approved' | 'rejected'; url?: string; };
    gst_certificate: { status: 'pending' | 'approved' | 'rejected'; url?: string; };
    udyam_aadhar: { status: 'pending' | 'approved' | 'rejected'; url?: string; };
  };
  store_stats: {
    total_products: number;
    total_orders: number;
    total_sales: number;
    commission_rate: string;
    pending_withdrawal: number;
  };
}

export const VendorKYCModule: React.FC<VendorKYCModuleProps> = ({ jwtToken }) => {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [kycStatusFilter, setKycStatusFilter] = useState('all');
  const [storeStatusFilter, setStoreStatusFilter] = useState('all');
  const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);
  const [selectedVendors, setSelectedVendors] = useState<number[]>([]);
  const [bulkActionInProgress, setBulkActionInProgress] = useState(false);
  const [bulkActionType, setBulkActionType] = useState<string>('');
  const [bulkProgressPercent, setBulkProgressPercent] = useState(0);
  const [showBulkConfirmDialog, setShowBulkConfirmDialog] = useState(false);
  const [pendingBulkAction, setPendingBulkAction] = useState<{action: string, count: number} | null>(null);

  // Mock Dokan vendors data
  const fetchVendors = async () => {
    setIsLoading(true);
    
    try {
      // Simulate Dokan API call: GET /wp-json/dokan/v1/stores
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockVendors: Vendor[] = [
        {
          id: 1,
          store_name: 'EliteQ Electronics',
          first_name: 'Rajesh',
          last_name: 'Kumar',
          email: 'electronics@eliteq.in',
          phone: '+91 98765 43210',
          address: {
            street_1: '123 Electronics Market',
            street_2: 'Nehru Place',
            city: 'New Delhi',
            zip: '110019',
            country: 'IN',
            state: 'Delhi'
          },
          banner: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800',
          gravatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
          shop_url: 'https://eliteq.in/store/electronics',
          products_per_page: 20,
          show_more_product_tab: true,
          toc_enabled: true,
          store_toc: 'Terms and conditions...',
          featured: true,
          rating: { rating: 4.8, count: 124 },
          enabled: true,
          registered: '2024-01-15T10:30:00',
          last_login: '2024-01-20T14:20:00',
          kyc_status: 'approved',
          kyc_documents: {
            aadhaar_card: { status: 'approved', url: '/docs/aadhaar.pdf' },
            pan_card: { status: 'approved', url: '/docs/pan.pdf' },
            bank_statement: { status: 'approved', url: '/docs/bank.pdf' },
            gst_certificate: { status: 'approved', url: '/docs/gst.pdf' },
            udyam_aadhar: { status: 'approved', url: '/docs/udyam.pdf' }
          },
          store_stats: {
            total_products: 45,
            total_orders: 234,
            total_sales: 567890,
            commission_rate: '15%',
            pending_withdrawal: 45000
          }
        },
        {
          id: 2,
          store_name: 'Fashion World',
          first_name: 'Priya',
          last_name: 'Sharma',
          email: 'fashion@example.com',
          phone: '+91 87654 32109',
          address: {
            street_1: '456 Fashion Street',
            street_2: 'Commercial Complex',
            city: 'Mumbai',
            zip: '400001',
            country: 'IN',
            state: 'Maharashtra'
          },
          banner: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800',
          gravatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
          shop_url: 'https://eliteq.in/store/fashion',
          products_per_page: 15,
          show_more_product_tab: true,
          toc_enabled: false,
          store_toc: '',
          featured: false,
          rating: { rating: 4.2, count: 67 },
          enabled: true,
          registered: '2024-01-10T09:15:00',
          last_login: '2024-01-19T11:30:00',
          kyc_status: 'pending',
          kyc_documents: {
            aadhaar_card: { status: 'approved', url: '/docs/aadhaar2.pdf' },
            pan_card: { status: 'approved', url: '/docs/pan2.pdf' },
            bank_statement: { status: 'pending' },
            gst_certificate: { status: 'rejected' },
            udyam_aadhar: { status: 'pending' }
          },
          store_stats: {
            total_products: 28,
            total_orders: 89,
            total_sales: 234567,
            commission_rate: '12%',
            pending_withdrawal: 18000
          }
        },
        {
          id: 3,
          store_name: 'Tech Gadgets Store',
          first_name: 'Amit',
          last_name: 'Patel',
          email: 'tech@example.com',
          phone: '+91 76543 21098',
          address: {
            street_1: '789 Tech Park',
            street_2: 'IT Hub',
            city: 'Pune',
            zip: '411001',
            country: 'IN',
            state: 'Maharashtra'
          },
          banner: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800',
          gravatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
          shop_url: 'https://eliteq.in/store/tech-gadgets',
          products_per_page: 25,
          show_more_product_tab: false,
          toc_enabled: true,
          store_toc: 'Store terms...',
          featured: false,
          rating: { rating: 4.5, count: 45 },
          enabled: false,
          registered: '2024-01-18T14:30:00',
          last_login: '2024-01-18T15:00:00',
          kyc_status: 'incomplete',
          kyc_documents: {
            aadhaar_card: { status: 'approved', url: '/docs/aadhaar3.pdf' },
            pan_card: { status: 'pending' },
            bank_statement: { status: 'pending' },
            gst_certificate: { status: 'pending' },
            udyam_aadhar: { status: 'pending' }
          },
          store_stats: {
            total_products: 12,
            total_orders: 23,
            total_sales: 78900,
            commission_rate: '18%',
            pending_withdrawal: 5600
          }
        }
      ];
      
      setVendors(mockVendors);
    } catch (error) {
      console.error('Failed to fetch vendors:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (jwtToken) {
      fetchVendors();
    }
  }, [jwtToken, kycStatusFilter, storeStatusFilter]);

  const getKYCStatusBadge = (status: string) => {
    const statusConfig = {
      approved: { className: 'bg-green-100 text-green-800', icon: CheckCircle },
      pending: { className: 'bg-yellow-100 text-yellow-800', icon: Clock },
      rejected: { className: 'bg-red-100 text-red-800', icon: XCircle },
      incomplete: { className: 'bg-gray-100 text-gray-800', icon: AlertTriangle }
    };

    const config = statusConfig[status as keyof typeof statusConfig];
    if (!config) return <Badge variant="outline">{status}</Badge>;

    const Icon = config.icon;
    return (
      <Badge className={config.className}>
        <Icon className="h-3 w-3 mr-1" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const getDocumentStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800 text-xs">Approved</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800 text-xs">Pending</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800 text-xs">Rejected</Badge>;
      default:
        return <Badge variant="outline" className="text-xs">Not Submitted</Badge>;
    }
  };

  const handleKYCAction = async (vendorId: number, action: 'approve' | 'reject', documentType?: string) => {
    console.log(`${action} KYC for vendor ${vendorId}`, documentType);
    
    if (action === 'approve' && !documentType) {
      // Approve entire KYC
      setVendors(prev => prev.map(vendor => 
        vendor.id === vendorId ? { ...vendor, kyc_status: 'approved' as const } : vendor
      ));
    }
  };

  const handleVendorStatusToggle = async (vendorId: number) => {
    setVendors(prev => prev.map(vendor => 
      vendor.id === vendorId ? { ...vendor, enabled: !vendor.enabled } : vendor
    ));
  };

  const handleBulkAction = async (action: string) => {
    if (selectedVendors.length === 0) return;
    
    setPendingBulkAction({action, count: selectedVendors.length});
    setShowBulkConfirmDialog(true);
  };

  const executeBulkAction = async () => {
    if (!pendingBulkAction) return;
    
    setBulkActionInProgress(true);
    setBulkActionType(pendingBulkAction.action);
    setBulkProgressPercent(0);
    setShowBulkConfirmDialog(false);
    
    try {
      const totalItems = selectedVendors.length;
      
      for (let i = 0; i < totalItems; i++) {
        const vendorId = selectedVendors[i];
        
        // Simulate API call with realistic delay
        await new Promise(resolve => setTimeout(resolve, 250));
        
        // Update vendors based on action
        if (pendingBulkAction.action === 'approve-kyc') {
          setVendors(prev => prev.map(v => 
            v.id === vendorId ? { ...v, kyc_status: 'approved' as const } : v
          ));
        } else if (pendingBulkAction.action === 'reject-kyc') {
          setVendors(prev => prev.map(v => 
            v.id === vendorId ? { ...v, kyc_status: 'rejected' as const } : v
          ));
        } else if (pendingBulkAction.action === 'enable-stores') {
          setVendors(prev => prev.map(v => 
            v.id === vendorId ? { ...v, enabled: true } : v
          ));
        } else if (pendingBulkAction.action === 'disable-stores') {
          setVendors(prev => prev.map(v => 
            v.id === vendorId ? { ...v, enabled: false } : v
          ));
        } else if (pendingBulkAction.action === 'feature') {
          setVendors(prev => prev.map(v => 
            v.id === vendorId ? { ...v, featured: true } : v
          ));
        } else if (pendingBulkAction.action === 'unfeature') {
          setVendors(prev => prev.map(v => 
            v.id === vendorId ? { ...v, featured: false } : v
          ));
        } else if (pendingBulkAction.action === 'delete') {
          setVendors(prev => prev.filter(v => v.id !== vendorId));
        }
        
        setBulkProgressPercent(((i + 1) / totalItems) * 100);
      }
      
      toast.success(`Successfully ${pendingBulkAction.action.replace('-', ' ')}d ${totalItems} vendor${totalItems > 1 ? 's' : ''}`);
      setSelectedVendors([]);
      
    } catch (error) {
      toast.error('Bulk action failed. Please try again.');
      console.error('Bulk action error:', error);
    } finally {
      setBulkActionInProgress(false);
      setBulkActionType('');
      setBulkProgressPercent(0);
      setPendingBulkAction(null);
    }
  };

  const selectAllVendors = () => {
    if (selectedVendors.length === filteredVendors.length) {
      setSelectedVendors([]);
    } else {
      setSelectedVendors(filteredVendors.map(v => v.id));
    }
  };

  const selectVendorsByKYCStatus = (status: string) => {
    const statusVendors = filteredVendors.filter(v => v.kyc_status === status).map(v => v.id);
    setSelectedVendors(statusVendors);
  };

  const selectVendorsByStoreStatus = (enabled: boolean) => {
    const statusVendors = filteredVendors.filter(v => v.enabled === enabled).map(v => v.id);
    setSelectedVendors(statusVendors);
  };

  const calculateKYCProgress = (documents: Vendor['kyc_documents']) => {
    const totalDocs = Object.keys(documents).length;
    const approvedDocs = Object.values(documents).filter(doc => doc.status === 'approved').length;
    return (approvedDocs / totalDocs) * 100;
  };

  const filteredVendors = vendors.filter(vendor => {
    const matchesSearch = vendor.store_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         vendor.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         `${vendor.first_name} ${vendor.last_name}`.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesKYC = kycStatusFilter === 'all' || vendor.kyc_status === kycStatusFilter;
    const matchesStatus = storeStatusFilter === 'all' || 
                         (storeStatusFilter === 'enabled' && vendor.enabled) ||
                         (storeStatusFilter === 'disabled' && !vendor.enabled);
    
    return matchesSearch && matchesKYC && matchesStatus;
  });

  const vendorStats = {
    total: vendors.length,
    approved: vendors.filter(v => v.kyc_status === 'approved').length,
    pending: vendors.filter(v => v.kyc_status === 'pending').length,
    rejected: vendors.filter(v => v.kyc_status === 'rejected').length,
    enabled: vendors.filter(v => v.enabled).length
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-16 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Vendor Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total Vendors</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{vendorStats.total}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600 bg-blue-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">KYC Approved</p>
                <p className="text-2xl font-bold text-green-600">{vendorStats.approved}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600 bg-green-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">KYC Pending</p>
                <p className="text-2xl font-bold text-yellow-600">{vendorStats.pending}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600 bg-yellow-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">KYC Rejected</p>
                <p className="text-2xl font-bold text-red-600">{vendorStats.rejected}</p>
              </div>
              <XCircle className="h-8 w-8 text-red-600 bg-red-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Active Stores</p>
                <p className="text-2xl font-bold text-blue-600">{vendorStats.enabled}</p>
              </div>
              <Store className="h-8 w-8 text-blue-600 bg-blue-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 flex-1">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search vendors, stores..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={kycStatusFilter} onValueChange={setKycStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="KYC Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All KYC</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="incomplete">Incomplete</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={storeStatusFilter} onValueChange={setStoreStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Store Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Stores</SelectItem>
                  <SelectItem value="enabled">Active</SelectItem>
                  <SelectItem value="disabled">Disabled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex gap-2">
              {selectedVendors.length > 0 && (
                <div className="flex gap-2">
                  {/* Quick Selection Options */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Users className="h-4 w-4 mr-2" />
                        Quick Select
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem onClick={selectAllVendors}>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        {selectedVendors.length === filteredVendors.length ? 'Deselect All' : 'Select All Visible'}
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => selectVendorsByKYCStatus('pending')}>
                        <Clock className="h-4 w-4 mr-2" />
                        Select Pending KYC
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => selectVendorsByKYCStatus('approved')}>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Select Approved KYC
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => selectVendorsByKYCStatus('rejected')}>
                        <XCircle className="h-4 w-4 mr-2" />
                        Select Rejected KYC
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => selectVendorsByStoreStatus(true)}>
                        <Store className="h-4 w-4 mr-2" />
                        Select Active Stores
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => selectVendorsByStoreStatus(false)}>
                        <Ban className="h-4 w-4 mr-2" />
                        Select Disabled Stores
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  {/* Main Bulk Actions */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline">
                        <Users className="h-4 w-4 mr-2" />
                        Bulk Actions ({selectedVendors.length})
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="w-56">
                      <div className="px-2 py-1 text-xs font-medium text-gray-500 uppercase tracking-wide">
                        KYC Actions
                      </div>
                      <DropdownMenuItem onClick={() => handleBulkAction('approve-kyc')}>
                        <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                        Approve KYC
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleBulkAction('reject-kyc')}>
                        <XCircle className="h-4 w-4 mr-2 text-red-600" />
                        Reject KYC
                      </DropdownMenuItem>
                      
                      <DropdownMenuSeparator />
                      <div className="px-2 py-1 text-xs font-medium text-gray-500 uppercase tracking-wide">
                        Store Management
                      </div>
                      <DropdownMenuItem onClick={() => handleBulkAction('enable-stores')}>
                        <UserCheck className="h-4 w-4 mr-2 text-green-600" />
                        Enable Stores
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleBulkAction('disable-stores')}>
                        <UserX className="h-4 w-4 mr-2 text-red-600" />
                        Disable Stores
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleBulkAction('feature')}>
                        <Star className="h-4 w-4 mr-2 text-yellow-500" />
                        Feature Vendors
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleBulkAction('unfeature')}>
                        <Star className="h-4 w-4 mr-2 text-gray-400" />
                        Remove Featured
                      </DropdownMenuItem>
                      
                      <DropdownMenuSeparator />
                      <div className="px-2 py-1 text-xs font-medium text-gray-500 uppercase tracking-wide">
                        Communication
                      </div>
                      <DropdownMenuItem onClick={() => handleBulkAction('email-welcome')}>
                        <Mail className="h-4 w-4 mr-2 text-blue-600" />
                        Send Welcome Email
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleBulkAction('email-notification')}>
                        <Mail className="h-4 w-4 mr-2 text-purple-600" />
                        Send Notification
                      </DropdownMenuItem>
                      
                      <DropdownMenuSeparator />
                      <div className="px-2 py-1 text-xs font-medium text-gray-500 uppercase tracking-wide">
                        Export & Danger
                      </div>
                      <DropdownMenuItem onClick={() => handleBulkAction('export')}>
                        <Download className="h-4 w-4 mr-2 text-blue-600" />
                        Export Selected
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => handleBulkAction('delete')} className="text-red-600">
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete Vendors
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              )}
              
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export Vendors
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Vendors Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Vendors & KYC Management ({filteredVendors.length})
            </div>
            {selectedVendors.length > 0 && (
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
                {selectedVendors.length} selected
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <div className="flex items-center gap-2">
                      <Checkbox 
                        checked={selectedVendors.length === filteredVendors.length && filteredVendors.length > 0}
                        ref={(ref) => {
                          if (ref) {
                            const isIndeterminate = selectedVendors.length > 0 && selectedVendors.length < filteredVendors.length;
                            (ref as any).indeterminate = isIndeterminate;
                          }
                        }}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedVendors(filteredVendors.map(v => v.id));
                          } else {
                            setSelectedVendors([]);
                          }
                        }}
                      />
                    </div>
                  </TableHead>
                  <TableHead>Vendor</TableHead>
                  <TableHead>Store Status</TableHead>
                  <TableHead>KYC Status</TableHead>
                  <TableHead>KYC Progress</TableHead>
                  <TableHead>Store Stats</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Joined Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredVendors.map((vendor) => (
                  <TableRow 
                    key={vendor.id}
                    className={selectedVendors.includes(vendor.id) ? 'bg-blue-50 dark:bg-blue-900/20' : ''}
                  >
                    <TableCell>
                      <Checkbox 
                        checked={selectedVendors.includes(vendor.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedVendors([...selectedVendors, vendor.id]);
                          } else {
                            setSelectedVendors(selectedVendors.filter(id => id !== vendor.id));
                          }
                        }}
                      />
                    </TableCell>
                    
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={vendor.gravatar} />
                          <AvatarFallback>
                            {vendor.first_name.charAt(0)}{vendor.last_name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium flex items-center gap-2">
                            {vendor.store_name}
                            {vendor.featured && <Star className="h-4 w-4 text-yellow-500 fill-current" />}
                          </div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {vendor.first_name} {vendor.last_name}
                          </div>
                          <div className="flex items-center gap-1 text-xs text-gray-500">
                            <Mail className="h-3 w-3" />
                            {vendor.email}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      <Badge className={vendor.enabled ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                        {vendor.enabled ? 'Active' : 'Disabled'}
                      </Badge>
                    </TableCell>
                    
                    <TableCell>
                      {getKYCStatusBadge(vendor.kyc_status)}
                    </TableCell>
                    
                    <TableCell>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Documents</span>
                          <span>{calculateKYCProgress(vendor.kyc_documents).toFixed(0)}%</span>
                        </div>
                        <Progress value={calculateKYCProgress(vendor.kyc_documents)} className="h-2" />
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      <div className="space-y-1 text-sm">
                        <div>{vendor.store_stats.total_products} products</div>
                        <div>{vendor.store_stats.total_orders} orders</div>
                        <div className="text-green-600">₹{vendor.store_stats.total_sales.toLocaleString()}</div>
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-yellow-500 fill-current" />
                        <span className="font-medium">{vendor.rating.rating}</span>
                        <span className="text-sm text-gray-500">({vendor.rating.count})</span>
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      <div className="space-y-1">
                        <div className="text-sm">{new Date(vendor.registered).toLocaleDateString()}</div>
                        <div className="text-xs text-gray-500">
                          Last login: {new Date(vendor.last_login).toLocaleDateString()}
                        </div>
                      </div>
                    </TableCell>
                    
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="sm" onClick={() => setSelectedVendor(vendor)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setSelectedVendor(vendor)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            {vendor.kyc_status === 'pending' && (
                              <>
                                <DropdownMenuItem onClick={() => handleKYCAction(vendor.id, 'approve')}>
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Approve KYC
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleKYCAction(vendor.id, 'reject')}>
                                  <XCircle className="h-4 w-4 mr-2" />
                                  Reject KYC
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                              </>
                            )}
                            <DropdownMenuItem onClick={() => handleVendorStatusToggle(vendor.id)}>
                              {vendor.enabled ? (
                                <>
                                  <Ban className="h-4 w-4 mr-2" />
                                  Disable Store
                                </>
                              ) : (
                                <>
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Enable Store
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Store className="h-4 w-4 mr-2" />
                              Visit Store
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Vendor Details Dialog */}
      <Dialog open={!!selectedVendor} onOpenChange={() => setSelectedVendor(null)}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Store className="h-5 w-5" />
              Vendor Details: {selectedVendor?.store_name}
            </DialogTitle>
          </DialogHeader>
          
          {selectedVendor && (
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="kyc">KYC Documents</TabsTrigger>
                <TabsTrigger value="store">Store Info</TabsTrigger>
                <TabsTrigger value="financials">Financials</TabsTrigger>
                <TabsTrigger value="actions">Actions</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Vendor Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center gap-4">
                        <Avatar className="h-16 w-16">
                          <AvatarImage src={selectedVendor.gravatar} />
                          <AvatarFallback className="text-lg">
                            {selectedVendor.first_name.charAt(0)}{selectedVendor.last_name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium text-lg">{selectedVendor.first_name} {selectedVendor.last_name}</div>
                          <div className="text-gray-600">{selectedVendor.email}</div>
                          <div className="text-sm text-gray-500">{selectedVendor.phone}</div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Store Status:</span>
                          <Badge className={selectedVendor.enabled ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                            {selectedVendor.enabled ? 'Active' : 'Disabled'}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">KYC Status:</span>
                          {getKYCStatusBadge(selectedVendor.kyc_status)}
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Featured:</span>
                          <span>{selectedVendor.featured ? 'Yes' : 'No'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Registered:</span>
                          <span>{new Date(selectedVendor.registered).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Store Performance</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                          <div className="text-2xl font-bold text-blue-600">{selectedVendor.store_stats.total_products}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">Products</div>
                        </div>
                        <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                          <div className="text-2xl font-bold text-green-600">{selectedVendor.store_stats.total_orders}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">Orders</div>
                        </div>
                        <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                          <div className="text-2xl font-bold text-purple-600">₹{selectedVendor.store_stats.total_sales.toLocaleString()}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">Total Sales</div>
                        </div>
                        <div className="text-center p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                          <div className="flex items-center justify-center gap-1 text-2xl font-bold text-orange-600">
                            <Star className="h-6 w-6 fill-current" />
                            {selectedVendor.rating.rating}
                          </div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">{selectedVendor.rating.count} Reviews</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="kyc" className="space-y-4">
                {selectedVendor.kyc_status === 'pending' && (
                  <Alert className="border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20">
                    <AlertTriangle className="h-4 w-4 text-yellow-600" />
                    <AlertDescription className="text-yellow-800 dark:text-yellow-200">
                      This vendor's KYC is pending review. Please verify all documents before approval.
                    </AlertDescription>
                  </Alert>
                )}
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(selectedVendor.kyc_documents).map(([docType, doc]) => (
                    <Card key={docType}>
                      <CardHeader>
                        <CardTitle className="text-sm flex items-center justify-between">
                          <span className="capitalize">{docType.replace('_', ' ')}</span>
                          {getDocumentStatusBadge(doc.status)}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {doc.url ? (
                            <div className="flex items-center gap-2">
                              <FileText className="h-4 w-4 text-gray-400" />
                              <a href={doc.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-sm">
                                View Document
                              </a>
                              <Download className="h-4 w-4 text-gray-400" />
                            </div>
                          ) : (
                            <div className="text-sm text-gray-500">No document uploaded</div>
                          )}
                          
                          {doc.status === 'pending' && (
                            <div className="flex gap-2">
                              <Button size="sm" onClick={() => handleKYCAction(selectedVendor.id, 'approve', docType)}>
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Approve
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => handleKYCAction(selectedVendor.id, 'reject', docType)}>
                                <XCircle className="h-3 w-3 mr-1" />
                                Reject
                              </Button>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                <div className="flex justify-end gap-2 pt-4">
                  {selectedVendor.kyc_status === 'pending' && (
                    <>
                      <Button onClick={() => handleKYCAction(selectedVendor.id, 'approve')} className="bg-green-600 hover:bg-green-700 text-white">
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Approve All KYC
                      </Button>
                      <Button variant="outline" onClick={() => handleKYCAction(selectedVendor.id, 'reject')}>
                        <XCircle className="h-4 w-4 mr-2" />
                        Reject KYC
                      </Button>
                    </>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="store" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Store Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-gray-600">Store Name</Label>
                        <p className="font-medium">{selectedVendor.store_name}</p>
                      </div>
                      <div>
                        <Label className="text-gray-600">Store URL</Label>
                        <a href={selectedVendor.shop_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline flex items-center gap-1">
                          Visit Store <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-gray-600">Address</Label>
                      <div className="text-sm space-y-1">
                        <div>{selectedVendor.address.street_1}</div>
                        {selectedVendor.address.street_2 && <div>{selectedVendor.address.street_2}</div>}
                        <div>{selectedVendor.address.city}, {selectedVendor.address.state} {selectedVendor.address.zip}</div>
                        <div>{selectedVendor.address.country}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="financials" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Commission & Earnings</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Commission Rate:</span>
                        <span className="font-medium">{selectedVendor.store_stats.commission_rate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Sales:</span>
                        <span className="font-medium">₹{selectedVendor.store_stats.total_sales.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Pending Withdrawal:</span>
                        <span className="font-medium text-orange-600">₹{selectedVendor.store_stats.pending_withdrawal.toLocaleString()}</span>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Payment Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <Button className="w-full">
                        <DollarSign className="h-4 w-4 mr-2" />
                        Process Withdrawal
                      </Button>
                      <Button variant="outline" className="w-full">
                        <FileText className="h-4 w-4 mr-2" />
                        View Payment History
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="actions" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button onClick={() => handleVendorStatusToggle(selectedVendor.id)} className={selectedVendor.enabled ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}>
                    {selectedVendor.enabled ? (
                      <>
                        <Ban className="h-4 w-4 mr-2" />
                        Disable Store
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Enable Store
                      </>
                    )}
                  </Button>
                  
                  <Button variant="outline">
                    <Award className="h-4 w-4 mr-2" />
                    Make Featured
                  </Button>
                  
                  <Button variant="outline">
                    <Mail className="h-4 w-4 mr-2" />
                    Send Message
                  </Button>
                  
                  <Button variant="outline">
                    <FileText className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>

      {/* Bulk Action Confirmation Dialog */}
      <AlertDialog open={showBulkConfirmDialog} onOpenChange={setShowBulkConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Bulk Action</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to <strong>{pendingBulkAction?.action?.replace('-', ' ')}</strong> {pendingBulkAction?.count} selected vendor{pendingBulkAction?.count !== 1 ? 's' : ''}?
              {pendingBulkAction?.action === 'delete' && (
                <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded text-red-800">
                  <strong>Warning:</strong> This will permanently delete vendor accounts and all associated data. This action cannot be undone.
                </div>
              )}
              {pendingBulkAction?.action === 'disable-stores' && (
                <div className="mt-2 p-3 bg-yellow-50 border border-yellow-200 rounded text-yellow-800">
                  <strong>Note:</strong> This will disable vendor stores, preventing them from processing orders or accessing their dashboard.
                </div>
              )}
              {pendingBulkAction?.action === 'reject-kyc' && (
                <div className="mt-2 p-3 bg-orange-50 border border-orange-200 rounded text-orange-800">
                  <strong>Note:</strong> This will mark KYC as rejected. Vendors will be notified and may need to resubmit documents.
                </div>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setPendingBulkAction(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={executeBulkAction}
              className={
                pendingBulkAction?.action === 'delete' 
                  ? 'bg-red-600 hover:bg-red-700' 
                  : pendingBulkAction?.action === 'disable-stores'
                  ? 'bg-yellow-600 hover:bg-yellow-700'
                  : pendingBulkAction?.action === 'reject-kyc'
                  ? 'bg-orange-600 hover:bg-orange-700'
                  : ''
              }
            >
              Continue
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Bulk Action Progress Dialog */}
      <Dialog open={bulkActionInProgress} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <RefreshCw className="h-5 w-5 animate-spin" />
              Processing Bulk Action
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-center">
              <p className="text-sm text-gray-600 mb-2">
                {bulkActionType.replace('-', ' ').charAt(0).toUpperCase() + bulkActionType.replace('-', ' ').slice(1)}ing vendors...
              </p>
              <Progress value={bulkProgressPercent} className="w-full" />
              <p className="text-xs text-gray-500 mt-2">
                {Math.round(bulkProgressPercent)}% complete
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};