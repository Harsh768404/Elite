import React from 'react';

interface EliteQLogoProps {
  darkMode?: boolean;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  animated?: boolean;
  className?: string;
}

export const EliteQLogo: React.FC<EliteQLogoProps> = ({ 
  darkMode = false, 
  size = 'md', 
  showText = true, 
  animated = false,
  className = '' 
}) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16'
  };

  const textSizeClasses = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl'
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* EliteQ Logo Icon */}
      <div className={`${sizeClasses[size]} relative ${animated ? 'animate-float' : ''}`}>
        <div className={`w-full h-full rounded-xl bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center shadow-lg ${
          animated ? 'transform-style-preserve-3d perspective-1000' : ''
        }`}>
          <div className="text-white font-bold text-base leading-none">
            E
          </div>
        </div>
        
        {/* Animated Glow Effect */}
        {animated && (
          <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-blue-600 to-blue-800 animate-glow opacity-50 -z-10"></div>
        )}
      </div>
      
      {/* EliteQ Text */}
      {showText && (
        <div className="flex flex-col">
          <div className={`font-bold ${textSizeClasses[size]} ${
            darkMode ? 'text-white' : 'text-gray-900'
          } tracking-tight leading-none`}>
            EliteQ
          </div>
          <div className={`text-xs ${
            darkMode ? 'text-gray-400' : 'text-gray-600'
          } tracking-wide`}>
            INDIA
          </div>
        </div>
      )}
    </div>
  );
};