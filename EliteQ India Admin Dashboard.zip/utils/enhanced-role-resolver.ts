// Enhanced Role Resolver for WordPress/WooCommerce - WITH REAL ELITEQ.IN DATA INTEGRATION
import { networkManager, createAdaptiveRetryConfig } from './network-connectivity-manager';
import { wordpressAPI } from './comprehensive-wordpress-api';

export interface UserRoleResult {
  roles: string[];
  primary_role: 'administrator' | 'vendor' | 'customer' | 'restricted';
  dashboard_route: string;
  resolution_method: string;
  debug_info: any;
  isRealData: boolean;
}

export class EnhancedRoleResolver {
  private baseUrl: string;
  private jwtToken: string;

  constructor(baseUrl: string, jwtToken: string) {
    this.baseUrl = baseUrl;
    this.jwtToken = jwtToken;
  }

  // ENHANCED: Real EliteQ.in role resolution with comprehensive fallbacks
  public async resolveUserRoles(userId?: number, jwtData?: any): Promise<UserRoleResult> {
    console.log('🔧 ===== ENHANCED ROLE RESOLVER FOR REAL ELITEQ.IN DATA =====');
    console.log('🎯 Target user ID:', userId);
    console.log('🔑 JWT data provided:', !!jwtData);
    console.log('🌐 EliteQ.in URL:', this.baseUrl);
    
    const debugInfo: any = {
      attempts: [],
      apiResponses: {},
      jwtPayload: null,
      userId: userId,
      wordpressRoleIssues: [],
      networkErrors: [],
      realDataSource: 'eliteq.in'
    };

    // METHOD 1: Use the enhanced WordPress API service for real data
    try {
      console.log('🔍 METHOD 1: Using enhanced WordPress API service for real user data');
      
      const user = await wordpressAPI.getUserWithRoles(userId);
      if (user && user.roles && Array.isArray(user.roles)) {
        console.log('✅ METHOD 1 SUCCESS: Real user roles from EliteQ.in:', user.roles);
        
        debugInfo.attempts.push('wordpress_api_service');
        debugInfo.apiResponses.wordpress_api = user;
        
        const roleResult = this.calculatePrimaryRoleForEliteQ(user.roles);
        console.log('✅ METHOD 1 COMPLETE: Primary role determined:', roleResult.primary_role);
        
        // Store real user data in localStorage
        if (typeof window !== 'undefined') {
          localStorage.setItem('eliteq_user_roles', JSON.stringify(user.roles));
          localStorage.setItem('eliteq_user_data', JSON.stringify(user));
          localStorage.setItem('eliteq_primary_role', roleResult.primary_role);
          localStorage.setItem('eliteq_dashboard_route', roleResult.dashboard_route);
        }
        
        return {
          roles: user.roles,
          primary_role: roleResult.primary_role,
          dashboard_route: roleResult.dashboard_route,
          resolution_method: 'wordpress_api_service_real_data',
          debug_info: {
            ...debugInfo,
            successful_method: 'wordpress_api_service_real_data',
            real_user_data: user,
            capabilities: user.capabilities || {},
            meta: user.meta || {}
          },
          isRealData: true
        };
      }
    } catch (error) {
      console.warn('⚠️ METHOD 1 ERROR:', error);
      debugInfo.attempts.push('wordpress_api_service_error');
      debugInfo.networkErrors.push(`WordPress API service error: ${error.message}`);
    }

    // METHOD 2: Direct WordPress REST API with real EliteQ credentials
    try {
      console.log('🔍 METHOD 2: Direct WordPress REST API call to EliteQ.in');
      
      const endpoint = userId ? 
        `${this.baseUrl}/wp-json/wp/v2/users/${userId}?context=edit` : 
        `${this.baseUrl}/wp-json/wp/v2/users/me?context=edit`;
      
      const response = await fetch(endpoint, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.jwtToken}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'User-Agent': 'EliteQ-Admin-Panel/1.0'
        }
      });

      if (response.ok) {
        const userData = await response.json();
        console.log('✅ METHOD 2 SUCCESS: Direct WordPress API response:', userData);
        
        debugInfo.attempts.push('direct_wordpress_api');
        debugInfo.apiResponses.direct_wordpress = userData;
        
        let userRoles: string[] = [];
        
        if (userData.roles && Array.isArray(userData.roles)) {
          userRoles = userData.roles;
        } else if (userData.capabilities) {
          userRoles = this.extractRolesFromCapabilities(userData.capabilities);
        }
        
        if (userRoles.length > 0) {
          const roleResult = this.calculatePrimaryRoleForEliteQ(userRoles);
          console.log('✅ METHOD 2 COMPLETE: Roles from direct API:', userRoles, 'Primary:', roleResult.primary_role);
          
          // Store real user data in localStorage
          if (typeof window !== 'undefined') {
            localStorage.setItem('eliteq_user_roles', JSON.stringify(userRoles));
            localStorage.setItem('eliteq_user_data', JSON.stringify(userData));
            localStorage.setItem('eliteq_primary_role', roleResult.primary_role);
            localStorage.setItem('eliteq_dashboard_route', roleResult.dashboard_route);
          }
          
          return {
            roles: userRoles,
            primary_role: roleResult.primary_role,
            dashboard_route: roleResult.dashboard_route,
            resolution_method: 'direct_wordpress_api_real_data',
            debug_info: {
              ...debugInfo,
              successful_method: 'direct_wordpress_api_real_data',
              real_user_data: userData
            },
            isRealData: true
          };
        }
      }
    } catch (error) {
      console.warn('⚠️ METHOD 2 ERROR:', error);
      debugInfo.attempts.push('direct_wordpress_api_error');
      debugInfo.networkErrors.push(`Direct WordPress API error: ${error.message}`);
    }

    // METHOD 3: Check real vendor data through Dokan if applicable
    try {
      console.log('🔍 METHOD 3: Checking real vendor data through Dokan API');
      
      const vendorData = await wordpressAPI.getVendorData(userId);
      if (vendorData && vendorData.isVendor) {
        console.log('✅ METHOD 3 SUCCESS: Real vendor data from EliteQ.in:', vendorData);
        
        debugInfo.attempts.push('dokan_vendor_api');
        debugInfo.apiResponses.dokan_vendor = vendorData;
        
        const userRoles = vendorData.user.roles || ['vendor'];
        const roleResult = this.calculatePrimaryRoleForEliteQ(userRoles);
        
        // Store real vendor data
        if (typeof window !== 'undefined') {
          localStorage.setItem('eliteq_user_roles', JSON.stringify(userRoles));
          localStorage.setItem('eliteq_user_data', JSON.stringify(vendorData.user));
          localStorage.setItem('eliteq_vendor_info', JSON.stringify(vendorData.vendorInfo));
          localStorage.setItem('eliteq_primary_role', roleResult.primary_role);
          localStorage.setItem('eliteq_dashboard_route', roleResult.dashboard_route);
        }
        
        return {
          roles: userRoles,
          primary_role: roleResult.primary_role,
          dashboard_route: roleResult.dashboard_route,
          resolution_method: 'dokan_vendor_api_real_data',
          debug_info: {
            ...debugInfo,
            successful_method: 'dokan_vendor_api_real_data',
            real_vendor_data: vendorData
          },
          isRealData: true
        };
      }
    } catch (error) {
      console.warn('⚠️ METHOD 3 ERROR:', error);
      debugInfo.attempts.push('dokan_vendor_api_error');
      debugInfo.networkErrors.push(`Dokan vendor API error: ${error.message}`);
    }

    // METHOD 4: Check localStorage for cached real data
    try {
      console.log('🔍 METHOD 4: Checking localStorage for cached real EliteQ data');
      
      if (typeof window !== 'undefined') {
        const cachedRoles = localStorage.getItem('eliteq_user_roles');
        const cachedUserData = localStorage.getItem('eliteq_user_data');
        const cachedPrimaryRole = localStorage.getItem('eliteq_primary_role');
        const cachedRoute = localStorage.getItem('eliteq_dashboard_route');
        
        if (cachedRoles && cachedUserData && cachedPrimaryRole && cachedRoute) {
          const userRoles = JSON.parse(cachedRoles);
          const userData = JSON.parse(cachedUserData);
          
          console.log('✅ METHOD 4 SUCCESS: Using cached real EliteQ data:', {
            roles: userRoles,
            primaryRole: cachedPrimaryRole,
            route: cachedRoute
          });
          
          debugInfo.attempts.push('cached_real_data');
          debugInfo.apiResponses.cached_data = { roles: userRoles, userData };
          
          return {
            roles: userRoles,
            primary_role: cachedPrimaryRole as any,
            dashboard_route: cachedRoute,
            resolution_method: 'cached_real_eliteq_data',
            debug_info: {
              ...debugInfo,
              successful_method: 'cached_real_eliteq_data',
              cached_user_data: userData
            },
            isRealData: true
          };
        }
      }
    } catch (error) {
      console.warn('⚠️ METHOD 4 ERROR:', error);
      debugInfo.attempts.push('cached_data_error');
    }

    // METHOD 5: Parse JWT token for real EliteQ user data
    try {
      console.log('🔍 METHOD 5: Parsing JWT token for real EliteQ user data');
      
      const jwtResult = this.extractRolesFromJWT();
      if (jwtResult.roles.length > 0) {
        debugInfo.attempts.push('jwt_token_parsing');
        debugInfo.jwtPayload = jwtResult.payload;
        
        const roleResult = this.calculatePrimaryRoleForEliteQ(jwtResult.roles);
        console.log('✅ METHOD 5 SUCCESS: Real roles from JWT token:', jwtResult.roles, 'Primary:', roleResult.primary_role);
        
        // Store JWT-derived data
        if (typeof window !== 'undefined') {
          localStorage.setItem('eliteq_user_roles', JSON.stringify(jwtResult.roles));
          localStorage.setItem('eliteq_primary_role', roleResult.primary_role);
          localStorage.setItem('eliteq_dashboard_route', roleResult.dashboard_route);
        }
        
        return {
          roles: jwtResult.roles,
          primary_role: roleResult.primary_role,
          dashboard_route: roleResult.dashboard_route,
          resolution_method: 'jwt_token_real_data',
          debug_info: {
            ...debugInfo,
            successful_method: 'jwt_token_real_data',
            jwt_payload: jwtResult.payload
          },
          isRealData: true
        };
      }
    } catch (error) {
      console.warn('⚠️ METHOD 5 ERROR:', error);
      debugInfo.attempts.push('jwt_token_parsing_error');
    }

    // FALLBACK: All real data methods failed
    console.error('🚨 ===== ALL REAL DATA METHODS FAILED FOR ELITEQ.IN =====');
    console.error('🚨 This indicates a serious issue with EliteQ.in WordPress configuration');
    console.error('🚨 Debug info:', debugInfo);
    
    return {
      roles: ['subscriber'],
      primary_role: 'restricted',
      dashboard_route: '/login',
      resolution_method: 'fallback_real_data_failed',
      debug_info: {
        ...debugInfo,
        error: 'All real EliteQ.in data methods failed',
        recommendations: [
          'Check EliteQ.in WordPress server connectivity',
          'Verify JWT token validity',
          'Check WordPress user role assignments',
          'Verify Dokan plugin configuration',
          'Check WordPress REST API permissions'
        ]
      },
      isRealData: false
    };
  }

  // Enhanced role calculation specifically for EliteQ India marketplace
  private calculatePrimaryRoleForEliteQ(roles: string[]): {
    primary_role: 'administrator' | 'vendor' | 'customer' | 'restricted';
    dashboard_route: string;
  } {
    console.log('🎯 Calculating primary role for EliteQ marketplace from roles:', roles);
    
    // EliteQ-specific role priority (highest to lowest)
    
    // 1. Administrator (highest priority) - FIXED: Use 'administrator' not 'admin'
    if (roles.includes('administrator') || roles.includes('editor') || roles.includes('author')) {
      console.log('👑 PRIMARY ROLE: Administrator detected for EliteQ marketplace');
      return {
        primary_role: 'administrator',
        dashboard_route: '/admin/dashboard'
      };
    }
    
    // 2. Shop Manager - FIXED: Use 'administrator' not 'admin'
    if (roles.includes('shop_manager')) {
      console.log('🏢 PRIMARY ROLE: Shop Manager detected for EliteQ marketplace');
      return {
        primary_role: 'administrator',
        dashboard_route: '/admin/dashboard'
      };
    }
    
    // 3. Vendor/Seller (Dokan & WooCommerce vendors)
    if (roles.includes('seller') || 
        roles.includes('vendor') || 
        roles.includes('dokan_vendor') ||
        roles.includes('wcfm_vendor') ||
        roles.includes('wc_product_vendors_admin_vendor')) {
      console.log('🏪 PRIMARY ROLE: Vendor detected for EliteQ marketplace');
      return {
        primary_role: 'vendor',
        dashboard_route: '/vendor/dashboard'
      };
    }
    
    // 4. Customer (WooCommerce customer)
    if (roles.includes('customer')) {
      console.log('👤 PRIMARY ROLE: Customer detected for EliteQ marketplace');
      return {
        primary_role: 'customer',
        dashboard_route: '/account/dashboard'
      };
    }
    
    // 5. Subscriber (basic WordPress user)
    if (roles.includes('subscriber')) {
      console.log('📧 PRIMARY ROLE: Subscriber detected for EliteQ marketplace');
      return {
        primary_role: 'customer',
        dashboard_route: '/account/dashboard'
      };
    }
    
    // Unknown role - restrict access
    console.warn('⚠️ PRIMARY ROLE: Unknown roles for EliteQ marketplace, restricting access');
    return {
      primary_role: 'restricted',
      dashboard_route: '/login'
    };
  }

  // Helper method to extract roles from JWT token
  private extractRolesFromJWT(): { roles: string[]; payload: any } {
    try {
      const tokenParts = this.jwtToken.split('.');
      if (tokenParts.length === 3) {
        const payload = JSON.parse(atob(tokenParts[1]));
        console.log('✅ JWT payload parsed:', payload);
        
        let userRoles: string[] = [];
        
        // Check various possible locations in JWT payload
        if (payload.data && payload.data.user) {
          const jwtUser = payload.data.user;
          
          if (jwtUser.roles) {
            userRoles = Array.isArray(jwtUser.roles) ? jwtUser.roles : [jwtUser.roles];
          } else if (jwtUser.capabilities) {
            userRoles = this.extractRolesFromCapabilities(jwtUser.capabilities);
          }
        } else if (payload.roles) {
          userRoles = Array.isArray(payload.roles) ? payload.roles : [payload.roles];
        } else if (payload.user_roles) {
          userRoles = Array.isArray(payload.user_roles) ? payload.user_roles : [payload.user_roles];
        } else if (payload.capabilities) {
          userRoles = this.extractRolesFromCapabilities(payload.capabilities);
        }
        
        return { roles: userRoles, payload };
      }
    } catch (error) {
      console.warn('⚠️ JWT payload parsing failed:', error);
    }
    
    return { roles: [], payload: null };
  }

  // Helper method for fallback role resolution
  private fallbackToJWTRoles(jwtData?: any, debugInfo?: any, recommendations?: string[]): UserRoleResult {
    console.log('🔧 Using fallback role resolution');
    
    // Try JWT token first
    const jwtResult = this.extractRolesFromJWT();
    if (jwtResult.roles.length > 0) {
      const roleResult = this.calculatePrimaryRole(jwtResult.roles);
      return {
        roles: jwtResult.roles,
        primary_role: roleResult.primary_role,
        dashboard_route: roleResult.dashboard_route,
        resolution_method: 'jwt_fallback',
        debug_info: {
          ...debugInfo,
          successful_method: 'jwt_fallback',
          jwt_payload: jwtResult.payload,
          recommendations: recommendations || []
        }
      };
    }
    
    // Absolute fallback
    return {
      roles: ['subscriber'], // Fallback role
      primary_role: 'restricted', // Mark as restricted due to role resolution failure
      dashboard_route: '/login',
      resolution_method: 'fallback_all_methods_failed',
      debug_info: {
        ...debugInfo,
        error: 'All role resolution methods failed including JWT fallback',
        wordpressIssues: debugInfo?.wordpressRoleIssues || [],
        networkIssues: debugInfo?.networkErrors || [],
        recommendations: recommendations || [],
        warning: 'WordPress may not expose user roles through standard REST API endpoints or network connectivity issues'
      }
    };
  }

  // Helper method to extract roles from WordPress capabilities object
  private extractRolesFromCapabilities(capabilities: any): string[] {
    if (!capabilities || typeof capabilities !== 'object') {
      return [];
    }
    
    console.log('🔍 Extracting roles from capabilities:', capabilities);
    
    const roles: string[] = [];
    const knownRoles = [
      'administrator',
      'shop_manager', 
      'vendor',
      'seller',
      'dokan_vendor',
      'customer',
      'subscriber',
      'editor',
      'author',
      'contributor'
    ];
    
    // Check for direct role keys in capabilities
    for (const role of knownRoles) {
      if (capabilities[role] === true || capabilities[role] === 1 || capabilities[role] === '1') {
        roles.push(role);
        console.log(`✅ Found role: ${role}`);
      }
    }
    
    // Also check for capabilities that indicate specific roles
    if (capabilities['manage_options'] || capabilities['edit_users']) {
      if (!roles.includes('administrator')) {
        roles.push('administrator');
        console.log('✅ Inferred administrator role from capabilities');
      }
    }
    
    if (capabilities['manage_woocommerce'] || capabilities['edit_shop_orders']) {
      if (!roles.includes('shop_manager') && !roles.includes('administrator')) {
        roles.push('shop_manager');
        console.log('✅ Inferred shop_manager role from capabilities');
      }
    }
    
    if (capabilities['dokan_view_store_dashboard'] || capabilities['dokan_edit_product']) {
      if (!roles.includes('vendor') && !roles.includes('seller')) {
        roles.push('vendor');
        console.log('✅ Inferred vendor role from Dokan capabilities');
      }
    }
    
    console.log('🎯 Final extracted roles:', roles);
    return roles;
  }

  // Generate specific recommendations based on failed attempts
  private generateRecommendations(debugInfo: any): string[] {
    const recommendations: string[] = [];
    
    if (debugInfo.networkErrors && debugInfo.networkErrors.length > 0) {
      recommendations.push('Check network connectivity to EliteQ.in WordPress server');
      recommendations.push('Verify firewall and proxy settings are not blocking WordPress API access');
      recommendations.push('Try refreshing the page or reconnecting to the network');
    }
    
    if (debugInfo.wordpressRoleIssues.some((issue: string) => issue.includes('Edit context failed'))) {
      recommendations.push('WordPress user may not have permission to view edit context');
      recommendations.push('Check if JWT token has proper scope and permissions');
    }
    
    if (debugInfo.wordpressRoleIssues.some((issue: string) => issue.includes('Standard /users/me response lacks roles'))) {
      recommendations.push('WordPress installation has roles hidden for security (normal behavior)');
      recommendations.push('Consider enabling context=edit access or custom role endpoint');
    }
    
    if (debugInfo.attempts.includes('jwt_token_parsing_error')) {
      recommendations.push('JWT token may be malformed or using non-standard structure');
      recommendations.push('Check JWT Auth plugin configuration and token generation');
    }
    
    if (!debugInfo.attempts.includes('woocommerce_customers')) {
      recommendations.push('WooCommerce customer endpoint may not be accessible');
      recommendations.push('Verify WooCommerce REST API is enabled and properly configured');
    }
    
    recommendations.push('Check WordPress user role assignment in wp-admin');
    recommendations.push('Verify Dokan plugin is properly assigning vendor roles');
    recommendations.push('Consider implementing a custom WordPress endpoint for role information');
    
    return recommendations;
  }

  // ENHANCED: Calculate primary role with strict priority
  private calculatePrimaryRole(roles: string[]): {
    primary_role: 'administrator' | 'shop_manager' | 'vendor' | 'restricted';
    dashboard_route: string;
  } {
    console.log('🎯 Calculating primary role from roles:', roles);
    
    // STRICT PRIORITY ORDER (highest to lowest)
    
    // 1. Administrator (highest priority)
    if (roles.includes('administrator')) {
      console.log('👑 PRIMARY ROLE: Administrator detected');
      return {
        primary_role: 'administrator',
        dashboard_route: '/admin-dashboard'
      };
    }
    
    // 2. Shop Manager
    if (roles.includes('shop_manager')) {
      console.log('🏢 PRIMARY ROLE: Shop Manager detected');
      return {
        primary_role: 'shop_manager',
        dashboard_route: '/admin-dashboard'
      };
    }
    
    // 3. Vendor/Seller (Dokan)
    if (roles.includes('seller') || roles.includes('vendor') || roles.includes('dokan_vendor')) {
      console.log('🏪 PRIMARY ROLE: Vendor/Seller detected');
      return {
        primary_role: 'vendor',
        dashboard_route: '/vendor-dashboard'
      };
    }
    
    // 4. Customer (regular WooCommerce customer)
    if (roles.includes('customer')) {
      console.log('👤 PRIMARY ROLE: Customer detected');
      return {
        primary_role: 'restricted', // Customers get limited access
        dashboard_route: '/account-dashboard'
      };
    }
    
    // 5. Subscriber (basic WordPress user)
    if (roles.includes('subscriber')) {
      console.log('📧 PRIMARY ROLE: Subscriber detected');
      return {
        primary_role: 'restricted', // Subscribers get limited access
        dashboard_route: '/account-dashboard'
      };
    }
    
    // 6. Editor/Author (WordPress content roles)
    if (roles.includes('editor') || roles.includes('author')) {
      console.log('✍️ PRIMARY ROLE: Content creator detected');
      return {
        primary_role: 'restricted', // Content creators get limited access
        dashboard_route: '/account-dashboard'
      };
    }
    
    // Unknown role - restrict access
    console.warn('⚠️ PRIMARY ROLE: Unknown roles, restricting access');
    return {
      primary_role: 'restricted',
      dashboard_route: '/login'
    };
  }

  // Helper method to validate role resolution
  public async validateRoleResolution(userId?: number): Promise<{
    isValid: boolean;
    issues: string[];
    recommendations: string[];
  }> {
    const issues: string[] = [];
    const recommendations: string[] = [];
    
    try {
      const result = await this.resolveUserRoles(userId);
      
      if (result.primary_role === 'restricted' && result.resolution_method === 'fallback_all_methods_failed') {
        issues.push('All role resolution methods failed');
        recommendations.push('Check WordPress REST API permissions and network connectivity');
        recommendations.push('Verify JWT token validity and scope');
        recommendations.push('Ensure user has proper WordPress role assigned');
      }
      
      if (result.roles.length === 0) {
        issues.push('No roles found for user');
        recommendations.push('Check WordPress user role assignment in wp-admin');
        recommendations.push('Verify Dokan plugin is properly assigning vendor roles');
      }
      
      if (result.roles.includes('subscriber') && result.roles.length === 1) {
        issues.push('User only has subscriber role - may indicate role assignment issue');
        recommendations.push('Check if user should have higher privileges');
        recommendations.push('Verify Dokan vendor registration process');
        recommendations.push('Check WordPress role assignment for this user');
      }
      
      if (result.debug_info?.networkIssues?.length > 0) {
        issues.push('Network connectivity issues detected');
        recommendations.push('Check network connection to EliteQ.in');
        recommendations.push('Verify WordPress server is accessible');
      }
      
      if (result.debug_info?.wordpressIssues?.length > 0) {
        issues.push('WordPress API issues detected');
        recommendations.push('Review WordPress REST API configuration');
        recommendations.push('Check user permissions and capabilities');
      }
      
      return {
        isValid: issues.length === 0,
        issues,
        recommendations
      };
    } catch (error) {
      return {
        isValid: false,
        issues: ['Role validation failed due to error'],
        recommendations: ['Check network connectivity and API endpoints']
      };
    }
  }
}

export default EnhancedRoleResolver;