import React, { Suspense } from 'react';
import { Skeleton } from './ui/skeleton';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { AlertCircle, Loader2 } from 'lucide-react';

// Import components
import DashboardModule from './DashboardModule';
import ProductManagementModule from './ProductManagementModule';
import OrderManagementModule from './OrderManagementModule';
import CustomerManagementModule from './CustomerManagementModule';
import SystemConfigModule from './SystemConfigModule';
import WebhookLogsModule from './WebhookLogsModule';
import ComprehensiveAPIDemo from './ComprehensiveAPIDemo';
import CustomersManagement from './CustomersManagement';
import VendorsManagement from './VendorsManagement';
import InteractionGuide from './InteractionGuide';
import AnnouncementsPage from './AnnouncementsPage';
import { ComprehensiveAPITester } from './ComprehensiveAPITester';

interface ModuleContentRendererProps {
  module: string;
  userRole: string;
}

// Loading fallback component
const ModuleLoader: React.FC<{ moduleName: string }> = ({ moduleName }) => (
  <div className="w-full max-w-6xl mx-auto p-6 space-y-6">
    <div className="flex items-center gap-2 mb-6">
      <Loader2 className="h-5 w-5 animate-spin" />
      <span>Loading {moduleName}...</span>
    </div>
    
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <Card key={i}>
          <CardHeader>
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-4 w-full" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-20 w-full" />
          </CardContent>
        </Card>
      ))}
    </div>
  </div>
);

// Error boundary component
const ModuleErrorBoundary: React.FC<{ 
  children: React.ReactNode; 
  moduleName: string 
}> = ({ children, moduleName }) => {
  const [hasError, setHasError] = React.useState(false);
  const [error, setError] = React.useState<Error | null>(null);

  React.useEffect(() => {
    const handleError = (error: ErrorEvent) => {
      setHasError(true);
      setError(new Error(error.message));
    };

    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      setHasError(true);
      setError(new Error(event.reason));
    };

    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []);

  if (hasError) {
    return (
      <div className="w-full max-w-4xl mx-auto p-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Module Error</AlertTitle>
          <AlertDescription>
            Failed to load {moduleName}: {error?.message || 'Unknown error'}
            <br />
            <button 
              onClick={() => {
                setHasError(false);
                setError(null);
                window.location.reload();
              }}
              className="mt-2 text-sm underline"
            >
              Reload page
            </button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return <>{children}</>;
};

// Placeholder component for unimplemented modules
const ModulePlaceholder: React.FC<{ 
  moduleName: string; 
  description: string;
  features?: string[];
}> = ({ moduleName, description, features = [] }) => (
  <div className="w-full max-w-4xl mx-auto p-6">
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertCircle className="h-5 w-5 text-blue-500" />
          {moduleName}
        </CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Module In Development</AlertTitle>
          <AlertDescription>
            This module is currently being developed and will be available soon.
            {features.length > 0 && (
              <div className="mt-3">
                <p className="font-medium mb-2">Planned features:</p>
                <ul className="list-disc list-inside space-y-1">
                  {features.map((feature, index) => (
                    <li key={index} className="text-sm">{feature}</li>
                  ))}
                </ul>
              </div>
            )}
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  </div>
);

const ModuleContentRenderer: React.FC<ModuleContentRendererProps> = ({ 
  module, 
  userRole 
}) => {
  console.log('🎯 Rendering module:', module, 'for role:', userRole);

  const renderModule = () => {
    switch (module) {
      case 'dashboard':
        return (
          <ModuleErrorBoundary moduleName="Dashboard">
            <Suspense fallback={<ModuleLoader moduleName="Dashboard" />}>
              <DashboardModule userRole={userRole} />
            </Suspense>
          </ModuleErrorBoundary>
        );

      case 'announcements':
        return (
          <ModuleErrorBoundary moduleName="Announcements">
            <Suspense fallback={<ModuleLoader moduleName="Announcements" />}>
              <AnnouncementsPage />
            </Suspense>
          </ModuleErrorBoundary>
        );

      case 'products':
        return (
          <ModuleErrorBoundary moduleName="Product Management">
            <Suspense fallback={<ModuleLoader moduleName="Product Management" />}>
              <ProductManagementModule userRole={userRole} />
            </Suspense>
          </ModuleErrorBoundary>
        );

      case 'orders':
        return (
          <ModuleErrorBoundary moduleName="Order Management">
            <Suspense fallback={<ModuleLoader moduleName="Order Management" />}>
              <OrderManagementModule userRole={userRole} />
            </Suspense>
          </ModuleErrorBoundary>
        );

      case 'customers':
        return (
          <ModuleErrorBoundary moduleName="Customer Management">
            <Suspense fallback={<ModuleLoader moduleName="Customer Management" />}>
              <CustomerManagementModule userRole={userRole} />
            </Suspense>
          </ModuleErrorBoundary>
        );

      case 'system-config':
        return (
          <ModuleErrorBoundary moduleName="System Configuration">
            <Suspense fallback={<ModuleLoader moduleName="System Configuration" />}>
              <SystemConfigModule userRole={userRole} />
            </Suspense>
          </ModuleErrorBoundary>
        );

      case 'webhooks':
        return (
          <ModuleErrorBoundary moduleName="Webhook Management">
            <Suspense fallback={<ModuleLoader moduleName="Webhook Management" />}>
              <WebhookLogsModule userRole={userRole} />
            </Suspense>
          </ModuleErrorBoundary>
        );

      // New Users Management Submenu Items
      case 'users-customers':
        return (
          <ModuleErrorBoundary moduleName="Customers Management">
            <Suspense fallback={<ModuleLoader moduleName="Customers Management" />}>
              <CustomersManagement />
            </Suspense>
          </ModuleErrorBoundary>
        );

      case 'users-vendors':
        return (
          <ModuleErrorBoundary moduleName="Vendors Management">
            <Suspense fallback={<ModuleLoader moduleName="Vendors Management" />}>
              <VendorsManagement />
            </Suspense>
          </ModuleErrorBoundary>
        );

      // New Settings Interaction Guide
      case 'settings-interaction':
        return (
          <ModuleErrorBoundary moduleName="Interaction Guide">
            <Suspense fallback={<ModuleLoader moduleName="Interaction Guide" />}>
              <InteractionGuide />
            </Suspense>
          </ModuleErrorBoundary>
        );

      case 'settings-general':
        return (
          <ModulePlaceholder
            moduleName="General Settings"
            description="Basic system configuration and preferences"
            features={[
              'Site information settings',
              'Default configurations',
              'General preferences',
              'System locale settings',
              'Time zone configuration',
              'Basic admin settings'
            ]}
          />
        );

      case 'settings-api':
        return (
          <ModulePlaceholder
            moduleName="API Settings"
            description="API keys, endpoints, and connection settings"
            features={[
              'WordPress API credentials',
              'WooCommerce API keys',
              'Third-party integrations',
              'API rate limiting',
              'Webhook configurations',
              'API security settings'
            ]}
          />
        );

      case 'api-testing':
        return <ComprehensiveAPITester />;
    
      case 'api-explorer':
        return <ComprehensiveAPITester />;
    
      case 'api-integration':
        return <ComprehensiveAPIDemo />;

      case 'analytics':
        return (
          <ModulePlaceholder
            moduleName="Analytics & Insights"
            description="Advanced analytics dashboard with comprehensive reporting"
            features={[
              'Real-time sales analytics',
              'Customer behavior insights',
              'Product performance metrics',
              'Revenue forecasting',
              'Custom report builder',
              'Data export capabilities'
            ]}
          />
        );

      case 'performance':
        return (
          <ModulePlaceholder
            moduleName="Performance Monitoring"
            description="Site performance metrics and optimization tools"
            features={[
              'Page load time monitoring',
              'Database query optimization',
              'Cache performance analysis',
              'API response time tracking',
              'Resource usage monitoring',
              'Performance recommendations'
            ]}
          />
        );

      case 'inventory':
        return (
          <ModulePlaceholder
            moduleName="Inventory Management"
            description="Advanced inventory tracking and management system"
            features={[
              'Real-time stock tracking',
              'Low stock alerts',
              'Bulk inventory updates',
              'Supplier management',
              'Purchase order system',
              'Inventory valuation reports'
            ]}
          />
        );

      case 'shipping':
        return (
          <ModulePlaceholder
            moduleName="Shipping Management"
            description="Comprehensive shipping and logistics management"
            features={[
              'Shipping zone configuration',
              'Rate calculation rules',
              'Carrier integration',
              'Tracking number management',
              'Shipping label generation',
              'Delivery performance analytics'
            ]}
          />
        );

      case 'payments':
        return (
          <ModulePlaceholder
            moduleName="Payment Management"
            description="Payment gateway and transaction management"
            features={[
              'Payment gateway configuration',
              'Transaction monitoring',
              'Refund management',
              'Payment analytics',
              'Fraud detection',
              'Subscription billing'
            ]}
          />
        );

      case 'content':
        return (
          <ModulePlaceholder
            moduleName="Content Management"
            description="WordPress content and media management"
            features={[
              'Post and page management',
              'Media library organization',
              'SEO content optimization',
              'Content scheduling',
              'Bulk content operations',
              'Content performance tracking'
            ]}
          />
        );

      case 'seo':
        return (
          <ModulePlaceholder
            moduleName="SEO & Marketing"
            description="Search engine optimization and marketing tools"
            features={[
              'SEO analysis and recommendations',
              'Keyword tracking',
              'Meta tag management',
              'Sitemap generation',
              'Marketing campaign management',
              'Social media integration'
            ]}
          />
        );

      case 'reviews':
        return (
          <ModulePlaceholder
            moduleName="Review Management"
            description="Customer review and rating management system"
            features={[
              'Review moderation tools',
              'Rating analytics',
              'Review response management',
              'Fake review detection',
              'Review widgets',
              'Customer feedback insights'
            ]}
          />
        );

      case 'users':
        return (
          <ModulePlaceholder
            moduleName="User Management"
            description="Admin and vendor account management"
            features={[
              'User role management',
              'Permission system',
              'Vendor onboarding',
              'User activity monitoring',
              'Bulk user operations',
              'User analytics'
            ]}
          />
        );

      case 'security':
        return (
          <ModulePlaceholder
            moduleName="Security Management"
            description="Security monitoring and protection systems"
            features={[
              'Security scan results',
              'Login attempt monitoring',
              'IP blocking management',
              'Security alerts',
              'SSL certificate monitoring',
              'Backup management'
            ]}
          />
        );

      case 'notifications':
        return (
          <ModulePlaceholder
            moduleName="Notification Center"
            description="System alerts and notification management"
            features={[
              'Real-time notifications',
              'Email notification settings',
              'Push notification management',
              'Alert customization',
              'Notification history',
              'Notification analytics'
            ]}
          />
        );

      default:
        return (
          <div className="w-full max-w-4xl mx-auto p-6">
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Module Not Found</AlertTitle>
              <AlertDescription>
                The requested module "{module}" does not exist or is not implemented yet.
                <br />
                Please select a different module from the sidebar.
              </AlertDescription>
            </Alert>
          </div>
        );
    }
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="animate-fade-in">
        {renderModule()}
      </div>
    </div>
  );
};

export default ModuleContentRenderer;