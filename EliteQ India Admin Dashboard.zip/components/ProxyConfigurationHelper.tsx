import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { 
  Server, Globe, CheckCircle, XCircle, AlertTriangle, 
  Copy, ExternalLink, Settings, Code, Zap
} from 'lucide-react';

interface ProxyStatus {
  url: string;
  available: boolean;
  tested: boolean;
  error?: string;
  latency?: number;
}

export const ProxyConfigurationHelper: React.FC = () => {
  const [proxyStatuses, setProxyStatuses] = useState<ProxyStatus[]>([]);
  const [testing, setTesting] = useState(false);
  const [currentProxy, setCurrentProxy] = useState<string | null>(null);

  // Common proxy URL patterns to test
  const getProxyUrls = () => {
    if (typeof window === 'undefined') return [];
    
    const origin = window.location.origin;
    const hostname = window.location.hostname;
    
    return [
      `${origin}/api/woocommerce-proxy`,
      `${origin}/functions/v1/woocommerce-proxy`,
      `https://${hostname.replace('.', '-')}.supabase.co/functions/v1/woocommerce-proxy`,
      `https://your-project.supabase.co/functions/v1/woocommerce-proxy`,
      // Add your actual Supabase function URL here
    ];
  };

  const testProxyUrl = async (url: string): Promise<ProxyStatus> => {
    const startTime = Date.now();
    
    try {
      console.log(`🧪 Testing proxy URL: ${url}`);
      
      const response = await fetch(url.replace('/woocommerce-proxy', '/woocommerce-health'), {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        mode: 'cors',
        signal: AbortSignal.timeout(10000), // 10 second timeout
      });

      const latency = Date.now() - startTime;
      
      if (response.ok) {
        const data = await response.json();
        return {
          url,
          available: data.healthy === true,
          tested: true,
          latency,
          error: data.healthy ? undefined : data.error
        };
      } else {
        return {
          url,
          available: false,
          tested: true,
          latency,
          error: `HTTP ${response.status}: ${response.statusText}`
        };
      }
    } catch (error) {
      const latency = Date.now() - startTime;
      return {
        url,
        available: false,
        tested: true,
        latency,
        error: error instanceof Error ? error.message : 'Connection failed'
      };
    }
  };

  const testAllProxies = async () => {
    setTesting(true);
    const urls = getProxyUrls();
    
    console.log('🔍 Testing all proxy URLs...');
    
    const results = await Promise.all(
      urls.map(url => testProxyUrl(url))
    );
    
    setProxyStatuses(results);
    
    // Find the first working proxy
    const workingProxy = results.find(result => result.available);
    if (workingProxy) {
      setCurrentProxy(workingProxy.url);
      console.log(`✅ Found working proxy: ${workingProxy.url}`);
    }
    
    setTesting(false);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const getStatusIcon = (status: ProxyStatus) => {
    if (!status.tested) {
      return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    }
    
    return status.available 
      ? <CheckCircle className="h-4 w-4 text-green-500" />
      : <XCircle className="h-4 w-4 text-red-500" />;
  };

  const getStatusBadge = (status: ProxyStatus) => {
    if (!status.tested) {
      return <Badge variant="outline" className="text-yellow-600">Untested</Badge>;
    }
    
    if (status.available) {
      return (
        <Badge variant="outline" className="text-green-600 border-green-300 bg-green-50">
          Available ({status.latency}ms)
        </Badge>
      );
    } else {
      return <Badge variant="outline" className="text-red-600 border-red-300 bg-red-50">Unavailable</Badge>;
    }
  };

  useEffect(() => {
    // Auto-test on mount
    testAllProxies();
  }, []);

  return (
    <Card className="border-blue-200 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Server className="h-5 w-5 text-blue-600" />
            <CardTitle className="text-lg">Proxy Configuration</CardTitle>
            <Badge variant="outline" className="text-blue-600">
              CORS Bypass
            </Badge>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={testAllProxies}
            disabled={testing}
          >
            {testing ? (
              <>
                <Settings className="h-4 w-4 mr-2 animate-spin" />
                Testing...
              </>
            ) : (
              <>
                <Zap className="h-4 w-4 mr-2" />
                Test Proxies
              </>
            )}
          </Button>
        </div>
        
        <p className="text-sm text-gray-600">
          To bypass CORS restrictions, a server-side proxy is required. Test and configure your proxy endpoints below.
        </p>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Current Active Proxy */}
        {currentProxy && (
          <Alert className="border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription>
              <div className="font-medium text-green-800 mb-1">Active Proxy Found</div>
              <div className="text-sm text-green-700">
                Using: <code className="bg-green-100 px-1 rounded">{currentProxy}</code>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Proxy Status List */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm text-gray-700">Proxy Endpoints</h4>
          
          {proxyStatuses.length === 0 ? (
            <div className="text-center py-4 text-gray-500">
              Click "Test Proxies" to check available endpoints
            </div>
          ) : (
            proxyStatuses.map((status, index) => (
              <div
                key={index}
                className={`p-3 rounded-lg border-2 transition-all duration-200 ${
                  status.available
                    ? 'border-green-200 bg-green-50'
                    : status.tested
                    ? 'border-red-200 bg-red-50'
                    : 'border-gray-200 bg-gray-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {getStatusIcon(status)}
                    <div className="min-w-0 flex-1">
                      <div className="font-mono text-sm truncate">
                        {status.url}
                      </div>
                      {status.error && (
                        <div className="text-xs text-red-600 mt-1">
                          {status.error}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {getStatusBadge(status)}
                    
                    {status.available && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(status.url)}
                        title="Copy URL"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Setup Instructions */}
        <div className="border-t pt-4">
          <h4 className="font-medium text-sm text-gray-700 mb-3">Setup Instructions</h4>
          
          <div className="space-y-3 text-sm">
            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="font-medium text-blue-800 mb-2">1. Deploy Supabase Function</div>
              <div className="text-blue-700">
                Deploy the WooCommerce proxy function to your Supabase project:
              </div>
              <div className="mt-2 bg-blue-100 p-2 rounded font-mono text-xs">
                supabase functions deploy woocommerce-proxy
              </div>
            </div>
            
            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="font-medium text-blue-800 mb-2">2. Update Configuration</div>
              <div className="text-blue-700">
                Update the PROXY_BASE_URL in your WooCommerce API utility with your function URL.
              </div>
            </div>
            
            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="font-medium text-blue-800 mb-2">3. Environment Variables</div>
              <div className="text-blue-700">
                Set these variables in your Supabase function:
              </div>
              <div className="mt-2 space-y-1">
                <div className="bg-blue-100 p-2 rounded font-mono text-xs">
                  WOOCOMMERCE_CONSUMER_KEY=ck_786cbc76a16a3ab8c7c9e805f5f69439de83d007
                </div>
                <div className="bg-blue-100 p-2 rounded font-mono text-xs">
                  WOOCOMMERCE_CONSUMER_SECRET=cs_633949961018ed5aacef954ddd4587eee96619b7
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* No Working Proxy Alert */}
        {proxyStatuses.length > 0 && !currentProxy && (
          <Alert className="border-orange-200 bg-orange-50">
            <AlertTriangle className="h-4 w-4 text-orange-600" />
            <AlertDescription>
              <div className="font-medium text-orange-800 mb-1">No Working Proxy Found</div>
              <div className="text-sm text-orange-700 space-y-1">
                <div>• Deploy the Supabase function using the instructions above</div>
                <div>• Check your Supabase project configuration</div>
                <div>• Verify function URL in browser console</div>
                <div>• Contact support if issues persist</div>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Documentation Link */}
        <div className="pt-2 border-t">
          <Button
            variant="ghost"
            size="sm"
            className="text-blue-600 hover:text-blue-800"
            onClick={() => window.open('https://supabase.com/docs/guides/functions', '_blank')}
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Supabase Functions Documentation
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};