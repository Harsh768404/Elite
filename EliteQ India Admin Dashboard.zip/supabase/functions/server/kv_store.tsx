// Simple Key-Value Store for Deno Deploy
// This provides basic storage functionality for caching and temporary data

const kvStore = new Map<string, string>();

export const get = async (key: string): Promise<string | null> => {
  try {
    return kvStore.get(key) || null;
  } catch (error) {
    console.error('KV Store get error:', error);
    return null;
  }
};

export const set = async (key: string, value: string): Promise<boolean> => {
  try {
    kvStore.set(key, value);
    return true;
  } catch (error) {
    console.error('KV Store set error:', error);
    return false;
  }
};

export const del = async (key: string): Promise<boolean> => {
  try {
    return kvStore.delete(key);
  } catch (error) {
    console.error('KV Store delete error:', error);
    return false;
  }
};

export const getByPrefix = async (prefix: string): Promise<string[]> => {
  try {
    const results: string[] = [];
    for (const [key, value] of kvStore.entries()) {
      if (key.startsWith(prefix)) {
        results.push(value);
      }
    }
    return results;
  } catch (error) {
    console.error('KV Store getByPrefix error:', error);
    return [];
  }
};

export const keys = async (): Promise<string[]> => {
  try {
    return Array.from(kvStore.keys());
  } catch (error) {
    console.error('KV Store keys error:', error);
    return [];
  }
};

export const clear = async (): Promise<boolean> => {
  try {
    kvStore.clear();
    return true;
  } catch (error) {
    console.error('KV Store clear error:', error);
    return false;
  }
};

export const size = (): number => {
  return kvStore.size;
};