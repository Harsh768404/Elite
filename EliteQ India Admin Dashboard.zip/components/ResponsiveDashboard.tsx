// This component is no longer needed as the responsive functionality 
// has been integrated directly into the main App component