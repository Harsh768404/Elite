import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { CheckCircle, XCircle, AlertCircle, Globe, Key, Shield, RefreshCw } from 'lucide-react';
import { envHelpers, envConfig } from '../utils/env-config';

export const EliteQCredentialStatus: React.FC = () => {
  const [refreshing, setRefreshing] = React.useState(false);
  const [lastRefresh, setLastRefresh] = React.useState<Date | null>(null);
  
  const envStatus = envHelpers.testEnvAccess();
  const maskedCredentials = envHelpers.getMaskedCredentials();
  
  const hasWooCommerce = envHelpers.hasWooCommerceCredentials();
  const hasWordPressJWT = envHelpers.hasWordPressJWTCredentials();
  
  // Additional checks for window.ENV
  const windowEnvCheck = React.useMemo(() => {
    if (typeof window !== 'undefined' && (window as any).ENV) {
      return {
        hasWindowEnv: true,
        keys: Object.keys((window as any).ENV),
        wcKey: !!(window as any).ENV.WOOCOMMERCE_CONSUMER_KEY,
        wcSecret: !!(window as any).ENV.WOOCOMMERCE_CONSUMER_SECRET,
        wpUrl: !!(window as any).ENV.WORDPRESS_BASE_URL,
        jwtKey: !!(window as any).ENV.JWT_AUTH_SECRET_KEY
      };
    }
    return { hasWindowEnv: false };
  }, [lastRefresh]);
  
  const refreshEnvironment = async () => {
    setRefreshing(true);
    try {
      // Reinitialize environment
      if (typeof window !== 'undefined') {
        if (!(window as any).ENV) {
          (window as any).ENV = {};
        }
        
        // Set EliteQ credentials explicitly
        (window as any).ENV.WOOCOMMERCE_CONSUMER_KEY = 'ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9';
        (window as any).ENV.WOOCOMMERCE_CONSUMER_SECRET = 'cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3';
        (window as any).ENV.WORDPRESS_BASE_URL = 'https://eliteq.in';
        (window as any).ENV.JWT_AUTH_SECRET_KEY = '9=<QX7=<(iLPhXh[G21AjCh#x-{%z)jA;FK]bRFpQT4jx?x+3l${m,IGCcVx&}Hm';
        (window as any).ENV.WOOCOMMERCE_WEBHOOK_SECRET = 'Du83&G.64ti/5a#plclUwhF;WIjsQEHy_>hdFQ-/pv/CLJ$s#0';
        
        // Set aliases
        (window as any).ENV.CONSUMER_KEY = (window as any).ENV.WOOCOMMERCE_CONSUMER_KEY;
        (window as any).ENV.CONSUMER_SECRET = (window as any).ENV.WOOCOMMERCE_CONSUMER_SECRET;
        
        console.log('🔄 Environment refreshed manually');
      }
      
      envHelpers.initializeWindowEnv();
      setLastRefresh(new Date());
    } catch (error) {
      console.error('Failed to refresh environment:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const getStatusIcon = (isConfigured: boolean) => {
    if (isConfigured) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    }
    return <XCircle className="h-4 w-4 text-red-500" />;
  };

  const getStatusBadge = (isConfigured: boolean, text: string) => {
    if (isConfigured) {
      return <Badge className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">{text}</Badge>;
    }
    return <Badge variant="destructive">{text}</Badge>;
  };

  const credentialStatus = [
    {
      name: 'WordPress Base URL',
      value: envConfig.WORDPRESS_BASE_URL,
      configured: !!envConfig.WORDPRESS_BASE_URL,
      masked: false
    },
    {
      name: 'WooCommerce Consumer Key',
      value: maskedCredentials.WOOCOMMERCE_CONSUMER_KEY,
      configured: maskedCredentials.WOOCOMMERCE_CONSUMER_KEY !== 'Not configured',
      masked: true
    },
    {
      name: 'WooCommerce Consumer Secret',
      value: maskedCredentials.WOOCOMMERCE_CONSUMER_SECRET,
      configured: maskedCredentials.WOOCOMMERCE_CONSUMER_SECRET !== 'Not configured',
      masked: true
    },
    {
      name: 'JWT Auth Secret Key',
      value: maskedCredentials.JWT_AUTH_SECRET_KEY,
      configured: maskedCredentials.JWT_AUTH_SECRET_KEY !== 'Not configured',
      masked: true
    },
    {
      name: 'Webhook Secret',
      value: maskedCredentials.WOOCOMMERCE_WEBHOOK_SECRET,
      configured: maskedCredentials.WOOCOMMERCE_WEBHOOK_SECRET !== 'Not configured',
      masked: true
    }
  ];

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-blue-600" />
              EliteQ India Credential Status
            </CardTitle>
            <CardDescription>
              Current configuration status for EliteQ.in WordPress and WooCommerce integration
            </CardDescription>
          </div>
          <Button 
            onClick={refreshEnvironment} 
            disabled={refreshing}
            variant="outline"
            size="sm"
          >
            {refreshing ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                Refreshing...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Overall Status */}
        <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <div className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-blue-600" />
            <span className="font-medium">EliteQ.in Integration</span>
          </div>
          <div className="flex items-center gap-2">
            {getStatusIcon(hasWooCommerce && hasWordPressJWT)}
            {getStatusBadge(
              hasWooCommerce && hasWordPressJWT, 
              hasWooCommerce && hasWordPressJWT ? 'Ready' : 'Configuration Required'
            )}
          </div>
        </div>

        {/* WordPress URL Display */}
        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700">
          <div className="flex items-center gap-2 mb-2">
            <Globe className="h-4 w-4 text-blue-600" />
            <span className="font-medium text-blue-900 dark:text-blue-100">WordPress Site</span>
          </div>
          <p className="text-blue-800 dark:text-blue-200 font-mono text-lg">
            {envConfig.WORDPRESS_BASE_URL || 'Not configured'}
          </p>
        </div>

        {/* Credential Details */}
        <div className="space-y-3">
          {credentialStatus.map((cred, index) => (
            <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                {getStatusIcon(cred.configured)}
                <div>
                  <span className="font-medium text-sm">{cred.name}</span>
                  {cred.masked && (
                    <div className="text-xs text-gray-500 mt-1 font-mono">
                      {cred.value}
                    </div>
                  )}
                  {!cred.masked && cred.value && (
                    <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {cred.value}
                    </div>
                  )}
                </div>
              </div>
              <div>
                {getStatusBadge(cred.configured, cred.configured ? 'Configured' : 'Missing')}
              </div>
            </div>
          ))}
        </div>

        {/* API Readiness Status */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className={`p-4 rounded-lg border ${hasWooCommerce ? 'bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-700' : 'bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-700'}`}>
            <div className="flex items-center gap-2 mb-2">
              {getStatusIcon(hasWooCommerce)}
              <span className="font-medium">WooCommerce API</span>
            </div>
            <p className={`text-sm ${hasWooCommerce ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
              {hasWooCommerce 
                ? 'Ready to connect to EliteQ.in store' 
                : 'Consumer key/secret required'
              }
            </p>
          </div>

          <div className={`p-4 rounded-lg border ${hasWordPressJWT ? 'bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-700' : 'bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-700'}`}>
            <div className="flex items-center gap-2 mb-2">
              {getStatusIcon(hasWordPressJWT)}
              <span className="font-medium">WordPress JWT Auth</span>
            </div>
            <p className={`text-sm ${hasWordPressJWT ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
              {hasWordPressJWT 
                ? 'Ready to authenticate users' 
                : 'JWT secret key required'
              }
            </p>
          </div>
        </div>

        {/* Environment Debug Info */}
        <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="h-4 w-4 text-orange-500" />
            <span className="font-medium text-sm">Environment Debug Info</span>
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
            <div>Environment Access: {envStatus.success ? '✅ OK' : '❌ Failed'}</div>
            <div>Variables Found: {envStatus.details.variablesFound || 0} / {envStatus.details.totalVariables || 0}</div>
            <div>Window ENV: {envStatus.details.windowEnvSet ? '✅ Available' : '❌ Not Set'}</div>
            <div>Process ENV: {envStatus.details.canAccessProcess ? '✅ Available' : '❌ Not Available'}</div>
            {windowEnvCheck.hasWindowEnv && (
              <>
                <div>Window ENV Keys: {windowEnvCheck.keys?.length || 0}</div>
                <div>WC Key in Window: {windowEnvCheck.wcKey ? '✅' : '❌'}</div>
                <div>WC Secret in Window: {windowEnvCheck.wcSecret ? '✅' : '❌'}</div>
                <div>WP URL in Window: {windowEnvCheck.wpUrl ? '✅' : '❌'}</div>
                <div>JWT Key in Window: {windowEnvCheck.jwtKey ? '✅' : '❌'}</div>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default EliteQCredentialStatus;