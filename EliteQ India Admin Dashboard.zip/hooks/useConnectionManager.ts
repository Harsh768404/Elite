import { useState, useEffect } from 'react';
import { ConnectionStatus } from '../types/app-types';
import { connectionTest } from '../utils/jwt-auth';

export const useConnectionManager = (jwtToken: string | null) => {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>({
    wordpress: false,
    woocommerce: false,
    woocommercePermissions: false,
    wpUsersPermissions: false,
    webhooks: false,
    jwt: false
  });
  const [isConnecting, setIsConnecting] = useState(false);
  const [showPermissionBanner, setShowPermissionBanner] = useState(false);
  const [lastSync, setLastSync] = useState<Date | null>(null);

  // Enhanced connection testing with detailed status tracking
  useEffect(() => {
    const testLiveConnection = async () => {
      if (jwtToken) {
        console.log('🧪 Testing live connections with detailed status tracking...');
        setIsConnecting(true);
        
        try {
          const results = await connectionTest.testAllConnections(jwtToken);
          
          console.log('📊 Connection test results:', results);
          
          const newStatus: ConnectionStatus = {
            wordpress: results.wordpress || false,
            woocommerce: results.woocommerce || false,
            woocommercePermissions: results.woocommercePermissions || false,
            wpUsersPermissions: results.wpUsersPermissions || false,
            webhooks: results.webhooks || false,
            jwt: results.jwt || false
          };
          
          setConnectionStatus(newStatus);
          
          // Show permission banner if WordPress works but WooCommerce doesn't
          if (newStatus.wordpress && newStatus.jwt && !newStatus.woocommercePermissions) {
            setShowPermissionBanner(true);
            console.log('⚠️ WordPress connected but WooCommerce permissions needed');
          } else {
            setShowPermissionBanner(false);
          }
          
          setLastSync(new Date());
          
        } catch (error) {
          console.error('🚨 Connection test failed:', error);
          // Set partial status - some connections might work
          setConnectionStatus(prev => ({
            ...prev,
            wordpress: false,
            jwt: false
          }));
        } finally {
          setIsConnecting(false);
        }
      }
    };

    testLiveConnection();
  }, [jwtToken]);

  const handleManualSync = async () => {
    console.log('🔄 Manual sync with live WordPress triggered');
    
    if (jwtToken) {
      setIsConnecting(true);
      try {
        const results = await connectionTest.testAllConnections(jwtToken);
        const newStatus: ConnectionStatus = {
          wordpress: results.wordpress || false,
          woocommerce: results.woocommerce || false,
          woocommercePermissions: results.woocommercePermissions || false,
          wpUsersPermissions: results.wpUsersPermissions || false,
          webhooks: results.webhooks || false,
          jwt: results.jwt || false
        };
        
        setConnectionStatus(newStatus);
        setLastSync(new Date());
        
        // Update permission banner
        if (newStatus.wordpress && newStatus.jwt && !newStatus.woocommercePermissions) {
          setShowPermissionBanner(true);
        } else {
          setShowPermissionBanner(false);
        }
        
        console.log('✅ Manual sync completed');
      } catch (error) {
        console.error('🚨 Manual sync failed:', error);
      } finally {
        setIsConnecting(false);
      }
    }
  };

  return {
    connectionStatus,
    isConnecting,
    showPermissionBanner,
    setShowPermissionBanner,
    lastSync,
    setLastSync,
    handleManualSync
  };
};