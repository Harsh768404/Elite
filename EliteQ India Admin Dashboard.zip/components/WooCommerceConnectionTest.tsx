import React, { useState, useEffect } from 'react';
import { 
  RefreshCw, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Settings, 
  Eye, 
  EyeOff,
  Info,
  ExternalLink,
  Copy,
  Check,
  Wrench
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { wooCommerceApi, wooCommerceConfig, WooCommerceApiError } from '../utils/woocommerce-api';
import EnvironmentDebugPanel from './EnvironmentDebugPanel';

interface ConnectionTestResult {
  isConnected: boolean;
  error?: string;
  latency?: number;
  details?: any;
  timestamp?: string;
}

interface CredentialInfo {
  name: string;
  value: string;
  isSet: boolean;
  preview: string;
}

export const WooCommerceConnectionTest: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState<ConnectionTestResult | null>(null);
  const [showCredentials, setShowCredentials] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  // Get credential information
  const getCredentialInfo = (): CredentialInfo[] => {
    const getEnvVar = (name: string): string => {
      try {
        if (typeof window !== 'undefined' && (window as any).ENV?.[name]) {
          return (window as any).ENV[name];
        }
        if (typeof process !== 'undefined' && process.env?.[name]) {
          return process.env[name];
        }
      } catch (error) {
        console.warn(`⚠️ Could not access environment variable ${name}:`, error);
      }
      return '';
    };

    const consumerKey = getEnvVar('WOOCOMMERCE_CONSUMER_KEY');
    const consumerSecret = getEnvVar('WOOCOMMERCE_CONSUMER_SECRET');

    return [
      {
        name: 'Consumer Key',
        value: consumerKey,
        isSet: !!consumerKey,
        preview: consumerKey ? `${consumerKey.substring(0, 10)}...${consumerKey.slice(-4)}` : 'Not set'
      },
      {
        name: 'Consumer Secret',
        value: consumerSecret,
        isSet: !!consumerSecret,
        preview: consumerSecret ? `${consumerSecret.substring(0, 10)}...${consumerSecret.slice(-4)}` : 'Not set'
      }
    ];
  };

  const testConnection = async () => {
    setIsLoading(true);
    setTestResult(null);

    try {
      console.log('🔍 ===== STARTING WOOCOMMERCE CONNECTION TEST =====');
      
      const result = await wooCommerceApi.testConnection();
      
      console.log('✅ Connection test result:', result);
      
      setTestResult({
        ...result,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('❌ Connection test failed:', error);
      
      let errorMessage = 'Unknown error occurred';
      let details = null;
      
      if (error instanceof WooCommerceApiError) {
        errorMessage = error.message;
        details = {
          status: error.status,
          code: error.code,
          response: error.response
        };
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      setTestResult({
        isConnected: false,
        error: errorMessage,
        details,
        timestamp: new Date().toISOString()
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(type);
      setTimeout(() => setCopied(null), 2000);
    } catch (error) {
      console.error('Failed to copy to clipboard:', error);
    }
  };

  // Auto-test connection on component mount
  useEffect(() => {
    testConnection();
  }, []);

  const credentials = getCredentialInfo();
  const allCredentialsSet = credentials.every(cred => cred.isSet);

  const getStatusIcon = (status: 'success' | 'error' | 'warning' | 'loading') => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-orange-500" />;
      case 'loading':
        return <RefreshCw className="h-5 w-5 text-blue-500 animate-spin" />;
      default:
        return <Info className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusBadge = () => {
    if (isLoading) {
      return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Testing...</Badge>;
    }

    if (!testResult) {
      return <Badge variant="outline">Unknown</Badge>;
    }

    if (testResult.isConnected) {
      return <Badge className="bg-green-100 text-green-800 border-green-200">Connected</Badge>;
    }

    return <Badge className="bg-red-100 text-red-800 border-red-200">Disconnected</Badge>;
  };

  return (
    <div className="w-full space-y-6">
      
      {/* Main Connection Test Card */}
      <Card className="w-full">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              WooCommerce API Connection
            </CardTitle>
            {getStatusBadge()}
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
        
        {/* Connection Status */}
        <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
          <div className="flex items-center gap-3">
            {isLoading 
              ? getStatusIcon('loading')
              : testResult?.isConnected 
              ? getStatusIcon('success')
              : getStatusIcon('error')
            }
            <div>
              <div className="font-medium">
                {isLoading 
                  ? 'Testing connection...'
                  : testResult?.isConnected 
                  ? 'Connection successful'
                  : 'Connection failed'
                }
              </div>
              {testResult?.latency && (
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Response time: {testResult.latency}ms
                </div>
              )}
            </div>
          </div>
          
          <Button 
            onClick={testConnection} 
            disabled={isLoading}
            variant="outline"
            size="sm"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            {isLoading ? 'Testing...' : 'Retest'}
          </Button>
        </div>

        {/* Error Message */}
        {testResult?.error && !testResult.isConnected && (
          <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20">
            <XCircle className="h-4 w-4" />
            <AlertDescription className="ml-2">
              <strong>Error:</strong> {testResult.error}
            </AlertDescription>
          </Alert>
        )}

        {/* Credentials Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-medium">API Credentials</h3>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowCredentials(!showCredentials)}
            >
              {showCredentials ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              {showCredentials ? 'Hide' : 'Show'}
            </Button>
          </div>

          <div className="space-y-3">
            {credentials.map((cred) => (
              <div key={cred.name} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                <div className="flex items-center gap-3">
                  {cred.isSet ? getStatusIcon('success') : getStatusIcon('error')}
                  <div>
                    <div className="font-medium">{cred.name}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400 font-mono">
                      {showCredentials ? cred.value || 'Not set' : cred.preview}
                    </div>
                  </div>
                </div>

                {cred.isSet && showCredentials && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(cred.value, cred.name)}
                  >
                    {copied === cred.name ? (
                      <Check className="h-4 w-4 text-green-500" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                )}
              </div>
            ))}
          </div>

          {!allCredentialsSet && (
            <Alert className="border-orange-200 bg-orange-50 dark:bg-orange-900/20">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="ml-2">
                Some API credentials are missing. Please set the <code>WOOCOMMERCE_CONSUMER_KEY</code> and <code>WOOCOMMERCE_CONSUMER_SECRET</code> environment variables.
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* API Configuration */}
        <div className="space-y-3">
          <h3 className="font-medium">API Configuration</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
              <div className="text-sm font-medium text-gray-600 dark:text-gray-400">Base URL</div>
              <div className="font-mono text-sm break-all">{wooCommerceConfig.baseUrl}</div>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
              <div className="text-sm font-medium text-gray-600 dark:text-gray-400">API URL</div>
              <div className="font-mono text-sm break-all">{wooCommerceConfig.apiUrl}</div>
            </div>
          </div>
        </div>

        {/* Advanced Details */}
        {testResult && (
          <Collapsible open={showDetails} onOpenChange={setShowDetails}>
            <CollapsibleTrigger asChild>
              <Button variant="outline" className="w-full">
                <Info className="h-4 w-4 mr-2" />
                {showDetails ? 'Hide' : 'Show'} Technical Details
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-4 pt-4">
              <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                <pre className="text-xs overflow-auto">
                  {JSON.stringify(testResult, null, 2)}
                </pre>
              </div>
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Troubleshooting Tips */}
        <div className="space-y-3">
          <h3 className="font-medium">Troubleshooting Tips</h3>
          <div className="space-y-2 text-sm">
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <div>Ensure WooCommerce is installed and active on your WordPress site</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <div>Check API keys in WordPress Admin → WooCommerce → Settings → Advanced → REST API</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <div>Verify API keys have read/write permissions</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <div>Ensure your WordPress site is accessible over HTTPS</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <div>Check that there are no server-side restrictions blocking the API</div>
            </div>
          </div>
        </div>

        {/* External Links */}
        <div className="flex gap-2">
          <Button variant="outline" size="sm" asChild>
            <a href="https://eliteq.in/wp-admin/admin.php?page=wc-settings&tab=advanced&section=keys" target="_blank" rel="noopener noreferrer">
              <ExternalLink className="h-4 w-4 mr-2" />
              WooCommerce API Settings
            </a>
          </Button>
          <Button variant="outline" size="sm" asChild>
            <a href="https://woocommerce.github.io/woocommerce-rest-api-docs/" target="_blank" rel="noopener noreferrer">
              <ExternalLink className="h-4 w-4 mr-2" />
              API Documentation
            </a>
          </Button>
        </div>

      </CardContent>
    </Card>

    {/* Comprehensive Diagnostics Tabs */}
    <Tabs defaultValue="environment" className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="environment" className="flex items-center gap-2">
          <Wrench className="h-4 w-4" />
          Environment Debug
        </TabsTrigger>
        <TabsTrigger value="troubleshooting" className="flex items-center gap-2">
          <Info className="h-4 w-4" />
          Advanced Help
        </TabsTrigger>
      </TabsList>

      <TabsContent value="environment" className="mt-4">
        <EnvironmentDebugPanel />
      </TabsContent>

      <TabsContent value="troubleshooting" className="mt-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5" />
              Common Issues & Solutions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            
            {/* Authentication Errors */}
            <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-700">
              <h3 className="font-medium text-red-900 dark:text-red-100 mb-2">
                401 Authentication Errors
              </h3>
              <div className="space-y-2 text-sm text-red-800 dark:text-red-300">
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>Check that WOOCOMMERCE_CONSUMER_KEY and WOOCOMMERCE_CONSUMER_SECRET are correctly set</div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>Verify API keys exist in WordPress Admin → WooCommerce → Settings → Advanced → REST API</div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>Ensure API keys have read/write permissions</div>
                </div>
              </div>
            </div>

            {/* Network Errors */}
            <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg border border-orange-200 dark:border-orange-700">
              <h3 className="font-medium text-orange-900 dark:text-orange-100 mb-2">
                Network Connection Issues
              </h3>
              <div className="space-y-2 text-sm text-orange-800 dark:text-orange-300">
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>Verify that https://eliteq.in is accessible and loading properly</div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>Check for CORS restrictions that might block API requests</div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>Ensure SSL certificate is valid and HTTPS is working</div>
                </div>
              </div>
            </div>

            {/* Environment Setup */}
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700">
              <h3 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
                Environment Configuration
              </h3>
              <div className="space-y-2 text-sm text-blue-800 dark:text-blue-300">
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>Environment variables must be set at build time or runtime</div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>In development, check your .env file contains the required variables</div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>In production, ensure environment variables are set in your hosting platform</div>
                </div>
              </div>
            </div>

            {/* WordPress Setup */}
            <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-700">
              <h3 className="font-medium text-green-900 dark:text-green-100 mb-2">
                WordPress/WooCommerce Setup
              </h3>
              <div className="space-y-2 text-sm text-green-800 dark:text-green-300">
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>WooCommerce plugin must be installed and activated</div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>REST API must be enabled in WooCommerce settings</div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <div>WordPress permalink structure should not be "Plain"</div>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div className="flex flex-wrap gap-2 pt-4">
              <Button variant="outline" size="sm" asChild>
                <a href="https://eliteq.in/wp-admin/admin.php?page=wc-settings&tab=advanced&section=keys" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  WooCommerce API Keys
                </a>
              </Button>
              <Button variant="outline" size="sm" asChild>
                <a href="https://woocommerce.github.io/woocommerce-rest-api-docs/" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  API Documentation
                </a>
              </Button>
              <Button variant="outline" size="sm" asChild>
                <a href="https://eliteq.in/wp-admin/" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  WordPress Admin
                </a>
              </Button>
            </div>

          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>

    </div>
  );
};

export default WooCommerceConnectionTest;