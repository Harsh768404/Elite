import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { MoreHorizontal, Eye, Edit, Trash2 } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';

interface Order {
  id: string;
  date: string;
  customer: string;
  amount: string;
  status: 'completed' | 'processing' | 'pending' | 'cancelled';
  items: number;
}

const recentOrders: Order[] = [
  {
    id: '#ORD-001',
    date: '2024-01-15',
    customer: 'Rajesh Kumar',
    amount: '₹15,280',
    status: 'completed',
    items: 3
  },
  {
    id: '#ORD-002',
    date: '2024-01-15',
    customer: 'Priya Sharma',
    amount: '₹8,950',
    status: 'processing',
    items: 2
  },
  {
    id: '#ORD-003',
    date: '2024-01-14',
    customer: 'Amit Patel',
    amount: '₹23,740',
    status: 'pending',
    items: 5
  },
  {
    id: '#ORD-004',
    date: '2024-01-14',
    customer: 'Sunita Gupta',
    amount: '₹5,680',
    status: 'completed',
    items: 1
  },
  {
    id: '#ORD-005',
    date: '2024-01-13',
    customer: 'Vikram Singh',
    amount: '₹12,450',
    status: 'cancelled',
    items: 2
  }
];

function getStatusBadge(status: Order['status']) {
  const variants = {
    completed: 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400',
    processing: 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400',
    pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400',
    cancelled: 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
  };

  const labels = {
    completed: 'Completed',
    processing: 'Processing',
    pending: 'Pending',
    cancelled: 'Cancelled'
  };

  return (
    <Badge variant="secondary" className={variants[status]}>
      {labels[status]}
    </Badge>
  );
}

export function RecentOrdersTable() {
  const handleViewOrder = (orderId: string) => {
    console.log('Viewing order:', orderId);
  };

  const handleEditOrder = (orderId: string) => {
    console.log('Editing order:', orderId);
  };

  const handleDeleteOrder = (orderId: string) => {
    console.log('Deleting order:', orderId);
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">
            Recent Orders
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Latest orders from your marketplace
          </p>
        </div>
        <Button variant="outline" size="sm">
          View All
        </Button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="border-b border-gray-200 dark:border-gray-700">
            <tr>
              <th className="text-left py-3 px-2 text-sm font-medium text-gray-900 dark:text-white">
                Order ID
              </th>
              <th className="text-left py-3 px-2 text-sm font-medium text-gray-900 dark:text-white">
                Date
              </th>
              <th className="text-left py-3 px-2 text-sm font-medium text-gray-900 dark:text-white">
                Customer
              </th>
              <th className="text-left py-3 px-2 text-sm font-medium text-gray-900 dark:text-white">
                Amount
              </th>
              <th className="text-left py-3 px-2 text-sm font-medium text-gray-900 dark:text-white">
                Status
              </th>
              <th className="text-left py-3 px-2 text-sm font-medium text-gray-900 dark:text-white">
                Items
              </th>
              <th className="text-right py-3 px-2 text-sm font-medium text-gray-900 dark:text-white">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {recentOrders.map((order) => (
              <tr 
                key={order.id}
                className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors duration-150"
              >
                <td className="py-4 px-2">
                  <span className="text-sm font-medium text-blue-600 dark:text-blue-400">
                    {order.id}
                  </span>
                </td>
                <td className="py-4 px-2">
                  <span className="text-sm text-gray-900 dark:text-gray-300">
                    {new Date(order.date).toLocaleDateString('en-IN')}
                  </span>
                </td>
                <td className="py-4 px-2">
                  <span className="text-sm text-gray-900 dark:text-gray-300">
                    {order.customer}
                  </span>
                </td>
                <td className="py-4 px-2">
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    {order.amount}
                  </span>
                </td>
                <td className="py-4 px-2">
                  {getStatusBadge(order.status)}
                </td>
                <td className="py-4 px-2">
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {order.items} items
                  </span>
                </td>
                <td className="py-4 px-2 text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleViewOrder(order.id)}>
                        <Eye className="h-4 w-4 mr-2" />
                        View
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleEditOrder(order.id)}>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleDeleteOrder(order.id)}
                        className="text-red-600 dark:text-red-400"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}