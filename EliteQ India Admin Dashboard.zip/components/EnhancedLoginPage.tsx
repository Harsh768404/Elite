import React, { useState, useEffect } from 'react';
import { Eye, EyeOff, Shield, AlertCircle, CheckCircle, Loader2, User, Key, Globe } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { EliteQLogo } from './EliteQLogo';

// Import the authentication service
import { simpleAuthService as authService } from '../utils/jwt-auth';

interface LoginPageProps {
  onLogin: (token: string, userData: any) => void; // Fixed: expects user data object, not role string
}

interface LoginState {
  phase: 'initial' | 'authenticating' | 'fetching_profile' | 'validating' | 'success' | 'error';
  progress: number;
  statusMessage: string;
  error?: string;
}

export const EnhancedLoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  // Form state
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  // Login process state
  const [loginState, setLoginState] = useState<LoginState>({
    phase: 'initial',
    progress: 0,
    statusMessage: 'Ready to authenticate with EliteQ.in WordPress backend'
  });

  // Auto-fill credentials from URL parameters for testing (remove in production)
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const testUser = urlParams.get('test_user');
    const testPass = urlParams.get('test_pass');
    
    if (testUser && testPass) {
      setUsername(testUser);
      setPassword(testPass);
      console.log('🧪 Test credentials loaded from URL parameters');
    }
  }, []);

  const updateLoginState = (phase: LoginState['phase'], progress: number, statusMessage: string, error?: string) => {
    setLoginState({ phase, progress, statusMessage, error });
    console.log(`📍 Login State: ${phase} (${progress}%) - ${statusMessage}`);
    if (error) {
      console.error('❌ Login Error:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username.trim() || !password.trim()) {
      updateLoginState('error', 0, 'Authentication failed', 'Please enter both username and password');
      return;
    }

    try {
      console.log('🚀 ===== ENHANCED LOGIN PROCESS STARTED (STRICT MODE) =====');
      console.log('👤 Attempting login for user:', username);
      console.log('🌐 Target WordPress site: https://eliteq.in');
      console.log('⚠️ STRICT MODE: No fallback roles will be assigned');
      
      // Phase 1: Start Authentication
      updateLoginState('authenticating', 10, 'Connecting to EliteQ.in WordPress backend...');
      
      await new Promise(resolve => setTimeout(resolve, 500)); // Brief delay for UX
      
      // Phase 2: Authenticate and fetch complete profile with STRICT validation
      updateLoginState('authenticating', 30, 'Verifying credentials with WordPress JWT...');
      
      const credentials = { username: username.trim(), password: password.trim() };
      
      try {
        const result = await authService.login(credentials);
        
        console.log('✅ ===== AUTHENTICATION SUCCESSFUL =====');
        console.log('🎯 Backend authentication completed with STRICT validation');
        console.log('📊 Complete user profile received from backend');
        
        // Phase 3: Processing user profile with STRICT validation
        updateLoginState('fetching_profile', 60, 'Processing complete user profile from WordPress...');
        
        await new Promise(resolve => setTimeout(resolve, 300));
        
        console.log('📋 ===== COMPLETE USER PROFILE ANALYSIS =====');
        console.log('👤 User Details:');
        console.log('   - ID:', result.user.id);
        console.log('   - Username:', result.user.username);
        console.log('   - Email:', result.user.email);
        console.log('   - Display Name:', result.user.display_name);
        console.log('   - Primary Role:', result.user.role);
        console.log('   - All Roles:', result.user.roles);
        console.log('   - Determined User Type:', result.user.user_type);
        console.log('   - Profile Complete:', result.user.profile_complete);
        console.log('   - Data Source:', result.user.data_source);
        console.log('   - Last Fetched:', result.user.last_fetched);
        
        // Phase 4: STRICT profile validation - NO FALLBACKS
        updateLoginState('validating', 80, 'Validating user profile and roles from backend...');
        
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // Phase 5: Basic validation - ensure we have a complete user profile
        updateLoginState('validating', 90, 'Validating user profile and determining dashboard access...');
        
        await new Promise(resolve => setTimeout(resolve, 200));
        
        // Basic validation - ensure we have required fields
        if (!result.user.id) {
          console.error('❌ NO USER ID');
          throw new Error('User ID is missing from backend response');
        }
        
        if (!result.user.email) {
          console.error('❌ NO USER EMAIL');
          throw new Error('User email is missing from backend response');
        }
        
        if (!result.user.role) {
          console.error('❌ NO PRIMARY ROLE');
          throw new Error('User role is missing from backend response');
        }
        
        if (!result.user.username) {
          console.error('❌ NO USERNAME');
          throw new Error('Username is missing from backend response');
        }
        
        console.log('🎭 ===== DASHBOARD ROUTING DECISION =====');
        console.log('📊 Primary Role from Backend:', result.user.role);
        console.log('🎯 Backend User Type:', result.user.user_type);
        console.log('📋 All Roles:', result.user.roles);
        
        // Phase 6: Success
        updateLoginState('success', 100, 
          result.user.user_type === 'administrator' 
            ? 'Administrator access granted! Redirecting to Admin Panel...'
            : result.user.user_type === 'vendor'
            ? 'Vendor access granted! Redirecting to Vendor Dashboard...'
            : 'User access granted! Redirecting to Dashboard...'
        );
        
        await new Promise(resolve => setTimeout(resolve, 500));
        
        console.log('🎉 ===== LOGIN PROCESS COMPLETED SUCCESSFULLY =====');
        console.log('✅ User authenticated with STRICT backend validation');
        console.log('✅ Profile validated and complete with real WordPress data');
        console.log('✅ Dashboard routing determined from VALIDATED backend roles');
        console.log('✅ NO FALLBACK DATA USED - ALL DATA IS AUTHENTIC');
        console.log('🚀 Proceeding to dashboard...');
        
        // Store login info for remember me
        if (rememberMe) {
          localStorage.setItem('eliteq_remember_token', result.token);
          console.log('💾 Remember me: Token stored for future sessions');
        }
        
        // FIXED: Pass complete user data object instead of just role string
        console.log('📤 ===== PASSING USER DATA TO ROUTER =====');
        console.log('🔑 Token:', !!result.token);
        console.log('👤 User Data Object:', {
          id: result.user.id,
          username: result.user.username,
          email: result.user.user_email,
          display_name: result.user.display_name,
          roles: result.user.roles,
          user_type: result.user.user_type
        });
        
        // FIXED: Create properly structured user data object for the AuthContext
        // Now using the clean, simple structure that matches the user's backend expectation
        const userDataForAuth = {
          id: result.user.id,
          username: result.user.username,
          email: result.user.email,  // Now using the correct field name
          display_name: result.user.display_name,
          roles: result.user.roles,
          role: result.user.role, // Single role field from backend (like "administrator" or "seller")
          user_type: result.user.user_type,
          avatar_url: result.user.avatar_url,
          profile_complete: result.user.profile_complete,
          data_source: result.user.data_source,
          last_fetched: result.user.last_fetched
        };
        
        console.log('📦 ===== FINAL USER DATA PREPARED FOR AUTH CONTEXT =====');
        console.log('✅ Structured user data:', userDataForAuth);
        console.log('🔑 Has ID:', !!userDataForAuth.id);
        console.log('👤 Has Username:', !!userDataForAuth.username);
        console.log('📧 Has Email:', !!userDataForAuth.email);
        console.log('🎭 Has Roles Array:', Array.isArray(userDataForAuth.roles) && userDataForAuth.roles.length > 0);
        console.log('🎯 Has Single Role:', !!userDataForAuth.role);
        
        // Execute login callback with backend-validated data and proper user object
        onLogin(result.token, userDataForAuth);
        
      } catch (authError) {
        console.error('🚨 ===== AUTHENTICATION FAILED =====');
        console.error('Authentication error:', authError);
        
        let errorMessage = 'Authentication failed';
        
        if (authError instanceof Error) {
          errorMessage = authError.message;
          
          // Handle specific authentication errors with detailed messages for role issues
          if (errorMessage.includes('incorrect_password')) {
            errorMessage = 'Incorrect password. Please check your password and try again.';
          } else if (errorMessage.includes('invalid_username') || errorMessage.includes('invalid_email')) {
            errorMessage = 'Unknown username or email. Please check your credentials.';
          } else if (errorMessage.includes('No user roles found')) {
            errorMessage = 'Your WordPress account does not have any roles assigned. Please contact the administrator to assign appropriate user roles.';
          } else if (errorMessage.includes('Cannot determine user type from roles')) {
            errorMessage = 'Your WordPress account has unrecognized user roles. Please contact the administrator to assign valid roles (administrator, vendor, customer, etc.).';
          } else if (errorMessage.includes('Profile validation failed')) {
            errorMessage = 'Your account profile could not be validated. This may be due to missing WordPress user data. Please contact the administrator.';
          } else if (errorMessage.includes('Incomplete user profile data')) {
            errorMessage = 'Your WordPress account has incomplete profile information. Please ensure your WordPress profile is complete or contact the administrator.';
          } else if (errorMessage.includes('WordPress API returned incomplete')) {
            errorMessage = 'WordPress API is not returning complete user information. This may be a server configuration issue. Please contact the administrator.';
          } else if (errorMessage.includes('Failed to retrieve user information')) {
            errorMessage = 'Unable to fetch your user profile from WordPress. Please check your internet connection and try again, or contact the administrator if the issue persists.';
          } else if (errorMessage.includes('Inconsistent administrator role')) {
            errorMessage = 'Administrator role data inconsistency detected. Please contact the administrator to verify your WordPress role assignments.';
          } else if (errorMessage.includes('User role routing mismatch')) {
            errorMessage = 'User role routing error detected. Please contact the administrator to verify your WordPress role configuration.';
          } else if (errorMessage.includes('Essential user data missing')) {
            errorMessage = 'Your WordPress account appears to have incomplete data. This could be due to WordPress configuration issues. Please contact your administrator to ensure your user profile is properly configured.';
          }
        }
        
        updateLoginState('error', 0, 'Authentication failed', errorMessage);
        
        // Clear any stored credentials on authentication failure
        localStorage.removeItem('eliteq_remember_token');
      }
      
    } catch (error) {
      console.error('🚨 Unexpected error during login process:', error);
      updateLoginState('error', 0, 'Login failed', 'An unexpected error occurred. Please try again.');
    }
  };

  const isLoading = loginState.phase === 'authenticating' || loginState.phase === 'fetching_profile' || loginState.phase === 'validating';

  const getPhaseColor = () => {
    switch (loginState.phase) {
      case 'success':
        return 'text-green-600 dark:text-green-400';
      case 'error':
        return 'text-red-600 dark:text-red-400';
      case 'authenticating':
      case 'fetching_profile':
      case 'validating':
        return 'text-blue-600 dark:text-blue-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getPhaseIcon = () => {
    switch (loginState.phase) {
      case 'success':
        return <CheckCircle className="h-4 w-4" />;
      case 'error':
        return <AlertCircle className="h-4 w-4" />;
      case 'authenticating':
      case 'fetching_profile':
      case 'validating':
        return <Loader2 className="h-4 w-4 animate-spin" />;
      default:
        return <Globe className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <EliteQLogo darkMode={false} size="lg" showText={true} animated={true} />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Admin Control Panel
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              WordPress + WooCommerce + Dokan Pro Management
            </p>
            <div className="flex items-center justify-center gap-2">
              <Badge variant="outline" className="text-blue-600 border-blue-300 bg-blue-50 dark:bg-blue-900/20">
                <Shield className="h-3 w-3 mr-1" />
                Strict Role Validation
              </Badge>
              <Badge variant="outline" className="text-green-600 border-green-300 bg-green-50 dark:bg-green-900/20">
                <Globe className="h-3 w-3 mr-1" />
                Live Mode
              </Badge>
            </div>
          </div>
        </div>

        {/* Login Form */}
        <Card className="shadow-xl border-0 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-xl text-center">
              Sign in to EliteQ.in
            </CardTitle>
            <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
              Enter your WordPress credentials
            </p>
          </CardHeader>
          
          <CardContent className="space-y-4">
            
            {/* Login Progress Indicator */}
            {(isLoading || loginState.phase === 'success' || loginState.phase === 'error') && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className={getPhaseColor()}>
                    {getPhaseIcon()}
                  </div>
                  <span className={`text-sm font-medium ${getPhaseColor()}`}>
                    {loginState.statusMessage}
                  </span>
                </div>
                
                {isLoading && (
                  <div className="space-y-2">
                    <Progress value={loginState.progress} className="h-2" />
                    <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                      <span>Validating with WordPress backend...</span>
                      <span>{loginState.progress}%</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Error Display */}
            {loginState.phase === 'error' && loginState.error && (
              <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-700">
                <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
                <AlertDescription className="text-red-700 dark:text-red-300">
                  <strong>Authentication Failed:</strong> {loginState.error}
                  
                  {/* Additional help for role-related errors */}
                  {(loginState.error.includes('roles') || loginState.error.includes('administrator') || loginState.error.includes('vendor')) && (
                    <div className="mt-2 text-sm">
                      <strong>Role Issue Detected:</strong> This error is related to WordPress user roles. Please contact your administrator to verify your role assignments.
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Username Field */}
              <div className="space-y-2">
                <Label htmlFor="username" className="text-sm font-medium">
                  WordPress Username or Email
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="Enter your WordPress username or email"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    disabled={isLoading}
                    className="pl-10 bg-white dark:bg-gray-700"
                    required
                  />
                </div>
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">
                  WordPress Password
                </Label>
                <div className="relative">
                  <Key className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your WordPress password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={isLoading}
                    className="pl-10 pr-10 bg-white dark:bg-gray-700"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              {/* Remember Me */}
              <div className="flex items-center space-x-2">
                <input
                  id="remember"
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  disabled={isLoading}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <Label htmlFor="remember" className="text-sm text-gray-600 dark:text-gray-400">
                  Remember me for future sessions
                </Label>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5"
                disabled={isLoading || loginState.phase === 'success'}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Validating with WordPress...</span>
                  </div>
                ) : loginState.phase === 'success' ? (
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" />
                    <span>Authentication Successful</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4" />
                    <span>Sign in to EliteQ Admin</span>
                  </div>
                )}
              </Button>
            </form>

            {/* Footer Info */}
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="text-center space-y-2">
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  🔒 Secure authentication with strict role validation
                </p>
                <div className="flex items-center justify-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                  <span>🌐 Connected to: eliteq.in</span>
                  <span>•</span>
                  <span>📊 Live backend validation</span>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  All roles are validated against WordPress backend - no fallbacks
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Development Info */}
        {process.env.NODE_ENV === 'development' && (
          <Card className="bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-700">
            <CardContent className="pt-4">
              <div className="text-xs text-yellow-700 dark:text-yellow-300 space-y-1">
                <p><strong>Fixed:</strong> Now passes complete user data object to AuthContext</p>
                <p><strong>WordPress:</strong> https://eliteq.in/wp-json/jwt-auth/v1/token</p>
                <p><strong>User API:</strong> https://eliteq.in/wp-json/wp/v2/users/me</p>
                <p><strong>Features:</strong> No fallback roles, strict validation, real WordPress data</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default EnhancedLoginPage;