import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  Clock, 
  Pause, 
  Truck, 
  CheckCircle, 
  XCircle, 
  CreditCard,
  AlertTriangle,
  RefreshCw,
  TrendingUp
} from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Skeleton } from './ui/skeleton';

interface OrderStatus {
  status: string;
  count: number;
  color: string;
  bgGradient: string;
  bgColor: string;
  textColor: string;
  borderColor: string;
  icon: React.ElementType;
  description: string;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  percentage?: number;
}

interface EliteQOrderStatusCardsProps {
  userRole: 'admin' | 'vendor';
}

export function EliteQOrderStatusCards({ userRole }: EliteQOrderStatusCardsProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [hasError, setHasError] = useState(false);

  const orderStatuses: OrderStatus[] = [
    {
      status: 'New Orders',
      count: 0,
      color: 'from-blue-500 to-blue-600',
      bgGradient: 'from-blue-50 to-blue-100 dark:from-blue-900/10 dark:to-blue-800/20',
      bgColor: 'bg-blue-50 dark:bg-blue-900/10',
      textColor: 'text-blue-600 dark:text-blue-400',
      borderColor: 'border-blue-200 dark:border-blue-700',
      icon: ShoppingBag,
      description: 'Fresh orders awaiting processing',
      change: '+0',
      changeType: 'neutral',
      percentage: 0
    },
    {
      status: 'Processing',
      count: 0,
      color: 'from-orange-500 to-orange-600',
      bgGradient: 'from-orange-50 to-orange-100 dark:from-orange-900/10 dark:to-orange-800/20',
      bgColor: 'bg-orange-50 dark:bg-orange-900/10',
      textColor: 'text-orange-600 dark:text-orange-400',
      borderColor: 'border-orange-200 dark:border-orange-700',
      icon: Clock,
      description: 'Orders being prepared for shipment',
      change: '+0',
      changeType: 'neutral',
      percentage: 0
    },
    {
      status: 'On-Hold',
      count: 0,
      color: 'from-yellow-500 to-yellow-600',
      bgGradient: 'from-yellow-50 to-yellow-100 dark:from-yellow-900/10 dark:to-yellow-800/20',
      bgColor: 'bg-yellow-50 dark:bg-yellow-900/10',
      textColor: 'text-yellow-600 dark:text-yellow-400',
      borderColor: 'border-yellow-200 dark:border-yellow-700',
      icon: Pause,
      description: 'Orders waiting for customer action',
      change: '+0',
      changeType: 'neutral',
      percentage: 0
    },
    {
      status: 'Shipped',
      count: 0,
      color: 'from-purple-500 to-purple-600',
      bgGradient: 'from-purple-50 to-purple-100 dark:from-purple-900/10 dark:to-purple-800/20',
      bgColor: 'bg-purple-50 dark:bg-purple-900/10',
      textColor: 'text-purple-600 dark:text-purple-400',
      borderColor: 'border-purple-200 dark:border-purple-700',
      icon: Truck,
      description: 'Orders in transit to customers',
      change: '+0',
      changeType: 'neutral',
      percentage: 0
    },
    {
      status: 'Delivered',
      count: 0,
      color: 'from-green-500 to-green-600',
      bgGradient: 'from-green-50 to-green-100 dark:from-green-900/10 dark:to-green-800/20',
      bgColor: 'bg-green-50 dark:bg-green-900/10',
      textColor: 'text-green-600 dark:text-green-400',
      borderColor: 'border-green-200 dark:border-green-700',
      icon: CheckCircle,
      description: 'Successfully completed orders',
      change: '+0',
      changeType: 'neutral',
      percentage: 0
    },
    {
      status: 'Cancelled',
      count: 0,
      color: 'from-red-500 to-red-600',
      bgGradient: 'from-red-50 to-red-100 dark:from-red-900/10 dark:to-red-800/20',
      bgColor: 'bg-red-50 dark:bg-red-900/10',
      textColor: 'text-red-600 dark:text-red-400',
      borderColor: 'border-red-200 dark:border-red-700',
      icon: XCircle,
      description: 'Orders cancelled by customer/admin',
      change: '+0',
      changeType: 'neutral',
      percentage: 0
    },
    {
      status: 'Pending Payment',
      count: 0,
      color: 'from-indigo-500 to-indigo-600',
      bgGradient: 'from-indigo-50 to-indigo-100 dark:from-indigo-900/10 dark:to-indigo-800/20',
      bgColor: 'bg-indigo-50 dark:bg-indigo-900/10',
      textColor: 'text-indigo-600 dark:text-indigo-400',
      borderColor: 'border-indigo-200 dark:border-indigo-700',
      icon: CreditCard,
      description: 'Awaiting payment confirmation',
      change: '+0',
      changeType: 'neutral',
      percentage: 0
    },
    {
      status: 'Failed',
      count: 0,
      color: 'from-pink-500 to-pink-600',
      bgGradient: 'from-pink-50 to-pink-100 dark:from-pink-900/10 dark:to-pink-800/20',
      bgColor: 'bg-pink-50 dark:bg-pink-900/10',
      textColor: 'text-pink-600 dark:text-pink-400',
      borderColor: 'border-pink-200 dark:border-pink-700',
      icon: AlertTriangle,
      description: 'Failed or problematic orders',
      change: '+0',
      changeType: 'neutral',
      percentage: 0
    }
  ];

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdated(new Date());
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  // Simulate data loading
  useEffect(() => {
    setIsLoading(true);
    const loadTimeout = setTimeout(() => {
      setIsLoading(false);
      setHasError(false);
    }, 1000);

    return () => clearTimeout(loadTimeout);
  }, []);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    setHasError(false);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      setLastUpdated(new Date());
      console.log('📊 Order status data refreshed');
    } catch (error) {
      console.error('❌ Failed to refresh order status data:', error);
      setHasError(true);
    } finally {
      setIsRefreshing(false);
    }
  };

  const getChangeIcon = (changeType: 'positive' | 'negative' | 'neutral') => {
    switch (changeType) {
      case 'positive':
        return <TrendingUp className="w-3 h-3 text-green-500" />;
      case 'negative':
        return <TrendingUp className="w-3 h-3 text-red-500 rotate-180" />;
      default:
        return <TrendingUp className="w-3 h-3 text-gray-400" />;
    }
  };

  const getChangeColor = (changeType: 'positive' | 'negative' | 'neutral') => {
    switch (changeType) {
      case 'positive':
        return 'text-green-600 dark:text-green-400';
      case 'negative':
        return 'text-red-600 dark:text-red-400';
      default:
        return 'text-gray-500 dark:text-gray-400';
    }
  };

  const getTotalOrders = () => {
    return orderStatuses.reduce((total, status) => total + status.count, 0);
  };

  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-64 mt-2" />
          </div>
          <Skeleton className="h-6 w-20" />
        </div>

        {/* Loading state for horizontal cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div key={i} className="p-6 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between mb-4">
                <Skeleton className="h-10 w-10 rounded-lg" />
                <Skeleton className="h-4 w-12" />
              </div>
              <Skeleton className="h-4 w-20 mb-2" />
              <Skeleton className="h-8 w-16 mb-3" />
              <Skeleton className="h-3 w-full" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (hasError) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Order Status Overview
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Real-time order status tracking across your {userRole === 'admin' ? 'marketplace' : 'store'}
            </p>
          </div>
          <Badge variant="destructive" className="text-xs">
            Error Loading
          </Badge>
        </div>

        <Card className="p-8 text-center border-red-200 dark:border-red-800">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Failed to Load Order Data
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            We couldn't fetch the latest order status information. Please try refreshing.
          </p>
          <Button onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Retry
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between mb-6 space-y-4 lg:space-y-0">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Order Status Overview
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            Real-time order status tracking across your {userRole === 'admin' ? 'marketplace' : 'store'}
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Badge variant="secondary" className="text-xs">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-1"></div>
            Live Updates
          </Badge>
          <div className="text-xs text-gray-500 dark:text-gray-400">
            Updated: {lastUpdated.toLocaleTimeString()}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="h-8"
          >
            <RefreshCw className={`w-3 h-3 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Horizontal Colorful Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {orderStatuses.map((order, index) => {
          const Icon = order.icon;
          
          return (
            <Card 
              key={index}
              className={`
                group relative overflow-hidden p-6 hover:shadow-xl transition-all duration-300 cursor-pointer
                bg-gradient-to-br ${order.bgGradient}
                border ${order.borderColor}
                hover:scale-[1.02] hover:-translate-y-1
                animate-fade-in
              `}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Background Decorative Circle */}
              <div className="absolute -top-4 -right-4 w-20 h-20 opacity-10">
                <div className={`w-full h-full bg-gradient-to-br ${order.color} rounded-full`}></div>
              </div>

              {/* Header - Icon and Change Indicator */}
              <div className="flex items-center justify-between mb-4">
                <div className={`
                  inline-flex items-center justify-center w-12 h-12 rounded-xl
                  bg-gradient-to-br ${order.color}
                  shadow-lg group-hover:scale-110 transition-transform duration-300
                `}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className={`flex items-center space-x-1 text-xs ${getChangeColor(order.changeType)}`}>
                  {getChangeIcon(order.changeType)}
                  <span className="font-medium">{order.change}</span>
                </div>
              </div>

              {/* Content */}
              <div className="space-y-2">
                <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  {order.status}
                </h3>
                
                <div className="flex items-baseline space-x-2">
                  <span className="text-3xl font-bold text-gray-900 dark:text-white">
                    {order.count}
                  </span>
                  {order.percentage !== undefined && (
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      ({order.percentage}%)
                    </span>
                  )}
                </div>

                <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                  {order.description}
                </p>
              </div>

              {/* Progress Bar */}
              <div className="mt-4 w-full bg-white/30 dark:bg-gray-700/30 rounded-full h-1.5">
                <div 
                  className={`h-1.5 rounded-full bg-gradient-to-r ${order.color} transition-all duration-300 animate-progress`}
                  style={{ 
                    width: `${Math.min((order.count / Math.max(getTotalOrders(), 1)) * 100, 100)}%`,
                    '--progress-width': `${Math.min((order.count / Math.max(getTotalOrders(), 1)) * 100, 100)}%`
                  } as React.CSSProperties}
                ></div>
              </div>

              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl"></div>
            </Card>
          );
        })}
      </div>

      {/* Summary Statistics */}
      <Card className="p-6 bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-900 border border-gray-200 dark:border-gray-700">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Orders</span>
            </div>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{getTotalOrders()}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">All time</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Completed</span>
            </div>
            <div className="text-2xl font-bold text-green-600 dark:text-green-400">
              {orderStatuses.find(s => s.status === 'Delivered')?.count || 0}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Success rate</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400">In Progress</span>
            </div>
            <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">
              {orderStatuses.filter(s => ['New Orders', 'Processing', 'Shipped'].includes(s.status))
                .reduce((total, s) => total + s.count, 0)}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Active orders</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Efficiency</span>
            </div>
            <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">98%</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Processing rate</div>
          </div>
        </div>
      </Card>

      {/* Empty State (when no orders) */}
      {getTotalOrders() === 0 && !isLoading && !hasError && (
        <Card className="p-8 text-center border-dashed border-2 border-gray-300 dark:border-gray-600 mt-6">
          <ShoppingBag className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No Orders Yet
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Orders will appear here once customers start placing them on your {userRole === 'admin' ? 'marketplace' : 'store'}.
          </p>
          <Button variant="outline" size="sm">
            View Products
          </Button>
        </Card>
      )}
    </div>
  );
}