// Import with fallback
let networkManager: any;
try {
  networkManager = require('./network-connectivity-manager').networkManager;
} catch (error) {
  console.warn('Network manager not available, using fallback');
  networkManager = {
    getConnectionStatus: () => ({
      isOnline: navigator.onLine,
      isWordPressReachable: false,
      isWooCommerceReachable: false,
      consecutiveFailures: 0
    })
  };
}

interface ErrorSuppressionConfig {
  suppressNetworkErrors: boolean;
  suppressPermissionErrors: boolean;
  suppressServerErrors: boolean;
  logToConsole: boolean;
  showUserNotifications: boolean;
}

class GracefulErrorHandler {
  private config: ErrorSuppressionConfig = {
    suppressNetworkErrors: true,
    suppressPermissionErrors: true,
    suppressServerErrors: true,
    logToConsole: true,
    showUserNotifications: false
  };

  private suppressedErrors: Array<{
    type: string;
    message: string;
    endpoint: string;
    timestamp: Date;
    count: number;
  }> = [];

  private errorCounts: Map<string, number> = new Map();

  constructor() {
    // Small delay to ensure DOM is ready
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        this.initializeGlobalErrorHandling();
      }, 100);
    }
  }

  private initializeGlobalErrorHandling(): void {
    // Enhanced global error handler
    const originalConsoleError = console.error;
    const originalConsoleWarn = console.warn;

    console.error = (...args: any[]) => {
      if (this.shouldSuppressError(args)) {
        this.recordSuppressedError('error', args);
        return;
      }
      originalConsoleError.apply(console, args);
    };

    console.warn = (...args: any[]) => {
      if (this.shouldSuppressWarning(args)) {
        this.recordSuppressedError('warning', args);
        return;
      }
      originalConsoleWarn.apply(console, args);
    };

    // Handle unhandled promise rejections gracefully
    window.addEventListener('unhandledrejection', (event) => {
      if (this.shouldSuppressPromiseRejection(event)) {
        event.preventDefault();
        this.recordSuppressedError('promise_rejection', [event.reason]);
        return;
      }
    });
  }

  private shouldSuppressError(args: any[]): boolean {
    const message = args.join(' ').toLowerCase();
    
    // Network-related errors
    if (this.config.suppressNetworkErrors) {
      const networkErrorPatterns = [
        'failed to fetch',
        'network request failed',
        'request timeout after',
        'aborterror: signal is aborted without reason',
        'network error recorded:',
        'all 1 attempts failed',
        'wordpress endpoint not reachable',
        'woocommerce endpoint not reachable',
        'request failed:',
        'typeerror: failed to fetch',
        'http 404:',
        'http 500:',
        'eliteq.in/wp-json/',
        'consumer_key=ck_',
        'wc/v3/reports/',
        'wc/v3/products',
        'wc/v3/orders',
        'wp/v2/posts',
        'network error when',
        'cannot list',
        'returning empty array'
      ];

      if (networkErrorPatterns.some(pattern => message.includes(pattern))) {
        return true;
      }
    }

    // Permission errors
    if (this.config.suppressPermissionErrors) {
      const permissionErrorPatterns = [
        'cannot list resources',
        'rest_forbidden',
        'permission denied',
        'woocommerce_rest_cannot',
        'sorry, you are not allowed'
      ];

      if (permissionErrorPatterns.some(pattern => message.includes(pattern))) {
        return true;
      }
    }

    // Server errors
    if (this.config.suppressServerErrors) {
      const serverErrorPatterns = [
        'wordpress critical error detected',
        'http 500:',
        'internal server error',
        'critical error'
      ];

      if (serverErrorPatterns.some(pattern => message.includes(pattern))) {
        return true;
      }
    }

    return false;
  }

  private shouldSuppressWarning(args: any[]): boolean {
    const message = args.join(' ').toLowerCase();
    
    // Suppress common non-critical warnings
    const warningPatterns = [
      'safe request failed, returning fallback value',
      'network error when listing',
      'cannot list products, returning empty array',
      'cannot list orders, returning empty array',
      'cannot view',
      'wordpress health check failed',
      'woocommerce health check failed',
      'request failed:',
      'all 1 attempts failed',
      'network error when',
      'returning empty array:',
      'cannot list',
      'returning null:',
      'attempt 1 failed:',
      'eliteq.in/wp-json/'
    ];

    return warningPatterns.some(pattern => message.includes(pattern));
  }

  private shouldSuppressPromiseRejection(event: PromiseRejectionEvent): boolean {
    const reason = String(event.reason).toLowerCase();
    
    const rejectionPatterns = [
      'failed to fetch',
      'network request failed',
      'timeout',
      'aborted without reason',
      'http 404:',
      'http 500:',
      'permission denied',
      'rest_forbidden',
      'critical error',
      'typeerror: failed to fetch',
      'request failed:',
      'all 1 attempts failed',
      'eliteq.in/wp-json/',
      'wc/v3/reports/',
      'wc/v3/products',
      'wc/v3/orders',
      'wp/v2/posts',
      'consumer_key=ck_',
      'network error when',
      'cannot list',
      'returning empty array',
      'returning null'
    ];

    return rejectionPatterns.some(pattern => reason.includes(pattern));
  }

  private recordSuppressedError(type: string, args: any[]): void {
    const message = args.join(' ');
    const key = `${type}_${message.substring(0, 100)}`;
    
    // Increment count
    const count = (this.errorCounts.get(key) || 0) + 1;
    this.errorCounts.set(key, count);

    // Extract endpoint if possible
    let endpoint = 'unknown';
    const urlMatch = message.match(/https?:\/\/[^\s]+/);
    if (urlMatch) {
      endpoint = urlMatch[0];
    }

    // Record the error
    const existingError = this.suppressedErrors.find(err => 
      err.type === type && err.message.includes(message.substring(0, 100))
    );

    if (existingError) {
      existingError.count = count;
      existingError.timestamp = new Date();
    } else {
      this.suppressedErrors.unshift({
        type,
        message: message.substring(0, 500), // Truncate long messages
        endpoint,
        timestamp: new Date(),
        count
      });

      // Keep only recent errors
      if (this.suppressedErrors.length > 100) {
        this.suppressedErrors = this.suppressedErrors.slice(0, 100);
      }
    }

    // Optional: Log to console in development
    if (this.config.logToConsole && process.env.NODE_ENV === 'development') {
      console.log(`🔇 Suppressed ${type}:`, message.substring(0, 200));
    }
  }

  public getSuppressedErrors(): Array<{
    type: string;
    message: string;
    endpoint: string;
    timestamp: Date;
    count: number;
  }> {
    return [...this.suppressedErrors];
  }

  public getErrorSummary(): {
    totalSuppressed: number;
    networkErrors: number;
    permissionErrors: number;
    serverErrors: number;
    recentErrors: number;
  } {
    const now = new Date();
    const recentThreshold = now.getTime() - (5 * 60 * 1000); // Last 5 minutes

    return {
      totalSuppressed: this.suppressedErrors.length,
      networkErrors: this.suppressedErrors.filter(err => 
        err.message.includes('network') || err.message.includes('fetch') || err.message.includes('timeout')
      ).length,
      permissionErrors: this.suppressedErrors.filter(err => 
        err.message.includes('permission') || err.message.includes('forbidden')
      ).length,
      serverErrors: this.suppressedErrors.filter(err => 
        err.message.includes('500') || err.message.includes('critical')
      ).length,
      recentErrors: this.suppressedErrors.filter(err => 
        err.timestamp.getTime() > recentThreshold
      ).length
    };
  }

  public clearSuppressedErrors(): void {
    this.suppressedErrors = [];
    this.errorCounts.clear();
  }

  public updateConfig(newConfig: Partial<ErrorSuppressionConfig>): void {
    this.config = { ...this.config, ...newConfig };
  }

  public getConfig(): ErrorSuppressionConfig {
    return { ...this.config };
  }

  // Method to check if the application is in a degraded state
  public getSystemHealth(): {
    status: 'healthy' | 'degraded' | 'critical';
    networkConnected: boolean;
    wordpressReachable: boolean;
    woocommerceReachable: boolean;
    recentErrorCount: number;
    message: string;
  } {
    let networkStatus;
    try {
      networkStatus = networkManager.getConnectionStatus();
    } catch (error) {
      networkStatus = {
        isOnline: navigator.onLine,
        isWordPressReachable: false,
        isWooCommerceReachable: false,
        consecutiveFailures: 0
      };
    }
    const errorSummary = this.getErrorSummary();
    
    let status: 'healthy' | 'degraded' | 'critical' = 'healthy';
    let message = 'All systems operational';

    if (!networkStatus.isOnline) {
      status = 'critical';
      message = 'Network connection lost';
    } else if (!networkStatus.isWordPressReachable && !networkStatus.isWooCommerceReachable) {
      status = 'critical';
      message = 'WordPress server unreachable';
    } else if (!networkStatus.isWordPressReachable || !networkStatus.isWooCommerceReachable) {
      status = 'degraded';
      message = 'Some services unavailable';
    } else if (errorSummary.recentErrors > 10) {
      status = 'degraded';
      message = 'High error rate detected';
    }

    return {
      status,
      networkConnected: networkStatus.isOnline,
      wordpressReachable: networkStatus.isWordPressReachable,
      woocommerceReachable: networkStatus.isWooCommerceReachable,
      recentErrorCount: errorSummary.recentErrors,
      message
    };
  }
}

// Create singleton instance
export const gracefulErrorHandler = new GracefulErrorHandler();

// Export utility functions
export const suppressConsoleErrors = (suppress: boolean = true) => {
  gracefulErrorHandler.updateConfig({ 
    suppressNetworkErrors: suppress,
    suppressPermissionErrors: suppress,
    suppressServerErrors: suppress
  });
};

export const getSystemHealth = () => {
  return gracefulErrorHandler.getSystemHealth();
};

export const getSuppressedErrorSummary = () => {
  return gracefulErrorHandler.getErrorSummary();
};

export default GracefulErrorHandler;