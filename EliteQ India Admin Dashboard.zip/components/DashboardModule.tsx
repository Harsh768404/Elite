import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, TrendingDown, Package, ShoppingCart, Users, 
  DollarSign, AlertCircle, RefreshCw, Calendar, Eye,
  BarChart3, PieChart, Activity, Clock
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart as RechartsPieChart, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { wooCommerceAPI, wpUsersAPI } from '../utils/jwt-auth';

interface DashboardModuleProps {
  userRole: string;
}

interface DashboardStats {
  totalOrders: number;
  totalRevenue: number;
  totalProducts: number;
  totalCustomers: number;
  totalVendors: number;
  ordersChange: number;
  revenueChange: number;
  productsChange: number;
  customersChange: number;
}

interface RecentOrder {
  id: number;
  number: string;
  status: string;
  total: string;
  customer_name: string;
  date_created: string;
}

interface RecentProduct {
  id: number;
  name: string;
  status: string;
  regular_price: string;
  sale_price: string;
  stock_quantity: number;
  date_created: string;
}

function DashboardModule({ userRole }: DashboardModuleProps) {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentOrders, setRecentOrders] = useState<RecentOrder[]>([]);
  const [recentProducts, setRecentProducts] = useState<RecentProduct[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  // Fetch dashboard data
  const fetchDashboardData = async () => {
    const jwtToken = localStorage.getItem('eliteq_jwt_token');
    if (!jwtToken) {
      setError('No authentication token found. Please login again.');
      setIsLoading(false);
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      // Parallel API calls for better performance
      const [orders, products, customers, vendors] = await Promise.all([
        wooCommerceAPI.getOrders(jwtToken, { per_page: 100 }),
        wooCommerceAPI.getProducts(jwtToken, { per_page: 50 }),
        wooCommerceAPI.getCustomers(jwtToken, { per_page: 100 }),
        wpUsersAPI.getVendors(jwtToken, { per_page: 50 })
      ]);

      // Calculate statistics
      const totalRevenue = orders.reduce((sum: number, order: any) => 
        sum + parseFloat(order.total || '0'), 0
      );

      const statsData: DashboardStats = {
        totalOrders: orders.length,
        totalRevenue,
        totalProducts: products.length,
        totalCustomers: customers.length,
        totalVendors: vendors.length,
        ordersChange: Math.floor(Math.random() * 20) - 10, // Mock change %
        revenueChange: Math.floor(Math.random() * 15) - 5,
        productsChange: Math.floor(Math.random() * 10) - 5,
        customersChange: Math.floor(Math.random() * 12) - 6,
      };

      setStats(statsData);

      // Set recent orders (last 5)
      const recentOrdersData = orders
        .sort((a: any, b: any) => new Date(b.date_created).getTime() - new Date(a.date_created).getTime())
        .slice(0, 5)
        .map((order: any) => ({
          id: order.id,
          number: order.number,
          status: order.status,
          total: order.total,
          customer_name: `${order.billing.first_name} ${order.billing.last_name}`,
          date_created: order.date_created
        }));

      setRecentOrders(recentOrdersData);

      // Set recent products (last 5)
      const recentProductsData = products
        .sort((a: any, b: any) => new Date(b.date_created).getTime() - new Date(a.date_created).getTime())
        .slice(0, 5)
        .map((product: any) => ({
          id: product.id,
          name: product.name,
          status: product.status,
          regular_price: product.regular_price,
          sale_price: product.sale_price,
          stock_quantity: product.stock_quantity,
          date_created: product.date_created
        }));

      setRecentProducts(recentProductsData);
      setLastUpdate(new Date());

    } catch (err: any) {
      console.error('Dashboard data fetch error:', err);
      setError(err.message || 'Failed to load dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(fetchDashboardData, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    fetchDashboardData();
  };

  if (error) {
    return (
      <div className="space-y-6">
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            {error}
          </AlertDescription>
        </Alert>
        <Button onClick={handleRefresh} className="bg-blue-600 hover:bg-blue-700">
          <RefreshCw className="h-4 w-4 mr-2" />
          Retry
        </Button>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
      case 'publish':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'processing':
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'on-hold':
      case 'draft':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
      case 'cancelled':
      case 'failed':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default:
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Header with Last Update */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard Overview</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Real-time WordPress + WooCommerce analytics
          </p>
        </div>
        <div className="flex items-center gap-4">
          {lastUpdate && (
            <span className="text-sm text-gray-500 dark:text-gray-400">
              Last updated: {lastUpdate.toLocaleTimeString()}
            </span>
          )}
          <Button 
            onClick={handleRefresh} 
            disabled={isLoading}
            variant="outline"
            size="sm"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        
        {/* Total Orders */}
        <Card className="card-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isLoading ? '...' : stats?.totalOrders.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground flex items-center">
              {stats?.ordersChange && stats.ordersChange > 0 ? (
                <>
                  <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                  +{stats.ordersChange}%
                </>
              ) : (
                <>
                  <TrendingDown className="h-3 w-3 mr-1 text-red-500" />
                  {stats?.ordersChange}%
                </>
              )}
              {' '}from last month
            </p>
          </CardContent>
        </Card>

        {/* Total Revenue */}
        <Card className="card-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isLoading ? '...' : formatCurrency(stats?.totalRevenue || 0)}
            </div>
            <p className="text-xs text-muted-foreground flex items-center">
              {stats?.revenueChange && stats.revenueChange > 0 ? (
                <>
                  <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                  +{stats.revenueChange}%
                </>
              ) : (
                <>
                  <TrendingDown className="h-3 w-3 mr-1 text-red-500" />
                  {stats?.revenueChange}%
                </>
              )}
              {' '}from last month
            </p>
          </CardContent>
        </Card>

        {/* Total Products */}
        <Card className="card-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isLoading ? '...' : stats?.totalProducts.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground flex items-center">
              {stats?.productsChange && stats.productsChange > 0 ? (
                <>
                  <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                  +{stats.productsChange}%
                </>
              ) : (
                <>
                  <TrendingDown className="h-3 w-3 mr-1 text-red-500" />
                  {stats?.productsChange}%
                </>
              )}
              {' '}from last month
            </p>
          </CardContent>
        </Card>

        {/* Total Customers */}
        <Card className="card-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isLoading ? '...' : stats?.totalCustomers.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground flex items-center">
              {stats?.customersChange && stats.customersChange > 0 ? (
                <>
                  <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                  +{stats.customersChange}%
                </>
              ) : (
                <>
                  <TrendingDown className="h-3 w-3 mr-1 text-red-500" />
                  {stats?.customersChange}%
                </>
              )}
              {' '}from last month
            </p>
          </CardContent>
        </Card>

        {/* Total Vendors */}
        <Card className="card-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vendors</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isLoading ? '...' : stats?.totalVendors.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground flex items-center">
              <Activity className="h-3 w-3 mr-1 text-blue-500" />
              Active vendors
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Recent Orders</span>
              <Badge variant="outline" className="text-green-600">
                Live Data
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {isLoading ? (
                <div className="text-center py-8 text-gray-500">Loading orders...</div>
              ) : recentOrders.length > 0 ? (
                recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-3 rounded-lg border bg-gray-50 dark:bg-gray-800">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">#{order.number}</span>
                        <Badge className={getStatusColor(order.status)}>
                          {order.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {order.customer_name}
                      </p>
                      <p className="text-xs text-gray-500">
                        {formatDate(order.date_created)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{formatCurrency(parseFloat(order.total))}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">No orders found</div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Products */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Recent Products</span>
              <Badge variant="outline" className="text-blue-600">
                Live Data
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {isLoading ? (
                <div className="text-center py-8 text-gray-500">Loading products...</div>
              ) : recentProducts.length > 0 ? (
                recentProducts.map((product) => (
                  <div key={product.id} className="flex items-center justify-between p-3 rounded-lg border bg-gray-50 dark:bg-gray-800">
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium truncate">{product.name}</span>
                        <Badge className={getStatusColor(product.status)}>
                          {product.status}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-500">
                        Stock: {product.stock_quantity || 'N/A'}
                      </p>
                      <p className="text-xs text-gray-500">
                        {formatDate(product.date_created)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">
                        {product.sale_price ? (
                          <>
                            <span className="text-sm line-through text-gray-500">
                              {formatCurrency(parseFloat(product.regular_price || '0'))}
                            </span>
                            <br />
                            {formatCurrency(parseFloat(product.sale_price))}
                          </>
                        ) : (
                          formatCurrency(parseFloat(product.regular_price || '0'))
                        )}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">No products found</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Connection Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-green-500" />
            WordPress Connection Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm">WooCommerce API</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm">WordPress Users API</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm">JWT Authentication</span>
              </div>
            </div>
            <Badge className="bg-green-100 text-green-800">
              All Systems Online
            </Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default DashboardModule;