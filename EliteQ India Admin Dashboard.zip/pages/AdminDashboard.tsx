import React, { useEffect } from 'react';
import { ModernEliteQDashboard } from '../components/ModernEliteQDashboard';
import { EliteQErrorFallback } from '../components/EliteQErrorFallback';

export default function AdminDashboard() {
  useEffect(() => {
    // Set page title for admin dashboard
    document.title = 'Admin Dashboard - EliteQ India Marketplace';
    
    // Log admin dashboard access
    console.log('🎯 Admin Dashboard loaded');
    console.log('👑 User Role: Administrator');
    console.log('🔐 Access Level: Full Control');
    console.log('📊 Dashboard Type: Admin Control Panel');
    
    // Admin-specific initialization
    const initializeAdminDashboard = () => {
      try {
        // Set admin-specific environment flags
        if (typeof window !== 'undefined') {
          (window as any).ELITEQ_USER_ROLE = 'admin';
          (window as any).ELITEQ_ACCESS_LEVEL = 'full';
          (window as any).ELITEQ_DASHBOARD_TYPE = 'admin';
        }
        
        console.log('✅ Admin dashboard initialized successfully');
      } catch (error) {
        console.error('❌ Error initializing admin dashboard:', error);
      }
    };

    initializeAdminDashboard();

    // Cleanup on unmount
    return () => {
      if (typeof window !== 'undefined') {
        delete (window as any).ELITEQ_USER_ROLE;
        delete (window as any).ELITEQ_ACCESS_LEVEL;
        delete (window as any).ELITEQ_DASHBOARD_TYPE;
      }
    };
  }, []);

  try {
    return (
      <div className="admin-dashboard-container">
        {/* Admin-specific header meta information */}
        <div className="sr-only">
          <h1>EliteQ India Admin Dashboard</h1>
          <p>WordPress + WooCommerce + Dokan Pro Marketplace Administration</p>
          <p>Full access to marketplace management, vendor oversight, and system configuration</p>
        </div>

        {/* Modern Admin Dashboard */}
        <ModernEliteQDashboard userRole="admin" />
      </div>
    );
  } catch (error) {
    console.error('❌ Admin Dashboard render error:', error);
    return (
      <EliteQErrorFallback 
        error={error as Error}
        resetError={() => window.location.reload()}
        context="Admin Dashboard"
      />
    );
  }
}