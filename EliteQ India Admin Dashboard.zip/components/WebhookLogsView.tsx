import React, { useState } from 'react';
import { 
  Webhook, CheckCircle, XCircle, AlertTriangle, Clock,
  Filter, Search, Download, RefreshCw, Eye, Copy,
  Calendar, Activity, Database, ExternalLink
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface WebhookLog {
  id: string;
  timestamp: string;
  store: string;
  event: string;
  status: 'success' | 'failed' | 'retrying' | 'pending';
  httpStatus: number;
  responseTime: number;
  payload: any;
  response: any;
  retryCount: number;
  nextRetry?: string;
}

export const WebhookLogsView: React.FC = () => {
  const [logs] = useState<WebhookLog[]>([
    {
      id: '1',
      timestamp: '2024-01-20 14:30:22',
      store: 'EliteQ Main Store',
      event: 'order.created',
      status: 'success',
      httpStatus: 200,
      responseTime: 145,
      payload: { order_id: 1247, total: '299.99', status: 'processing' },
      response: { success: true, message: 'Order processed successfully' },
      retryCount: 0
    },
    {
      id: '2',
      timestamp: '2024-01-20 14:25:15',
      store: 'Demo Store',
      event: 'product.updated',
      status: 'failed',
      httpStatus: 500,
      responseTime: 5000,
      payload: { product_id: 156, name: 'Updated Product', price: '199.99' },
      response: { error: 'Internal server error' },
      retryCount: 2,
      nextRetry: '2024-01-20 14:35:15'
    },
    {
      id: '3',
      timestamp: '2024-01-20 14:20:08',
      store: 'EliteQ Main Store',
      event: 'customer.created',
      status: 'retrying',
      httpStatus: 408,
      responseTime: 30000,
      payload: { customer_id: 89, email: 'customer@example.com' },
      response: { error: 'Request timeout' },
      retryCount: 1,
      nextRetry: '2024-01-20 14:22:08'
    },
    {
      id: '4',
      timestamp: '2024-01-20 14:15:45',
      store: 'Test Environment',
      event: 'order.updated',
      status: 'pending',
      httpStatus: 0,
      responseTime: 0,
      payload: { order_id: 23, status: 'completed' },
      response: null,
      retryCount: 0
    }
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [storeFilter, setStoreFilter] = useState('all');
  const [eventFilter, setEventFilter] = useState('all');
  const [selectedLog, setSelectedLog] = useState<WebhookLog | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const getStatusBadge = (status: WebhookLog['status']) => {
    switch (status) {
      case 'success':
        return (
          <Badge className="bg-green-100 text-green-800 border-green-200">
            <CheckCircle className="h-3 w-3 mr-1" />
            Success
          </Badge>
        );
      case 'failed':
        return (
          <Badge className="bg-red-100 text-red-800 border-red-200">
            <XCircle className="h-3 w-3 mr-1" />
            Failed
          </Badge>
        );
      case 'retrying':
        return (
          <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">
            <AlertTriangle className="h-3 w-3 mr-1" />
            Retrying
          </Badge>
        );
      case 'pending':
        return (
          <Badge className="bg-blue-100 text-blue-800 border-blue-200">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        );
    }
  };

  const getResponseTimeBadge = (responseTime: number) => {
    if (responseTime === 0) return null;
    
    const color = responseTime < 1000 ? 'text-green-600' : 
                 responseTime < 5000 ? 'text-yellow-600' : 'text-red-600';
    
    return (
      <span className={`text-xs font-mono ${color}`}>
        {responseTime}ms
      </span>
    );
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1500);
  };

  const handleExportLogs = () => {
    const csvContent = logs.map(log => 
      `${log.timestamp},${log.store},${log.event},${log.status},${log.httpStatus},${log.responseTime}`
    ).join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'webhook-logs.csv';
    a.click();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const filteredLogs = logs.filter(log => {
    const matchesSearch = log.event.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         log.store.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || log.status === statusFilter;
    const matchesStore = storeFilter === 'all' || log.store === storeFilter;
    const matchesEvent = eventFilter === 'all' || log.event.includes(eventFilter);
    
    return matchesSearch && matchesStatus && matchesStore && matchesEvent;
  });

  const stats = {
    total: logs.length,
    success: logs.filter(l => l.status === 'success').length,
    failed: logs.filter(l => l.status === 'failed').length,
    retrying: logs.filter(l => l.status === 'retrying').length,
    avgResponseTime: Math.round(
      logs.filter(l => l.responseTime > 0)
           .reduce((sum, l) => sum + l.responseTime, 0) / 
      logs.filter(l => l.responseTime > 0).length || 0
    )
  };

  const uniqueStores = [...new Set(logs.map(log => log.store))];
  const eventTypes = ['order', 'product', 'customer'];

  return (
    <div className="space-y-6">
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total Events</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.total}</p>
              </div>
              <Activity className="h-8 w-8 text-blue-600 bg-blue-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Success</p>
                <p className="text-2xl font-bold text-green-600">{stats.success}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600 bg-green-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Failed</p>
                <p className="text-2xl font-bold text-red-600">{stats.failed}</p>
              </div>
              <XCircle className="h-8 w-8 text-red-600 bg-red-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Retrying</p>
                <p className="text-2xl font-bold text-yellow-600">{stats.retrying}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-600 bg-yellow-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Avg Response</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.avgResponseTime}ms</p>
              </div>
              <Clock className="h-8 w-8 text-purple-600 bg-purple-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Actions */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search events..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 max-w-sm"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="max-w-[150px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="success">Success</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                  <SelectItem value="retrying">Retrying</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={storeFilter} onValueChange={setStoreFilter}>
                <SelectTrigger className="max-w-[180px]">
                  <SelectValue placeholder="Store" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Stores</SelectItem>
                  {uniqueStores.map(store => (
                    <SelectItem key={store} value={store}>{store}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={eventFilter} onValueChange={setEventFilter}>
                <SelectTrigger className="max-w-[150px]">
                  <SelectValue placeholder="Event" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Events</SelectItem>
                  {eventTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleRefresh} disabled={isRefreshing}>
                <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Button variant="outline" onClick={handleExportLogs}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Webhook className="h-5 w-5" />
            Webhook Events ({filteredLogs.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Store</TableHead>
                  <TableHead>Event</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>HTTP</TableHead>
                  <TableHead>Response Time</TableHead>
                  <TableHead>Retries</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => (
                  <TableRow key={log.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                    <TableCell className="font-mono text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        {log.timestamp}
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Database className="h-4 w-4 text-blue-600" />
                        <span className="font-medium">{log.store}</span>
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      <code className="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-sm">
                        {log.event}
                      </code>
                    </TableCell>
                    
                    <TableCell>
                      {getStatusBadge(log.status)}
                    </TableCell>
                    
                    <TableCell>
                      <Badge 
                        variant={log.httpStatus === 200 ? 'default' : 'destructive'}
                        className="font-mono"
                      >
                        {log.httpStatus || 'N/A'}
                      </Badge>
                    </TableCell>
                    
                    <TableCell>
                      {getResponseTimeBadge(log.responseTime)}
                    </TableCell>
                    
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {log.retryCount > 0 && (
                          <Badge variant="outline" className="text-xs">
                            {log.retryCount}x
                          </Badge>
                        )}
                        {log.nextRetry && (
                          <span className="text-xs text-gray-500">
                            Next: {new Date(log.nextRetry).toLocaleTimeString()}
                          </span>
                        )}
                      </div>
                    </TableCell>
                    
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedLog(log)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Log Details Dialog */}
      <Dialog open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Webhook className="h-5 w-5" />
              Webhook Event Details
            </DialogTitle>
          </DialogHeader>
          
          {selectedLog && (
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="payload">Payload</TabsTrigger>
                <TabsTrigger value="response">Response</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Event ID</label>
                    <div className="flex items-center gap-2">
                      <code className="text-sm bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                        {selectedLog.id}
                      </code>
                      <Button variant="ghost" size="sm" onClick={() => copyToClipboard(selectedLog.id)}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Timestamp</label>
                    <p className="text-sm font-mono text-gray-600 dark:text-gray-400">
                      {selectedLog.timestamp}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Store</label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{selectedLog.store}</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Event Type</label>
                    <code className="text-sm bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                      {selectedLog.event}
                    </code>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                    {getStatusBadge(selectedLog.status)}
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">HTTP Status</label>
                    <Badge variant={selectedLog.httpStatus === 200 ? 'default' : 'destructive'}>
                      {selectedLog.httpStatus || 'N/A'}
                    </Badge>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="payload" className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Request Payload
                    </label>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => copyToClipboard(JSON.stringify(selectedLog.payload, null, 2))}
                    >
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                  </div>
                  <pre className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg text-sm overflow-x-auto">
                    {JSON.stringify(selectedLog.payload, null, 2)}
                  </pre>
                </div>
              </TabsContent>
              
              <TabsContent value="response" className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Server Response
                    </label>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => copyToClipboard(JSON.stringify(selectedLog.response, null, 2))}
                    >
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                  </div>
                  <pre className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg text-sm overflow-x-auto">
                    {JSON.stringify(selectedLog.response, null, 2)}
                  </pre>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};