// Enhanced API utilities for JWT Auth with Role-based Routing
// Following the exact specification provided for administrator and dokan_vendor routing

interface LoginResponse {
  token: string;
  user_email: string;
  user_nicename: string;
  user_display_name: string;
  user_id?: number;
  user_role?: string[];
  roles?: string[];
}

interface LoginCredentials {
  username: string;
  password: string;
}

// 🔹 1. JWT Login API Integration
export const loginUser = async (username: string, password: string): Promise<LoginResponse> => {
  console.log('🔐 ===== JWT LOGIN API INTEGRATION =====');
  console.log('👤 Username:', username);
  console.log('🌐 WordPress URL: https://eliteq.in');
  
  const res = await fetch('https://eliteq.in/wp-json/jwt-auth/v1/token', {
    method: 'POST',
    headers: { 
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify({ username, password }),
  });

  console.log('📡 API Response:', {
    status: res.status,
    statusText: res.statusText,
    ok: res.ok
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error('❌ Login failed:', errorText);
    throw new Error('Login failed');
  }

  const data: LoginResponse = await res.json();
  
  console.log('✅ Login successful:', {
    hasToken: !!data.token,
    userEmail: data.user_email,
    userDisplayName: data.user_display_name,
    userId: data.user_id,
    userRole: data.user_role || data.roles
  });
  
  return data;
};

// Enhanced role determination from JWT response
export const determineUserRole = (jwtResponse: LoginResponse): {
  dashboardRole: 'administrator' | 'vendor';
  wordpressRoles: string[];
  redirectPath: string;
} => {
  console.log('🎭 ===== DETERMINING USER ROLE =====');
  
  // Extract roles from JWT response (handle different possible field names)
  let wordpressRoles: string[] = [];
  if (jwtResponse.user_role && Array.isArray(jwtResponse.user_role)) {
    wordpressRoles = jwtResponse.user_role;
  } else if (jwtResponse.roles && Array.isArray(jwtResponse.roles)) {
    wordpressRoles = jwtResponse.roles;
  }
  
  console.log('📋 WordPress roles from JWT:', wordpressRoles);
  
  // Determine dashboard role and redirect path
  let dashboardRole: 'administrator' | 'vendor' = 'vendor'; // Default to vendor
  let redirectPath = '/vendor/dashboard'; // Default redirect
  
  if (wordpressRoles.includes('administrator')) {
    dashboardRole = 'administrator';
    redirectPath = '/admin/dashboard';
    console.log('👑 Administrator detected - redirecting to admin dashboard');
  } else if (wordpressRoles.some(role => ['dokan_vendor', 'vendor', 'seller', 'shop_manager'].includes(role))) {
    dashboardRole = 'vendor';
    redirectPath = '/vendor/dashboard';
    console.log('🏪 Vendor detected - redirecting to vendor dashboard');
  } else {
    // For other roles, default to vendor dashboard but log the issue
    console.warn('⚠️ Unknown role detected, defaulting to vendor dashboard');
    console.warn('📋 Available roles:', wordpressRoles);
  }
  
  console.log('🎯 Final role determination:', {
    dashboardRole,
    wordpressRoles,
    redirectPath
  });
  
  return {
    dashboardRole,
    wordpressRoles,
    redirectPath
  };
};

// 🔹 2. Enhanced Login Handler with Role-based Routing
export const handleLogin = async (credentials: LoginCredentials): Promise<{
  success: boolean;
  redirectPath: string;
  userData?: any;
  error?: string;
}> => {
  console.log('🚀 ===== ENHANCED LOGIN HANDLER =====');
  
  try {
    // Step 1: Authenticate with WordPress
    const jwtData = await loginUser(credentials.username, credentials.password);
    
    // Step 2: Determine user role and redirect path
    const roleInfo = determineUserRole(jwtData);
    
    // Step 3: Save to localStorage as specified
    console.log('💾 ===== SAVING TO LOCALSTORAGE =====');
    
    localStorage.setItem('token', jwtData.token);
    localStorage.setItem('eliteq_jwt_token', jwtData.token); // Also save with our app prefix
    localStorage.setItem('user_role', JSON.stringify(roleInfo.wordpressRoles));
    localStorage.setItem('eliteq_user_role', roleInfo.dashboardRole); // Dashboard role
    
    // Enhanced user info object
    const userInfo = {
      id: jwtData.user_id,
      email: jwtData.user_email,
      username: jwtData.user_nicename,
      display_name: jwtData.user_display_name,
      roles: roleInfo.wordpressRoles,
      user_type: roleInfo.dashboardRole,
      token: jwtData.token,
      login_time: new Date().toISOString()
    };
    
    localStorage.setItem('user_info', JSON.stringify(userInfo));
    localStorage.setItem('eliteq_user_info', JSON.stringify(userInfo)); // Also save with our app prefix
    
    console.log('✅ Data saved to localStorage:', {
      token: '✓ Saved',
      userRole: roleInfo.dashboardRole,
      wordpressRoles: roleInfo.wordpressRoles,
      redirectPath: roleInfo.redirectPath
    });
    
    return {
      success: true,
      redirectPath: roleInfo.redirectPath,
      userData: userInfo
    };
    
  } catch (error) {
    console.error('🚨 Login handler error:', error);
    return {
      success: false,
      redirectPath: '/login',
      error: error instanceof Error ? error.message : 'Login failed'
    };
  }
};

// 🔹 3. Role-based Routing Logic
export const performRoleBasedRouting = (jwtResponse: LoginResponse): void => {
  console.log('🧭 ===== PERFORMING ROLE-BASED ROUTING =====');
  
  const roleInfo = determineUserRole(jwtResponse);
  
  console.log('📍 Routing decision:', {
    userRoles: roleInfo.wordpressRoles,
    dashboardRole: roleInfo.dashboardRole,
    redirectTo: roleInfo.redirectPath
  });
  
  // Redirect based on role as specified
  if (roleInfo.wordpressRoles.includes('administrator')) {
    console.log('👑 Redirecting administrator to admin dashboard');
    window.location.href = '/admin/dashboard';
  } else if (roleInfo.wordpressRoles.some(role => ['dokan_vendor', 'vendor', 'seller', 'shop_manager'].includes(role))) {
    console.log('🏪 Redirecting vendor to vendor dashboard');
    window.location.href = '/vendor/dashboard';
  } else {
    console.log('🏠 Redirecting unknown role to home page');
    window.location.href = '/';
  }
};

// 🔹 4. Token and Role Management Utilities
export const AuthManager = {
  // Get stored token
  getToken: (): string | null => {
    return localStorage.getItem('token') || localStorage.getItem('eliteq_jwt_token');
  },

  // Get user roles
  getUserRoles: (): string[] => {
    const storedRoles = localStorage.getItem('user_role');
    if (storedRoles) {
      try {
        return JSON.parse(storedRoles);
      } catch {
        return [];
      }
    }
    return [];
  },

  // Get dashboard role
  getDashboardRole: (): 'administrator' | 'vendor' | null => {
    return localStorage.getItem('eliteq_user_role') as 'administrator' | 'vendor' | null;
  },

  // Get user info
  getUserInfo: (): any | null => {
    const storedInfo = localStorage.getItem('user_info') || localStorage.getItem('eliteq_user_info');
    if (storedInfo) {
      try {
        return JSON.parse(storedInfo);
      } catch {
        return null;
      }
    }
    return null;
  },

  // Check if user is authenticated
  isAuthenticated: (): boolean => {
    const token = AuthManager.getToken();
    const role = AuthManager.getDashboardRole();
    return !!(token && role);
  },

  // Check if user has specific role
  hasRole: (role: string): boolean => {
    const userRoles = AuthManager.getUserRoles();
    return userRoles.includes(role);
  },

  // Check if user is administrator
  isAdmin: (): boolean => {
    return AuthManager.hasRole('administrator');
  },

  // Check if user is vendor
  isVendor: (): boolean => {
    const vendorRoles = ['dokan_vendor', 'vendor', 'seller', 'shop_manager'];
    const userRoles = AuthManager.getUserRoles();
    return vendorRoles.some(role => userRoles.includes(role));
  },

  // Logout function that clears localStorage and redirects
  logout: (): void => {
    console.log('🚪 ===== LOGGING OUT USER =====');
    
    // Clear all authentication data
    localStorage.removeItem('token');
    localStorage.removeItem('eliteq_jwt_token');
    localStorage.removeItem('user_role');
    localStorage.removeItem('eliteq_user_role');
    localStorage.removeItem('user_info');
    localStorage.removeItem('eliteq_user_info');
    localStorage.removeItem('eliteq_remember_token');
    
    console.log('🧹 Authentication data cleared');
    
    // Redirect to login
    window.location.href = '/login';
  }
};

// 🔹 5. JWT Token Validation
export const validateToken = async (token: string): Promise<boolean> => {
  console.log('🔍 Validating JWT token...');
  
  try {
    const res = await fetch('https://eliteq.in/wp-json/jwt-auth/v1/token/validate', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    const isValid = res.ok;
    console.log(`${isValid ? '✅' : '❌'} Token validation result:`, isValid);
    
    return isValid;
  } catch (error) {
    console.error('🚨 Token validation error:', error);
    return false;
  }
};

// 🔹 6. Auto-login on app startup
export const attemptAutoLogin = async (): Promise<{
  success: boolean;
  redirectPath?: string;
  error?: string;
}> => {
  console.log('🔄 ===== ATTEMPTING AUTO-LOGIN =====');
  
  const token = AuthManager.getToken();
  const dashboardRole = AuthManager.getDashboardRole();
  
  if (!token || !dashboardRole) {
    console.log('❌ No stored credentials found');
    return { success: false, error: 'No stored credentials' };
  }
  
  console.log('🔍 Validating stored token...');
  const isValidToken = await validateToken(token);
  
  if (!isValidToken) {
    console.log('❌ Stored token is invalid, clearing data');
    AuthManager.logout();
    return { success: false, error: 'Invalid token' };
  }
  
  console.log('✅ Auto-login successful');
  const redirectPath = dashboardRole === 'administrator' ? '/admin/dashboard' : '/vendor/dashboard';
  
  return {
    success: true,
    redirectPath
  };
};

// Export convenience function for the exact API specification
export { loginUser as default };