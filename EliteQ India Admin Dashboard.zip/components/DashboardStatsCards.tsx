import React from 'react';
import { ShoppingCart, DollarSign, Package, Users, Store, TrendingUp, TrendingDown } from 'lucide-react';
import { Card } from './ui/card';

interface StatsCardProps {
  title: string;
  value: string;
  change: string;
  changeType: 'increase' | 'decrease';
  icon: React.ElementType;
  color: string;
}

function StatsCard({ title, value, change, changeType, icon: Icon, color }: StatsCardProps) {
  return (
    <Card className="p-6 hover:shadow-lg transition-all duration-300 card-hover">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">
            {title}
          </p>
          <p className="text-2xl font-semibold text-gray-900 dark:text-white">
            {value}
          </p>
          <div className="flex items-center mt-2">
            {changeType === 'increase' ? (
              <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
            )}
            <span className={`text-sm font-medium ${
              changeType === 'increase' ? 'text-green-600' : 'text-red-600'
            }`}>
              {change}
            </span>
            <span className="text-sm text-gray-500 dark:text-gray-400 ml-1">
              from last month
            </span>
          </div>
        </div>
        <div className={`p-3 rounded-full ${color}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
      </div>
    </Card>
  );
}

interface DashboardStatsCardsProps {
  userRole: 'admin' | 'vendor';
}

export function DashboardStatsCards({ userRole }: DashboardStatsCardsProps) {
  const adminStats = [
    {
      title: 'Total Orders',
      value: '2,847',
      change: '+12.5%',
      changeType: 'increase' as const,
      icon: ShoppingCart,
      color: 'bg-blue-500'
    },
    {
      title: 'Revenue',
      value: '₹8,45,230',
      change: '+8.2%',
      changeType: 'increase' as const,
      icon: DollarSign,
      color: 'bg-green-500'
    },
    {
      title: 'Products',
      value: '1,234',
      change: '+15.3%',
      changeType: 'increase' as const,
      icon: Package,
      color: 'bg-purple-500'
    },
    {
      title: 'Customers',
      value: '5,678',
      change: '+22.1%',
      changeType: 'increase' as const,
      icon: Users,
      color: 'bg-orange-500'
    },
    {
      title: 'Vendors',
      value: '89',
      change: '+3.4%',
      changeType: 'increase' as const,
      icon: Store,
      color: 'bg-indigo-500'
    }
  ];

  const vendorStats = [
    {
      title: 'My Orders',
      value: '342',
      change: '+18.2%',
      changeType: 'increase' as const,
      icon: ShoppingCart,
      color: 'bg-blue-500'
    },
    {
      title: 'My Revenue',
      value: '₹1,23,450',
      change: '+25.1%',
      changeType: 'increase' as const,
      icon: DollarSign,
      color: 'bg-green-500'
    },
    {
      title: 'My Products',
      value: '87',
      change: '+12.0%',
      changeType: 'increase' as const,
      icon: Package,
      color: 'bg-purple-500'
    },
    {
      title: 'My Customers',
      value: '456',
      change: '+31.7%',
      changeType: 'increase' as const,
      icon: Users,
      color: 'bg-orange-500'
    }
  ];

  const stats = userRole === 'admin' ? adminStats : vendorStats;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
      {stats.map((stat, index) => (
        <StatsCard key={index} {...stat} />
      ))}
    </div>
  );
}