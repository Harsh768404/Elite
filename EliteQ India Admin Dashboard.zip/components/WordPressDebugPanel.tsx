import React, { useState } from 'react';
import { 
  Bug, Play, CheckCircle, AlertCircle, Eye, EyeOff,
  Globe, Key, Shield, Activity, Copy, RefreshCw
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { authService, setWordPressConfig, testWordPressConnection } from '../utils/jwt-auth';

interface WordPressDebugPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function WordPressDebugPanel({ isOpen, onClose }: WordPressDebugPanelProps) {
  const [testCredentials, setTestCredentials] = useState({
    siteUrl: 'https://your-wordpress-site.com',
    username: '',
    password: '',
    consumerKey: '',
    consumerSecret: ''
  });
  
  const [showPassword, setShowPassword] = useState(false);
  const [testResults, setTestResults] = useState<Record<string, any>>({});
  const [isLoading, setIsLoading] = useState(false);

  // JWT Secret Key constant
  const JWT_SECRET_KEY = 'F%p5l+k:fyIThfpy]hg,(}WfoIa[;XUQQipH<xhi2Y!#XUe)Lsh6M24dy})YZdCq';

  const runTest = async (testType: string) => {
    setIsLoading(true);
    const timestamp = new Date().toISOString();
    
    try {
      switch (testType) {
        case 'connection':
          const connectionResult = await testWordPressConnection(testCredentials.siteUrl);
          setTestResults(prev => ({
            ...prev,
            connection: { ...connectionResult, timestamp }
          }));
          break;
          
        case 'jwt-auth':
          if (!testCredentials.username || !testCredentials.password) {
            throw new Error('Username and password are required for JWT authentication test');
          }
          
          // Set the site URL first
          setWordPressConfig({ siteUrl: testCredentials.siteUrl });
          
          const authResult = await authService.login({
            username: testCredentials.username,
            password: testCredentials.password
          });
          
          setTestResults(prev => ({
            ...prev,
            'jwt-auth': { 
              success: true, 
              token: authResult.token, 
              role: authResult.role,
              timestamp 
            }
          }));
          break;
          
        case 'user-role':
          const storedToken = testResults['jwt-auth']?.token;
          if (!storedToken) {
            throw new Error('Please run JWT authentication test first');
          }
          
          const roleResult = await authService.getUserRole(storedToken);
          setTestResults(prev => ({
            ...prev,
            'user-role': { 
              success: true, 
              role: roleResult,
              timestamp 
            }
          }));
          break;
          
        case 'token-validation':
          const tokenToValidate = testResults['jwt-auth']?.token;
          if (!tokenToValidate) {
            throw new Error('Please run JWT authentication test first');
          }
          
          const validationResult = await authService.validateToken(tokenToValidate);
          setTestResults(prev => ({
            ...prev,
            'token-validation': { 
              success: validationResult, 
              isValid: validationResult,
              timestamp 
            }
          }));
          break;
          
        default:
          throw new Error(`Unknown test type: ${testType}`);
      }
    } catch (error: any) {
      setTestResults(prev => ({
        ...prev,
        [testType]: { 
          success: false, 
          error: error.message,
          timestamp 
        }
      }));
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const getTestStatus = (testKey: string) => {
    const result = testResults[testKey];
    if (!result) return 'not-run';
    return result.success ? 'success' : 'error';
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-600" />;
      default:
        return <Activity className="h-4 w-4 text-gray-400" />;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-auto">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Bug className="h-5 w-5" />
              WordPress Authentication Debug Panel
            </CardTitle>
            <Button variant="ghost" onClick={onClose}>
              ×
            </Button>
          </div>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="config" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="config">Configuration</TabsTrigger>
              <TabsTrigger value="tests">API Tests</TabsTrigger>
              <TabsTrigger value="results">Results</TabsTrigger>
            </TabsList>

            {/* Configuration Tab */}
            <TabsContent value="config" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* WordPress Site URL */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">WordPress Site URL</label>
                  <Input
                    placeholder="https://your-wordpress-site.com"
                    value={testCredentials.siteUrl}
                    onChange={(e) => setTestCredentials(prev => ({ 
                      ...prev, siteUrl: e.target.value 
                    }))}
                  />
                </div>

                {/* Username */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">WordPress Username</label>
                  <Input
                    placeholder="Enter WordPress username"
                    value={testCredentials.username}
                    onChange={(e) => setTestCredentials(prev => ({ 
                      ...prev, username: e.target.value 
                    }))}
                  />
                </div>

                {/* Password */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">WordPress Password</label>
                  <div className="relative">
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter WordPress password"
                      value={testCredentials.password}
                      onChange={(e) => setTestCredentials(prev => ({ 
                        ...prev, password: e.target.value 
                      }))}
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 p-0"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                {/* Consumer Key */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">WooCommerce Consumer Key</label>
                  <Input
                    placeholder="ck_xxxxxxxxxxxxxxxx"
                    value={testCredentials.consumerKey}
                    onChange={(e) => setTestCredentials(prev => ({ 
                      ...prev, consumerKey: e.target.value 
                    }))}
                  />
                </div>
              </div>

              {/* JWT Secret Info */}
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-2">
                    <div>
                      <strong>JWT Secret Key:</strong>
                    </div>
                    <code className="text-sm bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded block break-all">
                      {JWT_SECRET_KEY}
                    </code>
                    <div className="text-sm">
                      Make sure this is added to your WordPress wp-config.php file:
                    </div>
                    <code className="text-sm bg-blue-50 dark:bg-blue-900/20 px-2 py-1 rounded block">
                      define('JWT_AUTH_SECRET_KEY', '{JWT_SECRET_KEY}');
                    </code>
                  </div>
                </AlertDescription>
              </Alert>
            </TabsContent>

            {/* Tests Tab */}
            <TabsContent value="tests" className="space-y-4">
              
              {/* Test 1: WordPress Connection */}
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Globe className="h-4 w-4" />
                      <span className="font-medium">WordPress Connection Test</span>
                      {getStatusIcon(getTestStatus('connection'))}
                    </div>
                    <Button
                      onClick={() => runTest('connection')}
                      disabled={isLoading || !testCredentials.siteUrl}
                      size="sm"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Test
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Tests basic WordPress REST API connectivity
                  </p>
                  {testResults.connection && (
                    <div className="mt-2 p-2 bg-gray-50 dark:bg-gray-800 rounded text-xs">
                      <pre>{JSON.stringify(testResults.connection, null, 2)}</pre>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Test 2: JWT Authentication */}
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Key className="h-4 w-4" />
                      <span className="font-medium">JWT Authentication Test</span>
                      {getStatusIcon(getTestStatus('jwt-auth'))}
                    </div>
                    <Button
                      onClick={() => runTest('jwt-auth')}
                      disabled={isLoading || !testCredentials.username || !testCredentials.password}
                      size="sm"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Test
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Tests JWT token generation with provided credentials
                  </p>
                  {testResults['jwt-auth'] && (
                    <div className="mt-2 space-y-2">
                      {testResults['jwt-auth'].token && (
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-medium">Token:</span>
                          <code className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                            {testResults['jwt-auth'].token.substring(0, 20)}...
                          </code>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(testResults['jwt-auth'].token)}
                            className="h-6 w-6 p-0"
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                      <div className="p-2 bg-gray-50 dark:bg-gray-800 rounded text-xs">
                        <pre>{JSON.stringify(testResults['jwt-auth'], null, 2)}</pre>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Test 3: User Role Detection */}
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4" />
                      <span className="font-medium">User Role Detection</span>
                      {getStatusIcon(getTestStatus('user-role'))}
                    </div>
                    <Button
                      onClick={() => runTest('user-role')}
                      disabled={isLoading || !testResults['jwt-auth']?.token}
                      size="sm"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Test
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Tests user role detection from WordPress user data
                  </p>
                  {testResults['user-role'] && (
                    <div className="mt-2 p-2 bg-gray-50 dark:bg-gray-800 rounded text-xs">
                      <pre>{JSON.stringify(testResults['user-role'], null, 2)}</pre>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Test 4: Token Validation */}
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Activity className="h-4 w-4" />
                      <span className="font-medium">Token Validation</span>
                      {getStatusIcon(getTestStatus('token-validation'))}
                    </div>
                    <Button
                      onClick={() => runTest('token-validation')}
                      disabled={isLoading || !testResults['jwt-auth']?.token}
                      size="sm"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Test
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Tests JWT token validation with WordPress
                  </p>
                  {testResults['token-validation'] && (
                    <div className="mt-2 p-2 bg-gray-50 dark:bg-gray-800 rounded text-xs">
                      <pre>{JSON.stringify(testResults['token-validation'], null, 2)}</pre>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Results Tab */}
            <TabsContent value="results" className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Test Results Summary</h3>
                  <Button
                    onClick={() => setTestResults({})}
                    variant="outline"
                    size="sm"
                  >
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Clear Results
                  </Button>
                </div>

                {Object.keys(testResults).length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No test results yet. Run some tests to see results here.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {Object.entries(testResults).map(([testKey, result]) => (
                      <Card key={testKey}>
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-medium capitalize">
                                {testKey.replace('-', ' ')}
                              </span>
                              <Badge 
                                variant={result.success ? "default" : "destructive"}
                                className={result.success ? "bg-green-100 text-green-800" : ""}
                              >
                                {result.success ? 'PASS' : 'FAIL'}
                              </Badge>
                            </div>
                            <span className="text-xs text-gray-500">
                              {new Date(result.timestamp).toLocaleTimeString()}
                            </span>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="bg-gray-50 dark:bg-gray-800 rounded p-3">
                            <pre className="text-xs overflow-auto max-h-40">
                              {JSON.stringify(result, null, 2)}
                            </pre>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}