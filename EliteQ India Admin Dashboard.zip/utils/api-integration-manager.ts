/**
 * Enhanced API Integration Manager for EliteQ India
 * Comprehensive WordPress/WooCommerce Integration with all endpoints
 * Updated with complete endpoint coverage and enhanced functionality
 */

import { wordpressAPI } from './comprehensive-wordpress-api';
import { ALL_ENDPOINTS } from '../config/wordpress-endpoints';

// Enhanced API Integration Manager with comprehensive endpoint support
export class EnhancedAPIIntegrationManager {
  private cache = new Map<string, { data: any; timestamp: number; ttl: number }>();
  private isInitialized = false;
  private backgroundSyncInterval: NodeJS.Timeout | null = null;
  private syncFailureCount = 0;
  private maxSyncFailures = 3;
  private lastSyncAttempt = 0;
  private healthStatus = {
    wordpress: false,
    woocommerce: false,
    dokan: false,
    lastCheck: null as Date | null,
  };

  constructor() {
    this.initialize();
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      console.log('🚀 Initializing Enhanced API Integration Manager...');
      
      // Check API health (non-blocking)
      this.checkAPIHealth().catch(error => {
        console.warn('⚠️ Initial health check failed:', error.message);
      });
      
      // Initialize WordPress API connection (non-blocking)
      this.initializeWordPressConnection().catch(error => {
        console.warn('⚠️ Initial connection test failed:', error.message);
      });
      
      this.isInitialized = true;
      console.log('✅ Enhanced API Integration Manager initialized successfully');
    } catch (error) {
      console.error('❌ Failed to initialize API Integration Manager:', error);
      // Don't throw - allow partial functionality
      this.isInitialized = true;
    }
  }

  private async checkAPIHealth(): Promise<void> {
    try {
      const health = await wordpressAPI.healthCheck(true); // Background flag
      this.healthStatus = {
        wordpress: health.wordpress || false,
        woocommerce: health.woocommerce || false,
        dokan: health.api || false, // Using API status for Dokan
        lastCheck: new Date(),
      };
      
      // Reset sync failure count on successful health check
      if (health.wordpress || health.woocommerce || health.api) {
        this.syncFailureCount = Math.max(0, this.syncFailureCount - 1);
      }
      
    } catch (error) {
      this.syncFailureCount++;
      console.warn('🏥 Background health check failed:', error.message);
    }
  }

  private async initializeWordPressConnection(): Promise<void> {
    try {
      // Test basic WordPress connection with minimal data
      await wordpressAPI.getPosts({ per_page: 1 });
      
      // Test WooCommerce connection with minimal data
      await wordpressAPI.getProducts({ per_page: 1 });
      
      // Test Dokan connection with minimal data (optional)
      try {
        await wordpressAPI.getStores({ per_page: 1 });
      } catch (error) {
        // Dokan might not be available, that's okay
        console.warn('⚠️ Dokan connection test failed (this is okay if Dokan is not installed)');
      }
      
    } catch (error) {
      console.warn('⚠️ Connection test failed - this is normal if credentials need to be configured');
    }
  }

  // WordPress Core Content Methods
  async getAllPosts(params: any = {}): Promise<any[]> {
    return this.withCache('posts', () => wordpressAPI.getPosts(params));
  }

  async getAllPages(params: any = {}): Promise<any[]> {
    return this.withCache('pages', () => wordpressAPI.getPages(params));
  }

  async getAllMedia(params: any = {}): Promise<any[]> {
    return this.withCache('media', () => wordpressAPI.getMedia(params));
  }

  // WooCommerce Product Methods
  async getAllProducts(params: any = {}): Promise<any[]> {
    return this.withCache('products', () => wordpressAPI.getProducts(params));
  }

  async getProductById(id: number): Promise<any> {
    return this.withCache(`product_${id}`, () => wordpressAPI.getProduct(id));
  }

  async createProduct(productData: any): Promise<any> {
    const result = await wordpressAPI.createProduct(productData);
    this.clearCachePattern('products');
    return result;
  }

  async updateProduct(id: number, productData: any): Promise<any> {
    const result = await wordpressAPI.updateProduct(id, productData);
    this.clearCachePattern(['products', `product_${id}`]);
    return result;
  }

  // WooCommerce Order Methods
  async getAllOrders(params: any = {}): Promise<any[]> {
    return this.withCache('orders', () => wordpressAPI.getOrders(params));
  }

  async getOrderById(id: number): Promise<any> {
    return this.withCache(`order_${id}`, () => wordpressAPI.getOrder(id));
  }

  async createOrder(orderData: any): Promise<any> {
    const result = await wordpressAPI.createOrder(orderData);
    this.clearCachePattern('orders');
    return result;
  }

  async updateOrder(id: number, orderData: any): Promise<any> {
    const result = await wordpressAPI.updateOrder(id, orderData);
    this.clearCachePattern(['orders', `order_${id}`]);
    return result;
  }

  // Customer Management Methods
  async getAllCustomers(params: any = {}): Promise<any[]> {
    return this.withCache('customers', () => wordpressAPI.getCustomers(params));
  }

  async getCustomerById(id: number): Promise<any> {
    return this.withCache(`customer_${id}`, () => wordpressAPI.getCustomer(id));
  }

  async createCustomer(customerData: any): Promise<any> {
    const result = await wordpressAPI.createCustomer(customerData);
    this.clearCachePattern('customers');
    return result;
  }

  // Dokan Multivendor Methods
  async getAllStores(params: any = {}): Promise<any[]> {
    return this.withCache('dokan_stores', () => wordpressAPI.getStores(params));
  }

  async getAllVendors(params: any = {}): Promise<any[]> {
    return this.withCache('dokan_vendors', () => wordpressAPI.getVendors(params));
  }

  async getDokanAnnouncements(params: any = {}): Promise<any[]> {
    return this.withCache('dokan_announcements', () => wordpressAPI.getAnnouncements(params));
  }

  // Taxonomy Methods
  async getAllCategories(params: any = {}): Promise<any[]> {
    return this.withCache('categories', () => wordpressAPI.getCategories(params));
  }

  async getAllTags(params: any = {}): Promise<any[]> {
    return this.withCache('tags', () => wordpressAPI.getTags(params));
  }

  async getProductCategories(params: any = {}): Promise<any[]> {
    return this.withCache('product_categories', () => wordpressAPI.getProductCategories(params));
  }

  async getProductTags(params: any = {}): Promise<any[]> {
    return this.withCache('product_tags', () => wordpressAPI.getProductTags(params));
  }

  // Coupon Methods
  async getAllCoupons(params: any = {}): Promise<any[]> {
    return this.withCache('coupons', () => wordpressAPI.getCoupons(params));
  }

  async createCoupon(couponData: any): Promise<any> {
    const result = await wordpressAPI.createCoupon(couponData);
    this.clearCachePattern('coupons');
    return result;
  }

  // Generic endpoint access
  async getEndpointData(endpoint: string, params: any = {}): Promise<any> {
    return this.withCache(`custom_${endpoint}`, () => wordpressAPI.getEndpointData(endpoint, params));
  }

  // Batch operations
  async performBatchOperations(operations: Array<{ endpoint: string; method?: string; data?: any }>): Promise<any[]> {
    return wordpressAPI.batchRequest(operations);
  }

  // Cache management methods
  private async withCache<T>(key: string, fetcher: () => Promise<T>, ttl: number = 300000): Promise<T> {
    const cached = this.cache.get(key);
    
    if (cached && Date.now() < cached.timestamp + cached.ttl) {
      return cached.data;
    }

    const data = await fetcher();
    
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl,
    });

    return data;
  }

  private clearCachePattern(patterns: string | string[]): void {
    const patternsArray = Array.isArray(patterns) ? patterns : [patterns];
    
    for (const [key] of this.cache) {
      if (patternsArray.some(pattern => key.includes(pattern))) {
        this.cache.delete(key);
      }
    }
  }

  // Dashboard data aggregation with better error handling
  async getDashboardData(): Promise<any> {
    try {
      console.log('📊 Aggregating dashboard data...');
      
      const [
        recentProducts,
        recentOrders,
        productCategories,
        stores,
        healthStatus,
      ] = await Promise.allSettled([
        this.getAllProducts({ per_page: 5, orderby: 'date', order: 'desc' }).catch(() => []),
        this.getAllOrders({ per_page: 5, orderby: 'date', order: 'desc' }).catch(() => []),
        this.getProductCategories({ per_page: 10 }).catch(() => []),
        this.getAllStores({ per_page: 5 }).catch(() => []),
        wordpressAPI.healthCheck().catch(() => ({ error: 'Health check failed' })),
      ]);

      return {
        products: {
          recent: recentProducts.status === 'fulfilled' ? recentProducts.value : [],
          total: recentProducts.status === 'fulfilled' ? recentProducts.value.length : 0,
        },
        orders: {
          recent: recentOrders.status === 'fulfilled' ? recentOrders.value : [],
          total: recentOrders.status === 'fulfilled' ? recentOrders.value.length : 0,
        },
        categories: productCategories.status === 'fulfilled' ? productCategories.value : [],
        stores: stores.status === 'fulfilled' ? stores.value : [],
        health: healthStatus.status === 'fulfilled' ? healthStatus.value : { error: 'Health check failed' },
        lastUpdated: new Date().toISOString(),
      };
    } catch (error) {
      console.error('❌ Failed to aggregate dashboard data:', error);
      return {
        products: { recent: [], total: 0 },
        orders: { recent: [], total: 0 },
        categories: [],
        stores: [],
        health: { error: 'Dashboard data aggregation failed' },
        lastUpdated: new Date().toISOString(),
      };
    }
  }

  // Real-time updates and webhooks
  async processWebhookData(webhookData: any): Promise<void> {
    console.log('🔄 Processing webhook data:', webhookData);
    
    try {
      // Clear relevant cache based on webhook type
      if (webhookData.topic) {
        const topic = webhookData.topic;
        
        if (topic.includes('product')) {
          this.clearCachePattern('product');
        } else if (topic.includes('order')) {
          this.clearCachePattern('order');
        } else if (topic.includes('customer')) {
          this.clearCachePattern('customer');
        }
      }
      
      console.log('✅ Webhook data processed successfully');
    } catch (error) {
      console.error('❌ Failed to process webhook data:', error);
    }
  }

  // Get comprehensive statistics
  async getComprehensiveStats(): Promise<any> {
    try {
      const [products, orders, customers, stores] = await Promise.allSettled([
        this.getAllProducts({ per_page: 1 }).catch(() => []),
        this.getAllOrders({ per_page: 1 }).catch(() => []),
        this.getAllCustomers({ per_page: 1 }).catch(() => []),
        this.getAllStores({ per_page: 1 }).catch(() => []),
      ]);

      return {
        products: {
          total: products.status === 'fulfilled' ? products.value.length : 0,
          status: products.status,
        },
        orders: {
          total: orders.status === 'fulfilled' ? orders.value.length : 0,
          status: orders.status,
        },
        customers: {
          total: customers.status === 'fulfilled' ? customers.value.length : 0,
          status: customers.status,
        },
        stores: {
          total: stores.status === 'fulfilled' ? stores.value.length : 0,
          status: stores.status,
        },
        health: this.healthStatus,
        cache: {
          size: this.cache.size,
          keys: Array.from(this.cache.keys()),
        },
        sync: {
          failureCount: this.syncFailureCount,
          lastAttempt: this.lastSyncAttempt,
          isRunning: this.backgroundSyncInterval !== null,
        },
        api: wordpressAPI.getFailureStats(),
      };
    } catch (error) {
      console.error('❌ Failed to get comprehensive stats:', error);
      return { error: error.message };
    }
  }

  // Clear all cache
  clearAllCache(): void {
    this.cache.clear();
    wordpressAPI.clearCache();
    console.log('🗑️ All caches cleared');
  }

  // Get health status
  getHealthStatus(): any {
    return this.healthStatus;
  }

  // Enhanced background sync with better error handling
  async startBackgroundSync(): Promise<void> {
    if (this.backgroundSyncInterval) {
      console.log('🔄 Background sync already running');
      return;
    }

    console.log('🔄 Starting background synchronization...');
    
    // Start with a longer interval and exponential backoff on failures
    const performSync = async () => {
      const now = Date.now();
      this.lastSyncAttempt = now;

      // Skip if we've had too many recent failures
      if (this.syncFailureCount >= this.maxSyncFailures) {
        const nextRetryTime = this.lastSyncAttempt + (Math.pow(2, this.syncFailureCount) * 30000); // Exponential backoff
        if (now < nextRetryTime) {
          return; // Skip this sync
        }
      }

      try {
        // Perform lightweight background health check
        await this.checkAPIHealth();
        
        // Only refresh cache if health check passes
        if (this.healthStatus.wordpress || this.healthStatus.woocommerce) {
          // Refresh only critical cache entries with background flag
          const refreshPromises = [
            this.getAllProducts({ per_page: 1 }).catch(() => null),
            this.getAllOrders({ per_page: 1 }).catch(() => null),
          ];
          
          await Promise.allSettled(refreshPromises);
        }
        
        // Reset failure count on successful sync
        this.syncFailureCount = Math.max(0, this.syncFailureCount - 1);
        
      } catch (error) {
        this.syncFailureCount++;
        // Only log first few failures to avoid spam
        if (this.syncFailureCount <= 3) {
          console.warn('🔄 Background sync failed:', error.message);
        }
      }
    };

    // Initial sync after 5 seconds
    setTimeout(performSync, 5000);
    
    // Set up interval - longer interval to reduce load
    this.backgroundSyncInterval = setInterval(performSync, 120000); // Every 2 minutes instead of 1
    
    console.log('✅ Background sync started (2-minute intervals)');
  }

  async stopBackgroundSync(): Promise<void> {
    if (this.backgroundSyncInterval) {
      clearInterval(this.backgroundSyncInterval);
      this.backgroundSyncInterval = null;
      console.log('🛑 Background sync stopped');
    }
  }

  // Reset sync failures (useful for manual recovery)
  resetSyncFailures(): void {
    this.syncFailureCount = 0;
    this.lastSyncAttempt = 0;
    console.log('🔄 Sync failure count reset');
  }

  // Check if sync is healthy
  isSyncHealthy(): boolean {
    return this.syncFailureCount < this.maxSyncFailures;
  }
}

// Create singleton instance
export const enhancedAPIManager = new EnhancedAPIIntegrationManager();

// Export background data sync interface with better error handling
export const backgroundDataSync = {
  start: () => {
    try {
      return enhancedAPIManager.startBackgroundSync();
    } catch (error) {
      console.error('Failed to start background sync:', error);
    }
  },
  stop: () => {
    try {
      return enhancedAPIManager.stopBackgroundSync();
    } catch (error) {
      console.error('Failed to stop background sync:', error);
    }
  },
  reset: () => enhancedAPIManager.resetSyncFailures(),
  isHealthy: () => enhancedAPIManager.isSyncHealthy(),
  getStats: () => enhancedAPIManager.getComprehensiveStats(),
};

export default enhancedAPIManager;