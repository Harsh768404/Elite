import React, { useState } from 'react';
import { 
  BarChart3, Users, Eye, Activity, Globe, Smartphone, 
  Monitor, TabletSmartphone, TrendingUp, TrendingDown,
  MapPin, Search, Tag, Gift, Calendar, Filter,
  ArrowUpRight, ArrowDownRight, ExternalLink
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';

interface StatCard {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down' | 'neutral';
  icon: React.ComponentType<any>;
}

const overviewStats: StatCard[] = [
  {
    title: 'Total Visitors',
    value: '24,568',
    change: '+12.5%',
    trend: 'up',
    icon: Users
  },
  {
    title: 'Page Views',
    value: '89,234',
    change: '+8.2%',
    trend: 'up',
    icon: Eye
  },
  {
    title: 'Bounce Rate',
    value: '34.2%',
    change: '-2.1%',
    trend: 'down',
    icon: Activity
  },
  {
    title: 'Avg Session',
    value: '4m 32s',
    change: '+15.3%',
    trend: 'up',
    icon: Activity
  }
];

const topPages = [
  { page: '/products/electronics/smartphone', views: 12450, percentage: 23.4, change: '+5.2%' },
  { page: '/products/fashion/mens-clothing', views: 9876, percentage: 18.6, change: '+2.8%' },
  { page: '/products/home-garden/furniture', views: 8234, percentage: 15.5, change: '-1.2%' },
  { page: '/products/books/technology', views: 6543, percentage: 12.3, change: '+8.7%' },
  { page: '/products/sports/fitness', views: 5432, percentage: 10.2, change: '+3.4%' }
];

const locationData = [
  { country: 'India', city: 'Mumbai', visitors: 8234, percentage: 33.5 },
  { country: 'India', city: 'Delhi', visitors: 6789, percentage: 27.6 },
  { country: 'India', city: 'Bangalore', visitors: 4567, percentage: 18.6 },
  { country: 'India', city: 'Chennai', visitors: 3456, percentage: 14.1 },
  { country: 'India', city: 'Pune', visitors: 1498, percentage: 6.1 }
];

const systemInfo = [
  { category: 'Device', name: 'Desktop', percentage: 45.2, color: 'bg-blue-500' },
  { category: 'Device', name: 'Mobile', percentage: 42.8, color: 'bg-green-500' },
  { category: 'Device', name: 'Tablet', percentage: 12.0, color: 'bg-purple-500' },
  { category: 'Browser', name: 'Chrome', percentage: 68.3, color: 'bg-red-500' },
  { category: 'Browser', name: 'Safari', percentage: 18.7, color: 'bg-blue-500' },
  { category: 'Browser', name: 'Firefox', percentage: 8.9, color: 'bg-orange-500' },
  { category: 'Browser', name: 'Edge', percentage: 4.1, color: 'bg-indigo-500' },
  { category: 'OS', name: 'Windows', percentage: 52.4, color: 'bg-blue-600' },
  { category: 'OS', name: 'Android', percentage: 28.9, color: 'bg-green-600' },
  { category: 'OS', name: 'iOS', percentage: 13.2, color: 'bg-gray-600' },
  { category: 'OS', name: 'macOS', percentage: 5.5, color: 'bg-purple-600' }
];

const promotions = [
  { name: 'Winter Sale 2024', type: 'Discount', status: 'Active', impressions: 45678, clicks: 3456, ctr: '7.6%' },
  { name: 'Free Shipping Campaign', type: 'Shipping', status: 'Active', impressions: 23456, clicks: 1876, ctr: '8.0%' },
  { name: 'Electronics Mega Sale', type: 'Category', status: 'Completed', impressions: 67890, clicks: 5432, ctr: '8.0%' },
  { name: 'New User Welcome', type: 'Bonus', status: 'Active', impressions: 12345, clicks: 987, ctr: '8.0%' }
];

const keywords = [
  { keyword: 'smartphone', searches: 1234, clicks: 876, position: 2.3, type: 'internal' },
  { keyword: 'laptop', searches: 987, clicks: 654, position: 1.8, type: 'internal' },
  { keyword: 'headphones', searches: 765, clicks: 432, position: 3.1, type: 'internal' },
  { keyword: 'best smartphone deals', searches: 543, clicks: 321, position: 4.2, type: 'organic' },
  { keyword: 'electronics store', searches: 432, clicks: 234, position: 2.7, type: 'organic' }
];

export function StoreStats() {
  const [dateRange, setDateRange] = useState('30');
  const [selectedCategory, setSelectedCategory] = useState('Device');

  const getChangeIcon = (trend: 'up' | 'down' | 'neutral') => {
    if (trend === 'up') return <ArrowUpRight className="h-4 w-4 text-green-600" />;
    if (trend === 'down') return <ArrowDownRight className="h-4 w-4 text-red-600" />;
    return null;
  };

  const getChangeColor = (trend: 'up' | 'down' | 'neutral') => {
    if (trend === 'up') return 'text-green-600';
    if (trend === 'down') return 'text-red-600';
    return 'text-gray-600';
  };

  return (
    <div className="space-y-6">
      {/* Header with Date Range Filter */}
      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-lg p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-3 mb-2">
              <BarChart3 className="h-6 w-6 text-blue-600" />
              Store Analytics & Statistics
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Comprehensive insights into your store performance and visitor behavior
            </p>
          </div>
          
          {/* Date Range Filter */}
          <div className="flex items-center gap-3">
            <Calendar className="h-5 w-5 text-gray-400" />
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Today</SelectItem>
                <SelectItem value="7">Last 7 Days</SelectItem>
                <SelectItem value="30">Last 30 Days</SelectItem>
                <SelectItem value="90">Last 90 Days</SelectItem>
                <SelectItem value="custom">Custom Range</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* General Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {overviewStats.map((stat, index) => (
          <Card key={index} className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/20">
                  <stat.icon className="h-6 w-6 text-blue-600" />
                </div>
                <div className={`flex items-center gap-1 text-sm ${getChangeColor(stat.trend)}`}>
                  {getChangeIcon(stat.trend)}
                  {stat.change}
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-1">{stat.value}</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">{stat.title}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Top Pages */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Top Pages
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topPages.map((page, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{page.page}</p>
                    <div className="flex items-center gap-4 mt-1">
                      <span className="text-xs text-gray-600 dark:text-gray-400">
                        {page.views.toLocaleString()} views
                      </span>
                      <Progress value={page.percentage} className="w-20 h-2" />
                      <span className="text-xs text-gray-600 dark:text-gray-400">
                        {page.percentage}%
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs ${page.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                      {page.change}
                    </span>
                    <Button variant="ghost" size="sm">
                      <ExternalLink className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Location */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Visitor Locations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {locationData.map((location, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center text-white text-xs font-medium">
                      {location.city.charAt(0)}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{location.city}</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">{location.country}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{location.visitors.toLocaleString()}</p>
                    <p className="text-xs text-gray-600 dark:text-gray-400">{location.percentage}%</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Info */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Monitor className="h-5 w-5" />
              System Information
            </CardTitle>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Device">Device</SelectItem>
                <SelectItem value="Browser">Browser</SelectItem>
                <SelectItem value="OS">OS</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {systemInfo
              .filter(item => item.category === selectedCategory)
              .map((item, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium">{item.name}</span>
                    <span className="text-sm text-gray-600 dark:text-gray-400">{item.percentage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full ${item.color}`}
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Promotions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5" />
              Promotion Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {promotions.map((promo, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">{promo.name}</h4>
                    <Badge variant={promo.status === 'Active' ? 'default' : 'secondary'}>
                      {promo.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-gray-600 dark:text-gray-400 mb-3">
                    <Tag className="h-3 w-3" />
                    {promo.type}
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-lg font-semibold">{promo.impressions.toLocaleString()}</div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Impressions</div>
                    </div>
                    <div>
                      <div className="text-lg font-semibold">{promo.clicks.toLocaleString()}</div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Clicks</div>
                    </div>
                    <div>
                      <div className="text-lg font-semibold text-green-600">{promo.ctr}</div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">CTR</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Keywords */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Keywords Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="internal">Internal</TabsTrigger>
                <TabsTrigger value="organic">Organic</TabsTrigger>
              </TabsList>
              
              <TabsContent value="all" className="mt-4">
                <div className="space-y-3">
                  {keywords.map((keyword, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium">{keyword.keyword}</span>
                          <Badge variant="outline" className="text-xs">
                            {keyword.type}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-gray-600 dark:text-gray-400">
                          <span>{keyword.searches} searches</span>
                          <span>{keyword.clicks} clicks</span>
                          <span>Pos: {keyword.position}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-semibold">
                          {((keyword.clicks / keyword.searches) * 100).toFixed(1)}%
                        </div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">CTR</div>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="internal" className="mt-4">
                <div className="space-y-3">
                  {keywords.filter(k => k.type === 'internal').map((keyword, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <span className="text-sm font-medium">{keyword.keyword}</span>
                        <div className="flex items-center gap-4 text-xs text-gray-600 dark:text-gray-400 mt-1">
                          <span>{keyword.searches} searches</span>
                          <span>{keyword.clicks} clicks</span>
                        </div>
                      </div>
                      <div className="text-sm font-semibold">
                        {((keyword.clicks / keyword.searches) * 100).toFixed(1)}%
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="organic" className="mt-4">
                <div className="space-y-3">
                  {keywords.filter(k => k.type === 'organic').map((keyword, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <span className="text-sm font-medium">{keyword.keyword}</span>
                        <div className="flex items-center gap-4 text-xs text-gray-600 dark:text-gray-400 mt-1">
                          <span>Position: {keyword.position}</span>
                          <span>{keyword.clicks} clicks</span>
                        </div>
                      </div>
                      <div className="text-sm font-semibold">
                        {((keyword.clicks / keyword.searches) * 100).toFixed(1)}%
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}