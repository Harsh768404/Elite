import React, { useState, useEffect } from 'react';
import { Bell, Settings, LogOut, User, ChevronDown, Menu, Shield, Zap, Crown, Clock, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { Skeleton } from './ui/skeleton';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { useAuth } from '../contexts/AuthContext';
import { EliteQNavbarLogo } from './EliteQIndiaLogo';
import { announcementService, type AnnouncementListItem } from '../utils/announcement-service';

interface EliteQTopNavbarProps {
  onMenuToggle?: () => void;
  showMenuButton?: boolean;
}

export const EliteQTopNavbar: React.FC<EliteQTopNavbarProps> = ({ 
  onMenuToggle, 
  showMenuButton = false 
}) => {
  const { user, logout, getDisplayName, getAvatarUrl } = useAuth();
  const [announcements, setAnnouncements] = useState<AnnouncementListItem[]>([]);
  const [announcementCount, setAnnouncementCount] = useState(0);
  const [loadingAnnouncements, setLoadingAnnouncements] = useState(false);
  const [announcementDropdownOpen, setAnnouncementDropdownOpen] = useState(false);

  // Load announcements on component mount and when dropdown opens
  useEffect(() => {
    loadAnnouncements();
    
    // Set up periodic refresh every 5 minutes
    const interval = setInterval(() => {
      loadAnnouncements();
    }, 300000); // 5 minutes

    return () => clearInterval(interval);
  }, []);

  // Load announcements when dropdown opens
  useEffect(() => {
    if (announcementDropdownOpen) {
      loadAnnouncements(true);
    }
  }, [announcementDropdownOpen]);

  const loadAnnouncements = async (forceRefresh = false) => {
    try {
      setLoadingAnnouncements(true);
      const recentAnnouncements = await announcementService.getRecentAnnouncements(5);
      const count = await announcementService.getAnnouncementCount();
      
      setAnnouncements(recentAnnouncements);
      setAnnouncementCount(count);
      
      console.log('🔔 Loaded announcements for bell icon:', recentAnnouncements.length);
    } catch (error) {
      console.error('🔔 Error loading announcements:', error);
    } finally {
      setLoadingAnnouncements(false);
    }
  };

  const getInitials = (name: string): string => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'administrator':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400 border-red-200 dark:border-red-700';
      case 'shop_manager':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400 border-purple-200 dark:border-purple-700';
      case 'vendor':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400 border-blue-200 dark:border-blue-700';
      case 'customer':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400 border-green-200 dark:border-green-700';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400 border-gray-200 dark:border-gray-700';
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'administrator':
        return <Crown className="h-3 w-3" />;
      case 'shop_manager':
        return <Shield className="h-3 w-3" />;
      case 'vendor':
        return <Zap className="h-3 w-3" />;
      case 'customer':
        return <User className="h-3 w-3" />;
      default:
        return <Shield className="h-3 w-3" />;
    }
  };

  const getRoleDisplayName = (role: string) => {
    // First check if user has primary_role_display (preferred for UI display)
    if (user && (user as any).primary_role_display && role === user.primary_role) {
      return (user as any).primary_role_display;
    }
    
    // Fallback to manual mapping
    switch (role) {
      case 'administrator':
        return 'Administrator';
      case 'shop_manager':
        return 'Shop Manager';
      case 'vendor':
        return 'Vendor';
      case 'customer':
        return 'Customer';
      case 'subscriber':
        return 'Subscriber';
      default:
        return role.charAt(0).toUpperCase() + role.slice(1);
    }
  };

  const handleLogout = () => {
    console.log('🚪 User logging out from top navbar');
    console.log('👤 User role before logout:', user?.primary_role);
    console.log('🎯 User roles array before logout:', user?.roles);
    logout();
  };

  if (!user) {
    return null;
  }

  // Debug log for navbar rendering
  console.log('🧭 ===== NAVBAR RENDERING =====');
  console.log('👤 Current user:', user.display_name);
  console.log('📧 Current email:', user.email);
  console.log('🎭 Primary role:', user.primary_role);
  console.log('🎯 All roles:', user.roles);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-16 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md border-b border-gray-200 dark:border-gray-800 shadow-sm">
      <div className="flex items-center justify-between h-full px-4 lg:px-6">
        
        {/* Left Section - Logo and Menu */}
        <div className="flex items-center gap-4">
          {showMenuButton && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onMenuToggle}
              className="lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </Button>
          )}
          
          {/* EliteQ India Logo with Tagline */}
          <div className="flex items-center">
            <div className="flex flex-col">
              <EliteQNavbarLogo />
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1 ml-1 hidden sm:block">
                <span className="font-medium">Powerful Dashboard</span>
              </div>
            </div>
          </div>
          
          {/* Electronics marketplace indicator with user role */}
          <div className="hidden lg:flex items-center gap-2 ml-6">
            <div className="h-4 w-px bg-gray-300 dark:bg-gray-700"></div>
            <div className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
              <Zap className="h-3 w-3 text-orange-500" />
              <span>Electronics Marketplace</span>
              <span>•</span>
              <Badge 
                variant="outline" 
                className={`text-xs px-2 py-0.5 ${getRoleBadgeColor(user.primary_role)}`}
              >
                {getRoleIcon(user.primary_role)}
                <span className="ml-1">{getRoleDisplayName(user.primary_role)}</span>
              </Badge>
            </div>
          </div>
        </div>

        {/* Right Section - User Info and Actions */}
        <div className="flex items-center gap-2 lg:gap-4">
          
          {/* Announcements Bell Icon with Dropdown */}
          <DropdownMenu open={announcementDropdownOpen} onOpenChange={setAnnouncementDropdownOpen}>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-5 w-5" />
                {announcementCount > 0 && (
                  <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center animate-pulse">
                    {announcementCount > 9 ? '9+' : announcementCount}
                  </div>
                )}
              </Button>
            </DropdownMenuTrigger>
            
            <DropdownMenuContent align="end" className="w-80 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-xl">
              {/* Header */}
              <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-gray-900 dark:text-white">Announcements</h3>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      {announcementCount}
                    </Badge>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => loadAnnouncements(true)}
                      disabled={loadingAnnouncements}
                    >
                      <RefreshCw className={`h-3 w-3 ${loadingAnnouncements ? 'animate-spin' : ''}`} />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Announcements List */}
              <div className="max-h-96 overflow-y-auto">
                {loadingAnnouncements ? (
                  <div className="p-4 space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="space-y-2">
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-3 w-1/2" />
                        <Skeleton className="h-3 w-1/4" />
                      </div>
                    ))}
                  </div>
                ) : announcements.length > 0 ? (
                  <div className="py-1">
                    {announcements.map((announcement) => (
                      <div key={announcement.id} className="px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-600 last:border-b-0">
                        <div className="space-y-1">
                          <h4 className="font-medium text-sm text-gray-900 dark:text-white leading-tight">
                            {announcement.title}
                          </h4>
                          <p className="text-xs text-gray-600 dark:text-gray-400 line-clamp-2">
                            {announcement.description}
                          </p>
                          <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                            <Clock className="h-3 w-3" />
                            <span>{announcement.timeAgo}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 text-center">
                    <div className="p-3 bg-gray-100 dark:bg-gray-700 rounded-full mx-auto w-fit mb-2">
                      <Bell className="h-4 w-4 text-gray-400" />
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">No announcements</p>
                  </div>
                )}
              </div>

              {/* Footer */}
              {announcements.length > 0 && (
                <div className="px-4 py-2 border-t border-gray-200 dark:border-gray-700">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="w-full text-xs"
                    onClick={() => {
                      setAnnouncementDropdownOpen(false);
                      // This will be handled by the dashboard's module system
                      if (typeof window !== 'undefined') {
                        window.dispatchEvent(new CustomEvent('navigate-to-announcements'));
                      }
                    }}
                  >
                    View All Announcements
                  </Button>
                </div>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Settings */}
          <Button variant="ghost" size="sm">
            <Settings className="h-5 w-5" />
          </Button>

          {/* User Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2 p-2 h-auto hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                <Avatar className="h-8 w-8 ring-2 ring-blue-500/20">
                  <AvatarImage 
                    src={getAvatarUrl()} 
                    alt={getDisplayName()}
                    className="object-cover"
                  />
                  <AvatarFallback className="bg-gradient-to-br from-blue-600 to-blue-700 text-white text-sm font-medium">
                    {getInitials(getDisplayName())}
                  </AvatarFallback>
                </Avatar>
                
                <div className="hidden lg:flex lg:flex-col lg:items-start lg:text-left">
                  <div className="text-sm font-medium text-gray-900 dark:text-white leading-none">
                    {getDisplayName()}
                  </div>
                  <div className="text-xs text-gray-600 dark:text-gray-400 leading-none mt-0.5">
                    {user.email}
                  </div>
                </div>
                
                <ChevronDown className="h-4 w-4 text-gray-500 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            
            <DropdownMenuContent align="end" className="w-72 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-xl">
              {/* User Info Header */}
              <div className="px-3 py-3 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12 ring-2 ring-blue-500/20">
                    <AvatarImage 
                      src={getAvatarUrl()} 
                      alt={getDisplayName()}
                      className="object-cover"
                    />
                    <AvatarFallback className="bg-gradient-to-br from-blue-600 to-blue-700 text-white font-medium">
                      {getInitials(getDisplayName())}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-gray-900 dark:text-white truncate">
                      {getDisplayName()}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400 truncate">
                      {user.email}
                    </div>
                    <div className="mt-1 flex items-center gap-1">
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${getRoleBadgeColor(user.primary_role)}`}
                      >
                        {getRoleIcon(user.primary_role)}
                        <span className="ml-1">{getRoleDisplayName(user.primary_role)}</span>
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>

              {/* Menu Items */}
              <div className="py-1">
                <DropdownMenuItem className="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                  <User className="h-4 w-4" />
                  <span>Profile Settings</span>
                </DropdownMenuItem>
                
                <DropdownMenuItem className="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                  <Settings className="h-4 w-4" />
                  <span>Account Settings</span>
                </DropdownMenuItem>
                
                <DropdownMenuItem className="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                  <Bell className="h-4 w-4" />
                  <div className="flex items-center justify-between flex-1">
                    <span>Announcements</span>
                    {announcementCount > 0 && (
                      <Badge variant="secondary" className="h-5 px-1.5 text-xs">
                        {announcementCount}
                      </Badge>
                    )}
                  </div>
                </DropdownMenuItem>
              </div>

              <DropdownMenuSeparator className="bg-gray-200 dark:bg-gray-700" />

              {/* User Details Section with Real Data */}
              <div className="px-3 py-2 bg-gray-50 dark:bg-gray-800/50">
                <div className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
                  <div className="flex justify-between">
                    <span>User ID:</span>
                    <span className="font-mono">#{user.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Username:</span>
                    <span className="font-medium">{user.username}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Primary Role:</span>
                    <span className="font-medium">{getRoleDisplayName(user.primary_role)}</span>
                  </div>
                  {user.roles.length > 1 && (
                    <div className="pt-1">
                      <span className="block mb-1">All Roles:</span>
                      <div className="flex flex-wrap gap-1">
                        {user.roles.map((role, index) => (
                          <Badge key={index} variant="outline" className="text-xs px-1.5 py-0.5">
                            {getRoleDisplayName(role)}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <DropdownMenuSeparator className="bg-gray-200 dark:bg-gray-700" />

              {/* Logout */}
              <div className="py-1">
                <DropdownMenuItem 
                  onClick={handleLogout}
                  className="flex items-center gap-2 px-3 py-2 cursor-pointer text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Sign Out</span>
                </DropdownMenuItem>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
};

export default EliteQTopNavbar;