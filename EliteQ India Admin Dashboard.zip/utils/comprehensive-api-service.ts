// Comprehensive WordPress/WooCommerce API Service for EliteQ India - WITH NETWORK FIXES
import {
  WordPressPost,
  WordPressPage,
  WordPressMedia,
  WordPressUser,
  WordPressTaxonomy,
  WooCommerceProduct,
  WooCommerceOrder,
  DokanStore,
  DokanVendor,
  ElementorTemplate,
  WoodMartLayout,
  WoodMartSlide,
  WordPressAPIResponse,
  WordPressQueryParams,
  WordPressAPIError,
  JWTAuthResponse,
  WooCommerceSystemStatus
} from '../types/wordpress-types';

import { EnhancedRoleResolver } from './enhanced-role-resolver';
import { networkManager, createAdaptiveRetryConfig, NetworkError } from './network-connectivity-manager';

// API Configuration with network-aware settings
const API_CONFIG = {
  BASE_URL: 'https://eliteq.in',
  WP_API_NAMESPACE: '/wp-json/wp/v2',
  WC_API_NAMESPACE: '/wp-json/wc/v3',
  DOKAN_API_NAMESPACE: '/wp-json/dokan/v1',
  JWT_NAMESPACE: '/wp-json/jwt-auth/v1',
  CONSUMER_KEY: 'ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9',
  CONSUMER_SECRET: 'cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3',
  DEFAULT_PER_PAGE: 20,
  MAX_PER_PAGE: 100,
  // Network-aware timeouts - increased for slow/unstable networks
  REQUEST_TIMEOUT: 35000,     // Increased to 35s for slow networks
  HEALTH_CHECK_TIMEOUT: 20000, // Increased health check timeout  
  RETRY_ATTEMPTS: 1,          // Reduced retries to avoid overwhelming server
  RETRY_DELAY: 5000          // Longer delay between retries
};

// Enhanced permission error detection for WooCommerce
const isPermissionError = (error: any): boolean => {
  if (typeof error === 'string') {
    return error.includes('cannot list resources') || 
           error.includes('Sorry, you are not allowed') ||
           error.includes('rest_forbidden') ||
           error.includes('rest_cannot_read') ||
           error.includes('woocommerce_rest_cannot_view') ||
           error.includes('woocommerce_rest_cannot_read') ||
           error.includes('woocommerce_rest_cannot_edit');
  }
  if (error && error.message) {
    return error.message.includes('cannot list resources') || 
           error.message.includes('Sorry, you are not allowed') ||
           error.message.includes('rest_forbidden') ||
           error.message.includes('rest_cannot_read') ||
           error.message.includes('woocommerce_rest_cannot_view') ||
           error.message.includes('woocommerce_rest_cannot_read') ||
           error.message.includes('woocommerce_rest_cannot_edit');
  }
  if (error && error.code) {
    return error.code === 'woocommerce_rest_cannot_view' ||
           error.code === 'woocommerce_rest_cannot_read' ||
           error.code === 'woocommerce_rest_cannot_edit' ||
           error.code === 'rest_forbidden' ||
           error.code === 'rest_cannot_read';
  }
  return false;
};

// Network error detection
const isNetworkError = (error: any): boolean => {
  if (typeof error === 'string') {
    return error.includes('timeout') || 
           error.includes('Failed to fetch') ||
           error.includes('Network request failed') ||
           error.includes('fetch_failed') ||
           error.includes('network_error');
  }
  if (error && error.message) {
    return error.message.includes('timeout') || 
           error.message.includes('Failed to fetch') ||
           error.message.includes('Network request failed') ||
           error.message.includes('fetch_failed') ||
           error.message.includes('network_error');
  }
  return false;
};

// WordPress server error detection
const isServerError = (error: any): boolean => {
  if (typeof error === 'string') {
    return error.includes('critical error') || 
           error.includes('500') ||
           error.includes('Internal Server Error') ||
           error.includes('server_error');
  }
  if (error && error.message) {
    return error.message.includes('critical error') || 
           error.message.includes('500') ||
           error.message.includes('Internal Server Error') ||
           error.message.includes('server_error');
  }
  return false;
};

// Enhanced authentication manager with NETWORK FIXES
class AuthenticationManager {
  private jwtToken: string | null = null;
  private tokenExpiry: number | null = null;
  private refreshPromise: Promise<string> | null = null;
  private userRoles: string[] = [];
  private roleResolver: EnhancedRoleResolver | null = null;
  private userCapabilities: { [key: string]: boolean } = {};
  private lastRoleResolution: any = null;
  private wordpressRoleIssues: string[] = [];
  private woocommercePermissionIssues: string[] = [];
  private networkIssues: string[] = [];

  constructor() {
    this.loadTokenFromStorage();
    this.initializeNetworkMonitoring();
  }

  private initializeNetworkMonitoring(): void {
    // Monitor network status changes
    networkManager.onStatusChange((status) => {
      console.log('🌐 Network status changed:', status);
      
      if (!status.isOnline) {
        this.networkIssues.push('Network connection lost');
      } else if (status.isOnline && this.networkIssues.length > 0) {
        console.log('🌐 Network restored, clearing network issues');
        this.networkIssues = [];
      }
      
      if (!status.isWordPressReachable) {
        this.networkIssues.push('WordPress server unreachable');
      }
      
      if (!status.isWooCommerceReachable) {
        this.networkIssues.push('WooCommerce API unreachable');
      }
    });
  }

  private loadTokenFromStorage(): void {
    try {
      const token = localStorage.getItem('eliteq_jwt_token');
      const expiry = localStorage.getItem('eliteq_jwt_expiry');
      const roles = localStorage.getItem('eliteq_user_roles');
      const capabilities = localStorage.getItem('eliteq_user_capabilities');
      
      if (token && expiry) {
        const expiryTime = parseInt(expiry, 10);
        if (expiryTime > Date.now()) {
          this.jwtToken = token;
          this.tokenExpiry = expiryTime;
          this.userRoles = roles ? JSON.parse(roles) : [];
          this.userCapabilities = capabilities ? JSON.parse(capabilities) : {};
          console.log('✅ JWT token, roles, and capabilities loaded from storage');
          console.log('🎭 Cached user roles:', this.userRoles);
          console.log('🔑 Cached capabilities count:', Object.keys(this.userCapabilities).length);
          
          // Initialize role resolver
          this.roleResolver = new EnhancedRoleResolver(API_CONFIG.BASE_URL, token);
        } else {
          console.log('⚠️ JWT token expired, clearing from storage');
          this.clearToken();
        }
      }
    } catch (error) {
      console.error('❌ Error loading JWT token from storage:', error);
    }
  }

  private saveTokenToStorage(token: string, expiry: number, roles: string[] = [], capabilities: { [key: string]: boolean } = {}): void {
    try {
      localStorage.setItem('eliteq_jwt_token', token);
      localStorage.setItem('eliteq_jwt_expiry', expiry.toString());
      localStorage.setItem('eliteq_user_roles', JSON.stringify(roles));
      localStorage.setItem('eliteq_user_capabilities', JSON.stringify(capabilities));
      console.log('💾 JWT token, roles, and capabilities saved to storage');
      console.log('🎭 Saved user roles:', roles);
      console.log('🔑 Saved capabilities count:', Object.keys(capabilities).length);
    } catch (error) {
      console.error('❌ Error saving JWT token to storage:', error);
    }
  }

  private clearToken(): void {
    this.jwtToken = null;
    this.tokenExpiry = null;
    this.userRoles = [];
    this.userCapabilities = {};
    this.roleResolver = null;
    this.lastRoleResolution = null;
    this.wordpressRoleIssues = [];
    this.woocommercePermissionIssues = [];
    this.networkIssues = [];
    localStorage.removeItem('eliteq_jwt_token');
    localStorage.removeItem('eliteq_jwt_expiry');
    localStorage.removeItem('eliteq_user_roles');
    localStorage.removeItem('eliteq_user_capabilities');
    localStorage.removeItem('eliteq_primary_role');
    localStorage.removeItem('eliteq_dashboard_route');
    localStorage.removeItem('eliteq_role_resolution_method');
    localStorage.removeItem('eliteq_role_debug_info');
    localStorage.removeItem('eliteq_woocommerce_issues');
    localStorage.removeItem('eliteq_network_issues');
  }

  public async getValidToken(): Promise<string | null> {
    if (!this.jwtToken) {
      return null;
    }

    if (this.tokenExpiry && this.tokenExpiry > Date.now() + 300000) {
      return this.jwtToken;
    }

    if (this.refreshPromise) {
      return this.refreshPromise;
    }

    this.refreshPromise = this.refreshToken();
    const newToken = await this.refreshPromise;
    this.refreshPromise = null;
    
    return newToken;
  }

  private async refreshToken(): Promise<string> {
    try {
      console.log('🔄 Attempting to refresh JWT token with network retry...');
      
      const retryConfig = createAdaptiveRetryConfig({
        maxAttempts: 2,
        timeoutMs: 10000 // Shorter timeout for token refresh
      });

      const data: JWTAuthResponse = await networkManager.fetchWithRetry(
        `${API_CONFIG.BASE_URL}${API_CONFIG.JWT_NAMESPACE}/token/refresh`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.jwtToken}`
          }
        },
        retryConfig
      );
      
      if (data.token) {
        const expiry = Date.now() + (24 * 60 * 60 * 1000);
        this.jwtToken = data.token;
        this.tokenExpiry = expiry;
        
        // Re-resolve roles after token refresh
        await this.resolveUserRoles();
        
        this.saveTokenToStorage(data.token, expiry, this.userRoles, this.userCapabilities);
        console.log('✅ JWT token refreshed successfully');
        return data.token;
      }

      throw new Error('No token in refresh response');
    } catch (error) {
      console.error('❌ Token refresh failed:', error);
      
      if (isNetworkError(error)) {
        this.networkIssues.push('Token refresh failed due to network issues');
      }
      
      this.clearToken();
      throw error;
    }
  }

  public async login(username: string, password: string): Promise<JWTAuthResponse & { userRoles: string[] }> {
    try {
      console.log('🔐 ===== ENHANCED JWT LOGIN WITH NETWORK FIXES =====');
      console.log('👤 Attempting login for:', username);
      
      // Check network connectivity first
      const connectionStatus = networkManager.getConnectionStatus();
      if (!connectionStatus.isOnline) {
        throw new Error('Network connection is offline. Please check your internet connection.');
      }

      const retryConfig = createAdaptiveRetryConfig({
        maxAttempts: 3,
        timeoutMs: 15000
      });

      const data: JWTAuthResponse = await networkManager.fetchWithRetry(
        `${API_CONFIG.BASE_URL}${API_CONFIG.JWT_NAMESPACE}/token`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ username, password })
        },
        retryConfig
      );
      
      if (data.token) {
        const expiry = Date.now() + (24 * 60 * 60 * 1000);
        this.jwtToken = data.token;
        this.tokenExpiry = expiry;
        
        // Initialize role resolver with improved WordPress roles handling
        this.roleResolver = new EnhancedRoleResolver(API_CONFIG.BASE_URL, data.token);
        
        // CRITICAL: Use enhanced role resolver
        await this.resolveUserRoles(data);
        
        // ENHANCED: Check for WooCommerce permission issues
        await this.checkWooCommercePermissions();
        
        this.saveTokenToStorage(data.token, expiry, this.userRoles, this.userCapabilities);
        console.log('✅ Enhanced JWT login successful with roles:', this.userRoles);
        
        return {
          ...data,
          userRoles: this.userRoles
        };
      }

      throw new Error('No token received');
    } catch (error) {
      console.error('❌ Enhanced JWT login failed:', error);
      
      if (isNetworkError(error)) {
        this.networkIssues.push('Login failed due to network connectivity issues');
        throw new Error('Login failed due to network issues. Please check your connection and try again.');
      } else if (isServerError(error)) {
        this.networkIssues.push('Login failed due to WordPress server error');
        throw new Error('WordPress server is experiencing issues. Please try again later.');
      }
      
      throw error;
    }
  }

  private async resolveUserRoles(jwtData?: JWTAuthResponse): Promise<void> {
    if (!this.roleResolver || !this.jwtToken) {
      console.error('❌ Cannot resolve roles: missing resolver or token');
      return;
    }

    try {
      console.log('🔧 ===== RESOLVING USER ROLES WITH NETWORK FIXES =====');
      
      // Extract user ID from JWT token if not provided
      let userId = jwtData?.user_id;
      if (!userId) {
        try {
          const payload = JSON.parse(atob(this.jwtToken.split('.')[1]));
          userId = payload.data?.user?.id || payload.user_id || payload.id;
        } catch (error) {
          console.error('❌ Could not extract user ID from JWT token:', error);
        }
      }

      console.log('🎯 Resolving roles for user ID:', userId);

      // Use enhanced role resolver with NETWORK FIXES
      const roleResult = await this.roleResolver.resolveUserRoles(userId, jwtData);
      
      // Store the complete resolution result for debugging
      this.lastRoleResolution = roleResult;
      
      console.log('✅ ===== ENHANCED ROLE RESOLUTION COMPLETE =====');
      console.log('🎭 Resolved roles:', roleResult.roles);
      console.log('👑 Primary role:', roleResult.primary_role);
      console.log('🔧 Resolution method:', roleResult.resolution_method);
      console.log('📊 Debug info:', roleResult.debug_info);
      
      // CRITICAL: Check for WordPress-specific issues
      if (roleResult.debug_info?.wordpressIssues) {
        this.wordpressRoleIssues = roleResult.debug_info.wordpressIssues;
        console.warn('⚠️ WordPress role issues detected:', this.wordpressRoleIssues);
      }
      
      this.userRoles = roleResult.roles;
      
      // Try to get capabilities if available (but don't fail if not accessible)
      try {
        const currentUser = await this.getCurrentUserSafe();
        if (currentUser && currentUser.capabilities) {
          this.userCapabilities = currentUser.capabilities;
          console.log('✅ User capabilities retrieved:', Object.keys(this.userCapabilities).length);
        }
      } catch (capError) {
        console.warn('⚠️ Could not retrieve user capabilities (may be normal for security):', capError);
        
        if (isNetworkError(capError)) {
          this.networkIssues.push('Failed to retrieve user capabilities due to network issues');
        }
        
        this.userCapabilities = {};
      }
      
      // Store additional role information
      localStorage.setItem('eliteq_primary_role', roleResult.primary_role);
      localStorage.setItem('eliteq_dashboard_route', roleResult.dashboard_route);
      localStorage.setItem('eliteq_role_resolution_method', roleResult.resolution_method);
      localStorage.setItem('eliteq_role_debug_info', JSON.stringify(roleResult.debug_info));
      localStorage.setItem('eliteq_wordpress_issues', JSON.stringify(this.wordpressRoleIssues));
      localStorage.setItem('eliteq_network_issues', JSON.stringify(this.networkIssues));
      
    } catch (error) {
      console.error('❌ Role resolution failed:', error);
      
      if (isNetworkError(error)) {
        this.networkIssues.push('Role resolution failed due to network connectivity issues');
        console.warn('🌐 Role resolution failed due to network issues, using fallback');
      }
      
      // Emergency fallback - try to extract from JWT token
      try {
        const payload = JSON.parse(atob(this.jwtToken.split('.')[1]));
        if (payload.roles) {
          this.userRoles = Array.isArray(payload.roles) ? payload.roles : [payload.roles];
          console.log('🔧 Emergency fallback: using roles from JWT payload:', this.userRoles);
        } else {
          // CRITICAL: Only use subscriber as absolute last resort
          this.userRoles = ['subscriber'];
          console.error('🚨 ABSOLUTE FALLBACK: Using subscriber role - investigate network/API issues!');
          this.wordpressRoleIssues.push('Emergency fallback to subscriber role due to complete role resolution failure');
        }
      } catch (jwtError) {
        console.error('❌ JWT payload parsing also failed:', jwtError);
        this.userRoles = ['subscriber'];
        this.wordpressRoleIssues.push('Both WordPress API and JWT token parsing failed');
      }
    }
  }

  // NEW: Check WooCommerce permissions specifically with network handling
  private async checkWooCommercePermissions(): Promise<void> {
    console.log('🛒 ===== CHECKING WOOCOMMERCE PERMISSIONS WITH NETWORK HANDLING =====');
    this.woocommercePermissionIssues = [];

    // Test basic WooCommerce access
    const testEndpoints = [
      { name: 'Products', endpoint: '/products', params: { per_page: 1 } },
      { name: 'Orders', endpoint: '/orders', params: { per_page: 1 } },
      { name: 'Customers', endpoint: '/customers', params: { per_page: 1 } }
    ];

    for (const test of testEndpoints) {
      try {
        const url = new URL(`${API_CONFIG.BASE_URL}${API_CONFIG.WC_API_NAMESPACE}${test.endpoint}`);
        url.searchParams.set('consumer_key', API_CONFIG.CONSUMER_KEY);
        url.searchParams.set('consumer_secret', API_CONFIG.CONSUMER_SECRET);
        
        if (test.params) {
          Object.entries(test.params).forEach(([key, value]) => {
            url.searchParams.set(key, value.toString());
          });
        }

        const retryConfig = createAdaptiveRetryConfig({
          maxAttempts: 2,
          timeoutMs: 10000 // Shorter timeout for permission checks
        });

        await networkManager.fetchWithRetry(url.toString(), {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${this.jwtToken}`,
            'Accept': 'application/json'
          }
        }, retryConfig);

        console.log(`✅ WooCommerce ${test.name} access: OK`);

      } catch (error) {
        console.warn(`⚠️ WooCommerce ${test.name} test failed:`, error);
        
        if (isNetworkError(error)) {
          this.woocommercePermissionIssues.push(`${test.name} endpoint network error: Check network connection`);
          this.networkIssues.push(`WooCommerce ${test.name} endpoint unreachable`);
        } else if (isPermissionError(error)) {
          this.woocommercePermissionIssues.push(`Cannot access ${test.name}: Permission denied`);
        } else if (isServerError(error)) {
          this.woocommercePermissionIssues.push(`${test.name} endpoint server error: WordPress issues`);
          this.networkIssues.push(`WooCommerce ${test.name} endpoint server error`);
        } else {
          this.woocommercePermissionIssues.push(`${test.name} endpoint failed: ${error}`);
        }
      }
    }

    // Store WooCommerce issues
    localStorage.setItem('eliteq_woocommerce_issues', JSON.stringify(this.woocommercePermissionIssues));

    if (this.woocommercePermissionIssues.length > 0) {
      console.warn('🚨 WooCommerce Permission Issues Detected:');
      this.woocommercePermissionIssues.forEach(issue => console.warn(`  • ${issue}`));
      
      // Provide guidance based on user role
      if (this.userRoles.includes('administrator')) {
        console.warn('💡 You are an administrator but lack WooCommerce permissions. Check WooCommerce settings and network connectivity.');
      } else if (this.userRoles.includes('shop_manager')) {
        console.warn('💡 You are a shop manager but lack some WooCommerce permissions. This may be normal or due to network issues.');
      } else {
        console.warn('💡 Your WordPress role may not have WooCommerce access permissions, or there are network connectivity issues.');
      }
    } else {
      console.log('✅ All WooCommerce permission checks passed');
    }
  }

  // Safe method to get current user without throwing permission errors
  private async getCurrentUserSafe(): Promise<any> {
    try {
      const retryConfig = createAdaptiveRetryConfig({
        maxAttempts: 2,
        timeoutMs: 8000
      });

      return await networkManager.fetchWithRetry(
        `${API_CONFIG.BASE_URL}${API_CONFIG.WP_API_NAMESPACE}/users/me`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${this.jwtToken}`,
            'Accept': 'application/json',
          },
        },
        retryConfig
      );

    } catch (error) {
      if (isPermissionError(error)) {
        console.warn('⚠️ Permission denied for /users/me endpoint - user has limited access');
        return null;
      }
      if (isNetworkError(error)) {
        console.warn('⚠️ Network error for /users/me endpoint');
        this.networkIssues.push('Failed to fetch current user due to network issues');
        return null;
      }
      throw error;
    }
  }

  public getUserRoles(): string[] {
    return this.userRoles;
  }

  public getPrimaryRole(): string {
    return localStorage.getItem('eliteq_primary_role') || 'restricted';
  }

  public getDashboardRoute(): string {
    return localStorage.getItem('eliteq_dashboard_route') || '/login';
  }

  public getUserCapabilities(): { [key: string]: boolean } {
    return this.userCapabilities;
  }

  public hasCapability(capability: string): boolean {
    return this.userCapabilities[capability] === true;
  }

  // NEW: Check WooCommerce-specific capabilities
  public hasWooCommerceCapability(capability: string): boolean {
    const wooCommerceCapabilities = [
      'manage_woocommerce',
      'view_woocommerce_reports',
      'edit_shop_orders',
      'read_shop_orders',
      'edit_shop_coupons',
      'edit_products',
      'read_products',
      'delete_products',
      'manage_product_terms',
      'edit_product_terms',
      'delete_product_terms',
      'assign_product_terms'
    ];

    if (wooCommerceCapabilities.includes(capability)) {
      return this.hasCapability(capability) || this.userRoles.includes('administrator') || this.userRoles.includes('shop_manager');
    }

    return this.hasCapability(capability);
  }

  public getLastRoleResolution(): any {
    return this.lastRoleResolution;
  }

  public getWordPressRoleIssues(): string[] {
    return this.wordpressRoleIssues;
  }

  public getWooCommercePermissionIssues(): string[] {
    return this.woocommercePermissionIssues;
  }

  public getNetworkIssues(): string[] {
    return this.networkIssues;
  }

  public async debugRoleDetection(): Promise<any> {
    if (!this.roleResolver) {
      return { 
        error: 'No role resolver available',
        wordpressIssues: this.wordpressRoleIssues,
        woocommerceIssues: this.woocommercePermissionIssues,
        networkIssues: this.networkIssues
      };
    }

    try {
      // Get user ID
      let userId;
      if (this.jwtToken) {
        try {
          const payload = JSON.parse(atob(this.jwtToken.split('.')[1]));
          userId = payload.data?.user?.id || payload.user_id || payload.id;
        } catch (error) {
          console.error('Could not extract user ID from JWT token:', error);
        }
      }

      // Run validation
      const validation = await this.roleResolver.validateRoleResolution(userId);
      
      // Get network status
      const networkStatus = networkManager.getConnectionStatus();
      const networkErrors = networkManager.getRecentErrors();
      
      return {
        currentRoles: this.userRoles,
        primaryRole: this.getPrimaryRole(),
        lastResolution: this.lastRoleResolution,
        validation: validation,
        jwtToken: this.jwtToken ? 'Present' : 'Missing',
        userId: userId,
        wordpressIssues: this.wordpressRoleIssues,
        woocommerceIssues: this.woocommercePermissionIssues,
        networkIssues: this.networkIssues,
        networkStatus: networkStatus,
        recentNetworkErrors: networkErrors.slice(0, 10), // Last 10 errors
        capabilities: {
          hasWooCommerceAccess: this.hasWooCommerceCapability('manage_woocommerce'),
          canViewOrders: this.hasWooCommerceCapability('edit_shop_orders'),
          canViewProducts: this.hasWooCommerceCapability('edit_products'),
          canViewReports: this.hasWooCommerceCapability('view_woocommerce_reports')
        },
        storageInfo: {
          roles: localStorage.getItem('eliteq_user_roles'),
          primaryRole: localStorage.getItem('eliteq_primary_role'),
          dashboardRoute: localStorage.getItem('eliteq_dashboard_route'),
          resolutionMethod: localStorage.getItem('eliteq_role_resolution_method')
        }
      };
    } catch (error) {
      return { 
        error: error.message,
        wordpressIssues: this.wordpressRoleIssues,
        woocommerceIssues: this.woocommercePermissionIssues,
        networkIssues: this.networkIssues
      };
    }
  }

  public logout(): void {
    this.clearToken();
    console.log('👋 User logged out, all auth data cleared');
  }

  public isAuthenticated(): boolean {
    return this.jwtToken !== null && this.tokenExpiry !== null && this.tokenExpiry > Date.now();
  }
}

// HTTP Client with enhanced network handling
class HTTPClient {
  private authManager: AuthenticationManager;

  constructor(authManager: AuthenticationManager) {
    this.authManager = authManager;
  }

  private buildWooCommerceUrl(endpoint: string, params?: WordPressQueryParams): string {
    const url = new URL(`${API_CONFIG.BASE_URL}${API_CONFIG.WC_API_NAMESPACE}${endpoint}`);
    
    url.searchParams.set('consumer_key', API_CONFIG.CONSUMER_KEY);
    url.searchParams.set('consumer_secret', API_CONFIG.CONSUMER_SECRET);
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          if (Array.isArray(value)) {
            value.forEach(v => url.searchParams.append(key, v.toString()));
          } else {
            url.searchParams.set(key, value.toString());
          }
        }
      });
    }
    
    return url.toString();
  }

  private buildWordPressUrl(endpoint: string, params?: WordPressQueryParams): string {
    const url = new URL(`${API_CONFIG.BASE_URL}${API_CONFIG.WP_API_NAMESPACE}${endpoint}`);
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          if (Array.isArray(value)) {
            value.forEach(v => url.searchParams.append(key, v.toString()));
          } else {
            url.searchParams.set(key, value.toString());
          }
        }
      });
    }
    
    return url.toString();
  }

  private async getAuthHeaders(): Promise<Record<string, string>> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'User-Agent': 'EliteQ-Admin-Panel/1.0'
    };

    try {
      const token = await this.authManager.getValidToken();
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
    } catch (error) {
      console.warn('⚠️ Could not get auth token for request:', error);
    }

    return headers;
  }

  public async request<T>(
    url: string,
    options: RequestInit = {},
    skipRetry: boolean = false
  ): Promise<T> {
    try {
      const headers = await this.getAuthHeaders();
      
      const requestOptions = {
        ...options,
        headers: {
          ...headers,
          ...options.headers
        }
      };

      if (skipRetry) {
        // Direct fetch without retry for simple requests
        const response = await fetch(url, {
          ...requestOptions,
          signal: AbortSignal.timeout(API_CONFIG.REQUEST_TIMEOUT)
        });

        if (!response.ok) {
          let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
          try {
            const errorData = await response.json();
            if (errorData.message) {
              errorMessage = errorData.message;
            }
            if (errorData.code) {
              errorMessage = `${errorData.code}: ${errorData.message}`;
            }
          } catch {
            // Ignore JSON parsing errors for error responses
          }
          throw new Error(errorMessage);
        }

        return await response.json();
      } else {
        // Use network manager for retry logic
        const retryConfig = createAdaptiveRetryConfig();
        return await networkManager.fetchWithRetry<T>(url, requestOptions, retryConfig);
      }

    } catch (error) {
      console.error('❌ Request failed:', url, error);
      
      // Enhanced error handling
      if (isNetworkError(error)) {
        throw new Error(`Network error: ${error.message}. Please check your connection and try again.`);
      } else if (isServerError(error)) {
        throw new Error(`WordPress server error: ${error.message}. The server may be experiencing issues.`);
      } else if (isPermissionError(error)) {
        throw new Error(`Permission denied: ${error.message}`);
      }
      
      throw error;
    }
  }

  public async wooCommerceRequest<T>(
    endpoint: string,
    params?: WordPressQueryParams,
    options: RequestInit = {}
  ): Promise<T> {
    const url = this.buildWooCommerceUrl(endpoint, params);
    console.log('🛒 WooCommerce API Request:', endpoint, params);
    return this.request<T>(url, options, false); // Use retry for WooCommerce
  }

  public async wordPressRequest<T>(
    endpoint: string,
    params?: WordPressQueryParams,
    options: RequestInit = {},
    skipRetry: boolean = false
  ): Promise<T> {
    const url = this.buildWordPressUrl(endpoint, params);
    console.log('📝 WordPress API Request:', endpoint, params);
    return this.request<T>(url, options, skipRetry);
  }

  // Safe request method that handles all errors gracefully
  public async safeRequest<T>(
    url: string,
    options: RequestInit = {},
    fallbackValue: T | null = null
  ): Promise<T | null> {
    try {
      return await this.request<T>(url, options, true); // Skip retry for safe requests
    } catch (error) {
      console.warn('⚠️ Safe request failed, returning fallback value:', url, error);
      return fallbackValue;
    }
  }
}

// Main API Service Class - Enhanced with NETWORK FIXES
export class ComprehensiveAPIService {
  private httpClient: HTTPClient;
  private authManager: AuthenticationManager;

  constructor() {
    this.authManager = new AuthenticationManager();
    this.httpClient = new HTTPClient(this.authManager);
    console.log('🚀 Enhanced EliteQ Comprehensive API Service initialized with Network Fixes');
  }

  // Enhanced Authentication methods
  public async login(username: string, password: string): Promise<JWTAuthResponse & { userRoles: string[] }> {
    return this.authManager.login(username, password);
  }

  public logout(): void {
    this.authManager.logout();
  }

  public isAuthenticated(): boolean {
    return this.authManager.isAuthenticated();
  }

  public getUserRoles(): string[] {
    return this.authManager.getUserRoles();
  }

  public getPrimaryRole(): string {
    return this.authManager.getPrimaryRole();
  }

  public getDashboardRoute(): string {
    return this.authManager.getDashboardRoute();
  }

  public getUserCapabilities(): { [key: string]: boolean } {
    return this.authManager.getUserCapabilities();
  }

  public hasCapability(capability: string): boolean {
    return this.authManager.hasCapability(capability);
  }

  // NEW: WooCommerce-specific capability check
  public hasWooCommerceCapability(capability: string): boolean {
    return this.authManager.hasWooCommerceCapability(capability);
  }

  // DEBUG: Method to help troubleshoot role detection issues
  public async debugRoleDetection(): Promise<any> {
    return this.authManager.debugRoleDetection();
  }

  // Get various issue types
  public getWordPressRoleIssues(): string[] {
    return this.authManager.getWordPressRoleIssues();
  }

  public getWooCommercePermissionIssues(): string[] {
    return this.authManager.getWooCommercePermissionIssues();
  }

  public getNetworkIssues(): string[] {
    return this.authManager.getNetworkIssues();
  }

  // NEW: Network status methods
  public getNetworkStatus() {
    return networkManager.getConnectionStatus();
  }

  public getConnectionQuality() {
    return networkManager.getConnectionQuality();
  }

  public async testNetworkConnectivity() {
    return await networkManager.testConnection();
  }

  // WordPress Core Endpoints with enhanced error handling
  public async getPosts(params?: WordPressQueryParams): Promise<WordPressPost[]> {
    try {
      return await this.httpClient.wordPressRequest<WordPressPost[]>('/posts', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list posts, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  public async getPost(id: number): Promise<WordPressPost | null> {
    try {
      return await this.httpClient.wordPressRequest<WordPressPost>(`/posts/${id}`);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot view post, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  public async createPost(post: Partial<WordPressPost>): Promise<WordPressPost> {
    return this.httpClient.wordPressRequest<WordPressPost>('/posts', {}, {
      method: 'POST',
      body: JSON.stringify(post)
    });
  }

  public async updatePost(id: number, post: Partial<WordPressPost>): Promise<WordPressPost> {
    return this.httpClient.wordPressRequest<WordPressPost>(`/posts/${id}`, {}, {
      method: 'PUT',
      body: JSON.stringify(post)
    });
  }

  public async deletePost(id: number): Promise<WordPressPost> {
    return this.httpClient.wordPressRequest<WordPressPost>(`/posts/${id}`, {}, {
      method: 'DELETE'
    });
  }

  public async getPages(params?: WordPressQueryParams): Promise<WordPressPage[]> {
    try {
      return await this.httpClient.wordPressRequest<WordPressPage[]>('/pages', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list pages, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  public async getPage(id: number): Promise<WordPressPage | null> {
    try {
      return await this.httpClient.wordPressRequest<WordPressPage>(`/pages/${id}`);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot view page, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  public async getMedia(params?: WordPressQueryParams): Promise<WordPressMedia[]> {
    try {
      return await this.httpClient.wordPressRequest<WordPressMedia[]>('/media', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list media, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  public async getMediaItem(id: number): Promise<WordPressMedia | null> {
    try {
      return await this.httpClient.wordPressRequest<WordPressMedia>(`/media/${id}`);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot view media item, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  public async getUsers(params?: WordPressQueryParams): Promise<WordPressUser[]> {
    try {
      return await this.httpClient.wordPressRequest<WordPressUser[]>('/users', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list users, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  public async getUser(id: number): Promise<WordPressUser | null> {
    try {
      return await this.httpClient.wordPressRequest<WordPressUser>(`/users/${id}`);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot view user, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  public async getCurrentUser(): Promise<WordPressUser> {
    return this.httpClient.wordPressRequest<WordPressUser>('/users/me');
  }

  public async getCategories(params?: WordPressQueryParams): Promise<WordPressTaxonomy[]> {
    try {
      return await this.httpClient.wordPressRequest<WordPressTaxonomy[]>('/categories', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list categories, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  public async getTags(params?: WordPressQueryParams): Promise<WordPressTaxonomy[]> {
    try {
      return await this.httpClient.wordPressRequest<WordPressTaxonomy[]>('/tags', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list tags, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  // WooCommerce Product Endpoints with enhanced error handling
  public async getProducts(params?: WordPressQueryParams): Promise<WooCommerceProduct[]> {
    try {
      return await this.httpClient.wooCommerceRequest<WooCommerceProduct[]>('/products', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list products, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  public async getProduct(id: number): Promise<WooCommerceProduct | null> {
    try {
      return await this.httpClient.wooCommerceRequest<WooCommerceProduct>(`/products/${id}`);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot view product, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  public async createProduct(product: Partial<WooCommerceProduct>): Promise<WooCommerceProduct> {
    return this.httpClient.wooCommerceRequest<WooCommerceProduct>('/products', {}, {
      method: 'POST',
      body: JSON.stringify(product)
    });
  }

  public async updateProduct(id: number, product: Partial<WooCommerceProduct>): Promise<WooCommerceProduct> {
    return this.httpClient.wooCommerceRequest<WooCommerceProduct>(`/products/${id}`, {}, {
      method: 'PUT',
      body: JSON.stringify(product)
    });
  }

  public async deleteProduct(id: number): Promise<WooCommerceProduct> {
    return this.httpClient.wooCommerceRequest<WooCommerceProduct>(`/products/${id}`, {}, {
      method: 'DELETE'
    });
  }

  public async getProductCategories(params?: WordPressQueryParams): Promise<WordPressTaxonomy[]> {
    try {
      return await this.httpClient.wooCommerceRequest<WordPressTaxonomy[]>('/products/categories', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list product categories, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  public async getProductTags(params?: WordPressQueryParams): Promise<WordPressTaxonomy[]> {
    try {
      return await this.httpClient.wooCommerceRequest<WordPressTaxonomy[]>('/products/tags', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list product tags, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  // WooCommerce Order Endpoints with enhanced error handling
  public async getOrders(params?: WordPressQueryParams): Promise<WooCommerceOrder[]> {
    try {
      return await this.httpClient.wooCommerceRequest<WooCommerceOrder[]>('/orders', params);
    } catch (error) {
      if (isPermissionError(error)) {
        console.warn('⚠️ No permission to list orders, returning empty array');
        console.warn('💡 This is normal if your WordPress role lacks WooCommerce order permissions');
      } else if (isNetworkError(error)) {
        console.warn('⚠️ Network error when listing orders, returning empty array:', error.message);
      }
      return [];
    }
  }

  public async getOrder(id: number): Promise<WooCommerceOrder | null> {
    try {
      return await this.httpClient.wooCommerceRequest<WooCommerceOrder>(`/orders/${id}`);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot view order, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  public async updateOrder(id: number, order: Partial<WooCommerceOrder>): Promise<WooCommerceOrder> {
    return this.httpClient.wooCommerceRequest<WooCommerceOrder>(`/orders/${id}`, {}, {
      method: 'PUT',
      body: JSON.stringify(order)
    });
  }

  public async getCustomers(params?: WordPressQueryParams): Promise<WordPressUser[]> {
    try {
      return await this.httpClient.wooCommerceRequest<WordPressUser[]>('/customers', params);
    } catch (error) {
      if (isPermissionError(error)) {
        console.warn('⚠️ No permission to list customers, returning empty array');
        console.warn('💡 This is normal if your WordPress role lacks customer management permissions');
      } else if (isNetworkError(error)) {
        console.warn('⚠️ Network error when listing customers, returning empty array:', error.message);
      }
      return [];
    }
  }

  public async getCustomer(id: number): Promise<WordPressUser | null> {
    try {
      return await this.httpClient.wooCommerceRequest<WordPressUser>(`/customers/${id}`);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot view customer, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  // Custom Post Type Endpoints with enhanced error handling
  public async getElementorTemplates(params?: WordPressQueryParams): Promise<ElementorTemplate[]> {
    try {
      return await this.httpClient.wordPressRequest<ElementorTemplate[]>('/elementor_library', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list Elementor templates, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  public async getWoodMartLayouts(params?: WordPressQueryParams): Promise<WoodMartLayout[]> {
    try {
      return await this.httpClient.wordPressRequest<WoodMartLayout[]>('/woodmart_layout', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list WoodMart layouts, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  public async getWoodMartSlides(params?: WordPressQueryParams): Promise<WoodMartSlide[]> {
    try {
      return await this.httpClient.wordPressRequest<WoodMartSlide[]>('/woodmart_slide', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot list WoodMart slides, returning empty array:', error.message);
        return [];
      }
      throw error;
    }
  }

  // System and Status Endpoints
  public async getSystemStatus(): Promise<WooCommerceSystemStatus | null> {
    try {
      return await this.httpClient.wooCommerceRequest<WooCommerceSystemStatus>('/system_status');
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot view system status, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  // Generic endpoint method for custom endpoints with enhanced error handling
  public async customWordPressRequest<T>(
    endpoint: string,
    params?: WordPressQueryParams,
    options?: RequestInit
  ): Promise<T | null> {
    try {
      return await this.httpClient.wordPressRequest<T>(endpoint, params, options);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Custom WordPress request failed, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  public async customWooCommerceRequest<T>(
    endpoint: string,
    params?: WordPressQueryParams,
    options?: RequestInit
  ): Promise<T | null> {
    try {
      return await this.httpClient.wooCommerceRequest<T>(endpoint, params, options);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Custom WooCommerce request failed, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  // Bulk operations with enhanced error handling
  public async bulkUpdateProducts(updates: Array<{ id: number; data: Partial<WooCommerceProduct> }>): Promise<WooCommerceProduct[]> {
    const promises = updates.map(update => 
      this.updateProduct(update.id, update.data).catch(error => {
        console.warn(`⚠️ Failed to update product ${update.id}:`, error.message);
        return null;
      })
    );
    const results = await Promise.all(promises);
    return results.filter(result => result !== null) as WooCommerceProduct[];
  }

  public async bulkUpdateOrders(updates: Array<{ id: number; data: Partial<WooCommerceOrder> }>): Promise<WooCommerceOrder[]> {
    const promises = updates.map(update => 
      this.updateOrder(update.id, update.data).catch(error => {
        console.warn(`⚠️ Failed to update order ${update.id}:`, error.message);
        return null;
      })
    );
    const results = await Promise.all(promises);
    return results.filter(result => result !== null) as WooCommerceOrder[];
  }

  // Analytics and Reports with enhanced error handling
  public async getProductSalesReport(params?: { period?: string; date_min?: string; date_max?: string }): Promise<any> {
    try {
      return await this.httpClient.wooCommerceRequest('/reports/sales', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot view sales reports, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  public async getTopSellersReport(params?: { period?: string; date_min?: string; date_max?: string }): Promise<any> {
    try {
      return await this.httpClient.wooCommerceRequest('/reports/top_sellers', params);
    } catch (error) {
      if (isPermissionError(error) || isNetworkError(error)) {
        console.warn('⚠️ Cannot view top sellers report, returning null:', error.message);
        return null;
      }
      throw error;
    }
  }

  // Search and filter methods with enhanced error handling
  public async searchProducts(query: string, params?: WordPressQueryParams): Promise<WooCommerceProduct[]> {
    return this.getProducts({ ...params, search: query });
  }

  public async searchPosts(query: string, params?: WordPressQueryParams): Promise<WordPressPost[]> {
    return this.getPosts({ ...params, search: query });
  }

  public async searchOrders(query: string, params?: WordPressQueryParams): Promise<WooCommerceOrder[]> {
    return this.getOrders({ ...params, search: query });
  }

  // Enhanced health check method with network diagnostics
  public async healthCheck(): Promise<{ 
    status: string; 
    timestamp: string; 
    services: Record<string, boolean>;
    userInfo: {
      authenticated: boolean;
      roles: string[];
      primaryRole: string;
      dashboardRoute: string;
      capabilities: string[];
    };
    permissions: {
      canListProducts: boolean;
      canListOrders: boolean;
      canListUsers: boolean;
      canViewReports: boolean;
      canListCustomers: boolean;
    };
    woocommerceCapabilities: {
      hasWooCommerceAccess: boolean;
      canViewOrders: boolean;
      canViewProducts: boolean;
      canViewReports: boolean;
      canManageCustomers: boolean;
    };
    networkStatus: any;
    connectionQuality: string;
    roleDebug?: any;
    wordpressIssues?: string[];
    woocommerceIssues?: string[];
    networkIssues?: string[];
  }> {
    const timestamp = new Date().toISOString();
    const services: Record<string, boolean> = {};
    const permissions = {
      canListProducts: false,
      canListOrders: false,
      canListUsers: false,
      canViewReports: false,
      canListCustomers: false
    };

    const woocommerceCapabilities = {
      hasWooCommerceAccess: this.hasWooCommerceCapability('manage_woocommerce'),
      canViewOrders: this.hasWooCommerceCapability('edit_shop_orders'),
      canViewProducts: this.hasWooCommerceCapability('edit_products'),
      canViewReports: this.hasWooCommerceCapability('view_woocommerce_reports'),
      canManageCustomers: this.hasWooCommerceCapability('list_users') || this.hasCapability('list_users')
    };

    // Get network status
    const networkStatus = this.getNetworkStatus();
    const connectionQuality = this.getConnectionQuality();

    try {
      // Test WordPress API with safe request
      const posts = await this.httpClient.safeRequest('/wp-json/wp/v2/posts?per_page=1', {}, []);
      services.wordpress = Array.isArray(posts);
    } catch {
      services.wordpress = false;
    }

    try {
      // Test WooCommerce API with safe request
      const products = await this.getProducts({ per_page: 1 });
      services.woocommerce = Array.isArray(products);
      permissions.canListProducts = products.length >= 0;
    } catch {
      services.woocommerce = false;
    }

    // Test permissions with safe methods
    try {
      const orders = await this.getOrders({ per_page: 1 });
      permissions.canListOrders = Array.isArray(orders);
    } catch {
      permissions.canListOrders = false;
    }

    try {
      const users = await this.getUsers({ per_page: 1 });
      permissions.canListUsers = Array.isArray(users);
    } catch {
      permissions.canListUsers = false;
    }

    try {
      const reports = await this.getProductSalesReport();
      permissions.canViewReports = reports !== null;
    } catch {
      permissions.canViewReports = false;
    }

    try {
      const customers = await this.getCustomers({ per_page: 1 });
      permissions.canListCustomers = Array.isArray(customers);
    } catch {
      permissions.canListCustomers = false;
    }

    // Test user authentication and roles
    const userInfo = {
      authenticated: this.isAuthenticated(),
      roles: this.getUserRoles(),
      primaryRole: this.getPrimaryRole(),
      dashboardRoute: this.getDashboardRoute(),
      capabilities: Object.keys(this.getUserCapabilities()).filter(cap => this.hasCapability(cap))
    };

    try {
      if (userInfo.authenticated) {
        await this.getCurrentUser();
        services.authentication = true;
      } else {
        services.authentication = false;
      }
    } catch {
      services.authentication = false;
    }

    const allServicesUp = Object.values(services).every(status => status);
    
    // Get debugging info
    const roleDebug = await this.debugRoleDetection();
    const wordpressIssues = this.getWordPressRoleIssues();
    const woocommerceIssues = this.getWooCommercePermissionIssues();
    const networkIssues = this.getNetworkIssues();
    
    return {
      status: allServicesUp ? 'healthy' : 'degraded',
      timestamp,
      services,
      userInfo,
      permissions,
      woocommerceCapabilities,
      networkStatus,
      connectionQuality,
      roleDebug,
      wordpressIssues,
      woocommerceIssues,
      networkIssues
    };
  }
}

// Create and export singleton instance
export const apiService = new ComprehensiveAPIService();

// Export types for use in components
export * from '../types/wordpress-types';

console.log('✅ Enhanced Comprehensive API Service loaded with Network Connectivity Fixes and enhanced error handling');