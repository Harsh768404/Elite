import React, { useState } from 'react';
import { 
  Home, 
  ShoppingCart, 
  Package, 
  Users, 
  Store, 
  BarChart3, 
  Settings, 
  LogOut,
  ChevronLeft,
  ChevronRight,
  Bell,
  HelpCircle
} from 'lucide-react';
import { Button } from './ui/button';
import { cn } from './ui/utils';

interface ModernDashboardSidebarProps {
  collapsed: boolean;
  userRole: 'admin' | 'vendor';
  onToggle: () => void;
}

interface NavigationItem {
  icon: React.ElementType;
  label: string;
  href: string;
  badge?: number;
  active?: boolean;
  adminOnly?: boolean;
}

export function ModernDashboardSidebar({ collapsed, userRole, onToggle }: ModernDashboardSidebarProps) {
  const [activeItem, setActiveItem] = useState('dashboard');

  const navigationItems: NavigationItem[] = [
    {
      icon: Home,
      label: 'Dashboard',
      href: '/dashboard',
      active: activeItem === 'dashboard'
    },
    {
      icon: ShoppingCart,
      label: 'Orders',
      href: '/orders',
      badge: 5,
      active: activeItem === 'orders'
    },
    {
      icon: Package,
      label: 'Products',
      href: '/products',
      active: activeItem === 'products'
    },
    {
      icon: Users,
      label: 'Customers',
      href: '/customers',
      active: activeItem === 'customers'
    },
    {
      icon: Store,
      label: 'Vendors',
      href: '/vendors',
      active: activeItem === 'vendors',
      adminOnly: true
    },
    {
      icon: BarChart3,
      label: 'Analytics',
      href: '/analytics',
      active: activeItem === 'analytics'
    },
    {
      icon: Bell,
      label: 'Announcements',
      href: '/announcements',
      active: activeItem === 'announcements'
    },
    {
      icon: Settings,
      label: 'Settings',
      href: '/settings',
      active: activeItem === 'settings'
    }
  ];

  const filteredItems = navigationItems.filter(item => 
    userRole === 'admin' || !item.adminOnly
  );

  const handleItemClick = (href: string, label: string) => {
    setActiveItem(label.toLowerCase());
    // Here you would typically handle navigation
    console.log(`Navigating to: ${href}`);
  };

  return (
    <>
      {/* Mobile Overlay */}
      {!collapsed && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onToggle}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed left-0 top-16 h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 z-50",
        collapsed ? "w-16 lg:w-16" : "w-64 lg:w-64",
        "lg:translate-x-0",
        collapsed ? "-translate-x-full lg:translate-x-0" : "translate-x-0"
      )}>
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          {!collapsed && (
            <span className="text-sm font-medium text-gray-900 dark:text-white uppercase tracking-wide">
              Navigation
            </span>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="hidden lg:flex"
          >
            {collapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </Button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 p-4 space-y-2">
          {filteredItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.href}
                onClick={() => handleItemClick(item.href, item.label)}
                className={cn(
                  "w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                  item.active
                    ? "bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800"
                    : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white",
                  collapsed && "justify-center px-2"
                )}
              >
                <Icon className={cn(
                  "h-5 w-5 flex-shrink-0",
                  item.active ? "text-blue-600 dark:text-blue-400" : ""
                )} />
                
                {!collapsed && (
                  <>
                    <span className="truncate">{item.label}</span>
                    {item.badge && (
                      <span className="ml-auto bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs px-2 py-0.5 rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700 space-y-2">
          {/* Help Button */}
          <button
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white transition-all duration-200",
              collapsed && "justify-center px-2"
            )}
          >
            <HelpCircle className="h-5 w-5 flex-shrink-0" />
            {!collapsed && <span>Help & Support</span>}
          </button>

          {/* Logout Button */}
          <button
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all duration-200",
              collapsed && "justify-center px-2"
            )}
          >
            <LogOut className="h-5 w-5 flex-shrink-0" />
            {!collapsed && <span>Logout</span>}
          </button>
        </div>
      </aside>
    </>
  );
}