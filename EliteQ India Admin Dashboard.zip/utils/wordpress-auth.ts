// Complete WordPress JWT Authentication Service - ROLE RESOLUTION FIX
// Enhanced to implement strict role priority (administrator > shop_manager > seller > Dokan fallback)
// CRITICAL FIX: Administrators are no longer misclassified as vendors

import { envConfig } from './env-config';

const WORDPRESS_BASE_URL = envConfig.WORDPRESS_BASE_URL || 'https://eliteq.in';

interface LoginCredentials {
  username: string;
  password: string;
}

interface JWTTokenResponse {
  token: string;
  user_email: string;
  user_nicename: string;
  user_display_name: string;
  user_id?: number; // Optional - some WordPress JWT plugins don't include this
}

interface WordPressUserProfile {
  id: number;
  username: string;
  name: string;
  first_name: string;
  last_name: string;
  email: string;
  roles: string[];
  capabilities: { [key: string]: boolean };
  avatar_urls: { [key: string]: string };
  slug: string;
  description: string;
}

interface AuthenticatedUser {
  id: number;
  username: string;
  email: string;
  display_name: string;
  first_name: string;
  last_name: string;
  avatar_url: string;
  roles: string[];
  primary_role: 'administrator' | 'shop_manager' | 'vendor' | 'restricted';
  primary_role_display: string; // Human-readable role name for UI display
  dashboard_route: string;
  full_name: string;
  capabilities: { [key: string]: boolean };
  avatar_urls: { [key: string]: string };
  authenticated_at: string;
  token_expires_at?: string;
}

class WordPressAuthService {
  private readonly baseUrl = WORDPRESS_BASE_URL;
  private readonly tokenKey = 'wp_jwt_token';
  private readonly userKey = 'wp_user_data';

  /**
   * CRITICAL FIX: Authoritative Role Resolution with Strict Priority
   * Implements the exact requirements from the user:
   * 1. Fetch roles from WordPress API /wp-json/wp/v2/users/me
   * 2. Apply strict priority: administrator > shop_manager > seller > Dokan fallback
   * 3. Never allow admin/shop_manager to be classified as vendor
   */
  private async resolveAuthoritativeUserRole(token: string, userId: number, apiUserData: any): Promise<{
    primary_role: 'administrator' | 'shop_manager' | 'vendor' | 'restricted';
    primary_role_display: string;
    dashboard_route: string;
    hasAccess: boolean;
    roles: string[];
  }> {
    console.log('🎯 ===== AUTHORITATIVE ROLE RESOLUTION - STRICT PRIORITY =====');
    console.log('📋 User ID:', userId);
    console.log('📧 User Email:', apiUserData.email);
    
    // Step 1: Get authoritative roles from WordPress API
    let authoritativeRoles: string[] = [];
    
    try {
      console.log('🔍 Step 1: Fetching authoritative roles from WordPress API...');
      console.log('🌐 API Endpoint:', `${this.baseUrl}/wp-json/wp/v2/users/me`);
      
      const rolesResponse = await fetch(`${this.baseUrl}/wp-json/wp/v2/users/me`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
      });

      if (rolesResponse.ok) {
        const userData = await rolesResponse.json();
        console.log('✅ WordPress API roles response received');
        console.log('🎭 Raw roles field:', userData.roles);
        console.log('🎭 Roles type:', typeof userData.roles);
        
        // Parse roles robustly
        if (Array.isArray(userData.roles)) {
          authoritativeRoles = userData.roles.filter(role => typeof role === 'string' && role.length > 0);
        } else if (typeof userData.roles === 'string') {
          authoritativeRoles = userData.roles.split(',').map(r => r.trim()).filter(r => r.length > 0);
        } else if (typeof userData.roles === 'object' && userData.roles !== null) {
          authoritativeRoles = Object.keys(userData.roles).filter(key => Boolean(userData.roles[key]));
        }
        
        console.log('✅ Step 1 SUCCESS: Parsed authoritative roles:', authoritativeRoles);
      } else {
        console.error('❌ Step 1 FAILED: WordPress API returned', rolesResponse.status);
        throw new Error(`WordPress API failed: ${rolesResponse.status}`);
      }
    } catch (error) {
      console.error('❌ Step 1 FAILED: Could not fetch roles from WordPress API:', error);
      
      // Fallback: Use roles from the provided apiUserData if available
      if (apiUserData && apiUserData.roles) {
        console.log('🔧 Step 1 FALLBACK: Using roles from existing API data');
        if (Array.isArray(apiUserData.roles)) {
          authoritativeRoles = apiUserData.roles.filter(role => typeof role === 'string' && role.length > 0);
        }
        console.log('🔧 Step 1 FALLBACK: Extracted roles:', authoritativeRoles);
      }
    }

    // Step 2: Apply strict role priority mapping
    console.log('🎯 Step 2: Applying STRICT ROLE PRIORITY MAPPING...');
    console.log('📋 Authoritative roles array:', authoritativeRoles);
    
    let resolvedRole: 'administrator' | 'shop_manager' | 'vendor' | 'restricted' = 'restricted';
    let resolvedDisplay = 'Restricted';
    let resolvedRoute = '/login';
    let resolvedAccess = false;
    
    // Priority 1: Administrator (HIGHEST PRIORITY)
    if (authoritativeRoles.includes('administrator')) {
      resolvedRole = 'administrator';
      resolvedDisplay = 'Administrator';
      resolvedRoute = '/admin-dashboard';
      resolvedAccess = true;
      console.log('👑 PRIORITY 1: ADMINISTRATOR role detected - ADMIN ACCESS GRANTED');
      console.log('🚨 CRITICAL: This user MUST NOT be treated as vendor regardless of Dokan store');
    }
    // Priority 2: Shop Manager
    else if (authoritativeRoles.includes('shop_manager')) {
      resolvedRole = 'shop_manager';
      resolvedDisplay = 'Shop Manager';
      resolvedRoute = '/admin-dashboard'; // Shop managers get admin-style access
      resolvedAccess = true;
      console.log('🏢 PRIORITY 2: SHOP MANAGER role detected - ADMIN ACCESS GRANTED');
      console.log('🚨 CRITICAL: This user MUST NOT be treated as vendor regardless of Dokan store');
    }
    // Priority 3: Seller
    else if (authoritativeRoles.includes('seller')) {
      resolvedRole = 'vendor';
      resolvedDisplay = 'Vendor';
      resolvedRoute = '/vendor-dashboard';
      resolvedAccess = true;
      console.log('🏪 PRIORITY 3: SELLER role detected - VENDOR ACCESS GRANTED');
    }
    // Step 3: Fallback - Check Dokan store (ONLY if no higher priority roles)
    else {
      console.log('🔍 Step 3: No high-priority roles found - checking Dokan store fallback...');
      
      try {
        const storeResponse = await fetch(`${this.baseUrl}/wp-json/dokan/v1/stores/${userId}`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/json',
          },
        });

        if (storeResponse.ok) {
          const storeData = await storeResponse.json();
          console.log('🏪 Dokan store data received:', {
            id: storeData.id,
            enabled: storeData.enabled,
            status: storeData.status
          });
          
          // Check if store exists and is active
          if (storeData && storeData.id && storeData.enabled !== false && storeData.status !== 'disabled') {
            resolvedRole = 'vendor';
            resolvedDisplay = 'Vendor';
            resolvedRoute = '/vendor-dashboard';
            resolvedAccess = true;
            console.log('✅ Step 3 SUCCESS: Active Dokan store found - VENDOR ACCESS GRANTED');
          } else {
            console.log('❌ Step 3: Dokan store exists but is disabled - ACCESS DENIED');
          }
        } else {
          console.log('❌ Step 3: No active Dokan store found - ACCESS DENIED');
        }
      } catch (error) {
        console.error('❌ Step 3 FAILED: Could not check Dokan store:', error);
      }
    }

    // Final validation
    console.log('🎯 ===== FINAL ROLE RESOLUTION RESULT =====');
    console.log('👤 User:', apiUserData.email);
    console.log('🎭 Authoritative Roles:', authoritativeRoles);
    console.log('🏆 Resolved Primary Role:', resolvedRole);
    console.log('🏷️ Display Name:', resolvedDisplay);
    console.log('🧭 Dashboard Route:', resolvedRoute);
    console.log('🔐 Has Access:', resolvedAccess);
    
    // CRITICAL VALIDATION: Ensure admins are never treated as vendors
    if ((authoritativeRoles.includes('administrator') || authoritativeRoles.includes('shop_manager')) && resolvedRole === 'vendor') {
      console.error('🚨🚨🚨 CRITICAL ERROR DETECTED 🚨🚨🚨');
      console.error('🚨 Admin/Shop Manager user was resolved as vendor!');
      console.error('🚨 This indicates a logic error in role resolution');
      throw new Error('CRITICAL: Admin user classified as vendor - role resolution logic error');
    }

    return {
      primary_role: resolvedRole,
      primary_role_display: resolvedDisplay,
      dashboard_route: resolvedRoute,
      hasAccess: resolvedAccess,
      roles: authoritativeRoles
    };
  }

  /**
   * Step 1: Authenticate with WordPress JWT Auth plugin
   */
  async authenticateWithJWT(credentials: LoginCredentials): Promise<JWTTokenResponse> {
    console.log('🔐 ===== WORDPRESS JWT AUTHENTICATION =====');
    console.log('👤 Authenticating:', credentials.username);
    console.log('🌍 WordPress URL:', `${this.baseUrl}/wp-json/jwt-auth/v1/token`);

    try {
      const response = await fetch(`${this.baseUrl}/wp-json/jwt-auth/v1/token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          username: credentials.username,
          password: credentials.password,
        }),
      });

      console.log('📡 JWT Response Status:', response.status);
      console.log('📡 JWT Response OK:', response.ok);

      if (!response.ok) {
        const errorData = await response.text();
        console.error('❌ JWT Auth Failed:', errorData);
        
        let errorMessage = 'Invalid username or password';
        try {
          const errorObj = JSON.parse(errorData);
          if (errorObj.message) {
            errorMessage = errorObj.message;
          }
        } catch (e) {
          // Use default error message
        }
        
        throw new Error(errorMessage);
      }

      const tokenData: JWTTokenResponse = await response.json();
      
      console.log('✅ JWT Authentication Successful!');
      console.log('🔑 Token Length:', tokenData.token?.length || 0);
      console.log('📧 JWT User Email:', tokenData.user_email);
      console.log('👤 JWT Display Name:', tokenData.user_display_name);
      console.log('🔗 JWT Username:', tokenData.user_nicename);
      
      // Extract and log roles from JWT token immediately for debugging
      const jwtRoles = this.extractRolesFromJWTToken(tokenData.token);
      console.log('🎭 JWT Token Roles (immediate extraction):', jwtRoles);
      
      // Specific check for seller role in JWT token
      if (jwtRoles.includes('seller')) {
        console.log('🎯 ===== SELLER ROLE DETECTED IN JWT TOKEN =====');
        console.log('✅ User has "seller" role in JWT token');
        console.log('🔄 This should be mapped to "vendor" primary_role');
        console.log('🧭 Expected final redirect: /vendor-dashboard');
      }

      // Handle user_id with improved logging
      if (tokenData.user_id) {
        console.log('🆔 JWT User ID:', tokenData.user_id, '✓');
      } else {
        console.log('🔍 JWT user_id not included in response - will fetch from WordPress API or generate');
        console.log('📝 Note: Some WordPress JWT Auth plugin configurations exclude user_id for security');
      }

      // Log the complete JWT response structure for debugging (but only essential fields)
      console.log('📋 JWT Response Summary:', {
        hasToken: !!tokenData.token,
        hasEmail: !!tokenData.user_email,
        hasUsername: !!tokenData.user_nicename,
        hasDisplayName: !!tokenData.user_display_name,
        hasUserId: !!tokenData.user_id
      });

      if (!tokenData.token) {
        throw new Error('No authentication token received from WordPress');
      }

      // Validate that we have at least email and username for identification
      if (!tokenData.user_email && !tokenData.user_nicename) {
        console.error('❌ JWT response missing both user_email and user_nicename');
        throw new Error('Incomplete authentication data received from WordPress');
      }

      return tokenData;
    } catch (error) {
      console.error('❌ JWT Authentication Error:', error);
      
      // Enhanced error handling for common issues
      if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
        throw new Error('Cannot connect to WordPress server. Please check your internet connection or contact support.');
      }
      
      throw error instanceof Error ? error : new Error('Authentication failed');
    }
  }

  /**
   * COMPREHENSIVE WordPress API Profile Fetching with DIAGNOSTIC LOGGING
   * Fetches user data from /wp-json/wp/v2/users/me with Bearer JWT token
   * CRITICAL: This is where roles are fetched - any issues here cause misrouting
   */
  async fetchUserProfile(token: string, jwtData: JWTTokenResponse): Promise<WordPressUserProfile> {
    console.log('🔍 ===== WORDPRESS API PROFILE FETCH - COMPREHENSIVE DIAGNOSIS =====');
    console.log('📋 REQUEST DETAILS:');
    console.log('  🌐 Endpoint: /wp-json/wp/v2/users/me');
    console.log('  🔗 Full URL:', `${this.baseUrl}/wp-json/wp/v2/users/me`);
    console.log('  🔑 Bearer Token Present:', !!token);
    console.log('  🔑 Token Length:', token?.length || 0);
    console.log('  🔑 Token Preview:', token ? `${token.substring(0, 20)}...` : 'NO TOKEN');
    console.log('📊 JWT FALLBACK DATA AVAILABLE:');
    console.log('  📧 JWT Email:', jwtData.user_email);
    console.log('  👤 JWT Username:', jwtData.user_nicename);
    console.log('  🆔 JWT User ID:', jwtData.user_id);

    try {
      console.log('📡 ===== MAKING WORDPRESS API REQUEST =====');
      console.log('📡 Sending GET request to WordPress API...');
      
      const requestHeaders = {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      };
      
      console.log('📡 Request Headers:', {
        'Authorization': `Bearer ${token.substring(0, 20)}...`,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      });

      const response = await fetch(`${this.baseUrl}/wp-json/wp/v2/users/me`, {
        method: 'GET',
        headers: requestHeaders,
      });

      console.log('📡 ===== WORDPRESS API RESPONSE RECEIVED =====');
      console.log('📊 Response Status:', response.status);
      console.log('📊 Response Status Text:', response.statusText);
      console.log('📊 Response OK:', response.ok);
      console.log('📊 Response Headers:', Object.fromEntries(response.headers.entries()));

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ ===== WORDPRESS API CALL FAILED =====');
        console.error('❌ Status:', response.status);
        console.error('❌ Status Text:', response.statusText);
        console.error('❌ Error Response Body:', errorText);
        console.error('❌ This will cause JWT fallback - roles may be incomplete!');
        console.log('🔧 Falling back to JWT-only profile creation...');
        return this.createProfileFromJWTData(jwtData);
      }

      const apiUserData = await response.json();
      
      console.log('✅ ===== WORDPRESS API SUCCESS - COMPREHENSIVE DATA ANALYSIS =====');
      console.log('📋 COMPLETE API RESPONSE:');
      console.log(JSON.stringify(apiUserData, null, 2));
      
      // Check for alternative role locations in the response
      console.log('🔍 ===== ALTERNATIVE ROLE LOCATIONS CHECK =====');
      if (apiUserData.meta && apiUserData.meta.wp_user_level) {
        console.log('🔍 Found wp_user_level in meta:', apiUserData.meta.wp_user_level);
      }
      if (apiUserData.roles_in_context) {
        console.log('🔍 Found roles_in_context:', apiUserData.roles_in_context);
      }
      if (apiUserData.allcaps) {
        console.log('🔍 Found allcaps field:', Object.keys(apiUserData.allcaps || {}).slice(0, 10));
      }
      if (apiUserData.user_roles) {
        console.log('🔍 Found user_roles field:', apiUserData.user_roles);
      }
      
      console.log('📊 ===== CRITICAL FIELD ANALYSIS =====');
      console.log('🆔 User ID:', apiUserData.id, typeof apiUserData.id);
      console.log('📧 Email:', apiUserData.email, typeof apiUserData.email);
      console.log('👤 Username:', apiUserData.username, typeof apiUserData.username);
      console.log('📝 Display Name:', apiUserData.name, typeof apiUserData.name);
      console.log('👤 First Name:', apiUserData.first_name, typeof apiUserData.first_name);
      console.log('👤 Last Name:', apiUserData.last_name, typeof apiUserData.last_name);
      
      console.log('🎭 ===== ROLES FIELD DEEP ANALYSIS =====');
      console.log('🎭 Raw Roles Field:', apiUserData.roles);
      console.log('🎭 Roles Type:', typeof apiUserData.roles);
      console.log('🎭 Is Array:', Array.isArray(apiUserData.roles));
      console.log('🎭 Array Length:', Array.isArray(apiUserData.roles) ? apiUserData.roles.length : 'N/A');
      console.log('🎭 Roles JSON:', JSON.stringify(apiUserData.roles));
      
      if (Array.isArray(apiUserData.roles)) {
        console.log('🎭 ROLES ARRAY BREAKDOWN:');
        apiUserData.roles.forEach((role, index) => {
          console.log(`  ${index}: "${role}" (${typeof role})`);
        });
        
        console.log('🎭 ROLE PRESENCE CHECK:');
        console.log('  - administrator:', apiUserData.roles.includes('administrator'));
        console.log('  - shop_manager:', apiUserData.roles.includes('shop_manager'));
        console.log('  - seller:', apiUserData.roles.includes('seller'));
        console.log('  - vendor:', apiUserData.roles.includes('vendor'));
        console.log('  - dokan_vendor:', apiUserData.roles.includes('dokan_vendor'));
      } else {
        console.error('🚨 CRITICAL: Roles field is not an array - applying conversion logic!');
        console.error('🚨 Raw roles data type:', typeof apiUserData.roles);
        console.error('🚨 Raw roles value:', apiUserData.roles);
      }
      
      console.log('🔑 ===== CAPABILITIES ANALYSIS =====');
      console.log('🔑 Capabilities Present:', !!apiUserData.capabilities);
      console.log('🔑 Capabilities Type:', typeof apiUserData.capabilities);
      if (apiUserData.capabilities) {
        console.log('🔑 Capabilities Keys:', Object.keys(apiUserData.capabilities).slice(0, 10));
        console.log('🔑 Total Capabilities:', Object.keys(apiUserData.capabilities).length);
      }
      
      // CRITICAL: ROBUST ROLE PARSING - Handle all possible WordPress formats
      let finalRoles: string[] = [];
      
      console.log('🔧 ===== ROBUST ROLE PARSING =====');
      
      if (Array.isArray(apiUserData.roles) && apiUserData.roles.length > 0) {
        // Standard array format
        finalRoles = apiUserData.roles.filter(role => typeof role === 'string' && role.length > 0);
        console.log('✅ FORMAT 1: Standard array format detected');
        console.log('✅ Parsed roles:', finalRoles);
      } 
      else if (typeof apiUserData.roles === 'string' && apiUserData.roles.length > 0) {
        // String format - could be single role or comma-separated
        console.log('🔧 FORMAT 2: String format detected');
        if (apiUserData.roles.includes(',')) {
          // Comma-separated roles
          finalRoles = apiUserData.roles.split(',').map(role => role.trim()).filter(role => role.length > 0);
          console.log('✅ Comma-separated roles parsed:', finalRoles);
        } else {
          // Single role string
          finalRoles = [apiUserData.roles.trim()];
          console.log('✅ Single role string parsed:', finalRoles);
        }
      }
      else if (typeof apiUserData.roles === 'object' && apiUserData.roles !== null) {
        // Object format - extract keys where value is truthy
        console.log('🔧 FORMAT 3: Object format detected');
        const roleKeys = Object.keys(apiUserData.roles);
        console.log('🔍 Object keys:', roleKeys);
        
        // Filter to get roles that are set to true/truthy
        finalRoles = roleKeys.filter(key => {
          const value = apiUserData.roles[key];
          const isTruthy = Boolean(value) && value !== 'false' && value !== '0';
          console.log(`  Role "${key}": ${value} (${typeof value}) → ${isTruthy ? 'INCLUDED' : 'EXCLUDED'}`);
          return isTruthy;
        });
        console.log('✅ Object roles parsed:', finalRoles);
      }
      else {
        // CRITICAL FIX: Handle undefined roles field
        console.error('🚨 CRITICAL: Roles field is undefined - implementing comprehensive fallback methods');
        console.log('🔧 FORMAT 4: Emergency role extraction when WordPress API fails to provide roles');
        
        // Method 1: Extract from capabilities (ENHANCED)
        if (apiUserData.capabilities && typeof apiUserData.capabilities === 'object') {
          const capabilityKeys = Object.keys(apiUserData.capabilities);
          console.log('🔍 Method 1 - Total capability keys found:', capabilityKeys.length);
          console.log('🔍 Method 1 - Sample capability keys:', capabilityKeys.slice(0, 20));
          
          // Enhanced role detection from capabilities
          const roleCapabilities = {
            'administrator': ['manage_options', 'administrator'],
            'shop_manager': ['manage_woocommerce', 'shop_manager'],
            'seller': ['dokan_view_sales_overview', 'dokan_view_store_settings', 'seller'],
            'vendor': ['dokan_view_sales_overview', 'dokan_view_store_settings', 'vendor'],
            'dokan_vendor': ['dokan_view_sales_overview', 'dokan_view_store_settings', 'dokan_vendor'],
            'editor': ['edit_others_posts', 'editor'],
            'author': ['edit_published_posts', 'author'],
            'subscriber': ['read', 'subscriber'],
            'customer': ['read', 'customer']
          };
          
          console.log('🔍 Method 1 - Checking role-specific capabilities...');
          
          // Check for administrator first (highest priority)
          if (capabilityKeys.some(cap => ['manage_options', 'administrator'].includes(cap) && Boolean(apiUserData.capabilities[cap]))) {
            finalRoles.push('administrator');
            console.log('✅ Method 1 - ADMINISTRATOR role detected from capabilities!');
          }
          
          // Check for shop manager
          if (capabilityKeys.some(cap => ['manage_woocommerce', 'shop_manager'].includes(cap) && Boolean(apiUserData.capabilities[cap]))) {
            finalRoles.push('shop_manager');
            console.log('✅ Method 1 - SHOP MANAGER role detected from capabilities!');
          }
          
          // Check for Dokan vendor/seller capabilities
          const dokanCaps = ['dokan_view_sales_overview', 'dokan_view_store_settings', 'dokan_edit_product', 'dokan_view_store_billing_address'];
          if (capabilityKeys.some(cap => dokanCaps.includes(cap) && Boolean(apiUserData.capabilities[cap]))) {
            finalRoles.push('seller');
            console.log('✅ Method 1 - SELLER/VENDOR role detected from Dokan capabilities!');
          }
          
          // Fallback: Look for any role name in capabilities
          const standardRoles = ['administrator', 'shop_manager', 'seller', 'vendor', 'dokan_vendor', 'editor', 'author', 'subscriber', 'customer'];
          const rolesFromCaps = capabilityKeys.filter(cap => {
            const isRoleCapability = standardRoles.includes(cap);
            const hasCapability = Boolean(apiUserData.capabilities[cap]);
            if (isRoleCapability && hasCapability) {
              console.log(`✅ Method 1 - Found role capability: ${cap}`);
            }
            return isRoleCapability && hasCapability;
          });
          
          finalRoles = [...finalRoles, ...rolesFromCaps];
          console.log('✅ Method 1 - All roles from capabilities:', [...new Set(finalRoles)]);
        } else {
          console.error('🚨 Method 1 FAILED: No capabilities found in API response!');
          console.error('🚨 This indicates a serious WordPress API configuration issue');
        }
        
        // Method 2: Check alternative field names (ENHANCED)
        console.log('🔍 Method 2 - Checking alternative role field names...');
        const alternativeFields = ['user_roles', 'roles_in_context', 'allcaps', 'wp_capabilities', 'caps'];
        
        for (const field of alternativeFields) {
          if (apiUserData[field]) {
            console.log(`🔍 Method 2 - Found ${field}:`, typeof apiUserData[field], apiUserData[field]);
            
            if (Array.isArray(apiUserData[field])) {
              const rolesFromField = apiUserData[field].filter(role => typeof role === 'string');
              console.log(`✅ Method 2 - Roles from ${field} array:`, rolesFromField);
              finalRoles = [...finalRoles, ...rolesFromField];
            } else if (typeof apiUserData[field] === 'object' && apiUserData[field] !== null) {
              const roleKeys = Object.keys(apiUserData[field]).filter(key => {
                const isRole = ['administrator', 'shop_manager', 'seller', 'vendor', 'dokan_vendor', 'editor', 'author', 'subscriber', 'customer'].includes(key);
                const hasValue = Boolean(apiUserData[field][key]);
                if (isRole && hasValue) {
                  console.log(`✅ Method 2 - Found role ${key} in ${field}`);
                }
                return isRole && hasValue;
              });
              console.log(`✅ Method 2 - Roles from ${field} object:`, roleKeys);
              finalRoles = [...finalRoles, ...roleKeys];
            }
          } else {
            console.log(`❌ Method 2 - ${field} not found in response`);
          }
        }
        
        // Method 3: Check meta fields
        if (apiUserData.meta) {
          console.log('🔍 Method 3 - Checking meta fields:', Object.keys(apiUserData.meta || {}));
          
          // WordPress user level mapping (legacy support)
          if (apiUserData.meta.wp_user_level !== undefined) {
            const userLevel = parseInt(apiUserData.meta.wp_user_level);
            console.log('🔍 Method 3 - User level detected:', userLevel);
            
            if (userLevel >= 10) {
              finalRoles.push('administrator');
              console.log('✅ Method 3 - Added administrator role from user level');
            } else if (userLevel >= 7) {
              finalRoles.push('editor');
              console.log('✅ Method 3 - Added editor role from user level');
            } else if (userLevel >= 2) {
              finalRoles.push('author');
              console.log('✅ Method 3 - Added author role from user level');
            }
          }
          
          // Check for Dokan-specific meta
          const dokanMetaFields = ['dokan_store_name', 'dokan_enable_selling', '_vendor_enabled'];
          for (const metaField of dokanMetaFields) {
            if (apiUserData.meta[metaField]) {
              console.log(`🔍 Method 3 - Found Dokan meta ${metaField}:`, apiUserData.meta[metaField]);
              if (apiUserData.meta[metaField] === 'yes' || apiUserData.meta[metaField] === true) {
                finalRoles.push('seller');
                console.log('✅ Method 3 - Added seller role from Dokan meta');
                break;
              }
            }
          }
        }
        
        // Method 4: JWT Token Parsing (EMERGENCY FALLBACK)
        console.log('🔍 Method 4 - Emergency JWT token role extraction...');
        try {
          const jwtRoles = this.extractRolesFromJWTToken(jwtData.token);
          if (jwtRoles.length > 0) {
            finalRoles = [...finalRoles, ...jwtRoles];
            console.log('✅ Method 4 - Roles extracted from JWT token:', jwtRoles);
          } else {
            console.log('❌ Method 4 - No roles found in JWT token');
          }
        } catch (error) {
          console.error('❌ Method 4 - JWT token parsing failed:', error);
        }
        
        // Method 5: WordPress user level fallback (LEGACY SUPPORT)
        console.log('🔍 Method 5 - WordPress user level mapping...');
        if (apiUserData.meta && apiUserData.meta.wp_user_level !== undefined) {
          const userLevel = parseInt(apiUserData.meta.wp_user_level);
          console.log('🔍 Method 5 - WordPress user level:', userLevel);
          
          if (userLevel >= 10) {
            finalRoles.push('administrator');
            console.log('✅ Method 5 - Added administrator role from user level 10+');
          } else if (userLevel >= 7) {
            finalRoles.push('editor');
            console.log('✅ Method 5 - Added editor role from user level 7+');
          } else if (userLevel >= 2) {
            finalRoles.push('author');
            console.log('✅ Method 5 - Added author role from user level 2+');
          }
        }
        
        // Method 6: Email-based admin detection (LAST RESORT)
        console.log('🔍 Method 6 - Email-based admin detection...');
        const adminEmails = ['admin@eliteq.in', 'administrator@eliteq.in', 'support@eliteq.in'];
        if (adminEmails.includes(apiUserData.email?.toLowerCase())) {
          finalRoles.push('administrator');
          console.log('✅ Method 6 - Added administrator role based on admin email');
        }
        
        console.log('🔧 Final roles from all emergency fallback methods:', [...new Set(finalRoles)]);
      }
      
      // Final validation and cleanup
      finalRoles = finalRoles
        .filter(role => typeof role === 'string' && role.length > 0)
        .map(role => role.toLowerCase().trim())
        .filter((role, index, self) => self.indexOf(role) === index); // Remove duplicates
      
      console.log('🎯 ===== FINAL ROLE PARSING RESULT =====');
      if (finalRoles.length > 0) {
        console.log('✅ ===== ROLES SUCCESSFULLY PARSED =====');
        console.log('✅ Final roles array:', finalRoles);
        console.log('✅ Total roles found:', finalRoles.length);
        console.log('✅ These roles will be used for access control decisions');
        console.log('🎭 Final Role Presence Check:');
        console.log('  - administrator:', finalRoles.includes('administrator'));
        console.log('  - shop_manager:', finalRoles.includes('shop_manager'));
        console.log('  - seller:', finalRoles.includes('seller'));
        console.log('  - vendor:', finalRoles.includes('vendor'));
        console.log('  - dokan_vendor:', finalRoles.includes('dokan_vendor'));
        
        // CRITICAL: If we found admin roles, make sure they're prioritized
        if (finalRoles.includes('administrator')) {
          console.log('👑 ADMINISTRATOR ROLE DETECTED - This user should have admin access');
        }
        if (finalRoles.includes('shop_manager')) {
          console.log('🏢 SHOP MANAGER ROLE DETECTED - This user should have admin access');  
        }
        if (finalRoles.includes('seller') || finalRoles.includes('vendor') || finalRoles.includes('dokan_vendor')) {
          console.log('🏪 VENDOR/SELLER ROLE DETECTED - This user should have vendor access');
        }
      } else {
        console.log('⚠️ ===== NO ROLES FOUND - COMPREHENSIVE DEBUGGING =====');
        console.log('⚠️ Could not extract any roles from WordPress API response');
        console.log('🔍 DEBUGGING INFORMATION:');
        console.log('  📝 Original roles field:', apiUserData.roles);
        console.log('  📝 Roles field type:', typeof apiUserData.roles);
        console.log('  📝 Roles field JSON:', JSON.stringify(apiUserData.roles));
        console.log('  📝 Capabilities keys:', apiUserData.capabilities ? Object.keys(apiUserData.capabilities).slice(0, 15) : 'None');
        console.log('  📝 Meta keys:', apiUserData.meta ? Object.keys(apiUserData.meta).slice(0, 10) : 'None');
        console.log('  📝 All response keys:', Object.keys(apiUserData));
        
        console.log('🛠️ TROUBLESHOOTING STEPS:');
        console.log('  1. Check if user has roles assigned in WordPress admin');
        console.log('  2. Verify JWT plugin configuration');
        console.log('  3. Check if WordPress API includes roles in response');
        console.log('  4. Test with different user account');
        console.log('  5. Verify WP REST API permissions');
        
        console.log('⚠️ IMPACT: This will likely result in restricted access');
        console.log('⚠️ RECOMMENDATION: User may need roles manually assigned in WordPress');
        
        // EMERGENCY: Assign default role based on available information
        console.log('🚨 EMERGENCY ROLE ASSIGNMENT ATTEMPT...');
        
        // Check if user has any administrative capabilities
        if (apiUserData.capabilities) {
          const adminCaps = ['manage_options', 'manage_woocommerce', 'administrator', 'shop_manager'];
          const hasAdminCaps = adminCaps.some(cap => Boolean(apiUserData.capabilities[cap]));
          
          if (hasAdminCaps) {
            finalRoles = ['administrator'];
            console.log('🚨 EMERGENCY: Assigned administrator role based on admin capabilities');
          } else {
            // Check for vendor capabilities
            const vendorCaps = ['dokan_view_sales_overview', 'dokan_view_store_settings', 'seller', 'vendor'];
            const hasVendorCaps = vendorCaps.some(cap => Boolean(apiUserData.capabilities[cap]));
            
            if (hasVendorCaps) {
              finalRoles = ['seller'];
              console.log('🚨 EMERGENCY: Assigned seller role based on vendor capabilities');
            } else {
              // Last resort: assign customer role
              finalRoles = ['customer'];
              console.log('🚨 EMERGENCY: Assigned customer role as fallback');
            }
          }
        } else {
          // No capabilities at all - assign restricted role
          finalRoles = [];
          console.log('🚨 EMERGENCY: No capabilities found - will result in restricted access');
        }
        
        // Create a detailed error report
        const errorReport = {
          timestamp: new Date().toISOString(),
          user_id: apiUserData.id,
          user_email: apiUserData.email,
          user_login: apiUserData.username,
          roles_field: apiUserData.roles,
          roles_field_type: typeof apiUserData.roles,
          capabilities_present: !!apiUserData.capabilities,
          capabilities_count: apiUserData.capabilities ? Object.keys(apiUserData.capabilities).length : 0,
          capabilities_sample: apiUserData.capabilities ? Object.keys(apiUserData.capabilities).slice(0, 10) : [],
          meta_present: !!apiUserData.meta,
          meta_count: apiUserData.meta ? Object.keys(apiUserData.meta).length : 0,
          response_keys: Object.keys(apiUserData),
          parsing_methods_attempted: ['array_check', 'string_parse', 'object_parse', 'capabilities_fallback', 'alternative_fields', 'meta_check', 'jwt_fallback', 'user_level_mapping', 'email_detection'],
          emergency_role_assigned: finalRoles,
          wordpress_api_endpoint: `${this.baseUrl}/wp-json/wp/v2/users/me`,
          jwt_token_length: jwtData.token?.length || 0
        };
        
        console.log('📊 COMPREHENSIVE ERROR REPORT FOR SUPPORT:', JSON.stringify(errorReport, null, 2));
      }

      // Create the final profile with WordPress API data
      const profile: WordPressUserProfile = {
        id: apiUserData.id || this.generateUserIdFromEmail(jwtData.user_email),
        username: apiUserData.username || jwtData.user_nicename || this.extractUsernameFromEmail(jwtData.user_email),
        name: apiUserData.name || jwtData.user_display_name || apiUserData.username || 'User',
        first_name: apiUserData.first_name || '',
        last_name: apiUserData.last_name || '',
        email: apiUserData.email || jwtData.user_email,
        roles: finalRoles, // CRITICAL: This determines access control
        capabilities: apiUserData.capabilities || this.createBasicCapabilities(),
        avatar_urls: apiUserData.avatar_urls || {},
        slug: apiUserData.slug || apiUserData.username || this.extractUsernameFromEmail(jwtData.user_email),
        description: apiUserData.description || ''
      };
      
      console.log('✅ ===== FINAL USER PROFILE CONSTRUCTED =====');
      console.log('📋 PROFILE SUMMARY:');
      console.log('  🆔 ID:', profile.id);
      console.log('  📧 Email:', profile.email);
      console.log('  👤 Username:', profile.username);
      console.log('  📝 Display Name:', profile.name);
      console.log('  🎭 FINAL ROLES (WILL DETERMINE ACCESS):', JSON.stringify(profile.roles));
      console.log('  🔑 Capabilities Count:', Object.keys(profile.capabilities).length);
      console.log('✅ Profile creation completed - ready for role resolution');

      return profile;

    } catch (error) {
      console.error('❌ ===== WORDPRESS API EXCEPTION =====');
      console.error('❌ Error Type:', error?.constructor?.name);
      console.error('❌ Error Message:', error?.message);
      console.error('❌ Full Error:', error);
      
      if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
        console.error('🌐 NETWORK ERROR: Cannot reach WordPress API');
        console.error('🌐 Possible causes:');
        console.error('   - WordPress server is down');
        console.error('   - CORS issues');
        console.error('   - DNS resolution problems');
        console.error('   - Invalid base URL:', this.baseUrl);
      }
      
      console.log('🔧 ===== FALLBACK TO JWT DATA =====');
      console.log('🔧 WordPress API failed, creating profile from JWT token only');
      console.log('🔧 WARNING: JWT may not contain complete role information');
      return this.createProfileFromJWTData(jwtData);
    }
  }



  /**
   * Enhanced JWT token role extraction with comprehensive parsing
   */
  private extractRolesFromJWTToken(token: string): string[] {
    console.log('🔍 ===== JWT TOKEN ROLE EXTRACTION =====');
    
    if (!token) {
      console.log('❌ No JWT token provided for role extraction');
      return [];
    }
    
    try {
      // JWT tokens have 3 parts: header.payload.signature
      const parts = token.split('.');
      if (parts.length !== 3) {
        console.log('❌ Invalid JWT token format');
        return [];
      }
      
      // Decode the payload (base64)
      const payload = parts[1];
      const decodedPayload = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
      const tokenData = JSON.parse(decodedPayload);
      
      console.log('🔍 JWT Payload decoded successfully');
      console.log('🔍 JWT Payload keys:', Object.keys(tokenData));
      
      let roles: string[] = [];
      
      // Method 1: Direct roles field
      if (tokenData.roles && Array.isArray(tokenData.roles)) {
        roles = [...roles, ...tokenData.roles];
        console.log('✅ JWT Method 1 - Found roles array:', tokenData.roles);
      }
      
      // Method 2: User data nested structure
      if (tokenData.data && tokenData.data.user) {
        const userData = tokenData.data.user;
        if (userData.roles && Array.isArray(userData.roles)) {
          roles = [...roles, ...userData.roles];
          console.log('✅ JWT Method 2 - Found roles in user data:', userData.roles);
        }
        
        // Check capabilities in user data
        if (userData.allcaps || userData.capabilities) {
          const caps = userData.allcaps || userData.capabilities;
          const roleFromCaps = this.extractRolesFromCapabilities(caps);
          roles = [...roles, ...roleFromCaps];
          console.log('✅ JWT Method 2 - Found roles in user capabilities:', roleFromCaps);
        }
      }
      
      // Method 3: WordPress specific fields
      const wpFields = ['wp_user_roles', 'user_roles', 'capabilities', 'allcaps'];
      for (const field of wpFields) {
        if (tokenData[field]) {
          if (Array.isArray(tokenData[field])) {
            roles = [...roles, ...tokenData[field]];
            console.log(`✅ JWT Method 3 - Found roles in ${field}:`, tokenData[field]);
          } else if (typeof tokenData[field] === 'object') {
            const roleFromObj = this.extractRolesFromCapabilities(tokenData[field]);
            roles = [...roles, ...roleFromObj];
            console.log(`✅ JWT Method 3 - Found roles from ${field} object:`, roleFromObj);
          }
        }
      }
      
      // Clean and deduplicate
      roles = [...new Set(roles)]
        .filter(role => typeof role === 'string' && role.length > 0)
        .map(role => role.toLowerCase().trim());
      
      console.log('🎯 JWT Token Role Extraction Result:', roles);
      return roles;
      
    } catch (error) {
      console.error('❌ JWT token role extraction failed:', error);
      return [];
    }
  }
  
  /**
   * Extract roles from capabilities object
   */
  private extractRolesFromCapabilities(capabilities: any): string[] {
    if (!capabilities || typeof capabilities !== 'object') {
      return [];
    }
    
    const roleCapabilities = ['administrator', 'shop_manager', 'seller', 'vendor', 'dokan_vendor', 'editor', 'author', 'contributor', 'subscriber', 'customer'];
    
    return Object.keys(capabilities)
      .filter(cap => roleCapabilities.includes(cap) && Boolean(capabilities[cap]))
      .map(role => role.toLowerCase().trim());
  }

  /**
   * Store authentication data securely
   */
  private storeAuthData(token: string, user: AuthenticatedUser): void {
    try {
      localStorage.setItem(this.tokenKey, token);
      localStorage.setItem(this.userKey, JSON.stringify(user));
      
      console.log('💾 Authentication data stored securely');
    } catch (error) {
      console.error('❌ Failed to store auth data:', error);
      throw new Error('Failed to store authentication data');
    }
  }

  /**
   * Retrieve stored authentication data
   */
  getStoredAuthData(): { token: string; user: AuthenticatedUser } | null {
    try {
      const token = localStorage.getItem(this.tokenKey);
      const userJson = localStorage.getItem(this.userKey);

      if (!token || !userJson) {
        console.log('📭 No stored authentication data found');
        return null;
      }

      const user: AuthenticatedUser = JSON.parse(userJson);

      // Validate stored data
      if (!user.id || !user.email || !Array.isArray(user.roles)) {
        console.warn('⚠️ Invalid stored user data, clearing');
        this.clearAuthData();
        return null;
      }

      // Check token expiry
      if (user.token_expires_at && new Date() > new Date(user.token_expires_at)) {
        console.log('🔄 Stored token has expired');
        this.clearAuthData();
        return null;
      }

      console.log('✅ Valid stored authentication data found');
      console.log('👤 User:', user.display_name);
      console.log('📧 Email:', user.email);
      console.log('🎭 Role:', user.primary_role);

      return { token, user };
    } catch (error) {
      console.error('❌ Error retrieving stored auth data:', error);
      this.clearAuthData();
      return null;
    }
  }

  /**
   * Validate token with WordPress
   */
  async validateToken(token: string): Promise<boolean> {
    try {
      console.log('🔍 Validating JWT token with WordPress...');
      
      const response = await fetch(`${this.baseUrl}/wp-json/jwt-auth/v1/token/validate`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const isValid = response.ok;
      console.log('🔍 Token validation result:', isValid);
      
      return isValid;
    } catch (error) {
      console.error('❌ Token validation failed:', error);
      return false;
    }
  }

  /**
   * Refresh user data
   */
  async refreshUserData(token: string): Promise<AuthenticatedUser> {
    console.log('🔄 Refreshing user data from WordPress...');
    
    try {
      // Get current stored data for JWT fallback info
      const storedAuth = this.getStoredAuthData();
      const jwtFallback: JWTTokenResponse = {
        token,
        user_email: storedAuth?.user.email || '',
        user_nicename: storedAuth?.user.username || '',
        user_display_name: storedAuth?.user.display_name || '',
        user_id: storedAuth?.user.id || undefined
      };
      
      const profile = await this.fetchUserProfile(token, jwtFallback);
      
      // Use new authoritative role resolution
      const roleResolution = await this.resolveAuthoritativeUserRole(
        token,
        profile.id,
        profile
      );

      // Create refreshed user with authoritative roles
      const refreshedUser: AuthenticatedUser = {
        id: profile.id,
        username: profile.username || profile.slug || jwtFallback.user_nicename,
        email: profile.email || jwtFallback.user_email,
        display_name: profile.name || jwtFallback.user_display_name,
        first_name: profile.first_name || '',
        last_name: profile.last_name || '',
        avatar_url: profile.avatar_urls?.['96'] || profile.avatar_urls?.['48'] || '',
        full_name: `${profile.first_name || ''} ${profile.last_name || ''}`.trim() || profile.name || jwtFallback.user_display_name,
        capabilities: profile.capabilities || {},
        avatar_urls: profile.avatar_urls || {},
        authenticated_at: new Date().toISOString(),
        token_expires_at: this.calculateTokenExpiry(token),
        // Use authoritative role resolution
        roles: roleResolution.roles,
        primary_role: roleResolution.primary_role,
        primary_role_display: roleResolution.primary_role_display,
        dashboard_route: roleResolution.dashboard_route
      };
      
      // Update stored user data
      localStorage.setItem(this.userKey, JSON.stringify(refreshedUser));
      
      console.log('✅ User data refreshed successfully');
      return refreshedUser;
    } catch (error) {
      console.error('❌ Failed to refresh user data:', error);
      throw error;
    }
  }

  /**
   * Clear authentication data
   */
  clearAuthData(): void {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
    console.log('🧹 Authentication data cleared');
  }

  /**
   * Logout user
   */
  logout(): void {
    console.log('🚪 ===== USER LOGOUT =====');
    this.clearAuthData();
    
    // Redirect to home page
    window.location.href = '/';
  }

  /**
   * Generate a consistent user ID from email hash when user_id is not available
   */
  private generateUserIdFromEmail(email: string): number {
    if (!email) {
      console.log('🔢 No email available for ID generation, using default ID: 1000');
      return 1000; // Default ID for cases where we have no identifier
    }
    
    // Simple hash function to generate consistent ID from email
    let hash = 0;
    for (let i = 0; i < email.length; i++) {
      const char = email.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    
    // Ensure positive number and add offset to avoid conflicts with real user IDs
    const id = Math.abs(hash) + 10000;
    console.log('🔢 Generated consistent user ID:', id, 'from email:', email);
    return id;
  }

  /**
   * Create a user profile from JWT data when WordPress API is unavailable
   */
  private createProfileFromJWTData(jwtData: JWTTokenResponse): WordPressUserProfile {
    console.log('🔧 ===== CREATING PROFILE FROM JWT DATA (FALLBACK) =====');
    console.log('🎯 JWT Data available:', jwtData);
    
    // Extract roles from JWT token using multiple methods
    let jwtRoles: string[] = [];
    
    try {
      jwtRoles = this.extractRolesFromJWTToken(jwtData.token);
      console.log('✅ Extracted roles from JWT token:', jwtRoles);
    } catch (error) {
      console.error('❌ Failed to extract roles from JWT token:', error);
      jwtRoles = [];
    }
    
    // If no roles found, apply emergency inference
    if (jwtRoles.length === 0) {
      console.log('🚨 EMERGENCY: No roles found in JWT token - applying emergency role inference');
      
      if (jwtData.user_email) {
        const emailDomain = jwtData.user_email.split('@')[1]?.toLowerCase();
        const emailLocal = jwtData.user_email.split('@')[0]?.toLowerCase();
        
        if (emailDomain === 'eliteq.in' || emailLocal?.includes('admin')) {
          jwtRoles = ['administrator'];
          console.log('🚨 EMERGENCY: Assigned administrator role based on email domain/pattern');
        } else if (emailLocal?.includes('vendor') || emailLocal?.includes('seller')) {
          jwtRoles = ['seller'];
          console.log('🚨 EMERGENCY: Assigned seller role based on email pattern');
        } else {
          jwtRoles = ['customer'];
          console.log('🚨 EMERGENCY: Assigned customer role as ultimate fallback');
        }
      } else {
        jwtRoles = ['customer'];
        console.log('🚨 EMERGENCY: No email available - assigned customer role as ultimate fallback');
      }
    }

    const profile: WordPressUserProfile = {
      id: jwtData.user_id || this.generateUserIdFromEmail(jwtData.user_email),
      username: jwtData.user_nicename || this.extractUsernameFromEmail(jwtData.user_email),
      name: jwtData.user_display_name || jwtData.user_nicename || 'User',
      first_name: '',
      last_name: '',
      email: jwtData.user_email,
      roles: jwtRoles,
      capabilities: this.createBasicCapabilities(),
      avatar_urls: {},
      slug: jwtData.user_nicename || this.extractUsernameFromEmail(jwtData.user_email),
      description: ''
    };
    
    console.log('✅ ===== JWT FALLBACK PROFILE CREATED =====');
    console.log('🆔 ID:', profile.id);
    console.log('📧 Email:', profile.email);
    console.log('👤 Username:', profile.username);
    console.log('🎭 Final Roles:', profile.roles);
    console.log('⚠️ Note: WordPress API was unreachable - using JWT data only');
    
    return profile;
  }

  /**
   * Extract username from email when username is not available
   */
  private extractUsernameFromEmail(email: string): string {
    if (!email) return 'user';
    const username = email.split('@')[0];
    return username || 'user';
  }

  /**
   * Create basic capabilities for fallback scenarios
   */
  private createBasicCapabilities(): { [key: string]: boolean } {
    return {
      read: true,
      edit_posts: false,
      upload_files: false
    };
  }

  /**
   * Create a user profile from JWT data when WordPress API is unavailable
   * ENHANCED: Extracts roles from JWT token payload with comprehensive parsing
   */
  private createProfileFromJWTData(jwtData: JWTTokenResponse): WordPressUserProfile {
    console.log('🔧 ===== CREATING PROFILE FROM JWT DATA (FALLBACK) =====');
    console.log('🎯 JWT Data available:', jwtData);
    
    // Extract roles from JWT token using multiple methods
    let jwtRoles: string[] = [];
    
    console.log('🔍 ===== JWT ROLE EXTRACTION METHODS =====');
    
    // Method 1: Direct user_roles field
    try {
      if (jwtData.user_roles && Array.isArray(jwtData.user_roles)) {
        jwtRoles = [...jwtRoles, ...jwtData.user_roles];
        console.log('✅ Method 1 - Found user_roles in JWT data:', jwtData.user_roles);
      }
    } catch (error) {
      console.log('❌ Method 1 failed:', error);
    }
    
    // Method 2: Nested data structure
    try {
      if (jwtData.data && jwtData.data.user && jwtData.data.user.roles) {
        const nestedRoles = Array.isArray(jwtData.data.user.roles) ? jwtData.data.user.roles : [jwtData.data.user.roles];
        jwtRoles = [...jwtRoles, ...nestedRoles];
        console.log('✅ Method 2 - Found roles in JWT nested data:', nestedRoles);
      }
    } catch (error) {
      console.log('❌ Method 2 failed:', error);
    }
    
    // Method 3: Extract from token payload directly
    try {
      const tokenFromJWT = jwtData.token || jwtData.jwt_token;
      if (tokenFromJWT) {
        const rolesFromToken = this.extractRolesFromJWTToken(tokenFromJWT);
        if (rolesFromToken.length > 0) {
          jwtRoles = [...jwtRoles, ...rolesFromToken];
          console.log('✅ Method 3 - Found roles in JWT token payload:', rolesFromToken);
        }
      }
    } catch (error) {
      console.log('❌ Method 3 failed:', error);
    }
    
    // Method 4: Check capabilities in JWT
    try {
      if (jwtData.capabilities || (jwtData.data && jwtData.data.user && jwtData.data.user.capabilities)) {
        const caps = jwtData.capabilities || jwtData.data.user.capabilities;
        if (typeof caps === 'object' && caps !== null) {
          const roleCapabilities = ['administrator', 'shop_manager', 'seller', 'vendor', 'dokan_vendor'];
          const rolesFromCaps = Object.keys(caps).filter(cap => 
            roleCapabilities.includes(cap) && Boolean(caps[cap])
          );
          if (rolesFromCaps.length > 0) {
            jwtRoles = [...jwtRoles, ...rolesFromCaps];
            console.log('✅ Method 4 - Found roles in JWT capabilities:', rolesFromCaps);
          }
        }
      }
    } catch (error) {
      console.log('❌ Method 4 failed:', error);
    }
    
    // Clean up and deduplicate roles
    jwtRoles = [...new Set(jwtRoles)]
      .filter(role => typeof role === 'string' && role.length > 0)
      .map(role => role.toLowerCase().trim());
    
    console.log('🎭 ===== FINAL JWT ROLES EXTRACTION =====');
    if (jwtRoles.length > 0) {
      console.log('✅ Successfully extracted roles from JWT:', jwtRoles);
      console.log('📊 Total roles found:', jwtRoles.length);
      console.log('🔍 Role breakdown:');
      jwtRoles.forEach(role => console.log(`  - ${role}`));
    } else {
      console.log('⚠️ No roles found in JWT data');
      console.log('⚠️ Will rely on access determination logic and Dokan store check');
      console.log('🔍 Available JWT fields:', Object.keys(jwtData));
    }
    
    // EMERGENCY: If no roles found from JWT, try to infer from email or set default
    let finalJWTRoles = jwtRoles;
    
    if (finalJWTRoles.length === 0) {
      console.log('🚨 EMERGENCY: No roles found in JWT token - applying emergency role inference');
      
      // Try to infer role from email domain
      if (jwtData.user_email) {
        const emailDomain = jwtData.user_email.split('@')[1]?.toLowerCase();
        const emailLocal = jwtData.user_email.split('@')[0]?.toLowerCase();
        
        if (emailDomain === 'eliteq.in' || emailLocal?.includes('admin')) {
          finalJWTRoles = ['administrator'];
          console.log('🚨 EMERGENCY: Assigned administrator role based on email domain/pattern');
        } else if (emailLocal?.includes('vendor') || emailLocal?.includes('seller')) {
          finalJWTRoles = ['seller'];
          console.log('🚨 EMERGENCY: Assigned seller role based on email pattern');
        } else {
          finalJWTRoles = ['customer'];
          console.log('🚨 EMERGENCY: Assigned customer role as ultimate fallback');
        }
      } else {
        finalJWTRoles = ['customer'];
        console.log('🚨 EMERGENCY: No email available - assigned customer role as ultimate fallback');
      }
    }

    const profile: WordPressUserProfile = {
      id: jwtData.user_id || this.generateUserIdFromEmail(jwtData.user_email),
      username: jwtData.user_nicename || this.extractUsernameFromEmail(jwtData.user_email),
      name: jwtData.user_display_name || jwtData.user_nicename || 'User',
      first_name: '',
      last_name: '',
      email: jwtData.user_email,
      roles: finalJWTRoles, // Use comprehensive role extraction with emergency fallback
      capabilities: this.createBasicCapabilities(),
      avatar_urls: {},
      slug: jwtData.user_nicename || this.extractUsernameFromEmail(jwtData.user_email),
      description: ''
    };
    
    console.log('✅ ===== ENHANCED JWT FALLBACK PROFILE CREATED =====');
    console.log('🆔 ID:', profile.id);
    console.log('📧 Email:', profile.email);
    console.log('👤 Username:', profile.username);
    console.log('🎭 Final Roles:', profile.roles);
    console.log('📊 Profile completeness:', {
      has_id: !!profile.id,
      has_email: !!profile.email,
      has_username: !!profile.username,
      has_roles: profile.roles.length > 0,
      roles_count: profile.roles.length
    });
    console.log('⚠️ Note: WordPress API was unreachable - using JWT data only');
    
    return profile;
  }

  /**
   * Extract username from email when username is not available
   */
  private extractUsernameFromEmail(email: string): string {
    if (!email) return 'user';
    const username = email.split('@')[0];
    return username || 'user';
  }

  /**
   * Infer user role from email domain
   */
  private inferRoleFromEmailDomain(email: string): string[] {
    if (!email) return ['subscriber'];
    
    const domain = email.split('@')[1]?.toLowerCase();
    const localPart = email.split('@')[0]?.toLowerCase();
    
    // Check for admin indicators
    if (domain === 'eliteq.in' || 
        localPart.includes('admin') || 
        localPart.includes('manager') ||
        localPart.includes('owner')) {
      console.log('👑 Inferred ADMINISTRATOR role from email pattern:', email);
      return ['administrator'];
    }
    
    // Check for vendor indicators
    if (localPart.includes('vendor') || 
        localPart.includes('seller') || 
        localPart.includes('shop')) {
      console.log('🏪 Inferred SELLER role from email pattern:', email);
      return ['seller'];
    }
    
    // Default to subscriber
    console.log('📝 Defaulted to SUBSCRIBER role for email:', email);
    return ['subscriber'];
  }

  /**
   * Infer user roles from WordPress capabilities
   */
  private inferRolesFromCapabilities(capabilities: any, jwtData: JWTTokenResponse): string[] {
    console.log('🔍 ===== INFERRING ROLES FROM CAPABILITIES =====');
    console.log('🔑 Available capabilities:', Object.keys(capabilities || {}));
    
    if (!capabilities || typeof capabilities !== 'object') {
      console.log('🔧 No valid capabilities found, using email domain inference');
      return this.inferRoleFromEmailDomain(jwtData.user_email);
    }
    
    const capabilityKeys = Object.keys(capabilities);
    const inferredRoles: string[] = [];
    
    // Check for administrator capabilities
    if (capabilities.manage_options || capabilities.administrator || 
        capabilityKeys.some(cap => cap.includes('admin'))) {
      inferredRoles.push('administrator');
      console.log('👑 Inferred ADMINISTRATOR role from capabilities');
    }
    
    // Check for vendor/seller capabilities - ENHANCED SELLER DETECTION
    const vendorCapabilities = [
      'dokan_vendor', 'vendor', 'seller', 'shop_manager', 'manage_woocommerce',
      'wcfm_vendor', 'wcmp_vendor', 'wc_product_vendors_admin_vendor'
    ];
    
    const hasVendorCapability = vendorCapabilities.some(cap => capabilities[cap]);
    const hasVendorInKey = capabilityKeys.some(cap => 
      cap.includes('vendor') || cap.includes('seller') || 
      cap.includes('shop') || cap.includes('dokan') || cap.includes('wcfm')
    );
    
    if (hasVendorCapability || hasVendorInKey) {
      inferredRoles.push('seller'); // Use 'seller' to match JWT token role
      console.log('🏪 Inferred SELLER role from capabilities');
      console.log('🔍 Matched capabilities:', vendorCapabilities.filter(cap => capabilities[cap]));
      console.log('🔍 Matched capability keys:', capabilityKeys.filter(cap => 
        cap.includes('vendor') || cap.includes('seller') || 
        cap.includes('shop') || cap.includes('dokan') || cap.includes('wcfm')
      ));
    }
    
    // If no specific roles found, try email domain as last resort
    if (inferredRoles.length === 0) {
      const emailRoles = this.inferRoleFromEmailDomain(jwtData.user_email);
      inferredRoles.push(...emailRoles);
      console.log('📧 Used email domain inference for roles:', emailRoles);
    }
    
    // Ensure we always have at least one role
    if (inferredRoles.length === 0) {
      inferredRoles.push('subscriber');
      console.log('📝 Final fallback to SUBSCRIBER role');
    }
    
    console.log('🎯 Final inferred roles:', inferredRoles);
    return inferredRoles;
  }

  /**
   * Create basic capabilities for fallback scenarios
   */
  private createBasicCapabilities(): { [key: string]: boolean } {
    return {
      read: true,
      edit_posts: false,
      upload_files: false
    };
  }

  /**
   * Get human-readable display name for roles - ENSURES correct role labels in UI
   */
  private getRoleDisplayName(primary_role: string): string {
    const roleDisplayNames: { [key: string]: string } = {
      'administrator': 'Administrator',
      'shop_manager': 'Shop Manager',
      'vendor': 'Vendor',
      'restricted': 'Restricted Access'
    };
    
    const displayName = roleDisplayNames[primary_role] || 'Unknown Role';
    console.log(`🏷️ Role Display Mapping: ${primary_role} → "${displayName}"`);
    
    return displayName;
  }

  /**
   * Validate enhanced profile has minimum required data
   */
  private validateEnhancedProfile(profile: WordPressUserProfile, jwtData: JWTTokenResponse): {
    isValid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];
    
    // ID is required (can be generated)
    if (!profile.id || profile.id === 0) {
      errors.push('Missing or invalid user ID');
    }
    
    // Email is required (must come from JWT)
    if (!profile.email) {
      errors.push('Missing user email');
    }
    
    // Username is required (can be generated from email)
    if (!profile.username) {
      errors.push('Missing username');
    }
    
    // Roles must be an array with at least one role
    if (!Array.isArray(profile.roles) || profile.roles.length === 0) {
      errors.push('Missing or invalid user roles');
    }
    
    console.log('🔍 Profile validation summary:');
    console.log('  ✓ ID:', profile.id, profile.id > 0 ? '✅' : '❌');
    console.log('  ✓ Email:', profile.email, profile.email ? '✅' : '❌');
    console.log('  ✓ Username:', profile.username, profile.username ? '✅' : '❌');
    console.log('  ✓ Roles:', profile.roles, Array.isArray(profile.roles) && profile.roles.length > 0 ? '✅' : '❌');
    
    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * COMPREHENSIVE ROLE RESOLUTION DIAGNOSIS - Fixes misrouting issues
   * STRICT PRIORITY: administrator > shop_manager > seller > Dokan fallback
   * ZERO TOLERANCE: Admin/shop_manager can NEVER be vendor
   */
  private async determineUserAccess(profile: WordPressUserProfile, token: string): Promise<{
    primary_role: 'administrator' | 'shop_manager' | 'vendor' | 'restricted';
    dashboard_route: string;
    has_access: boolean;
  }> {
    console.log('🚨 ===== ROLE RESOLUTION DIAGNOSIS - COMPREHENSIVE LOGGING =====');
    console.log('📋 WORDPRESS USER PROFILE ANALYSIS:');
    console.log('  🆔 User ID:', profile.id);
    console.log('  📧 Email:', profile.email);
    console.log('  👤 Username:', profile.username);
    console.log('  📝 Display Name:', profile.name);
    console.log('  🎭 CRITICAL - WordPress Roles Array:', JSON.stringify(profile.roles));
    console.log('  📊 Roles Array Type:', typeof profile.roles);
    console.log('  📏 Roles Array Length:', Array.isArray(profile.roles) ? profile.roles.length : 'NOT ARRAY');
    
    // STEP 1: VALIDATE WORDPRESS API RESPONSE
    const roles = profile.roles || [];
    
    if (!Array.isArray(roles)) {
      console.error('🚨 FATAL ERROR: WordPress API returned invalid roles');
      console.error('🚨 Expected: Array, Got:', typeof roles, roles);
      console.error('🚨 EMERGENCY FALLBACK: Setting restricted access');
      return {
        primary_role: 'restricted',
        dashboard_route: '/account-dashboard',
        has_access: false
      };
    }
    
    console.log('✅ WordPress API Response Validation PASSED');
    console.log('📋 DETAILED ROLE PRESENCE CHECK:');
    console.log('  🔍 Has "administrator":', roles.includes('administrator'), roles.indexOf('administrator'));
    console.log('  🔍 Has "shop_manager":', roles.includes('shop_manager'), roles.indexOf('shop_manager'));
    console.log('  🔍 Has "seller":', roles.includes('seller'), roles.indexOf('seller'));
    console.log('  🔍 Has "vendor":', roles.includes('vendor'), roles.indexOf('vendor'));
    console.log('  🔍 Has "dokan_vendor":', roles.includes('dokan_vendor'), roles.indexOf('dokan_vendor'));
    console.log('  🔍 All Roles:', roles.map((role, index) => `${index}: "${role}"`));
    
    // STEP 2: APPLY STRICT PRIORITY LOGIC WITH DETAILED DECISION TRACKING
    let primary_role: 'administrator' | 'shop_manager' | 'vendor' | 'restricted' = 'restricted';
    let hasAccess = false;
    let dashboard_route = '/account-dashboard';
    let decisionReason = '';
    
    console.log('🎯 ===== PRIORITY LOGIC EXECUTION =====');
    
    // PRIORITY 1: ADMINISTRATOR (HIGHEST - CANNOT BE OVERRIDDEN)
    if (roles.includes("administrator")) {
      primary_role = "administrator";
      hasAccess = true;
      dashboard_route = "/admin-dashboard";
      decisionReason = 'PRIORITY 1: Administrator role detected in roles array';
      
      console.log('👑 ===== ADMINISTRATOR DETECTED - PRIORITY 1 =====');
      console.log('🔥 DECISION MADE: administrator role found at index:', roles.indexOf('administrator'));
      console.log('🎭 MAPPING: administrator → primary_role: "administrator"');
      console.log('🧭 ROUTING: /admin-dashboard');
      console.log('🔐 ACCESS: GRANTED (highest privilege)');
      console.log('🛡️ PROTECTION: Immediate return - NO OTHER CHECKS PERFORMED');
      console.log('⚠️ GUARANTEE: This user can NEVER be classified as vendor');
      
      // IMMEDIATE RETURN - Prevent any other logic from running
      console.log('🎯 FINAL DECISION (PRIORITY 1):', {
        primary_role,
        dashboard_route,
        has_access: hasAccess,
        decision_reason: decisionReason,
        roles_checked: ['administrator']
      });
      
      return { primary_role, dashboard_route, has_access: hasAccess };
    }
    
    console.log('❌ PRIORITY 1 CHECK: No "administrator" role found');
    
    // PRIORITY 2: SHOP MANAGER (SECOND HIGHEST - ADMIN DASHBOARD ACCESS)
    if (roles.includes("shop_manager")) {
      primary_role = "shop_manager";
      hasAccess = true;
      dashboard_route = "/admin-dashboard"; // Shop managers get admin dashboard
      decisionReason = 'PRIORITY 2: Shop Manager role detected in roles array';
      
      console.log('🏢 ===== SHOP MANAGER DETECTED - PRIORITY 2 =====');
      console.log('🔥 DECISION MADE: shop_manager role found at index:', roles.indexOf('shop_manager'));
      console.log('🎭 MAPPING: shop_manager → primary_role: "shop_manager"');
      console.log('🧭 ROUTING: /admin-dashboard (same as administrator)');
      console.log('🔐 ACCESS: GRANTED (admin-level privilege)');
      console.log('🛡️ PROTECTION: Immediate return - NO OTHER CHECKS PERFORMED');
      console.log('⚠️ GUARANTEE: This user can NEVER be classified as vendor');
      
      // IMMEDIATE RETURN - Prevent any other logic from running
      console.log('🎯 FINAL DECISION (PRIORITY 2):', {
        primary_role,
        dashboard_route,
        has_access: hasAccess,
        decision_reason: decisionReason,
        roles_checked: ['administrator', 'shop_manager']
      });
      
      return { primary_role, dashboard_route, has_access: hasAccess };
    }
    
    console.log('❌ PRIORITY 2 CHECK: No "shop_manager" role found');
    
    // PRIORITY 3: SELLER (MAPS TO VENDOR)
    if (roles.includes("seller")) {
      primary_role = "vendor"; // Map seller → vendor
      hasAccess = true;
      dashboard_route = "/vendor-dashboard";
      decisionReason = 'PRIORITY 3: Seller role detected and mapped to vendor';
      
      console.log('🏪 ===== SELLER DETECTED - PRIORITY 3 =====');
      console.log('🔥 DECISION MADE: seller role found at index:', roles.indexOf('seller'));
      console.log('🎭 MAPPING: seller → primary_role: "vendor" (requirement mapping)');
      console.log('🧭 ROUTING: /vendor-dashboard');
      console.log('🔐 ACCESS: GRANTED (vendor-level privilege)');
      console.log('✅ SAFETY: No admin/shop_manager roles detected - safe to assign vendor');
      
      console.log('🎯 FINAL DECISION (PRIORITY 3):', {
        primary_role,
        dashboard_route,
        has_access: hasAccess,
        decision_reason: decisionReason,
        roles_checked: ['administrator', 'shop_manager', 'seller']
      });
      
      return { primary_role, dashboard_route, has_access: hasAccess };
    }
    
    console.log('❌ PRIORITY 3 CHECK: No "seller" role found');
    
    // PRIORITY 4: DOKAN STORE FALLBACK (ONLY if no WordPress roles matched)
    console.log('🔍 ===== DOKAN STORE FALLBACK CHECK - PRIORITY 4 =====');
    console.log('📝 No matching WordPress roles found, checking for active Dokan store...');
    console.log('🛡️ SAFETY CONFIRMED: No admin/shop_manager roles to protect');
    
    try {
      const dokanStoreUrl = `${this.baseUrl}/wp-json/dokan/v1/stores/${profile.id}`;
      console.log('🌐 DOKAN API REQUEST:');
      console.log('  URL:', dokanStoreUrl);
      console.log('  Method: GET');
      console.log('  Headers: Authorization Bearer ***');
      
      const storeResponse = await fetch(dokanStoreUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
      });
      
      console.log('📡 DOKAN API RESPONSE:');
      console.log('  Status:', storeResponse.status);
      console.log('  Status Text:', storeResponse.statusText);
      console.log('  OK:', storeResponse.ok);
      
      if (storeResponse.ok) {
        const storeData = await storeResponse.json();
        console.log('🏪 DOKAN STORE DATA:', JSON.stringify(storeData, null, 2));
        console.log('🔍 Store Analysis:');
        console.log('  Store Exists:', !!storeData);
        console.log('  Store Disabled:', storeData?.is_disabled);
        console.log('  Store Active:', !storeData?.is_disabled);
        
        if (storeData && !storeData.is_disabled) {
          primary_role = "vendor";
          hasAccess = true;
          dashboard_route = "/vendor-dashboard";
          decisionReason = 'PRIORITY 4: Active Dokan store found (fallback)';
          
          console.log('✅ ===== DOKAN STORE FALLBACK SUCCESS =====');
          console.log('🔥 DECISION MADE: Active Dokan store detected');
          console.log('🎭 MAPPING: dokan_store → primary_role: "vendor"');
          console.log('🧭 ROUTING: /vendor-dashboard');
          console.log('🔐 ACCESS: GRANTED (vendor-level via store fallback)');
          console.log('📝 FALLBACK REASON: User has active Dokan store despite no WordPress roles');
          
          console.log('🎯 FINAL DECISION (PRIORITY 4):', {
            primary_role,
            dashboard_route,
            has_access: hasAccess,
            decision_reason: decisionReason,
            roles_checked: ['administrator', 'shop_manager', 'seller', 'dokan_store_fallback'],
            dokan_store_data: storeData
          });
          
          return { primary_role, dashboard_route, has_access: hasAccess };
        } else {
          console.log('❌ DOKAN FALLBACK FAILED: Store exists but is disabled');
        }
      } else {
        const errorText = await storeResponse.text();
        console.log('❌ DOKAN API ERROR:', errorText);
      }
    } catch (error) {
      console.error('⚠️ DOKAN STORE CHECK EXCEPTION:', error);
    }
    
    // FINAL RESULT: NO ACCESS GRANTED
    decisionReason = 'NO VALID ROLES: No administrator, shop_manager, seller roles found and no active Dokan store';
    
    console.log('🚫 ===== ACCESS RESTRICTED - NO VALID ROLES =====');
    console.log('❌ FINAL OUTCOME: Access denied');
    console.log('🔍 CHECKED ROLES:', ['administrator', 'shop_manager', 'seller']);
    console.log('🏪 DOKAN FALLBACK: Failed or no active store');
    console.log('📝 REASON:', decisionReason);
    console.log('🧭 DEFAULT ROUTING: /account-dashboard (restricted)');
    
    // ABSOLUTE FINAL SAFEGUARD - This should NEVER trigger if logic is correct
    if ((roles.includes('administrator') || roles.includes('shop_manager')) && primary_role === 'vendor') {
      console.error('🚨🚨🚨 LOGIC ERROR DETECTED 🚨🚨🚨');
      console.error('🚨 IMPOSSIBLE STATE: Admin/Shop Manager classified as vendor!');
      console.error('🚨 This indicates a critical bug in the logic above');
      console.error('🚨 Roles:', roles);
      console.error('🚨 Computed primary_role:', primary_role);
      console.error('🚨 EMERGENCY CORRECTION APPLIED');
      
      // Emergency correction
      if (roles.includes('administrator')) {
        primary_role = 'administrator';
        dashboard_route = '/admin-dashboard';
        hasAccess = true;
        decisionReason = 'EMERGENCY CORRECTION: Administrator role found';
      } else if (roles.includes('shop_manager')) {
        primary_role = 'shop_manager';
        dashboard_route = '/admin-dashboard';
        hasAccess = true;
        decisionReason = 'EMERGENCY CORRECTION: Shop Manager role found';
      }
    }
    
    console.log('🎯 ===== COMPREHENSIVE FINAL DECISION SUMMARY =====');
    console.log('📊 WordPress Roles Input:', roles);
    console.log('🎭 Resolved Primary Role:', primary_role);
    console.log('🔐 Access Granted:', hasAccess);
    console.log('🧭 Dashboard Route:', dashboard_route);
    console.log('📝 Decision Reason:', decisionReason);
    console.log('🔍 Priority Checks Performed:', ['administrator', 'shop_manager', 'seller', 'dokan_fallback']);
    console.log('🛡️ Administrator Protected:', roles.includes('administrator') ? 'YES ✅' : 'N/A');
    console.log('🛡️ Shop Manager Protected:', roles.includes('shop_manager') ? 'YES ✅' : 'N/A');
    console.log('✅ Role resolution diagnosis complete');
    
    return {
      primary_role,
      dashboard_route,
      has_access: hasAccess
    };
  }

  /**
   * Step 4: Create authenticated user profile with async role resolution
   */
  private async createAuthenticatedUser(
    tokenData: JWTTokenResponse,
    profile: WordPressUserProfile
  ): Promise<AuthenticatedUser> {
    console.log('⚡ ===== CREATING AUTHENTICATED USER =====');
    
    // Perform role resolution with Dokan fallback check
    const accessInfo = await this.determineUserAccess(profile, tokenData.token);
    
    // Create full name
    let fullName = profile.name || '';
    if (!fullName && (profile.first_name || profile.last_name)) {
      fullName = `${profile.first_name || ''} ${profile.last_name || ''}`.trim();
    }
    if (!fullName) {
      fullName = profile.username || tokenData.user_display_name || 'User';
    }
    
    // Get best avatar URL
    const avatarUrls = profile.avatar_urls || {};
    const avatarUrl = avatarUrls['96'] || avatarUrls['48'] || avatarUrls['24'] || '';
    
    const authenticatedUser: AuthenticatedUser = {
      id: profile.id,
      username: profile.username,
      email: profile.email,
      display_name: profile.name,
      first_name: profile.first_name || '',
      last_name: profile.last_name || '',
      avatar_url: avatarUrl,
      roles: profile.roles,
      primary_role: accessInfo.primary_role,
      primary_role_display: this.getRoleDisplayName(accessInfo.primary_role),
      dashboard_route: accessInfo.dashboard_route,
      full_name: fullName,
      capabilities: profile.capabilities || {},
      avatar_urls: profile.avatar_urls || {},
      authenticated_at: new Date().toISOString(),
      token_expires_at: this.calculateTokenExpiry(tokenData.token),
    };
    
    console.log('✅ ===== AUTHENTICATED USER CREATED SUCCESSFULLY =====');
    console.log('🎭 Primary Role:', authenticatedUser.primary_role);
    console.log('🏷️ Role Display Name:', authenticatedUser.primary_role_display);
    console.log('🎯 All WordPress Roles:', authenticatedUser.roles);
    console.log('🧭 Dashboard Route:', authenticatedUser.dashboard_route);
    console.log('👤 Full Name:', authenticatedUser.full_name);
    console.log('📧 Email:', authenticatedUser.email);
    console.log('🔐 Access Level:', accessInfo.has_access ? 'GRANTED' : 'RESTRICTED');
    
    // CRITICAL ADMINISTRATOR PROTECTION VERIFICATION
    if (authenticatedUser.roles.includes('administrator')) {
      console.log('🛡️ ===== ADMINISTRATOR PROTECTION VERIFICATION =====');
      console.log('✅ User has administrator role in WordPress');
      console.log('🎭 Primary role should be "administrator":', authenticatedUser.primary_role === 'administrator' ? '✅ CORRECT' : '❌ WRONG!');
      console.log('🏷️ Display name should be "Administrator":', authenticatedUser.primary_role_display === 'Administrator' ? '✅ CORRECT' : '❌ WRONG!');
      console.log('🧭 Should redirect to admin dashboard:', authenticatedUser.dashboard_route === '/admin-dashboard' ? '✅ CORRECT' : '❌ WRONG!');
      
      if (authenticatedUser.primary_role !== 'administrator') {
        console.error('🚨 CRITICAL ERROR: Administrator user misclassified!');
        console.error('🚨 This should NEVER happen - check role resolution logic!');
      }
    }
    
    // SHOP MANAGER PROTECTION VERIFICATION
    if (authenticatedUser.roles.includes('shop_manager')) {
      console.log('🛡️ ===== SHOP MANAGER PROTECTION VERIFICATION =====');
      console.log('✅ User has shop_manager role in WordPress');
      console.log('🎭 Primary role should be "shop_manager":', authenticatedUser.primary_role === 'shop_manager' ? '✅ CORRECT' : '❌ WRONG!');
      console.log('🏷️ Display name should be "Shop Manager":', authenticatedUser.primary_role_display === 'Shop Manager' ? '✅ CORRECT' : '❌ WRONG!');
      console.log('🧭 Should redirect to admin dashboard:', authenticatedUser.dashboard_route === '/admin-dashboard' ? '✅ CORRECT' : '❌ WRONG!');
      
      if (authenticatedUser.primary_role !== 'shop_manager') {
        console.error('🚨 CRITICAL ERROR: Shop Manager user misclassified!');
        console.error('🚨 This should NEVER happen - check role resolution logic!');
      }
    }
    
    // COMPREHENSIVE DEBUGGING FOR ROLE-BASED ACCESS
    console.log('📊 ===== DETAILED ROLE ANALYSIS =====');
    console.log('🔍 WordPress roles found:');
    console.log('  - administrator:', authenticatedUser.roles.includes('administrator') ? '✅ YES' : '❌ NO');
    console.log('  - seller:', authenticatedUser.roles.includes('seller') ? '✅ YES' : '❌ NO');
    console.log('  - shop_manager:', authenticatedUser.roles.includes('shop_manager') ? '✅ YES' : '❌ NO');
    console.log('  - vendor:', authenticatedUser.roles.includes('vendor') ? '✅ YES' : '❌ NO');
    console.log('  - dokan_vendor:', authenticatedUser.roles.includes('dokan_vendor') ? '��� YES' : '❌ NO');
    
    // Special debugging for seller users
    if (authenticatedUser.roles.includes('seller')) {
      console.log('🎉 ===== SELLER USER SUCCESSFULLY PROCESSED =====');
      console.log('✅ User with "seller" role detected and processed');
      console.log('🏪 Role mapping: seller → vendor (primary_role)');
      console.log('🧭 Expected redirect: /vendor-dashboard');
      console.log('🔐 Access granted:', accessInfo.has_access);
      console.log('🎯 This user should now have vendor dashboard access');
    }
    
    // Warning for potential access issues
    if (!accessInfo.has_access) {
      console.log('🚨 ===== ACCESS WILL BE RESTRICTED =====');
      console.log('❌ User will see "Access Restricted" message');
      console.log('🔍 WordPress roles found:', authenticatedUser.roles);
      console.log('🏪 Dokan store check: completed (see logs above)');
      console.log('📝 Required: administrator, seller, shop_manager roles OR active Dokan store');
    }
    
    return authenticatedUser;
  }

  /**
   * COMPREHENSIVE JWT TOKEN ROLE EXTRACTION with DETAILED DIAGNOSTICS
   * Extracts roles from JWT payload to diagnose token-based authentication issues
   */
  private extractRolesFromJWTToken(token: string): string[] {
    console.log('🔍 ===== JWT TOKEN ROLE EXTRACTION - COMPREHENSIVE ANALYSIS =====');
    
    try {
      // Parse JWT token
      const tokenParts = token.split('.');
      console.log('🔧 JWT Token Structure:');
      console.log('  Parts Count:', tokenParts.length);
      console.log('  Header Length:', tokenParts[0]?.length || 0);
      console.log('  Payload Length:', tokenParts[1]?.length || 0);
      console.log('  Signature Length:', tokenParts[2]?.length || 0);
      
      if (tokenParts.length !== 3) {
        console.error('🚨 INVALID JWT: Expected 3 parts, got', tokenParts.length);
        return [];
      }
      
      const payload = JSON.parse(atob(tokenParts[1]));
      console.log('🎯 ===== COMPLETE JWT PAYLOAD ANALYSIS =====');
      console.log('📋 Full Payload:');
      console.log(JSON.stringify(payload, null, 2));
      
      console.log('🕐 JWT Timing Information:');
      console.log('  Issued At (iat):', payload.iat ? new Date(payload.iat * 1000).toISOString() : 'Not set');
      console.log('  Expires At (exp):', payload.exp ? new Date(payload.exp * 1000).toISOString() : 'Not set');
      console.log('  Not Before (nbf):', payload.nbf ? new Date(payload.nbf * 1000).toISOString() : 'Not set');
      
      console.log('👤 JWT User Information:');
      console.log('  User Email:', payload.data?.user?.user_email || payload.user_email || 'Not found');
      console.log('  User ID:', payload.data?.user?.ID || payload.user_id || 'Not found');
      console.log('  User Login:', payload.data?.user?.user_login || payload.user_login || 'Not found');
      
      // Check for roles in multiple possible locations
      const possibleRoleFields = [
        'roles', 'role', 'user_role', 'user_roles', 'wp_user_roles', 
        'capabilities', 'caps', 'data', 'user', 'user_data'
      ];
      
      console.log('🎭 ===== ROLE FIELD SCANNING =====');
      let extractedRoles: string[] = [];
      
      for (const field of possibleRoleFields) {
        if (payload[field]) {
          console.log(`🔍 Found field '${field}':`, typeof payload[field], payload[field]);
          
          if (Array.isArray(payload[field])) {
            console.log(`  ✅ ${field} is array with ${payload[field].length} items:`, payload[field]);
            extractedRoles = [...extractedRoles, ...payload[field]];
          } else if (typeof payload[field] === 'string') {
            console.log(`  ✅ ${field} is string:`, payload[field]);
            extractedRoles.push(payload[field]);
          } else if (typeof payload[field] === 'object' && payload[field] !== null) {
            console.log(`  🔍 ${field} is object, checking nested fields...`);
            
            // Check for nested roles
            if (payload[field].roles && Array.isArray(payload[field].roles)) {
              console.log(`    ✅ ${field}.roles found:`, payload[field].roles);
              extractedRoles = [...extractedRoles, ...payload[field].roles];
            }
            
            // Check for nested user object
            if (payload[field].user && payload[field].user.roles) {
              console.log(`    ✅ ${field}.user.roles found:`, payload[field].user.roles);
              if (Array.isArray(payload[field].user.roles)) {
                extractedRoles = [...extractedRoles, ...payload[field].user.roles];
              }
            }
            
            // For capabilities object, extract role-like keys
            const keys = Object.keys(payload[field]);
            console.log(`    🔑 ${field} has ${keys.length} keys:`, keys.slice(0, 10));
            
            const roleKeys = keys.filter(key => 
              ['administrator', 'seller', 'vendor', 'shop_manager', 'dokan_vendor', 'wcfm_vendor', 'subscriber', 'customer'].includes(key)
            );
            
            if (roleKeys.length > 0) {
              console.log(`    ✅ Found role-like keys in ${field}:`, roleKeys);
              extractedRoles = [...extractedRoles, ...roleKeys];
            }
          }
        } else {
          console.log(`❌ Field '${field}' not found in JWT payload`);
        }
      }
      
      console.log('🎭 ===== ROLE EXTRACTION RESULTS =====');
      console.log('🎭 Raw extracted roles:', extractedRoles);
      console.log('🎭 Extracted roles count:', extractedRoles.length);
      
      // Clean and validate roles
      const validRoles = [...new Set(extractedRoles)].filter(role => {
        if (typeof role !== 'string') {
          console.log(`❌ Filtering out non-string role:`, typeof role, role);
          return false;
        }
        
        if (role.length === 0) {
          console.log(`❌ Filtering out empty role`);
          return false;
        }
        
        // Filter out capability names that aren't roles
        const isCapability = role.startsWith('read') || 
                           role.startsWith('edit_') || 
                           role.startsWith('delete_') ||
                           role.startsWith('upload_') ||
                           role.startsWith('manage_') ||
                           ['true', 'false', '1', '0'].includes(role);
        
        if (isCapability) {
          console.log(`❌ Filtering out capability (not role): ${role}`);
          return false;
        }
        
        console.log(`✅ Valid role found: ${role}`);
        return true;
      });
      
      console.log('🎭 ===== FINAL JWT ROLES =====');
      console.log('✅ Valid roles from JWT token:', validRoles);
      console.log('📊 Total valid roles:', validRoles.length);
      
      if (validRoles.length === 0) {
        console.log('⚠️ WARNING: No roles found in JWT token');
        console.log('⚠️ This may cause access issues - WordPress API roles will be primary source');
      } else {
        console.log('🎭 Role Presence in JWT:');
        console.log('  - administrator:', validRoles.includes('administrator'));
        console.log('  - shop_manager:', validRoles.includes('shop_manager'));
        console.log('  - seller:', validRoles.includes('seller'));
        console.log('  - vendor:', validRoles.includes('vendor'));
        console.log('  - dokan_vendor:', validRoles.includes('dokan_vendor'));
      }
      
      return validRoles;
      
    } catch (error) {
      console.error('❌ ===== JWT TOKEN PARSING FAILED =====');
      console.error('❌ Error Type:', error?.constructor?.name);
      console.error('❌ Error Message:', error?.message);
      console.error('❌ This means JWT token is malformed or invalid');
      console.error('❌ Roles will need to come from WordPress API only');
      return [];
    }
  }

  /**
   * Calculate JWT token expiry
   */
  private calculateTokenExpiry(token: string): string {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      if (payload.exp) {
        return new Date(payload.exp * 1000).toISOString();
      }
    } catch (error) {
      console.log('🔧 Could not parse token expiry, using 7-day default');
    }
    
    // Default to 7 days
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + 7);
    return expiryDate.toISOString();
  }

  /**
   * Complete authentication flow
   */
  async authenticate(credentials: LoginCredentials): Promise<{
    token: string;
    user: AuthenticatedUser;
    success: boolean;
  }> {
    console.log('🚀 ===== COMPLETE WORDPRESS AUTHENTICATION FLOW =====');
    console.log('📱 EliteQ India - WordPress Authentication');
    console.log('⏰ Started at:', new Date().toISOString());

    if (!credentials.username?.trim()) {
      throw new Error('Username or email is required');
    }

    if (!credentials.password?.trim()) {
      throw new Error('Password is required');
    }

    try {
      // Step 1: Get JWT token from WordPress
      console.log('🔐 Step 1: WordPress JWT Authentication');
      const tokenData = await this.authenticateWithJWT(credentials);

      // Step 2: Fetch complete user profile with JWT fallbacks
      console.log('👤 Step 2: Fetching User Profile with Fallbacks');
      const profile = await this.fetchUserProfile(tokenData.token, tokenData);

      // Step 3: Create authenticated user with role resolution
      console.log('⚡ Step 3: Creating Authenticated User with Role Resolution');
      const authenticatedUser = await this.createAuthenticatedUser(tokenData, profile);

      // Step 4: Store authentication data
      console.log('💾 Step 4: Storing Authentication Data');
      this.storeAuthData(tokenData.token, authenticatedUser);

      console.log('🎉 ===== AUTHENTICATION SUCCESSFUL =====');
      console.log('✅ User authenticated:', authenticatedUser.display_name);
      console.log('✅ Email confirmed:', authenticatedUser.email);
      console.log('✅ Role verified:', authenticatedUser.primary_role);
      console.log('✅ Access level:', authenticatedUser.primary_role !== 'restricted' ? 'GRANTED' : 'RESTRICTED');
      console.log('🧭 Redirect to:', authenticatedUser.dashboard_route);
      
      // COMPREHENSIVE AUTHENTICATION RESULT LOGGING FOR DEBUGGING
      console.log('📋 ===== COMPLETE AUTHENTICATION DIAGNOSTIC =====');
      try {
        const decodedToken = JSON.parse(atob(tokenData.token.split('.')[1]));
        console.log('🔑 ===== DECODED JWT TOKEN =====');
        console.log('🔑 Complete JWT Payload:', decodedToken);
        console.log('🔑 JWT Issued At:', decodedToken.iat ? new Date(decodedToken.iat * 1000).toISOString() : 'Not set');
        console.log('🔑 JWT Expires At:', decodedToken.exp ? new Date(decodedToken.exp * 1000).toISOString() : 'Not set');
        console.log('🔑 JWT User Email:', decodedToken.data?.user?.user_email || 'Not in token');
        console.log('🔑 JWT User ID:', decodedToken.data?.user?.ID || 'Not in token');
      } catch (e) {
        console.log('🔑 Could not decode JWT token for logging:', e);
      }
      console.log('🎭 Roles Array:', authenticatedUser.roles);
      console.log('🎯 Resolved Primary Role:', authenticatedUser.primary_role);
      console.log('🔓 Access Decision (hasAccess):', authenticatedUser.primary_role !== 'restricted');
      console.log('🧭 Dashboard Route Decision:', authenticatedUser.dashboard_route);
      console.log('📊 Role-based Access Summary:');
      console.log('  - Is Administrator:', authenticatedUser.roles.includes('administrator'));
      console.log('  - Is Seller:', authenticatedUser.roles.includes('seller'));
      console.log('  - Is Shop Manager:', authenticatedUser.roles.includes('shop_manager'));
      console.log('  - Is Vendor:', authenticatedUser.roles.includes('vendor'));
      console.log('  - Primary Role Assigned:', authenticatedUser.primary_role);
      console.log('  - Will Redirect To:', authenticatedUser.dashboard_route);
      console.log('  - Access Granted:', authenticatedUser.primary_role !== 'restricted' ? 'YES' : 'NO');
      console.log('📝 Authentication flow completed successfully');
      
      // COMPREHENSIVE FINAL VALIDATION - DIAGNOSE MISROUTING ISSUES
      console.log('🔍 ===== COMPREHENSIVE FINAL VALIDATION =====');
      
      if (authenticatedUser.roles.includes('administrator')) {
        console.log('👑 ===== ADMINISTRATOR USER FINAL VALIDATION =====');
        console.log('✅ Administrator role confirmed in final user object');
        const hasAccess = authenticatedUser.primary_role !== 'restricted';
        console.log('🎭 primary_role should be "administrator":', authenticatedUser.primary_role === 'administrator' ? '✅ CORRECT' : '❌ INCORRECT');
        console.log('🔐 hasAccess should be true:', hasAccess ? '✅ CORRECT' : '❌ INCORRECT');
        console.log('🧭 dashboard_route should be "/admin-dashboard":', authenticatedUser.dashboard_route === '/admin-dashboard' ? '✅ CORRECT' : '❌ INCORRECT');
        
        if (authenticatedUser.primary_role !== 'administrator' || !hasAccess || authenticatedUser.dashboard_route !== '/admin-dashboard') {
          console.error('🚨 ADMINISTRATOR USER VALIDATION FAILED!');
          console.error('Expected: primary_role="administrator", hasAccess=true, dashboard_route="/admin-dashboard"');
          console.error('Actual:', {
            primary_role: authenticatedUser.primary_role,
            hasAccess: hasAccess,
            dashboard_route: authenticatedUser.dashboard_route
          });
        } else {
          console.log('🎉 ADMINISTRATOR USER VALIDATION PASSED!');
        }
      }
      
      if (authenticatedUser.roles.includes('shop_manager')) {
        console.log('🏢 ===== SHOP MANAGER USER FINAL VALIDATION =====');
        console.log('✅ Shop Manager role confirmed in final user object');
        const hasAccess = authenticatedUser.primary_role !== 'restricted';
        console.log('🎭 primary_role should be "shop_manager":', authenticatedUser.primary_role === 'shop_manager' ? '✅ CORRECT' : '❌ INCORRECT');
        console.log('🔐 hasAccess should be true:', hasAccess ? '✅ CORRECT' : '❌ INCORRECT');
        console.log('🧭 dashboard_route should be "/admin-dashboard":', authenticatedUser.dashboard_route === '/admin-dashboard' ? '✅ CORRECT' : '❌ INCORRECT');
        
        if (authenticatedUser.primary_role !== 'shop_manager' || !hasAccess || authenticatedUser.dashboard_route !== '/admin-dashboard') {
          console.error('🚨 SHOP MANAGER USER VALIDATION FAILED!');
          console.error('Expected: primary_role="shop_manager", hasAccess=true, dashboard_route="/admin-dashboard"');
          console.error('Actual:', {
            primary_role: authenticatedUser.primary_role,
            hasAccess: hasAccess,
            dashboard_route: authenticatedUser.dashboard_route
          });
        } else {
          console.log('🎉 SHOP MANAGER USER VALIDATION PASSED!');
        }
      }
      
      if (authenticatedUser.roles.includes('seller')) {
        console.log('🏪 ===== SELLER USER FINAL VALIDATION =====');
        console.log('✅ Seller role confirmed in final user object');
        const hasAccess = authenticatedUser.primary_role !== 'restricted';
        console.log('🎭 primary_role should be "vendor":', authenticatedUser.primary_role === 'vendor' ? '✅ CORRECT' : '❌ INCORRECT');
        console.log('🔐 hasAccess should be true:', hasAccess ? '✅ CORRECT' : '❌ INCORRECT');
        console.log('🧭 dashboard_route should be "/vendor-dashboard":', authenticatedUser.dashboard_route === '/vendor-dashboard' ? '✅ CORRECT' : '❌ INCORRECT');
        
        if (authenticatedUser.primary_role !== 'vendor' || !hasAccess || authenticatedUser.dashboard_route !== '/vendor-dashboard') {
          console.error('🚨 SELLER USER AUTHENTICATION VALIDATION FAILED!');
          console.error('Expected: primary_role="vendor", hasAccess=true, dashboard_route="/vendor-dashboard"');
          console.error('Actual:', {
            primary_role: authenticatedUser.primary_role,
            hasAccess: hasAccess,
            dashboard_route: authenticatedUser.dashboard_route
          });
        } else {
          console.log('🎉 SELLER USER AUTHENTICATION VALIDATION PASSED!');
        }
      }
      
      // Check for mixed roles that could cause conflicts
      const criticalRoles = ['administrator', 'shop_manager', 'seller'];
      const userCriticalRoles = authenticatedUser.roles.filter(role => criticalRoles.includes(role));
      
      if (userCriticalRoles.length > 1) {
        console.log('⚠️ ===== MULTIPLE CRITICAL ROLES DETECTED =====');
        console.log('⚠️ User has multiple access-controlling roles:', userCriticalRoles);
        console.log('⚠️ Priority should be: administrator > shop_manager > seller');
        console.log('⚠️ Final decision - primary_role:', authenticatedUser.primary_role);
        
        // Verify priority is correct
        if (userCriticalRoles.includes('administrator') && authenticatedUser.primary_role !== 'administrator') {
          console.error('🚨 PRIORITY ERROR: User has administrator role but primary_role is not administrator!');
        } else if (userCriticalRoles.includes('shop_manager') && !userCriticalRoles.includes('administrator') && authenticatedUser.primary_role !== 'shop_manager') {
          console.error('🚨 PRIORITY ERROR: User has shop_manager role but primary_role is not shop_manager!');
        } else {
          console.log('✅ Role priority correctly applied');
        }
      }
      
      // Final access check
      if (authenticatedUser.primary_role === 'restricted') {
        console.log('🚫 ===== ACCESS RESTRICTED FINAL CHECK =====');
        console.log('🚫 User will be denied dashboard access');
        console.log('🔍 Roles found:', authenticatedUser.roles);
        console.log('📋 Expected any of: administrator, shop_manager, seller, or active Dokan store');
        console.log('📝 User will see "Access Restricted" screen');
      } else {
        console.log('✅ ===== ACCESS GRANTED FINAL CHECK =====');
        console.log('✅ User will be redirected to dashboard');
        console.log('🎭 Primary role:', authenticatedUser.primary_role);
        console.log('🧭 Redirect target:', authenticatedUser.dashboard_route);
      }
      
      // VERIFICATION: EXACT PSEUDOCODE IMPLEMENTATION CHECK
      console.log('🔍 ===== PSEUDOCODE IMPLEMENTATION VERIFICATION =====');
      console.log('📝 Verifying implementation matches exact requirements...');
      
      const roles = authenticatedUser.roles || [];
      let expected_primary_role = null;
      let expected_hasAccess = false;
      
      if (roles.includes("administrator")) {
        expected_primary_role = "administrator";
        expected_hasAccess = true;
      } else if (roles.includes("seller")) {
        expected_primary_role = "vendor"; // map seller -> vendor
        expected_hasAccess = true;
      } else if (roles.includes("shop_manager")) {
        expected_primary_role = "vendor"; // treat shop_manager as vendor
        expected_hasAccess = true;
      }
      
      const actualHasAccess = authenticatedUser.primary_role !== 'restricted';
      console.log('🎯 Expected vs Actual:');
      console.log('  Expected primary_role:', expected_primary_role, '| Actual:', authenticatedUser.primary_role);
      console.log('  Expected hasAccess:', expected_hasAccess, '| Actual:', actualHasAccess);
      console.log('  Roles array:', roles);
      console.log('  Pseudocode match:', 
        (expected_primary_role === authenticatedUser.primary_role && expected_hasAccess === actualHasAccess) 
        ? '✅ PERFECT MATCH' : '❌ MISMATCH');
      console.log('✅ Pseudocode verification complete');

      return {
        token: tokenData.token,
        user: authenticatedUser,
        success: true
      };

    } catch (error) {
      console.error('❌ Authentication Flow Failed:', error);
      this.clearAuthData();
      throw error instanceof Error ? error : new Error('Authentication failed');
    }
  }

  /**
   * Store authentication data securely
   */
  private storeAuthData(token: string, user: AuthenticatedUser): void {
    try {
      localStorage.setItem(this.tokenKey, token);
      localStorage.setItem(this.userKey, JSON.stringify(user));
      
      console.log('💾 Authentication data stored securely');
    } catch (error) {
      console.error('❌ Failed to store auth data:', error);
      throw new Error('Failed to store authentication data');
    }
  }

  /**
   * Retrieve stored authentication data
   */
  getStoredAuthData(): { token: string; user: AuthenticatedUser } | null {
    try {
      const token = localStorage.getItem(this.tokenKey);
      const userJson = localStorage.getItem(this.userKey);

      if (!token || !userJson) {
        console.log('📭 No stored authentication data found');
        return null;
      }

      const user: AuthenticatedUser = JSON.parse(userJson);

      // Validate stored data
      if (!user.id || !user.email || !Array.isArray(user.roles)) {
        console.warn('⚠️ Invalid stored user data, clearing');
        this.clearAuthData();
        return null;
      }

      // Check token expiry
      if (user.token_expires_at && new Date() > new Date(user.token_expires_at)) {
        console.log('🔄 Stored token has expired');
        this.clearAuthData();
        return null;
      }

      console.log('✅ Valid stored authentication data found');
      console.log('👤 User:', user.display_name);
      console.log('📧 Email:', user.email);
      console.log('🎭 Role:', user.primary_role);

      return { token, user };
    } catch (error) {
      console.error('❌ Error retrieving stored auth data:', error);
      this.clearAuthData();
      return null;
    }
  }

  /**
   * Validate token with WordPress
   */
  async validateToken(token: string): Promise<boolean> {
    try {
      console.log('🔍 Validating JWT token with WordPress...');
      
      const response = await fetch(`${this.baseUrl}/wp-json/jwt-auth/v1/token/validate`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const isValid = response.ok;
      console.log('🔍 Token validation result:', isValid);
      
      return isValid;
    } catch (error) {
      console.error('❌ Token validation failed:', error);
      return false;
    }
  }

  /**
   * Refresh user data
   */
  async refreshUserData(token: string): Promise<AuthenticatedUser> {
    console.log('🔄 Refreshing user data from WordPress...');
    
    try {
      // Get current stored data for JWT fallback info
      const storedAuth = this.getStoredAuthData();
      const jwtFallback: JWTTokenResponse = {
        token,
        user_email: storedAuth?.user.email || '',
        user_nicename: storedAuth?.user.username || '',
        user_display_name: storedAuth?.user.display_name || '',
        user_id: storedAuth?.user.id || undefined
      };
      
      const profile = await this.fetchUserProfile(token, jwtFallback);
      const refreshedUser = await this.createAuthenticatedUser(jwtFallback, profile);
      
      // Update stored user data
      localStorage.setItem(this.userKey, JSON.stringify(refreshedUser));
      
      console.log('✅ User data refreshed successfully');
      return refreshedUser;
    } catch (error) {
      console.error('❌ Failed to refresh user data:', error);
      throw error;
    }
  }

  /**
   * Clear authentication data
   */
  clearAuthData(): void {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
    console.log('🧹 Authentication data cleared');
  }

  /**
   * Logout user
   */
  logout(): void {
    console.log('🚪 ===== USER LOGOUT =====');
    this.clearAuthData();
    
    // Redirect to home page
    window.location.href = '/';
  }
}

// Export singleton instance
export const wordpressAuth = new WordPressAuthService();

// Export types
export type { 
  LoginCredentials, 
  AuthenticatedUser, 
  WordPressUserProfile,
  JWTTokenResponse 
};

/**
 * Utility function to get human-readable role display names
 * Use this consistently across the application for role display
 */
export const getRoleDisplayName = (role: string): string => {
  const roleDisplayNames: { [key: string]: string } = {
    'administrator': 'Administrator',
    'shop_manager': 'Shop Manager',
    'vendor': 'Vendor',
    'seller': 'Seller',
    'customer': 'Customer',
    'subscriber': 'Subscriber',
    'restricted': 'Restricted Access'
  };
  
  return roleDisplayNames[role] || role.charAt(0).toUpperCase() + role.slice(1);
};

export default wordpressAuth;