import React, { useState } from 'react';
import { 
  Store, CheckCircle, XCircle, AlertTriangle, RefreshCw,
  ExternalLink, Settings, Trash2, Eye, Globe, Webhook,
  MoreHorizontal, Play, Pause, Database, Shield, Users,
  FileCheck, Package, ShoppingCart, Activity, Download,
  Upload, Edit, Key, Zap, BarChart3
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel } from './ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';

interface StoreListViewProps {
  onAddStore: () => void;
}

interface StoreData {
  id: string;
  name: string;
  url: string;
  status: 'connected' | 'error' | 'warning' | 'maintenance';
  lastSync: string;
  totalOrders: number;
  totalProducts: number;
  totalVendors: number;
  pendingKYC: number;
  webhooksActive: number;
  webhooksTotal: number;
  apiVersion: string;
  createdAt: string;
  dokanEnabled: boolean;
  healthScore: number;
  adminUser: string;
  features: string[];
}

export const StoreListView: React.FC<StoreListViewProps> = ({ onAddStore }) => {
  const [stores] = useState<StoreData[]>([
    {
      id: '1',
      name: 'EliteQ Main Store',
      url: 'https://eliteq.in',
      status: 'connected',
      lastSync: '2 minutes ago',
      totalOrders: 1247,
      totalProducts: 156,
      totalVendors: 23,
      pendingKYC: 5,
      webhooksActive: 8,
      webhooksTotal: 10,
      apiVersion: 'v3',
      createdAt: '2024-01-15',
      dokanEnabled: true,
      healthScore: 95,
      adminUser: 'admin_eliteq',
      features: ['Orders', 'Products', 'Webhooks', 'Dokan KYC', 'Vendor Management']
    },
    {
      id: '2',
      name: 'Demo Marketplace',
      url: 'https://demo.eliteq.in',
      status: 'warning',
      lastSync: '1 hour ago',
      totalOrders: 89,
      totalProducts: 45,
      totalVendors: 8,
      pendingKYC: 3,
      webhooksActive: 6,
      webhooksTotal: 8,
      apiVersion: 'v3',
      createdAt: '2024-01-10',
      dokanEnabled: true,
      healthScore: 78,
      adminUser: 'demo_admin',
      features: ['Orders', 'Products', 'Webhooks', 'Dokan KYC']
    },
    {
      id: '3',
      name: 'Test Environment',
      url: 'https://test.eliteq.in',
      status: 'maintenance',
      lastSync: '3 hours ago',
      totalOrders: 23,
      totalProducts: 12,
      totalVendors: 2,
      pendingKYC: 1,
      webhooksActive: 2,
      webhooksTotal: 6,
      apiVersion: 'v3',
      createdAt: '2024-01-08',
      dokanEnabled: false,
      healthScore: 45,
      adminUser: 'test_admin',
      features: ['Orders', 'Products']
    }
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedStore, setSelectedStore] = useState<StoreData | null>(null);
  const [isRefreshing, setIsRefreshing] = useState<string | null>(null);
  const [actionInProgress, setActionInProgress] = useState<string | null>(null);

  const getStatusBadge = (status: StoreData['status']) => {
    switch (status) {
      case 'connected':
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-200 border-green-200">
            <CheckCircle className="h-3 w-3 mr-1" />
            Connected
          </Badge>
        );
      case 'error':
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-200 border-red-200">
            <XCircle className="h-3 w-3 mr-1" />
            Error
          </Badge>
        );
      case 'warning':
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200 border-yellow-200">
            <AlertTriangle className="h-3 w-3 mr-1" />
            Warning
          </Badge>
        );
      case 'maintenance':
        return (
          <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-200 border-gray-200">
            <Pause className="h-3 w-3 mr-1" />
            Maintenance
          </Badge>
        );
      default:
        return null;
    }
  };

  const getHealthScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 70) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const handleStoreAction = async (storeId: string, action: string) => {
    setActionInProgress(`${storeId}-${action}`);
    
    // Simulate API call
    setTimeout(() => {
      setActionInProgress(null);
      console.log(`${action} completed for store ${storeId}`);
    }, 2000);
  };

  const handleRefreshStore = async (storeId: string) => {
    setIsRefreshing(storeId);
    setTimeout(() => {
      setIsRefreshing(null);
    }, 2000);
  };

  const filteredStores = stores.filter(store => {
    const matchesSearch = store.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         store.url.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || store.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalStats = {
    stores: stores.length,
    connected: stores.filter(s => s.status === 'connected').length,
    totalOrders: stores.reduce((sum, store) => sum + store.totalOrders, 0),
    totalProducts: stores.reduce((sum, store) => sum + store.totalProducts, 0),
    totalVendors: stores.reduce((sum, store) => sum + store.totalVendors, 0),
    pendingKYC: stores.reduce((sum, store) => sum + store.pendingKYC, 0),
    activeWebhooks: stores.reduce((sum, store) => sum + store.webhooksActive, 0)
  };

  return (
    <div className="space-y-6">
      
      {/* Enhanced Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total Stores</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{totalStats.stores}</p>
              </div>
              <Store className="h-8 w-8 text-blue-600 bg-blue-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Connected</p>
                <p className="text-2xl font-bold text-green-600">{totalStats.connected}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600 bg-green-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total Orders</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {totalStats.totalOrders.toLocaleString()}
                </p>
              </div>
              <ShoppingCart className="h-8 w-8 text-purple-600 bg-purple-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Products</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {totalStats.totalProducts.toLocaleString()}
                </p>
              </div>
              <Package className="h-8 w-8 text-indigo-600 bg-indigo-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Vendors</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {totalStats.totalVendors}
                </p>
              </div>
              <Users className="h-8 w-8 text-teal-600 bg-teal-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Pending KYC</p>
                <p className="text-2xl font-bold text-orange-600">{totalStats.pendingKYC}</p>
              </div>
              <FileCheck className="h-8 w-8 text-orange-600 bg-orange-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Webhooks</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {totalStats.activeWebhooks}
                </p>
              </div>
              <Webhook className="h-8 w-8 text-pink-600 bg-pink-100 p-2 rounded-lg" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 flex-1">
              <Input
                placeholder="Search stores..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="max-w-sm"
              />
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="max-w-[180px]">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="connected">Connected</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button onClick={onAddStore} className="bg-blue-600 hover:bg-blue-700 text-white">
              <Store className="h-4 w-4 mr-2" />
              Add Store
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stores Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Store className="h-5 w-5" />
            Connected Stores ({filteredStores.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Store</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Health</TableHead>
                  <TableHead>Orders</TableHead>
                  <TableHead>Products</TableHead>
                  <TableHead>Vendors</TableHead>
                  <TableHead>KYC Pending</TableHead>
                  <TableHead>Webhooks</TableHead>
                  <TableHead>Last Sync</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStores.map((store) => (
                  <TableRow key={store.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium text-gray-900 dark:text-white flex items-center gap-2">
                          {store.name}
                          {store.dokanEnabled && (
                            <Badge variant="outline" className="text-xs">Dokan</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-1 text-sm text-gray-500">
                          <Globe className="h-3 w-3" />
                          <a 
                            href={store.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="hover:text-blue-600 hover:underline"
                          >
                            {store.url}
                          </a>
                          <ExternalLink className="h-3 w-3" />
                        </div>
                        <div className="text-xs text-gray-400">
                          Admin: {store.adminUser}
                        </div>
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      {getStatusBadge(store.status)}
                    </TableCell>
                    
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${getHealthScoreColor(store.healthScore)}`}>
                          {store.healthScore}
                        </div>
                        <Progress value={store.healthScore} className="w-16 h-2" />
                      </div>
                    </TableCell>
                    
                    <TableCell className="font-mono text-sm">
                      {store.totalOrders.toLocaleString()}
                    </TableCell>
                    
                    <TableCell className="font-mono text-sm">
                      {store.totalProducts.toLocaleString()}
                    </TableCell>
                    
                    <TableCell className="font-mono text-sm">
                      {store.totalVendors}
                    </TableCell>
                    
                    <TableCell>
                      {store.pendingKYC > 0 ? (
                        <Badge variant="outline" className="text-orange-600 border-orange-300">
                          {store.pendingKYC} pending
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-green-600 border-green-300">
                          All approved
                        </Badge>
                      )}
                    </TableCell>
                    
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Webhook className="h-4 w-4 text-orange-600" />
                        <span className="text-sm">
                          {store.webhooksActive}/{store.webhooksTotal}
                        </span>
                      </div>
                    </TableCell>
                    
                    <TableCell className="text-sm text-gray-600">
                      {store.lastSync}
                    </TableCell>
                    
                    <TableCell className="text-right">
                      <div className="flex items-center gap-2 justify-end">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRefreshStore(store.id)}
                          disabled={isRefreshing === store.id}
                        >
                          <RefreshCw className={`h-4 w-4 ${isRefreshing === store.id ? 'animate-spin' : ''}`} />
                        </Button>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-56">
                            <DropdownMenuLabel>Store Management</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => setSelectedStore(store)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleStoreAction(store.id, 'sync')}>
                              <RefreshCw className="h-4 w-4 mr-2" />
                              Sync Now
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuLabel>Admin Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleStoreAction(store.id, 'kyc-sync')}>
                              <FileCheck className="h-4 w-4 mr-2" />
                              Force KYC Sync
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleStoreAction(store.id, 'order-update')}>
                              <ShoppingCart className="h-4 w-4 mr-2" />
                              Order Status Update
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleStoreAction(store.id, 'product-approval')}>
                              <Package className="h-4 w-4 mr-2" />
                              Product Approval Toggle
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Webhook className="h-4 w-4 mr-2" />
                              View Webhooks
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Key className="h-4 w-4 mr-2" />
                              Edit Credentials
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Settings className="h-4 w-4 mr-2" />
                              Configure
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="h-4 w-4 mr-2" />
                              Disconnect
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Store Details Dialog */}
      <Dialog open={!!selectedStore} onOpenChange={() => setSelectedStore(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Store className="h-5 w-5" />
              Store Details: {selectedStore?.name}
            </DialogTitle>
          </DialogHeader>
          
          {selectedStore && (
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="data">Data</TabsTrigger>
                <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
                <TabsTrigger value="admin">Admin Tools</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <ShoppingCart className="h-8 w-8 text-blue-600 mb-2" />
                    <div className="text-2xl font-bold text-blue-600">{selectedStore.totalOrders}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Total Orders</div>
                  </div>
                  <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <Package className="h-8 w-8 text-green-600 mb-2" />
                    <div className="text-2xl font-bold text-green-600">{selectedStore.totalProducts}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Products</div>
                  </div>
                  <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <Users className="h-8 w-8 text-purple-600 mb-2" />
                    <div className="text-2xl font-bold text-purple-600">{selectedStore.totalVendors}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Vendors</div>
                  </div>
                  <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                    <FileCheck className="h-8 w-8 text-orange-600 mb-2" />
                    <div className="text-2xl font-bold text-orange-600">{selectedStore.pendingKYC}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Pending KYC</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Store URL</label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{selectedStore.url}</p>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Admin User</label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{selectedStore.adminUser}</p>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">API Version</label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{selectedStore.apiVersion}</p>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Created</label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{selectedStore.createdAt}</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Features</label>
                  <div className="flex flex-wrap gap-2">
                    {selectedStore.features.map((feature, index) => (
                      <Badge key={index} variant="outline">{feature}</Badge>
                    ))}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="data" className="space-y-4">
                <div className="space-y-4">
                  <h3 className="font-medium">Recent Products</h3>
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-gray-600">Last sync data would be displayed here</p>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="webhooks" className="space-y-4">
                <div className="space-y-4">
                  <h3 className="font-medium">Webhook Status</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <span className="text-sm">order.created</span>
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <span className="text-sm">product.updated</span>
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="admin" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Button 
                    className="h-16 flex-col gap-2" 
                    variant="outline"
                    onClick={() => handleStoreAction(selectedStore.id, 'kyc-sync')}
                    disabled={actionInProgress === `${selectedStore.id}-kyc-sync`}
                  >
                    <FileCheck className="h-6 w-6" />
                    Force KYC Sync
                  </Button>
                  <Button 
                    className="h-16 flex-col gap-2" 
                    variant="outline"
                    onClick={() => handleStoreAction(selectedStore.id, 'order-update')}
                    disabled={actionInProgress === `${selectedStore.id}-order-update`}
                  >
                    <ShoppingCart className="h-6 w-6" />
                    Order Status Update
                  </Button>
                  <Button 
                    className="h-16 flex-col gap-2" 
                    variant="outline"
                    onClick={() => handleStoreAction(selectedStore.id, 'product-approval')}
                    disabled={actionInProgress === `${selectedStore.id}-product-approval`}
                  >
                    <Package className="h-6 w-6" />
                    Product Approval
                  </Button>
                  <Button 
                    className="h-16 flex-col gap-2" 
                    variant="outline"
                    onClick={() => handleStoreAction(selectedStore.id, 'full-sync')}
                    disabled={actionInProgress === `${selectedStore.id}-full-sync`}
                  >
                    <Database className="h-6 w-6" />
                    Full Data Sync
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};