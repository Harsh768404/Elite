import { wpUsersAPI, wooCommerceAPI } from './jwt-auth';

export interface Announcement {
  id: number;
  title: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  excerpt: {
    rendered: string;
  };
  date: string;
  modified: string;
  author: number;
  status: string;
  meta?: {
    author_name?: string;
    posted_by?: string;
  };
}

export interface AnnouncementListItem {
  id: number;
  title: string;
  description: string;
  time: string;
  timeAgo: string;
  postedBy: string;
  content: string;
  status: string;
  date: string;
}

class AnnouncementService {
  private baseUrl = 'https://eliteq.in';
  private cache: AnnouncementListItem[] = [];
  private lastFetch = 0;
  private cacheExpiry = 300000; // 5 minutes

  // Format time to "X hours ago" format
  private formatTimeAgo(dateString: string): string {
    const now = new Date();
    const date = new Date(dateString);
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 60) {
      return `${diffMins} min${diffMins !== 1 ? 's' : ''} ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hr${diffHours !== 1 ? 's' : ''} ago`;
    } else {
      return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
    }
  }

  // Format date for display
  private formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  // Strip HTML tags and decode entities
  private stripHtml(html: string): string {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return doc.body.textContent || '';
  }

  // Transform raw announcement data to our format
  private transformAnnouncement(announcement: Announcement): AnnouncementListItem {
    const title = this.stripHtml(announcement.title?.rendered || '');
    const description = this.stripHtml(announcement.excerpt?.rendered || announcement.content?.rendered || '').substring(0, 120) + '...';
    const content = this.stripHtml(announcement.content?.rendered || '');
    const postedBy = announcement.meta?.author_name || announcement.meta?.posted_by || 'System';

    return {
      id: announcement.id,
      title: title || 'Untitled Announcement',
      description: description || 'No description available',
      content: content || 'No content available',
      time: this.formatDate(announcement.date),
      timeAgo: this.formatTimeAgo(announcement.date),
      postedBy: postedBy,
      status: announcement.status || 'publish',
      date: announcement.date
    };
  }

  // Fetch announcements with proper authentication and timeout handling
  async fetchAnnouncements(forceRefresh = false): Promise<AnnouncementListItem[]> {
    console.log('📢 ===== FETCHING ANNOUNCEMENTS =====');
    
    // Return cache if still valid and not forcing refresh
    const now = Date.now();
    if (!forceRefresh && this.cache.length > 0 && (now - this.lastFetch) < this.cacheExpiry) {
      console.log('📢 Returning cached announcements:', this.cache.length);
      return this.cache;
    }

    try {
      let announcements: Announcement[] = [];
      
      // Try to fetch with timeout protection
      try {
        // Get JWT token for authentication
        const token = localStorage.getItem('eliteq_jwt_token');
        const headers: HeadersInit = {
          'Content-Type': 'application/json',
        };

        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }

        // Use AbortController for timeout
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000); // 8 second timeout

        const dokanUrl = `${this.baseUrl}/wp-json/wp/v2/dokan_announcement`;
        console.log('📢 Fetching from Dokan endpoint (8s timeout):', dokanUrl);

        try {
          const response = await fetch(dokanUrl, {
            method: 'GET',
            headers: headers,
            signal: controller.signal
          });

          clearTimeout(timeoutId);

          if (response.ok) {
            const data = await response.json();
            announcements = Array.isArray(data) ? data : [];
            console.log('📢 Successfully fetched from Dokan:', announcements.length, 'announcements');
          } else {
            console.warn('📢 Dokan endpoint failed:', response.status, response.statusText);
            throw new Error(`Dokan API failed: ${response.status}`);
          }
        } catch (fetchError) {
          clearTimeout(timeoutId);
          throw fetchError;
        }

      } catch (dokanError) {
        console.warn('📢 Dokan endpoint error (timeout/network):', dokanError.message);
        
        // Fallback: Try regular posts endpoint with shorter timeout
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout for fallback

          const fallbackUrl = `${this.baseUrl}/wp-json/wp/v2/posts?per_page=5`;
          console.log('📢 Trying fallback endpoint (5s timeout):', fallbackUrl);
          
          const token = localStorage.getItem('eliteq_jwt_token');
          const headers: HeadersInit = {
            'Content-Type': 'application/json',
          };

          if (token) {
            headers['Authorization'] = `Bearer ${token}`;
          }

          try {
            const fallbackResponse = await fetch(fallbackUrl, {
              method: 'GET',
              headers: headers,
              signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (fallbackResponse.ok) {
              const fallbackData = await fallbackResponse.json();
              announcements = Array.isArray(fallbackData) ? fallbackData.slice(0, 3) : []; // Limit to 3 for demo
              console.log('📢 Fallback successful:', announcements.length, 'announcements');
            } else {
              console.warn('📢 Fallback also failed:', fallbackResponse.status);
            }
          } catch (fallbackFetchError) {
            clearTimeout(timeoutId);
            console.warn('📢 Fallback also timed out/failed:', fallbackFetchError.message);
          }
        } catch (fallbackError) {
          console.warn('📢 Fallback error:', fallbackError.message);
        }
      }

      // If no real data, create mock data for development
      if (announcements.length === 0) {
        console.log('📢 No real announcements found, using mock data for demo');
        announcements = this.createMockAnnouncements();
      }

      // Transform and cache the data
      this.cache = announcements.map(announcement => this.transformAnnouncement(announcement));
      this.lastFetch = now;

      console.log('📢 Final announcements cache:', this.cache.length, 'items');
      return this.cache;

    } catch (error) {
      console.warn('📢 Error fetching announcements (using fallback):', error.message);
      
      // Return cached data if available, otherwise mock data
      if (this.cache.length > 0) {
        console.log('📢 Returning cached data due to error');
        return this.cache;
      }
      
      // Last resort: mock data
      console.log('📢 Creating mock data due to error');
      const mockAnnouncements = this.createMockAnnouncements();
      this.cache = mockAnnouncements.map(announcement => this.transformAnnouncement(announcement));
      return this.cache;
    }
  }

  // Create mock announcements for development/fallback
  private createMockAnnouncements(): Announcement[] {
    const now = new Date();
    const twoHoursAgo = new Date(now.getTime() - 2 * 60 * 60 * 1000);
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const threeDaysAgo = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);

    return [
      {
        id: 1,
        title: { rendered: 'New Electronics Categories Added' },
        content: { rendered: 'We have expanded our electronics marketplace with new categories including Smart Home devices, Gaming accessories, and Professional audio equipment. Explore the latest products from top brands.' },
        excerpt: { rendered: 'New electronics categories now available including Smart Home, Gaming, and Professional audio.' },
        date: twoHoursAgo.toISOString(),
        modified: twoHoursAgo.toISOString(),
        author: 1,
        status: 'publish',
        meta: {
          author_name: 'EliteQ Admin',
          posted_by: 'Admin'
        }
      },
      {
        id: 2,
        title: { rendered: 'System Maintenance Scheduled' },
        content: { rendered: 'Scheduled maintenance will occur on Sunday, August 4th from 2:00 AM to 4:00 AM IST. During this time, some features may be temporarily unavailable. We apologize for any inconvenience.' },
        excerpt: { rendered: 'System maintenance scheduled for Sunday, August 4th from 2:00 AM to 4:00 AM IST.' },
        date: oneDayAgo.toISOString(),
        modified: oneDayAgo.toISOString(),
        author: 1,
        status: 'publish',
        meta: {
          author_name: 'System',
          posted_by: 'System'
        }
      },
      {
        id: 3,
        title: { rendered: 'Vendor Commission Update' },
        content: { rendered: 'Starting next month, we are updating our vendor commission structure to be more competitive. Existing vendors will receive detailed information via email. New vendor registration is now open with enhanced benefits.' },
        excerpt: { rendered: 'Vendor commission structure update effective next month. Enhanced benefits for new registrations.' },
        date: threeDaysAgo.toISOString(),
        modified: threeDaysAgo.toISOString(),
        author: 1,
        status: 'publish',
        meta: {
          author_name: 'EliteQ Team',
          posted_by: 'Admin'
        }
      }
    ];
  }

  // Get announcement count for badge display
  async getAnnouncementCount(): Promise<number> {
    try {
      const announcements = await this.fetchAnnouncements();
      return announcements.length;
    } catch (error) {
      console.error('📢 Error getting announcement count:', error);
      return 0;
    }
  }

  // Get recent announcements (for bell dropdown)
  async getRecentAnnouncements(limit = 5): Promise<AnnouncementListItem[]> {
    try {
      const announcements = await this.fetchAnnouncements();
      return announcements.slice(0, limit);
    } catch (error) {
      console.error('📢 Error getting recent announcements:', error);
      return [];
    }
  }

  // Clear cache (useful for refresh)
  clearCache(): void {
    this.cache = [];
    this.lastFetch = 0;
    console.log('📢 Announcement cache cleared');
  }

  // Get single announcement by ID
  async getAnnouncementById(id: number): Promise<AnnouncementListItem | null> {
    try {
      const announcements = await this.fetchAnnouncements();
      return announcements.find(announcement => announcement.id === id) || null;
    } catch (error) {
      console.error('📢 Error getting announcement by ID:', error);
      return null;
    }
  }
}

// Export singleton instance
export const announcementService = new AnnouncementService();

// Export utility functions
export const refreshAnnouncements = () => {
  announcementService.clearCache();
  return announcementService.fetchAnnouncements(true);
};

export const getAnnouncementCount = () => {
  return announcementService.getAnnouncementCount();
};

export const getRecentAnnouncements = (limit?: number) => {
  return announcementService.getRecentAnnouncements(limit);
};