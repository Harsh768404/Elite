// WooCommerce API Integration for EliteQ India
// WordPress Admin Control Panel - Enhanced API Client with Error Handling

import { envConfig, envHelpers } from './env-config';

const ELITEQ_BASE_URL = envConfig.WORDPRESS_BASE_URL || 'https://eliteq.in';
const WOOCOMMERCE_BASE_URL = `${ELITEQ_BASE_URL}/wp-json/wc/v3`;

// WooCommerce REST API Credentials - EliteQ India (from environment variables)
const getWooCommerceCredentials = () => {
  console.log('🔑 ===== WOOCOMMERCE API CREDENTIALS CHECK =====');
  
  // Try multiple methods to get credentials
  let credentials;
  
  try {
    // Method 1: Use environment helpers
    credentials = envHelpers.getWooCommerceCredentials();
    
    if (credentials && credentials.consumer_key && credentials.consumer_secret) {
      console.log('✅ Credentials found via environment helpers');
      console.log('🗝️ Consumer Key Preview:', `${credentials.consumer_key.substring(0, 8)}...${credentials.consumer_key.slice(-4)}`);
      console.log('🔐 Consumer Secret Preview:', `${credentials.consumer_secret.substring(0, 8)}...${credentials.consumer_secret.slice(-4)}`);
      return credentials;
    }
  } catch (error) {
    console.warn('⚠️ Environment helpers failed:', error);
  }

  // Method 2: Direct window.ENV access
  if (typeof window !== 'undefined' && (window as any).ENV) {
    const windowKey = (window as any).ENV.WOOCOMMERCE_CONSUMER_KEY || (window as any).ENV.CONSUMER_KEY;
    const windowSecret = (window as any).ENV.WOOCOMMERCE_CONSUMER_SECRET || (window as any).ENV.CONSUMER_SECRET;
    
    if (windowKey && windowSecret) {
      console.log('✅ Credentials found in window.ENV');
      console.log('🗝️ Consumer Key Preview:', `${windowKey.substring(0, 8)}...${windowKey.slice(-4)}`);
      console.log('🔐 Consumer Secret Preview:', `${windowSecret.substring(0, 8)}...${windowSecret.slice(-4)}`);
      return {
        consumer_key: windowKey,
        consumer_secret: windowSecret
      };
    }
  }

  // Method 3: Direct hardcoded credentials as last resort for EliteQ
  const hardcodedCredentials = {
    consumer_key: 'ck_4d068c0a74e3fa3bbeb9895acf3fa07d520c3bd9',
    consumer_secret: 'cs_77a3b392dc4d434d1ffc611fa9d8d62e326833e3'
  };
  
  console.log('🔧 Using hardcoded EliteQ credentials as fallback');
  console.log('🗝️ Consumer Key Preview:', `${hardcodedCredentials.consumer_key.substring(0, 8)}...${hardcodedCredentials.consumer_key.slice(-4)}`);
  console.log('🔐 Consumer Secret Preview:', `${hardcodedCredentials.consumer_secret.substring(0, 8)}...${hardcodedCredentials.consumer_secret.slice(-4)}`);
  
  return hardcodedCredentials;
};

interface WooCommerceRequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  data?: any;
  params?: Record<string, any>;
  headers?: Record<string, string>;
  timeout?: number;
}

interface WooCommerceApiResponse<T = any> {
  data: T;
  headers: Headers;
  status: number;
}

interface ProductData {
  id?: number;
  name: string;
  type?: 'simple' | 'grouped' | 'external' | 'variable';
  status?: 'draft' | 'pending' | 'private' | 'publish';
  featured?: boolean;
  catalog_visibility?: 'visible' | 'catalog' | 'search' | 'hidden';
  description?: string;
  short_description?: string;
  sku?: string;
  price?: string;
  regular_price?: string;
  sale_price?: string;
  manage_stock?: boolean;
  stock_quantity?: number;
  stock_status?: 'instock' | 'outofstock' | 'onbackorder';
  backorders?: 'no' | 'notify' | 'yes';
  categories?: Array<{ id: number; name?: string }>;
  tags?: Array<{ id: number; name?: string }>;
  images?: Array<{ src: string; alt?: string }>;
  attributes?: Array<{
    id: number;
    name: string;
    options: string[];
    visible: boolean;
    variation: boolean;
  }>;
  weight?: string;
  dimensions?: {
    length: string;
    width: string;
    height: string;
  };
  shipping_class?: string;
  reviews_allowed?: boolean;
  meta_data?: Array<{ key: string; value: any }>;
}

interface OrderData {
  id?: number;
  status?: 'pending' | 'processing' | 'on-hold' | 'completed' | 'cancelled' | 'refunded' | 'failed';
  currency?: string;
  customer_id?: number;
  customer_note?: string;
  billing?: {
    first_name: string;
    last_name: string;
    company?: string;
    address_1: string;
    address_2?: string;
    city: string;
    state: string;
    postcode: string;
    country: string;
    email: string;
    phone: string;
  };
  shipping?: {
    first_name: string;
    last_name: string;
    company?: string;
    address_1: string;
    address_2?: string;
    city: string;
    state: string;
    postcode: string;
    country: string;
  };
  payment_method?: string;
  payment_method_title?: string;
  line_items?: Array<{
    product_id: number;
    variation_id?: number;
    quantity: number;
    price?: string;
  }>;
  shipping_lines?: Array<{
    method_id: string;
    method_title: string;
    total: string;
  }>;
  coupon_lines?: Array<{
    code: string;
    discount?: string;
  }>;
  meta_data?: Array<{ key: string; value: any }>;
}

interface CustomerData {
  id?: number;
  email: string;
  first_name?: string;
  last_name?: string;
  username?: string;
  password?: string;
  billing?: {
    first_name?: string;
    last_name?: string;
    company?: string;
    address_1?: string;
    address_2?: string;
    city?: string;
    state?: string;
    postcode?: string;
    country?: string;
    email?: string;
    phone?: string;
  };
  shipping?: {
    first_name?: string;
    last_name?: string;
    company?: string;
    address_1?: string;
    address_2?: string;
    city?: string;
    state?: string;
    postcode?: string;
    country?: string;
  };
  meta_data?: Array<{ key: string; value: any }>;
}

// Enhanced error class for better error handling
class WooCommerceApiError extends Error {
  public status: number;
  public code: string;
  public response?: any;

  constructor(message: string, status: number = 0, code: string = 'UNKNOWN', response?: any) {
    super(message);
    this.name = 'WooCommerceApiError';
    this.status = status;
    this.code = code;
    this.response = response;
  }
}

class WooCommerceAPI {
  private baseUrl: string;
  private credentials: { consumer_key: string; consumer_secret: string };
  private defaultTimeout: number = 10000; // 10 seconds

  constructor() {
    this.baseUrl = WOOCOMMERCE_BASE_URL;
    try {
      this.credentials = getWooCommerceCredentials();
    } catch (error) {
      console.error('❌ Failed to initialize WooCommerce credentials:', error);
      throw error;
    }
  }

  // Create authenticated URL with OAuth 1.0a signature
  private createAuthenticatedUrl(endpoint: string, params: Record<string, any> = {}): string {
    const url = new URL(`${this.baseUrl}/${endpoint.replace(/^\//, '')}`);
    
    console.log(`🔗 Creating authenticated URL for: ${endpoint}`);
    console.log(`🗝️ Using Consumer Key: ${this.credentials.consumer_key.substring(0, 10)}...`);
    console.log(`🔐 Using Consumer Secret: ${this.credentials.consumer_secret.substring(0, 10)}...`);
    
    // Add consumer key and secret for basic authentication
    url.searchParams.append('consumer_key', this.credentials.consumer_key);
    url.searchParams.append('consumer_secret', this.credentials.consumer_secret);
    
    // Add additional parameters
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        url.searchParams.append(key, String(value));
      }
    });
    
    const finalUrl = url.toString();
    console.log(`🔗 Final URL (credentials hidden): ${finalUrl.replace(/consumer_(key|secret)=[^&]+/g, 'consumer_$1=***')}`);
    
    return finalUrl;
  }

  // Enhanced generic API request method with error handling
  private async makeRequest<T = any>(
    endpoint: string, 
    options: WooCommerceRequestOptions = {}
  ): Promise<WooCommerceApiResponse<T>> {
    const { method = 'GET', data, params = {}, headers = {}, timeout = this.defaultTimeout } = options;
    
    try {
      const url = this.createAuthenticatedUrl(endpoint, method === 'GET' ? params : {});
      
      // Create AbortController for timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);
      
      const requestOptions: RequestInit = {
        method,
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'EliteQ-Admin-Panel/1.0',
          'Accept': 'application/json',
          'Authorization': `Basic ${btoa(`${this.credentials.consumer_key}:${this.credentials.consumer_secret}`)}`,
          ...headers,
        },
        signal: controller.signal,
      };

      if (data && method !== 'GET') {
        requestOptions.body = JSON.stringify(data);
      }

      console.log(`🔗 WooCommerce API Request: ${method} ${endpoint}`);
      console.log(`🗝️ Auth Method: Basic Auth + Query Parameters`);
      
      const response = await fetch(url, requestOptions);
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
        let errorData = null;
        
        try {
          const contentType = response.headers.get('content-type');
          if (contentType && contentType.includes('application/json')) {
            errorData = await response.json();
            if (errorData.message) {
              errorMessage = errorData.message;
            } else if (errorData.error) {
              errorMessage = errorData.error;
            } else if (errorData.code === 'woocommerce_rest_authentication_error') {
              errorMessage = 'Invalid WooCommerce API credentials. Please check your consumer key and secret.';
            }
          } else {
            const textError = await response.text();
            if (textError) errorMessage = textError;
          }
        } catch (parseError) {
          console.warn('Could not parse error response:', parseError);
        }
        
        // Enhanced error logging for authentication issues
        if (response.status === 401) {
          console.error('❌ WooCommerce Authentication Error (401):', errorMessage);
          console.error('🔍 Credential Check:');
          console.error('  - Consumer Key:', this.credentials.consumer_key ? `${this.credentials.consumer_key.substring(0, 10)}...` : 'MISSING');
          console.error('  - Consumer Secret:', this.credentials.consumer_secret ? `${this.credentials.consumer_secret.substring(0, 10)}...` : 'MISSING');
          console.error('  - API Endpoint:', `${this.baseUrl}/${endpoint}`);
          console.error('  - Base URL:', ELITEQ_BASE_URL);
          console.error('🔧 Troubleshooting:');
          console.error('  1. Verify WooCommerce is installed and active');
          console.error('  2. Check API keys in WooCommerce → Settings → Advanced → REST API');
          console.error('  3. Ensure API keys have read/write permissions');
          console.error('  4. Verify HTTPS is working on the WordPress site');
        } else {
          console.error(`❌ WooCommerce API Error (${response.status}):`, errorMessage);
        }
        
        // Throw enhanced error with context
        throw new WooCommerceApiError(
          errorMessage,
          response.status,
          this.getErrorCode(response.status),
          errorData
        );
      }

      const responseData = await response.json();
      
      console.log(`✅ WooCommerce API Success: ${method} ${endpoint}`);
      
      return {
        data: responseData,
        headers: response.headers,
        status: response.status,
      };
      
    } catch (error) {
      // Handle different types of errors
      if (error instanceof WooCommerceApiError) {
        throw error; // Re-throw our custom errors
      }
      
      if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
        console.error('🚨 Network error - WooCommerce server unreachable');
        console.error('🔍 Possible causes:');
        console.error('  - WordPress site is down');
        console.error('  - SSL/HTTPS issues');
        console.error('  - Network connectivity problems');
        console.error('  - CORS restrictions');
        throw new WooCommerceApiError(
          'Cannot connect to WooCommerce server. Please check your internet connection or server status.',
          0,
          'NETWORK_ERROR'
        );
      }
      
      if (error instanceof Error && error.name === 'AbortError') {
        console.error('🚨 Request timeout - WooCommerce API took too long to respond');
        throw new WooCommerceApiError(
          'Request timeout. The WooCommerce server took too long to respond.',
          0,
          'TIMEOUT_ERROR'
        );
      }
      
      console.error(`🚨 WooCommerce API Request Failed:`, error);
      throw new WooCommerceApiError(
        error instanceof Error ? error.message : 'Unknown error occurred',
        0,
        'UNKNOWN_ERROR'
      );
    }
  }

  // Helper to get error codes based on HTTP status
  private getErrorCode(status: number): string {
    switch (status) {
      case 400: return 'BAD_REQUEST';
      case 401: return 'UNAUTHORIZED';
      case 403: return 'FORBIDDEN';
      case 404: return 'NOT_FOUND';
      case 429: return 'RATE_LIMITED';
      case 500: return 'SERVER_ERROR';
      case 502: return 'BAD_GATEWAY';
      case 503: return 'SERVICE_UNAVAILABLE';
      case 504: return 'GATEWAY_TIMEOUT';
      default: return 'HTTP_ERROR';
    }
  }

  // PRODUCTS API METHODS with Enhanced Error Handling
  
  async getProducts(params: Record<string, any> = {}) {
    const defaultParams = {
      per_page: 20,
      orderby: 'date',
      order: 'desc',
      status: 'any',
      ...params
    };
    
    try {
      return await this.makeRequest('products', { params: defaultParams });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        console.warn(`⚠️ Products API failed: ${error.message}`);
        if (error.status === 401) {
          console.warn('🔧 This is likely an authentication issue. Please verify your WooCommerce API credentials.');
        }
        throw error;
      }
      throw new WooCommerceApiError('Failed to fetch products', 0, 'PRODUCTS_ERROR');
    }
  }

  async getProduct(productId: number) {
    try {
      return await this.makeRequest(`products/${productId}`);
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError(`Failed to fetch product ${productId}`, 0, 'PRODUCT_ERROR');
    }
  }

  async createProduct(productData: ProductData) {
    try {
      return await this.makeRequest('products', {
        method: 'POST',
        data: productData
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to create product', 0, 'CREATE_PRODUCT_ERROR');
    }
  }

  async updateProduct(productId: number, productData: Partial<ProductData>) {
    try {
      return await this.makeRequest(`products/${productId}`, {
        method: 'PUT',
        data: productData
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError(`Failed to update product ${productId}`, 0, 'UPDATE_PRODUCT_ERROR');
    }
  }

  async deleteProduct(productId: number, force: boolean = false) {
    try {
      return await this.makeRequest(`products/${productId}`, {
        method: 'DELETE',
        params: { force }
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError(`Failed to delete product ${productId}`, 0, 'DELETE_PRODUCT_ERROR');
    }
  }

  async batchProducts(data: { create?: ProductData[]; update?: ProductData[]; delete?: number[] }) {
    try {
      return await this.makeRequest('products/batch', {
        method: 'POST',
        data
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to batch update products', 0, 'BATCH_PRODUCTS_ERROR');
    }
  }

  // ORDERS API METHODS with Enhanced Error Handling
  
  async getOrders(params: Record<string, any> = {}) {
    const defaultParams = {
      per_page: 20,
      orderby: 'date',
      order: 'desc',
      status: 'any',
      ...params
    };
    
    try {
      return await this.makeRequest('orders', { params: defaultParams });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        console.warn(`⚠️ Orders API failed: ${error.message}`);
        if (error.status === 401) {
          console.warn('🔧 This is likely an authentication issue. Please verify your WooCommerce API credentials.');
        }
        throw error;
      }
      throw new WooCommerceApiError('Failed to fetch orders', 0, 'ORDERS_ERROR');
    }
  }

  async getOrder(orderId: number) {
    try {
      return await this.makeRequest(`orders/${orderId}`);
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError(`Failed to fetch order ${orderId}`, 0, 'ORDER_ERROR');
    }
  }

  async createOrder(orderData: OrderData) {
    try {
      return await this.makeRequest('orders', {
        method: 'POST',
        data: orderData
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to create order', 0, 'CREATE_ORDER_ERROR');
    }
  }

  async updateOrder(orderId: number, orderData: Partial<OrderData>) {
    try {
      return await this.makeRequest(`orders/${orderId}`, {
        method: 'PUT',
        data: orderData
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError(`Failed to update order ${orderId}`, 0, 'UPDATE_ORDER_ERROR');
    }
  }

  async deleteOrder(orderId: number, force: boolean = false) {
    try {
      return await this.makeRequest(`orders/${orderId}`, {
        method: 'DELETE',
        params: { force }
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError(`Failed to delete order ${orderId}`, 0, 'DELETE_ORDER_ERROR');
    }
  }

  async updateOrderStatus(orderId: number, status: string) {
    return this.updateOrder(orderId, { status: status as any });
  }

  // CUSTOMERS API METHODS
  
  async getCustomers(params: Record<string, any> = {}) {
    const defaultParams = {
      per_page: 20,
      orderby: 'registered_date',
      order: 'desc',
      ...params
    };
    
    try {
      return await this.makeRequest('customers', { params: defaultParams });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to fetch customers', 0, 'CUSTOMERS_ERROR');
    }
  }

  async getCustomer(customerId: number) {
    try {
      return await this.makeRequest(`customers/${customerId}`);
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError(`Failed to fetch customer ${customerId}`, 0, 'CUSTOMER_ERROR');
    }
  }

  async createCustomer(customerData: CustomerData) {
    try {
      return await this.makeRequest('customers', {
        method: 'POST',
        data: customerData
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to create customer', 0, 'CREATE_CUSTOMER_ERROR');
    }
  }

  async updateCustomer(customerId: number, customerData: Partial<CustomerData>) {
    try {
      return await this.makeRequest(`customers/${customerId}`, {
        method: 'PUT',
        data: customerData
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError(`Failed to update customer ${customerId}`, 0, 'UPDATE_CUSTOMER_ERROR');
    }
  }

  async deleteCustomer(customerId: number, force: boolean = false, reassign?: number) {
    const params: any = { force };
    if (reassign) params.reassign = reassign;
    
    try {
      return await this.makeRequest(`customers/${customerId}`, {
        method: 'DELETE',
        params
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError(`Failed to delete customer ${customerId}`, 0, 'DELETE_CUSTOMER_ERROR');
    }
  }

  // CATEGORIES API METHODS
  
  async getProductCategories(params: Record<string, any> = {}) {
    try {
      return await this.makeRequest('products/categories', { params });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to fetch product categories', 0, 'CATEGORIES_ERROR');
    }
  }

  async getProductCategory(categoryId: number) {
    try {
      return await this.makeRequest(`products/categories/${categoryId}`);
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError(`Failed to fetch category ${categoryId}`, 0, 'CATEGORY_ERROR');
    }
  }

  async createProductCategory(categoryData: any) {
    try {
      return await this.makeRequest('products/categories', {
        method: 'POST',
        data: categoryData
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to create product category', 0, 'CREATE_CATEGORY_ERROR');
    }
  }

  // SYSTEM HEALTH AND CONNECTION TESTING
  
  async testConnection(): Promise<{ isConnected: boolean; error?: string; latency?: number; details?: any }> {
    try {
      const startTime = Date.now();
      console.log('🔍 Testing WooCommerce API connection...');
      
      // Test basic connection with a simple API call
      const response = await this.makeRequest('', { timeout: 8000 });
      const latency = Date.now() - startTime;
      
      console.log(`✅ WooCommerce connection test successful (${latency}ms)`);
      return { 
        isConnected: true, 
        latency,
        details: {
          baseUrl: ELITEQ_BASE_URL,
          apiUrl: WOOCOMMERCE_BASE_URL,
          consumerKeyPreview: `${this.credentials.consumer_key.substring(0, 10)}...`,
          timestamp: new Date().toISOString()
        }
      };
    } catch (error) {
      console.error('❌ WooCommerce connection test failed:', error);
      
      if (error instanceof WooCommerceApiError) {
        return { 
          isConnected: false, 
          error: error.message,
          details: {
            status: error.status,
            code: error.code,
            baseUrl: ELITEQ_BASE_URL,
            apiUrl: WOOCOMMERCE_BASE_URL,
            timestamp: new Date().toISOString()
          }
        };
      }
      
      return { 
        isConnected: false, 
        error: 'Unknown connection error',
        details: {
          baseUrl: ELITEQ_BASE_URL,
          apiUrl: WOOCOMMERCE_BASE_URL,
          timestamp: new Date().toISOString()
        }
      };
    }
  }

  async getSystemStatus() {
    try {
      return await this.makeRequest('system_status');
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to get system status', 0, 'SYSTEM_STATUS_ERROR');
    }
  }

  // SEARCH AND FILTERING with Error Handling
  
  async searchProducts(query: string, params: Record<string, any> = {}) {
    try {
      return await this.getProducts({
        search: query,
        ...params
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to search products', 0, 'SEARCH_PRODUCTS_ERROR');
    }
  }

  async searchOrders(query: string, params: Record<string, any> = {}) {
    try {
      return await this.getOrders({
        search: query,
        ...params
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to search orders', 0, 'SEARCH_ORDERS_ERROR');
    }
  }

  async searchCustomers(query: string, params: Record<string, any> = {}) {
    try {
      return await this.getCustomers({
        search: query,
        ...params
      });
    } catch (error) {
      if (error instanceof WooCommerceApiError) {
        throw error;
      }
      throw new WooCommerceApiError('Failed to search customers', 0, 'SEARCH_CUSTOMERS_ERROR');
    }
  }

  // Get current credentials (for debugging)
  getCredentials() {
    return {
      consumer_key: this.credentials.consumer_key.substring(0, 10) + '...',
      consumer_secret: this.credentials.consumer_secret.substring(0, 10) + '...',
      baseUrl: this.baseUrl
    };
  }
}

// Create and export singleton instance
export const wooCommerceApi = new WooCommerceAPI();

// Export types for use in components
export type {
  ProductData,
  OrderData,
  CustomerData,
  WooCommerceApiResponse,
  WooCommerceRequestOptions
};

// Export error class
export { WooCommerceApiError };

// Export configuration for debugging
export const wooCommerceConfig = {
  baseUrl: ELITEQ_BASE_URL,
  apiUrl: WOOCOMMERCE_BASE_URL,
  getCredentials: () => {
    try {
      const creds = getWooCommerceCredentials();
      return {
        consumer_key: creds.consumer_key.substring(0, 10) + '...',
        consumer_secret: creds.consumer_secret.substring(0, 10) + '...'
      };
    } catch (error) {
      return {
        consumer_key: 'ERROR: Not configured',
        consumer_secret: 'ERROR: Not configured'
      };
    }
  }
};

// Helper functions for common operations
export const wooCommerceHelpers = {
  // Format currency for Indian market
  formatCurrency: (amount: number | string): string => {
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 2
    }).format(numAmount);
  },

  // Format date for Indian timezone
  formatDate: (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  },

  // Get status color for orders
  getOrderStatusColor: (status: string): string => {
    const statusColors: Record<string, string> = {
      'pending': 'bg-yellow-100 text-yellow-800',
      'processing': 'bg-blue-100 text-blue-800',
      'on-hold': 'bg-orange-100 text-orange-800',
      'completed': 'bg-green-100 text-green-800',
      'cancelled': 'bg-red-100 text-red-800',
      'refunded': 'bg-purple-100 text-purple-800',
      'failed': 'bg-gray-100 text-gray-800'
    };
    return statusColors[status] || 'bg-gray-100 text-gray-800';
  },

  // Get stock status color
  getStockStatusColor: (status: string, quantity?: number): string => {
    if (status === 'outofstock') return 'text-red-600';
    if (status === 'onbackorder') return 'text-orange-600';
    if (quantity !== undefined && quantity < 10) return 'text-yellow-600';
    return 'text-green-600';
  },

  // Check if error is recoverable
  isRecoverableError: (error: any): boolean => {
    if (error instanceof WooCommerceApiError) {
      return ['NETWORK_ERROR', 'TIMEOUT_ERROR', 'SERVICE_UNAVAILABLE'].includes(error.code);
    }
    return false;
  },

  // Check if error is authentication related
  isAuthError: (error: any): boolean => {
    if (error instanceof WooCommerceApiError) {
      return error.status === 401 || error.code === 'UNAUTHORIZED';
    }
    return false;
  }
};