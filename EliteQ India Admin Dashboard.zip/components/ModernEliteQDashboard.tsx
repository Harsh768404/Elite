import React, { useState, useEffect } from 'react';
import { Bell, Menu, Moon, Sun, Shield, Zap, User, Settings, HelpCircle, LogOut, ChevronDown } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
} from './ui/dropdown-menu';
import { EliteQIndiaLogo } from './EliteQIndiaLogo';
import { EliteQComprehensiveSidebar } from './EliteQComprehensiveSidebar';
import { EliteQWelcomeBanner } from './EliteQWelcomeBanner';
import { EliteQOverviewSection } from './EliteQOverviewSection';
import { PerformanceOverviewSection } from './PerformanceOverviewSection';
import { OrderStatusOverviewSection } from './OrderStatusOverviewSection';
import { EliteQAnalyticsCharts } from './EliteQAnalyticsCharts';
import { EliteQPaymentOverviewTable } from './EliteQPaymentOverviewTable';
import NetworkStatusIndicator from './NetworkStatusIndicator';
import { EliteQErrorFallback } from './EliteQErrorFallback';
import { SystemStatusBanner } from './SystemStatusBanner';
import { useAuth } from '../contexts/AuthContext';

interface ModernEliteQDashboardProps {
  userRole?: 'admin' | 'vendor';
}

export function ModernEliteQDashboard({ userRole = 'admin' }: ModernEliteQDashboardProps) {
  // Get real user data from AuthContext
  const { user, logout, getDisplayName, getAvatarUrl, isAdmin, isVendor } = useAuth();
  
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [notificationCount] = useState(3);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Determine user role based on real authentication data
  const resolvedUserRole = isAdmin ? 'admin' : isVendor ? 'vendor' : userRole;

  console.log('🎨 ===== MODERN ELITEQ DASHBOARD WITH REAL DATA =====');
  console.log('👤 Real User Data:', user);
  console.log('🎭 Resolved User Role:', resolvedUserRole);
  console.log('🔺 isAdmin:', isAdmin);
  console.log('🏪 isVendor:', isVendor);
  console.log('📧 User Email:', user?.email);
  console.log('🎯 User Roles:', user?.roles);

  // Only support Admin and Vendor roles - reject others
  if (!user || (!isAdmin && !isVendor)) {
    console.log('🚫 ===== UNSUPPORTED ROLE - REDIRECTING =====');
    console.log('👤 User:', user);
    console.log('🎭 Required roles: administrator or vendor');
    console.log('🔐 User has admin access:', isAdmin);
    console.log('🏪 User has vendor access:', isVendor);
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 dark:from-gray-900 dark:to-red-900/20 flex items-center justify-center p-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-red-600 dark:text-red-400" />
          </div>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
            Dashboard Access Restricted
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            This dashboard only supports Administrator and Vendor roles.
          </p>
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 mb-6 text-left">
            <div className="text-sm space-y-1">
              <div><strong>Your Email:</strong> {user?.email || 'Unknown'}</div>
              <div><strong>Your Roles:</strong> {user?.roles?.join(', ') || 'None'}</div>
              <div><strong>Primary Role:</strong> {user?.primary_role || 'Unknown'}</div>
              <div><strong>Supported Roles:</strong> Administrator, Vendor</div>
            </div>
          </div>
          <Button onClick={() => window.location.href = '/account-dashboard'}>
            Go to Account Dashboard
          </Button>
        </div>
      </div>
    );
  }

  // Get real user data from WordPress
  const realUserData = {
    id: user.id,
    name: getDisplayName(),
    email: user.email,
    avatar: getAvatarUrl(),
    role: resolvedUserRole,
    roleDisplay: isAdmin ? 'Administrator' : 'Vendor',
    isVerified: user.isRealData || false,
    lastLogin: user.authenticated_at ? new Date(user.authenticated_at).toLocaleString() : 'Recently',
    capabilities: user.capabilities || {},
    roles: user.roles || []
  };

  console.log('📊 ===== REAL USER DATA MAPPED FOR DASHBOARD =====');
  console.log('👤 Display Name:', realUserData.name);
  console.log('📧 Email:', realUserData.email);
  console.log('🎭 Role Display:', realUserData.roleDisplay);
  console.log('✅ Is Verified:', realUserData.isVerified);
  console.log('🕐 Last Login:', realUserData.lastLogin);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  const getInitials = (name: string): string => {
    if (!name) return 'U';
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getTrustBadges = () => {
    if (resolvedUserRole === 'admin') {
      return [
        { icon: Shield, label: 'Admin Access', color: 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400' },
        { icon: Zap, label: 'Full Control', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400' }
      ];
    } else {
      return [
        { icon: Shield, label: 'Verified Vendor', color: 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' },
        { icon: Zap, label: 'Vendor Dashboard', color: 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400' }
      ];
    }
  };

  const handleLogout = () => {
    console.log('🚪 User logging out from dashboard - using real logout');
    logout();
  };

  const handleProfileSettings = () => {
    console.log('⚙️ Opening profile settings - navigating to account dashboard');
    window.location.href = '/account-dashboard';
  };

  const handleSupport = (type: string) => {
    console.log(`📞 Opening support: ${type}`);
    // Real support implementation would go here
    alert(`${type} support would open here - integrate with your support system`);
  };

  return (
    <div className={`min-h-screen bg-gray-50 dark:bg-gray-900 ${darkMode ? 'dark' : ''}`}>
      {/* Header section with real user data */}
      <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50 shadow-sm">
        <div className="flex items-center justify-between px-4 h-16">
          {/* Left side - Logo, Menu, and Title */}
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleSidebar}
              className="lg:hidden hover:bg-blue-50 dark:hover:bg-blue-900/20"
            >
              <Menu className="h-5 w-5" />
            </Button>
            
            <div className="flex items-center space-x-3">
              <div className="relative">
                <EliteQIndiaLogo size="sm" variant="icon" className="h-8 w-8" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white dark:border-gray-900 rounded-full animate-pulse"></div>
              </div>
              <div className="hidden sm:block">
                <h1 className="text-lg font-semibold text-gray-900 dark:text-white">
                  EliteQ India
                </h1>
                <p className="text-sm text-blue-600 dark:text-blue-400 font-medium">
                  {resolvedUserRole === 'admin' ? 'Admin Control Panel' : 'Vendor Dashboard'}
                </p>
              </div>
            </div>

            {/* Trust Badges in Header */}
            <div className="hidden lg:flex items-center space-x-2 ml-4">
              {getTrustBadges().map((badge, index) => {
                const Icon = badge.icon;
                return (
                  <Badge key={index} variant="secondary" className={`text-xs ${badge.color} border-0`}>
                    <Icon className="w-3 h-3 mr-1" />
                    {badge.label}
                  </Badge>
                );
              })}
            </div>
          </div>

          {/* Right side - Time, Network Status, Notifications, Dark Mode, and User Profile */}
          <div className="flex items-center space-x-3">
            {/* Current Time */}
            <div className="hidden md:flex items-center text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
              {currentTime.toLocaleTimeString('en-IN', { 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: true 
              })}
            </div>

            {/* Network Status Indicator */}
            <NetworkStatusIndicator />

            {/* Notification Bell */}
            <Button
              variant="ghost"
              size="sm"
              className="relative hover:bg-blue-50 dark:hover:bg-blue-900/20"
            >
              <Bell className="h-5 w-5 text-gray-600 dark:text-gray-400" />
              {notificationCount > 0 && (
                <>
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs animate-pulse"
                  >
                    {notificationCount}
                  </Badge>
                  <div className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 rounded-full animate-ping opacity-75"></div>
                </>
              )}
            </Button>

            {/* Dark Mode Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleDarkMode}
              className="hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              {darkMode ? (
                <Sun className="h-5 w-5 text-yellow-500" />
              ) : (
                <Moon className="h-5 w-5 text-gray-600" />
              )}
            </Button>

            {/* User Profile Avatar Dropdown with Real Data */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  className="flex items-center space-x-2 p-2 h-auto hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors rounded-lg"
                >
                  <Avatar className="h-8 w-8 ring-2 ring-blue-500/20">
                    <AvatarImage 
                      src={realUserData.avatar || undefined} 
                      alt={realUserData.name}
                      className="object-cover"
                    />
                    <AvatarFallback className="bg-gradient-to-br from-blue-600 to-blue-700 text-white text-sm font-medium">
                      {getInitials(realUserData.name)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="hidden lg:flex lg:flex-col lg:items-start lg:text-left">
                    <div className="text-sm font-medium text-gray-900 dark:text-white leading-none">
                      {realUserData.name}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400 leading-none mt-0.5">
                      {realUserData.roleDisplay}
                    </div>
                  </div>
                  
                  <ChevronDown className="h-4 w-4 text-gray-500 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              
              <DropdownMenuContent align="end" className="w-80 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-xl">
                {/* User Info Header with Real Data */}
                <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700">
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-12 w-12 ring-2 ring-blue-500/20">
                      <AvatarImage 
                        src={realUserData.avatar || undefined} 
                        alt={realUserData.name}
                        className="object-cover"
                      />
                      <AvatarFallback className="bg-gradient-to-br from-blue-600 to-blue-700 text-white font-medium">
                        {getInitials(realUserData.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-gray-900 dark:text-white truncate">
                        {realUserData.name}
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400 truncate">
                        {realUserData.email}
                      </div>
                      <div className="mt-1 flex items-center space-x-1">
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${
                            resolvedUserRole === 'admin' 
                              ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400 border-red-200' 
                              : 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400 border-green-200'
                          }`}
                        >
                          <Shield className="w-3 h-3 mr-1" />
                          {realUserData.roleDisplay}
                        </Badge>
                        {realUserData.isVerified && (
                          <Badge variant="outline" className="text-xs bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400 border-blue-200">
                            ✓ Verified
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Menu Items */}
                <div className="py-1">
                  <DropdownMenuItem 
                    onClick={handleProfileSettings}
                    className="flex items-center space-x-2 px-4 py-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 profile-dropdown-item"
                  >
                    <User className="h-4 w-4" />
                    <span>Profile Settings</span>
                  </DropdownMenuItem>
                  
                  <DropdownMenuItem className="flex items-center space-x-2 px-4 py-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 profile-dropdown-item">
                    <Settings className="h-4 w-4" />
                    <span>Account Settings</span>
                  </DropdownMenuItem>
                  
                  {/* Support Submenu */}
                  <DropdownMenuSub>
                    <DropdownMenuSubTrigger className="flex items-center space-x-2 px-4 py-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 profile-dropdown-item">
                      <HelpCircle className="h-4 w-4" />
                      <span>Support</span>
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent className="w-56 support-submenu">
                      <DropdownMenuItem 
                        onClick={() => handleSupport('Live Chat')}
                        className="cursor-pointer"
                      >
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span>Live Chat Support</span>
                        </div>
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleSupport('Email')}
                        className="cursor-pointer"
                      >
                        Email Support
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleSupport('Phone')}
                        className="cursor-pointer"
                      >
                        Phone Support
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleSupport('Documentation')}
                        className="cursor-pointer"
                      >
                        Help Documentation
                      </DropdownMenuItem>
                    </DropdownMenuSubContent>
                  </DropdownMenuSub>
                </div>

                <DropdownMenuSeparator className="bg-gray-200 dark:bg-gray-700" />

                {/* User Details Section with Real Data */}
                <div className="px-4 py-2 bg-gray-50 dark:bg-gray-800/50">
                  <div className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
                    <div className="flex justify-between">
                      <span>User ID:</span>
                      <span className="font-mono">#{realUserData.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Role:</span>
                      <span className="font-medium">{realUserData.roleDisplay}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>WordPress Roles:</span>
                      <span className="font-medium text-xs">{realUserData.roles.join(', ')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Last Login:</span>
                      <span className="font-medium">{realUserData.lastLogin}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <div className="flex items-center space-x-1">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-green-600 dark:text-green-400">Online</span>
                      </div>
                    </div>
                  </div>
                </div>

                <DropdownMenuSeparator className="bg-gray-200 dark:bg-gray-700" />

                {/* Logout */}
                <div className="py-1">
                  <DropdownMenuItem 
                    onClick={handleLogout}
                    className="flex items-center space-x-2 px-4 py-2 cursor-pointer text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20 profile-dropdown-item"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Sign Out</span>
                  </DropdownMenuItem>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar with resolved user role */}
        <EliteQComprehensiveSidebar 
          collapsed={sidebarCollapsed}
          userRole={resolvedUserRole}
          onToggle={toggleSidebar}
        />

        {/* Main Dashboard Area */}
        <main className={`flex-1 transition-all duration-300 ${
          sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64'
        }`}>
          <div className="p-6 space-y-6 max-w-7xl mx-auto">
            {/* System Status Banner */}
            <SystemStatusBanner />

            {/* Welcome Banner with real user data */}
            <EliteQWelcomeBanner 
              userRole={resolvedUserRole}
              userName={realUserData.name}
              isVerified={realUserData.isVerified}
            />

            {/* Overview Section with real user role */}
            <EliteQOverviewSection userRole={resolvedUserRole} />

            {/* Performance Overview Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center space-x-2">
                  <div className="w-1 h-6 bg-blue-500 rounded-full"></div>
                  <span>Performance Metrics</span>
                </h2>
                <Badge variant="outline" className="text-xs">
                  Real-time Data
                </Badge>
              </div>
              <PerformanceOverviewSection userRole={resolvedUserRole} />
            </div>

            {/* Order Status Overview Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center space-x-2">
                  <div className="w-1 h-6 bg-green-500 rounded-full"></div>
                  <span>Order Management</span>
                </h2>
                <Badge variant="outline" className="text-xs">
                  Live Updates
                </Badge>
              </div>
              <OrderStatusOverviewSection userRole={resolvedUserRole} />
            </div>

            {/* Analytics section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center space-x-2">
                  <div className="w-1 h-6 bg-purple-500 rounded-full"></div>
                  <span>Analytics & Insights</span>
                </h2>
                <Badge variant="outline" className="text-xs">
                  Aug 1-3, 2025
                </Badge>
              </div>
              <EliteQAnalyticsCharts userRole={resolvedUserRole} />
            </div>

            {/* Payment section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center space-x-2">
                  <div className="w-1 h-6 bg-orange-500 rounded-full"></div>
                  <span>Payment Transactions</span>
                </h2>
                <Badge variant="outline" className="text-xs">
                  All Payment Methods
                </Badge>
              </div>
              <EliteQPaymentOverviewTable userRole={resolvedUserRole} />
            </div>

            {/* Footer section */}
            <div className="mt-12 pt-8 border-t border-gray-200 dark:border-gray-700">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Security Badge */}
                <div className="flex items-center space-x-3 p-4 bg-green-50 dark:bg-green-900/10 rounded-lg border border-green-200 dark:border-green-800">
                  <Shield className="w-8 h-8 text-green-600 dark:text-green-400" />
                  <div>
                    <p className="text-sm font-medium text-green-900 dark:text-green-100">
                      Secure Connection
                    </p>
                    <p className="text-xs text-green-700 dark:text-green-400">
                      256-bit SSL encryption active
                    </p>
                  </div>
                </div>

                {/* Trust Badge */}
                <div className="flex items-center space-x-3 p-4 bg-blue-50 dark:bg-blue-900/10 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">✓</span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-blue-900 dark:text-blue-100">
                      {resolvedUserRole === 'admin' ? 'Admin Verified' : 'Vendor Verified'}
                    </p>
                    <p className="text-xs text-blue-700 dark:text-blue-400">
                      EliteQ India certified
                    </p>
                  </div>
                </div>

                {/* System Status */}
                <div className="flex items-center space-x-3 p-4 bg-purple-50 dark:bg-purple-900/10 rounded-lg border border-purple-200 dark:border-purple-800">
                  <Zap className="w-8 h-8 text-purple-600 dark:text-purple-400" />
                  <div>
                    <p className="text-sm font-medium text-purple-900 dark:text-purple-100">
                      System Healthy
                    </p>
                    <p className="text-xs text-purple-700 dark:text-purple-400">
                      All services operational
                    </p>
                  </div>
                </div>
              </div>

              {/* Copyright */}
              <div className="mt-6 text-center text-xs text-gray-500 dark:text-gray-400">
                © 2025 EliteQ India - Trusted Electronics Marketplace. All rights reserved.
                <span className="ml-2">|</span>
                <span className="ml-2">WordPress + WooCommerce + Dokan Pro</span>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}