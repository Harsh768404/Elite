import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, AlertTriangle, CheckCircle, Clock, RefreshCw, Server, Globe } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { networkManager } from '../utils/network-connectivity-manager';
import { gracefulErrorHandler } from '../utils/graceful-error-handler';
import { cn } from './ui/utils';

interface NetworkStatus {
  isOnline: boolean;
  isWordPressReachable: boolean;
  isWooCommerceReachable: boolean;
  latency: number;
  lastChecked: Date;
  errorCount: number;
  consecutiveFailures: number;
}

interface NetworkStatusIndicatorProps {
  variant?: 'default' | 'compact' | 'banner';
  className?: string;
}

function NetworkStatusIndicator({ variant = 'default', className }: NetworkStatusIndicatorProps) {
  const [networkStatus, setNetworkStatus] = useState<NetworkStatus>({
    isOnline: navigator.onLine,
    isWordPressReachable: false,
    isWooCommerceReachable: false,
    latency: 0,
    lastChecked: new Date(),
    errorCount: 0,
    consecutiveFailures: 0
  });

  const [expanded, setExpanded] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [systemHealth, setSystemHealth] = useState(gracefulErrorHandler.getSystemHealth());
  const [errorSummary, setErrorSummary] = useState(gracefulErrorHandler.getErrorSummary());

  useEffect(() => {
    // Get initial network status with error handling
    try {
      const initialStatus = networkManager.getConnectionStatus();
      setNetworkStatus(initialStatus);
    } catch (error) {
      console.warn('Failed to get initial network status:', error);
    }

    // Listen for network status changes from the network manager
    let unsubscribe: (() => void) | undefined;
    try {
      unsubscribe = networkManager.onStatusChange((status) => {
        setNetworkStatus(status);
        setSystemHealth(gracefulErrorHandler.getSystemHealth());
        setErrorSummary(gracefulErrorHandler.getErrorSummary());
      });
    } catch (error) {
      console.warn('Failed to subscribe to network status changes:', error);
    }

    // Update system health and error summary periodically
    const healthInterval = setInterval(() => {
      setSystemHealth(gracefulErrorHandler.getSystemHealth());
      setErrorSummary(gracefulErrorHandler.getErrorSummary());
    }, 10000); // Every 10 seconds

    // Listen for browser online/offline events
    const handleOnline = () => {
      setNetworkStatus(prev => ({ ...prev, isOnline: true }));
    };

    const handleOffline = () => {
      setNetworkStatus(prev => ({ ...prev, isOnline: false }));
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      if (unsubscribe) {
        try {
          unsubscribe();
        } catch (error) {
          console.warn('Error unsubscribing from network status:', error);
        }
      }
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(healthInterval);
    };
  }, []);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await networkManager.testConnection();
      // Clear suppressed errors after successful connection test
      gracefulErrorHandler.clearSuppressedErrors();
    } catch (error) {
      console.warn('Network test failed:', error);
    }
    setIsRefreshing(false);
  };

  const getStatusColor = () => {
    if (systemHealth.status === 'critical') return 'bg-red-500';
    if (systemHealth.status === 'degraded') return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getStatusIcon = () => {
    if (systemHealth.status === 'critical') {
      return networkStatus.isOnline ? <Server className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />;
    }
    if (systemHealth.status === 'degraded') return <AlertTriangle className="w-4 h-4" />;
    return <CheckCircle className="w-4 h-4" />;
  };

  const getStatusText = () => {
    if (systemHealth.status === 'critical') {
      return networkStatus.isOnline ? 'Server Issues' : 'Offline';
    }
    if (systemHealth.status === 'degraded') return 'Degraded';
    return 'Online';
  };

  const getConnectionQuality = () => {
    return networkManager.getConnectionQuality();
  };

  const getLatencyColor = (latency: number) => {
    if (latency < 300) return 'text-green-600 dark:text-green-400';
    if (latency < 800) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getQualityBadgeVariant = (quality: string) => {
    switch (quality) {
      case 'excellent': return 'default';
      case 'good': return 'secondary';
      case 'poor': return 'destructive';
      case 'offline': return 'destructive';
      default: return 'secondary';
    }
  };

  // Handle different variants
  if (variant === 'compact') {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        <div className={`w-2 h-2 rounded-full ${getStatusColor()}`}></div>
        <span className="text-xs text-gray-600 dark:text-gray-400">
          {getStatusText()}
        </span>
      </div>
    );
  }

  if (variant === 'banner') {
    // Return null for banner variant as we have SystemStatusBanner component for this
    return null;
  }

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
        title={`Network Status: ${systemHealth.message}`}
      >
        <div className={`w-2 h-2 rounded-full ${getStatusColor()} animate-pulse`}></div>
        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
          {getStatusText()}
        </span>
        {getStatusIcon()}
      </button>

      {expanded && (
        <div className="absolute top-full right-0 mt-2 w-96 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 p-4 z-50">
          <div className="space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white flex items-center space-x-2">
                <Globe className="w-4 h-4" />
                <span>Network Status</span>
              </h3>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="text-xs">
                  Live
                </Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                  className="h-6 w-6 p-0"
                >
                  <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : ''}`} />
                </Button>
              </div>
            </div>

            {/* System Health Overview */}
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-900 dark:text-white">System Health</span>
                <Badge variant={systemHealth.status === 'healthy' ? 'default' : systemHealth.status === 'degraded' ? 'secondary' : 'destructive'}>
                  {systemHealth.status}
                </Badge>
              </div>
              <p className="text-xs text-gray-600 dark:text-gray-400">
                {systemHealth.message}
              </p>
            </div>

            {/* Connection Quality */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Connection Quality</span>
                <Badge variant={getQualityBadgeVariant(getConnectionQuality())}>
                  {getConnectionQuality()}
                </Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Latency</span>
                <span className={`text-sm font-medium ${getLatencyColor(networkStatus.latency)}`}>
                  {Math.round(networkStatus.latency)}ms
                </span>
              </div>
            </div>

            {/* Service Status */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                Services
              </h4>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-900 rounded">
                  <div className="flex items-center space-x-2">
                    <Wifi className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">Internet Connection</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className={`w-2 h-2 rounded-full ${networkStatus.isOnline ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className="text-xs font-medium">
                      {networkStatus.isOnline ? 'Online' : 'Offline'}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-900 rounded">
                  <div className="flex items-center space-x-2">
                    <Server className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">WordPress API</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className={`w-2 h-2 rounded-full ${networkStatus.isWordPressReachable ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className="text-xs font-medium">
                      {networkStatus.isWordPressReachable ? 'Reachable' : 'Unreachable'}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-900 rounded">
                  <div className="flex items-center space-x-2">
                    <Server className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">WooCommerce API</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className={`w-2 h-2 rounded-full ${networkStatus.isWooCommerceReachable ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className="text-xs font-medium">
                      {networkStatus.isWooCommerceReachable ? 'Reachable' : 'Unreachable'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Error Summary */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                Error Summary
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Network Errors:</span>
                  <span className="font-medium">{errorSummary.networkErrors}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Permission Errors:</span>
                  <span className="font-medium">{errorSummary.permissionErrors}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Server Errors:</span>
                  <span className="font-medium">{errorSummary.serverErrors}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Recent (5min):</span>
                  <span className="font-medium">{errorSummary.recentErrors}</span>
                </div>
              </div>
            </div>

            {/* Connection Issues Warning */}
            {(networkStatus.consecutiveFailures > 0 || errorSummary.recentErrors > 5) && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                <div className="flex items-start space-x-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-medium text-yellow-800 dark:text-yellow-200">
                      Connection Issues Detected
                    </p>
                    <p className="text-xs text-yellow-700 dark:text-yellow-300 mt-1">
                      Dashboard is using fallback data. Functionality may be limited.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Last Checked */}
            <div className="pt-2 border-t border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500 dark:text-gray-400">Last checked</span>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {networkStatus.lastChecked.toLocaleTimeString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default NetworkStatusIndicator;
export { NetworkStatusIndicator };