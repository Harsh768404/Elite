import React, { useEffect, useState } from 'react';
import { Shield, AlertCircle, Loader2, CheckCircle, ArrowRight } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface RouteGuardProps {
  children: React.ReactNode;
  requiredRole?: 'admin' | 'vendor' | 'user';
  redirectTo?: string;
  showUnauthorized?: boolean;
}

export const RouteGuard: React.FC<RouteGuardProps> = ({
  children,
  requiredRole,
  redirectTo,
  showUnauthorized = true,
}) => {
  const { isAuthenticated, isLoading, user, dashboardRole, hasRole } = useAuth();
  const [redirecting, setRedirecting] = useState(false);

  useEffect(() => {
    const checkAuthAndRedirect = async () => {
      // Wait for auth to finish loading
      if (isLoading) return;

      console.log('🛡️ ===== ROUTE GUARD CHECK =====');
      console.log('👤 Authenticated:', isAuthenticated);
      console.log('🎭 Dashboard Role:', dashboardRole);
      console.log('🎯 Mapped Role:', user?.role);
      console.log('🔐 Required Role:', requiredRole);
      console.log('👤 User:', user?.username);

      // Not authenticated - redirect to login
      if (!isAuthenticated || !user || !dashboardRole) {
        console.log('❌ Not authenticated, redirecting to login');
        setRedirecting(true);
        setTimeout(() => {
          window.location.href = '/';
        }, 1000);
        return;
      }

      // Check role-based access using the new mapping system
      if (requiredRole) {
        let hasAccess = false;

        // Use the hasRole function which checks both mapped role and dashboard role
        hasAccess = hasRole(requiredRole);

        console.log('🔍 Access check result:', hasAccess);
        console.log('📋 Access details:', {
          requiredRole,
          userMappedRole: user.role,
          userDashboardRole: dashboardRole,
          hasAccess
        });

        if (!hasAccess) {
          console.log('❌ Insufficient permissions');
          
          if (redirectTo) {
            console.log('🔄 Redirecting to:', redirectTo);
            setRedirecting(true);
            setTimeout(() => {
              window.location.href = redirectTo;
            }, 1500);
            return;
          }
          
          // If no redirect specified, show unauthorized message
          return;
        }
      }

      console.log('✅ Route guard passed');
    };

    checkAuthAndRedirect();
  }, [isAuthenticated, isLoading, dashboardRole, requiredRole, redirectTo, user, hasRole]);

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center pb-4">
            <div className="flex justify-center mb-4">
              <Shield className="h-12 w-12 text-blue-600 animate-pulse" />
            </div>
            <CardTitle className="text-xl">Verifying Access</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div className="flex items-center justify-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
              <span className="text-gray-600 dark:text-gray-400">
                Checking authentication and mapping roles...
              </span>
            </div>
            <div className="text-sm text-gray-500 dark:text-gray-400">
              Reading JWT token and applying role mapping
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Redirecting state
  if (redirecting) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center pb-4">
            <div className="flex justify-center mb-4">
              <ArrowRight className="h-12 w-12 text-orange-600 animate-pulse" />
            </div>
            <CardTitle className="text-xl">Redirecting...</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div className="flex items-center justify-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin text-orange-600" />
              <span className="text-gray-600 dark:text-gray-400">
                {!isAuthenticated ? 'Redirecting to login...' : 'Redirecting to appropriate dashboard...'}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Not authenticated
  if (!isAuthenticated || !user || !dashboardRole) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center pb-4">
            <div className="flex justify-center mb-4">
              <AlertCircle className="h-12 w-12 text-red-600" />
            </div>
            <CardTitle className="text-xl text-red-600">Authentication Required</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-gray-600 dark:text-gray-400">
              You need to be logged in to access this page.
            </p>
            <Button 
              onClick={() => window.location.href = '/'}
              className="w-full"
            >
              Go to Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Role-based access check with enhanced role mapping support
  if (requiredRole) {
    const hasAccess = hasRole(requiredRole);

    if (!hasAccess && showUnauthorized) {
      return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
          <Card className="w-full max-w-lg">
            <CardHeader className="text-center pb-4">
              <div className="flex justify-center mb-4">
                <AlertCircle className="h-12 w-12 text-red-600" />
              </div>
              <CardTitle className="text-xl text-red-600">Access Denied</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  You don't have permission to access this page.
                </p>
                
                <div className="space-y-3">
                  <div className="text-sm">
                    <strong className="text-gray-900 dark:text-white">Your Access Level:</strong>
                    <div className="mt-1 space-y-1">
                      <div>
                        <Badge 
                          variant={user.role === 'admin' ? 'default' : 'secondary'} 
                          className="mr-2"
                        >
                          Mapped Role: {user.role}
                        </Badge>
                        <Badge 
                          variant={dashboardRole === 'admin' ? 'default' : 'secondary'} 
                          className="mr-2"
                        >
                          Dashboard: {dashboardRole}
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="text-sm">
                    <strong className="text-gray-900 dark:text-white">Required Access:</strong>
                    <div className="mt-1">
                      <Badge variant="outline" className="text-red-600 border-red-300">
                        {requiredRole === 'admin' ? 'Administrator' : 
                         requiredRole === 'vendor' ? 'Vendor' : 'User'} Only
                      </Badge>
                    </div>
                  </div>

                  <div className="text-sm">
                    <strong className="text-gray-900 dark:text-white">Your WordPress Roles:</strong>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {user.raw_roles.map(role => (
                        <Badge key={role} variant="outline" className="text-xs">
                          {role}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Role mapping explanation */}
                  <div className="text-xs text-gray-500 dark:text-gray-400 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <strong>Role Mapping:</strong><br/>
                    • administrator → admin<br/>
                    • seller, dokan_vendor, vendor → vendor<br/>
                    • user, customer, subscriber → user
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button 
                  onClick={() => window.history.back()}
                  variant="outline"
                  className="flex-1"
                >
                  Go Back
                </Button>
                <Button 
                  onClick={() => {
                    // Redirect to appropriate dashboard based on current role
                    const redirectPath = dashboardRole === 'admin' ? '/admin-dashboard' : '/vendor-dashboard';
                    window.location.href = redirectPath;
                  }}
                  className="flex-1"
                >
                  Go to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }
  }

  // All checks passed - render children
  return <>{children}</>;
};

// Convenience components for specific route protection with new role mapping
export const AdminRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <RouteGuard requiredRole="admin" redirectTo="/vendor-dashboard">
    {children}
  </RouteGuard>
);

export const VendorRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <RouteGuard requiredRole="vendor" redirectTo="/admin-dashboard">
    {children}
  </RouteGuard>
);

export const UserRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <RouteGuard requiredRole="user">
    {children}
  </RouteGuard>
);

export const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <RouteGuard>
    {children}
  </RouteGuard>
);