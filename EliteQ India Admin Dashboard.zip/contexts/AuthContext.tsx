import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { wordpressAPI } from '../utils/comprehensive-wordpress-api';
import { EnhancedRoleResolver } from '../utils/enhanced-role-resolver';

interface LoginCredentials {
  username: string;
  password: string;
}

interface AuthenticatedUser {
  id: number;
  username: string;
  email: string;
  display_name: string;
  first_name: string;
  last_name: string;
  avatar_url: string;
  roles: string[];
  primary_role: 'administrator' | 'vendor' | 'customer' | 'restricted';
  primary_role_display: string;
  dashboard_route: string;
  full_name: string;
  capabilities: { [key: string]: boolean };
  avatar_urls: { [key: string]: string };
  authenticated_at: string;
  token_expires_at?: string;
  isRealData: boolean;
  source: string;
}

interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  isInitializing: boolean;
  user: AuthenticatedUser | null;
  token: string | null;
  error: string | null;
}

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => void;
  clearError: () => void;
  refreshUser: () => Promise<void>;
  
  // Helper methods
  isAdmin: boolean;
  isVendor: boolean;
  isCustomer: boolean;
  hasAccess: boolean;
  hasRole: (role: string) => boolean;
  getDisplayName: () => string;
  getAvatarUrl: () => string;
  getDashboardRoute: () => string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

// Format role display name helper function for EliteQ marketplace
const formatRoleDisplay = (role: string): string => {
  switch (role) {
    case 'administrator':
      return 'Administrator';
    case 'vendor':
      return 'Vendor';
    case 'customer':
      return 'Customer';
    case 'restricted':
      return 'Restricted';
    default:
      return 'User';
  }
};

// ENHANCED: Role priority resolution for real EliteQ marketplace
const resolveUserPrimaryRole = (roles: string[]): {
  primary_role: 'administrator' | 'vendor' | 'customer' | 'restricted';
  dashboard_route: string;
} => {
  console.log('🎯 ===== RESOLVING PRIMARY ROLE FOR ELITEQ MARKETPLACE =====');
  console.log('🎭 Input roles array:', roles);
  
  if (!Array.isArray(roles) || roles.length === 0) {
    console.log('❌ No roles found, defaulting to restricted');
    return {
      primary_role: 'restricted',
      dashboard_route: '/login'
    };
  }
  
  // EliteQ-specific role priority (highest to lowest)
  
  // Priority 1: Administrator/Editor/Author (HIGHEST) - FIXED: Use 'administrator' not 'admin'
  if (roles.includes('administrator') || roles.includes('editor') || roles.includes('author')) {
    console.log('👑 PRIORITY 1: Administrator role found - ADMIN ACCESS');
    return {
      primary_role: 'administrator',
      dashboard_route: '/admin/dashboard'
    };
  }
  
  // Priority 2: Shop Manager - FIXED: Use 'administrator' not 'admin'
  if (roles.includes('shop_manager')) {
    console.log('🏢 PRIORITY 2: Shop Manager role found - ADMIN ACCESS');
    return {
      primary_role: 'administrator',
      dashboard_route: '/admin/dashboard'
    };
  }
  
  // Priority 3: Vendor/Seller (Dokan & WooCommerce vendors)
  if (roles.includes('seller') || 
      roles.includes('vendor') || 
      roles.includes('dokan_vendor') ||
      roles.includes('wcfm_vendor') ||
      roles.includes('wc_product_vendors_admin_vendor')) {
    console.log('🏪 PRIORITY 3: Vendor/Seller role found - VENDOR ACCESS');
    return {
      primary_role: 'vendor',
      dashboard_route: '/vendor/dashboard'
    };
  }
  
  // Priority 4: Customer/Subscriber
  if (roles.includes('customer') || roles.includes('subscriber')) {
    console.log('👤 PRIORITY 4: Customer/Subscriber role found - CUSTOMER ACCESS');
    return {
      primary_role: 'customer',
      dashboard_route: '/account/dashboard'
    };
  }
  
  // No valid access roles found
  console.log('❌ No valid access roles found - RESTRICTED');
  return {
    primary_role: 'restricted',
    dashboard_route: '/login'
  };
};

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    isLoading: false,
    isInitializing: true,
    user: null,
    token: null,
    error: null,
  });

  // Initialize authentication state with real EliteQ data
  useEffect(() => {
    const initializeAuth = async () => {
      console.log('🔄 ===== INITIALIZING REAL ELITEQ AUTHENTICATION =====');
      
      try {
        // Check for existing JWT token in localStorage
        const existingToken = localStorage.getItem('eliteq_jwt_token');
        const existingUserData = localStorage.getItem('eliteq_user_data');
        const existingRoles = localStorage.getItem('eliteq_user_roles');
        
        if (existingToken && existingUserData && existingRoles) {
          console.log('📱 Found existing EliteQ authentication data');
          
          try {
            // Validate token with real WordPress
            const isValid = await wordpressAPI.validateToken();
            
            if (isValid) {
              // Get fresh user data from real EliteQ.in
              const currentUser = await wordpressAPI.getCurrentUser();
              const userRoles = JSON.parse(existingRoles);
              
              console.log('✅ Real EliteQ authentication validated');
              console.log('👤 Real user data from EliteQ.in:', currentUser.name);
              console.log('🎭 Real user roles:', userRoles);
              
              // Resolve role with EliteQ-specific logic
              const roleResolution = resolveUserPrimaryRole(userRoles);
              
              const enhancedUser: AuthenticatedUser = {
                id: currentUser.id,
                username: currentUser.username || '',
                email: currentUser.email,
                display_name: currentUser.name || '',
                first_name: currentUser.first_name || '',
                last_name: currentUser.last_name || '',
                avatar_url: currentUser.avatar_urls?.['96'] || currentUser.avatar_urls?.['48'] || '',
                roles: userRoles,
                primary_role: roleResolution.primary_role,
                primary_role_display: formatRoleDisplay(roleResolution.primary_role),
                dashboard_route: roleResolution.dashboard_route,
                full_name: `${currentUser.first_name || ''} ${currentUser.last_name || ''}`.trim() || currentUser.name || currentUser.username || 'User',
                capabilities: currentUser.capabilities || {},
                avatar_urls: currentUser.avatar_urls || {},
                authenticated_at: new Date().toISOString(),
                isRealData: true,
                source: 'eliteq.in'
              };

              console.log('✅ ===== REAL ELITEQ AUTHENTICATION RESTORED =====');
              console.log('👤 User:', enhancedUser.display_name);
              console.log('📧 Email:', enhancedUser.email);
              console.log('🎭 Primary Role:', enhancedUser.primary_role);
              console.log('🎯 All Roles:', enhancedUser.roles);
              console.log('🧭 Dashboard Route:', enhancedUser.dashboard_route);
              console.log('🌐 Real Data Source:', enhancedUser.source);

              setAuthState({
                isAuthenticated: true,
                isLoading: false,
                isInitializing: false,
                user: enhancedUser,
                token: existingToken,
                error: null,
              });

              return;
            }
          } catch (validationError) {
            console.warn('⚠️ Token validation failed, clearing auth:', validationError);
            wordpressAPI.logout();
          }
        }
        
        console.log('📭 No valid existing authentication found');
        setAuthState(prev => ({
          ...prev,
          isInitializing: false,
        }));
        
      } catch (error) {
        console.error('❌ Real EliteQ auth initialization failed:', error);
        wordpressAPI.logout();
        setAuthState({
          isAuthenticated: false,
          isLoading: false,
          isInitializing: false,
          user: null,
          token: null,
          error: error instanceof Error ? error.message : 'Authentication initialization failed',
        });
      }
    };

    initializeAuth();
  }, []);

  // Enhanced login function with real EliteQ WordPress integration
  const login = async (credentials: LoginCredentials): Promise<void> => {
    console.log('🔐 ===== STARTING REAL ELITEQ LOGIN PROCESS =====');
    console.log('👤 Login attempt for:', credentials.username);
    console.log('🌐 Connecting to EliteQ.in WordPress...');

    setAuthState(prev => ({
      ...prev,
      isLoading: true,
      error: null,
    }));

    try {
      // Authenticate with real EliteQ WordPress
      const loginResult = await wordpressAPI.authenticate(credentials.username, credentials.password);
      
      console.log('✅ ===== REAL ELITEQ LOGIN SUCCESS =====');
      console.log('🔑 JWT Token received from EliteQ.in');
      console.log('👤 User authenticated:', loginResult.user?.name);
      console.log('🎭 User roles from EliteQ:', loginResult.user?.roles);

      // Use enhanced role resolver for real data
      const roleResolver = new EnhancedRoleResolver('https://eliteq.in', loginResult.token);
      const roleResult = await roleResolver.resolveUserRoles(loginResult.user?.id, loginResult);
      
      console.log('📊 ===== REAL ELITEQ ROLE RESOLUTION =====');
      console.log('🎭 Resolved roles:', roleResult.roles);
      console.log('👑 Primary role:', roleResult.primary_role);
      console.log('🧭 Dashboard route:', roleResult.dashboard_route);
      console.log('📊 Resolution method:', roleResult.resolution_method);
      console.log('🌐 Is real data:', roleResult.isRealData);

      // Get fresh user data from real EliteQ API
      const currentUser = await wordpressAPI.getCurrentUser();

      // Create authenticated user object with real EliteQ data
      const authenticatedUser: AuthenticatedUser = {
        id: currentUser.id,
        username: currentUser.username || loginResult.user?.user_login || '',
        email: currentUser.email || loginResult.user?.user_email || '',
        display_name: currentUser.name || loginResult.user?.display_name || '',
        first_name: currentUser.first_name || '',
        last_name: currentUser.last_name || '',
        avatar_url: currentUser.avatar_urls?.['96'] || currentUser.avatar_urls?.['48'] || '',
        roles: roleResult.roles,
        primary_role: roleResult.primary_role,
        primary_role_display: formatRoleDisplay(roleResult.primary_role),
        dashboard_route: roleResult.dashboard_route,
        full_name: `${currentUser.first_name || ''} ${currentUser.last_name || ''}`.trim() || currentUser.name || currentUser.username || 'User',
        capabilities: currentUser.capabilities || {},
        avatar_urls: currentUser.avatar_urls || {},
        authenticated_at: new Date().toISOString(),
        isRealData: roleResult.isRealData,
        source: 'eliteq.in'
      };

      console.log('🎉 ===== REAL ELITEQ LOGIN COMPLETE =====');
      console.log('👤 Final User:', authenticatedUser.display_name);
      console.log('📧 Final Email:', authenticatedUser.email);
      console.log('🎭 Final Primary Role:', authenticatedUser.primary_role);
      console.log('🎯 Final All Roles:', authenticatedUser.roles);
      console.log('🧭 Final Dashboard Route:', authenticatedUser.dashboard_route);
      console.log('🔐 Access Level:', authenticatedUser.primary_role !== 'restricted' ? 'GRANTED' : 'RESTRICTED');
      console.log('🌐 Real Data Source:', authenticatedUser.source);

      // Update auth state with real EliteQ user data
      setAuthState({
        isAuthenticated: true,
        isLoading: false,
        isInitializing: false,
        user: authenticatedUser,
        token: loginResult.token,
        error: null,
      });

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Login failed';
      console.error('❌ Real EliteQ login failed:', errorMessage);

      setAuthState({
        isAuthenticated: false,
        isLoading: false,
        isInitializing: false,
        user: null,
        token: null,
        error: errorMessage,
      });

      throw error;
    }
  };

  // Enhanced logout function
  const logout = (): void => {
    console.log('🚪 ===== ELITEQ LOGOUT INITIATED =====');
    
    setAuthState({
      isAuthenticated: false,
      isLoading: false,
      isInitializing: false,
      user: null,
      token: null,
      error: null,
    });

    wordpressAPI.logout();
    
    // Clear EliteQ-specific localStorage items
    if (typeof window !== 'undefined') {
      localStorage.removeItem('eliteq_jwt_token');
      localStorage.removeItem('eliteq_user_data');
      localStorage.removeItem('eliteq_user_roles');
      localStorage.removeItem('eliteq_primary_role');
      localStorage.removeItem('eliteq_dashboard_route');
      localStorage.removeItem('eliteq_vendor_info');
    }
    
    // Navigate to login page
    window.history.pushState({}, '', '/login');
    window.dispatchEvent(new PopStateEvent('popstate'));
    
    console.log('✅ EliteQ logout complete, redirected to login page');
  };

  // Clear error
  const clearError = (): void => {
    setAuthState(prev => ({
      ...prev,
      error: null,
    }));
  };

  // Refresh user data from real EliteQ
  const refreshUser = async (): Promise<void> => {
    if (!authState.isAuthenticated) {
      throw new Error('No authentication available');
    }

    console.log('🔄 Refreshing real EliteQ user data...');

    try {
      const currentUser = await wordpressAPI.getCurrentUser();
      const userRoles = JSON.parse(localStorage.getItem('eliteq_user_roles') || '[]');
      
      // Re-resolve role to ensure accuracy
      const roleResolution = resolveUserPrimaryRole(userRoles);
      
      const refreshedUser: AuthenticatedUser = {
        ...authState.user!,
        id: currentUser.id,
        username: currentUser.username || authState.user!.username,
        email: currentUser.email,
        display_name: currentUser.name || authState.user!.display_name,
        first_name: currentUser.first_name || '',
        last_name: currentUser.last_name || '',
        avatar_url: currentUser.avatar_urls?.['96'] || currentUser.avatar_urls?.['48'] || '',
        roles: userRoles,
        primary_role: roleResolution.primary_role,
        primary_role_display: formatRoleDisplay(roleResolution.primary_role),
        dashboard_route: roleResolution.dashboard_route,
        capabilities: currentUser.capabilities || {},
        avatar_urls: currentUser.avatar_urls || {},
        isRealData: true,
        source: 'eliteq.in'
      };
      
      setAuthState(prev => ({
        ...prev,
        user: refreshedUser,
      }));

      console.log('✅ Real EliteQ user data refreshed successfully');
    } catch (error) {
      console.error('❌ Failed to refresh real EliteQ user data:', error);
      throw error;
    }
  };

  // Helper functions
  const hasRole = (role: string): boolean => {
    return authState.user?.roles?.includes(role) || false;
  };

  const getDisplayName = (): string => {
    if (!authState.user) return 'User';
    return authState.user.display_name || 
           authState.user.full_name || 
           authState.user.username || 
           'User';
  };

  const getAvatarUrl = (): string => {
    return authState.user?.avatar_url || '';
  };

  const getDashboardRoute = (): string => {
    return authState.user?.dashboard_route || '/';
  };

  // Computed properties with enhanced protection - FIXED: Use 'administrator' not 'admin'
  const isAdmin = authState.user?.primary_role === 'administrator';
  const isVendor = authState.user?.primary_role === 'vendor';
  const isCustomer = authState.user?.primary_role === 'customer';
  const hasAccess = authState.user?.primary_role !== 'restricted';
  
  // Additional role checks
  const isShopManager = authState.user?.roles?.includes('shop_manager') || false;
  
  // Enhanced role debugging
  if (authState.user && authState.isAuthenticated) {
    console.log('🔍 ===== ENHANCED AUTH CONTEXT PROPERTIES =====');
    console.log('👤 User:', authState.user.display_name);
    console.log('🎯 Roles Array:', authState.user.roles);
    console.log('🎭 Primary Role:', authState.user.primary_role);
    console.log('🧭 Dashboard Route:', authState.user.dashboard_route);
    console.log('📊 Computed Properties:');
    console.log('  🔺 isAdmin:', isAdmin);
    console.log('  🏢 isShopManager:', isShopManager);
    console.log('  🏪 isVendor:', isVendor);
    console.log('  🔐 hasAccess:', hasAccess);
    console.log('📋 Role Verification:');
    console.log('  ✅ Has "administrator":', authState.user.roles?.includes('administrator'));
    console.log('  ✅ Has "shop_manager":', authState.user.roles?.includes('shop_manager'));
    console.log('  ✅ Has "seller":', authState.user.roles?.includes('seller'));
    console.log('  ✅ Has "vendor":', authState.user.roles?.includes('vendor'));
  }
  
  // Enhanced safeguards - These should NEVER trigger with corrected logic
  if (authState.user?.roles?.includes('administrator') && !isAdmin) {
    console.error('🚨 CRITICAL ROUTING ERROR: Administrator user has wrong classification!');
    console.error('🚨 This will cause admin to be treated as vendor!');
    console.error('🚨 Expected primary_role: administrator, Got:', authState.user.primary_role);
    console.error('🚨 Expected isAdmin: true, Got:', isAdmin);
    console.error('🚨 User roles:', authState.user.roles);
    
    // This is the exact error message you saw - should now be FIXED
  }
  
  if (authState.user?.roles?.includes('shop_manager') && !isShopManager) {
    console.error('🚨 CRITICAL: Shop Manager user not detected as shop_manager!');
    console.error('🚨 This indicates a bug in the corrected role resolution logic!');
    console.error('🚨 User primary_role:', authState.user.primary_role);
    console.error('🚨 User roles:', authState.user.roles);
  }

  const contextValue: AuthContextType = {
    ...authState,
    login,
    logout,
    clearError,
    refreshUser,
    hasRole,
    getDisplayName,
    getAvatarUrl,
    getDashboardRoute,
    isAdmin,
    isVendor,
    isCustomer,
    hasAccess,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Loading component for auth initialization
export const AuthLoadingScreen: React.FC = () => (
  <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-blue-900/20 dark:to-indigo-900/30 flex items-center justify-center">
    <div className="text-center space-y-6">
      <div className="relative">
        <div className="w-20 h-20 border-4 border-blue-200 dark:border-blue-800 rounded-full animate-spin">
          <div className="absolute top-0 left-0 w-full h-full border-4 border-transparent border-t-blue-600 rounded-full animate-spin"></div>
        </div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
            <svg className="w-5 h-5 text-white animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="text-2xl font-semibold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
          Connecting to WordPress
        </h2>
        <p className="text-gray-600 dark:text-gray-400 max-w-md">
          Enhanced role resolution - Verifying your credentials and loading your dashboard...
        </p>
      </div>

      <div className="text-center space-y-2">
        <div className="text-lg font-bold bg-gradient-to-r from-blue-800 to-blue-600 bg-clip-text text-transparent">
          EliteQ<span className="text-orange-500">India</span>
        </div>
        <div className="text-xs text-gray-500 dark:text-gray-400">
          WordPress Electronics Marketplace - Fixed Admin Routing
        </div>
      </div>
    </div>
  </div>
);

// Access Restricted component
export const AccessRestrictedScreen: React.FC<{ user?: AuthenticatedUser | null }> = ({ user }) => (
  <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 dark:from-gray-900 dark:to-red-900/20 flex items-center justify-center p-4">
    <div className="text-center max-w-md">
      <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
        <svg className="w-8 h-8 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.232 16.5c-.77.833.192 2.5 1.732 2.5z" />
        </svg>
      </div>
      
      <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
        Access Restricted
      </h2>
      
      <p className="text-gray-600 dark:text-gray-400 mb-6">
        Your WordPress account doesn't have the required permissions to access this dashboard.
      </p>
      
      {user && (
        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 mb-6 text-left">
          <div className="text-sm space-y-2">
            <div className="flex justify-between">
              <span className="font-medium">Your Email:</span>
              <span>{user.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Your Roles:</span>
              <span>{user.roles?.join(', ') || 'None'}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Primary Role:</span>
              <span>{user.primary_role_display}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Required Roles:</span>
              <span>administrator, vendor, seller, shop_manager</span>
            </div>
          </div>
        </div>
      )}
      
      <div className="space-y-3">
        <p className="text-sm text-gray-600 dark:text-gray-400">
          To access this dashboard, you need one of the following WordPress roles:
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          <span className="px-3 py-1 bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400 rounded-full text-xs">
            Administrator
          </span>
          <span className="px-3 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400 rounded-full text-xs">
            Vendor
          </span>
          <span className="px-3 py-1 bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400 rounded-full text-xs">
            Seller
          </span>
          <span className="px-3 py-1 bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400 rounded-full text-xs">
            Shop Manager
          </span>
        </div>
      </div>
      
      <div className="mt-8 space-y-3">
        <button 
          onClick={() => window.location.href = '/login'}
          className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Return to Login
        </button>
        <p className="text-xs text-gray-500 dark:text-gray-400">
          Contact your WordPress administrator to update your account permissions
        </p>
      </div>
    </div>
  </div>
);

export default AuthContext;