import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  CreditCard, 
  Smartphone, 
  Building, 
  Banknote, 
  Calendar,
  Search,
  Filter,
  Download,
  Eye,
  RefreshCw
} from 'lucide-react';
import { Input } from './ui/input';

interface PaymentRecord {
  id: string;
  paymentType: 'Card' | 'UPI' | 'Netbanking' | 'BNPL' | 'Cardless EMI';
  paymentId: string;
  orderId: string;
  username: string;
  amount: string;
  status: 'Paid' | 'Failed' | 'Pending';
  date: string;
  method: string;
}

interface EliteQPaymentOverviewTableProps {
  userRole: 'admin' | 'vendor';
}

export function EliteQPaymentOverviewTable({ userRole }: EliteQPaymentOverviewTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedPaymentType, setSelectedPaymentType] = useState('all');
  const [isLoading, setIsLoading] = useState(false);

  // Sample payment data
  const paymentRecords: PaymentRecord[] = [
    {
      id: '1',
      paymentType: 'UPI',
      paymentId: 'UPI_001',
      orderId: 'ORD_001',
      username: 'rajesh.kumar',
      amount: '₹15,280',
      status: 'Paid',
      date: '2024-08-03',
      method: 'Google Pay'
    },
    {
      id: '2',
      paymentType: 'Card',
      paymentId: 'CARD_002',
      orderId: 'ORD_002',
      username: 'priya.sharma',
      amount: '₹8,950',
      status: 'Pending',
      date: '2024-08-02',
      method: 'Visa **** 1234'
    },
    {
      id: '3',
      paymentType: 'Netbanking',
      paymentId: 'NB_003',
      orderId: 'ORD_003',
      username: 'amit.patel',
      amount: '₹23,740',
      status: 'Failed',
      date: '2024-08-01',
      method: 'HDFC Bank'
    }
  ];

  const getPaymentIcon = (type: string) => {
    switch (type) {
      case 'Card':
        return <CreditCard className="w-4 h-4" />;
      case 'UPI':
        return <Smartphone className="w-4 h-4" />;
      case 'Netbanking':
        return <Building className="w-4 h-4" />;
      case 'BNPL':
        return <Calendar className="w-4 h-4" />;
      case 'Cardless EMI':
        return <Banknote className="w-4 h-4" />;
      default:
        return <CreditCard className="w-4 h-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      'Paid': 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400',
      'Failed': 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400',
      'Pending': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400'
    };

    return (
      <Badge variant="secondary" className={statusConfig[status as keyof typeof statusConfig]}>
        {status}
      </Badge>
    );
  };

  const filteredRecords = paymentRecords.filter(record => {
    const matchesSearch = 
      record.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.paymentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.orderId.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = selectedStatus === 'all' || record.status === selectedStatus;
    const matchesPaymentType = selectedPaymentType === 'all' || record.paymentType === selectedPaymentType;

    return matchesSearch && matchesStatus && matchesPaymentType;
  });

  const handleRefresh = async () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  };

  const handleExport = () => {
    console.log('Exporting payment data...');
  };

  const handleViewPayment = (paymentId: string) => {
    console.log('Viewing payment:', paymentId);
  };

  return (
    <div className="mb-8">
      <Card className="p-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between mb-6 space-y-4 lg:space-y-0">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Payment Overview
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Monitor payment transactions across all {userRole === 'admin' ? 'marketplace' : 'store'} orders
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={isLoading}
            >
              <RefreshCw className={`w-4 h-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleExport}
            >
              <Download className="w-4 h-4 mr-1" />
              Export
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
              Search
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search payments..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
              Payment Type
            </label>
            <select
              value={selectedPaymentType}
              onChange={(e) => setSelectedPaymentType(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-sm"
            >
              <option value="all">All Types</option>
              <option value="Card">Card</option>
              <option value="UPI">UPI</option>
              <option value="Netbanking">Netbanking</option>
              <option value="BNPL">BNPL</option>
              <option value="Cardless EMI">Cardless EMI</option>
            </select>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
              Status
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-sm"
            >
              <option value="all">All Status</option>
              <option value="Paid">Paid</option>
              <option value="Pending">Pending</option>
              <option value="Failed">Failed</option>
            </select>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
              &nbsp;
            </label>
            <Button variant="outline" className="w-full">
              <Filter className="w-4 h-4 mr-2" />
              More Filters
            </Button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <div className="flex items-center space-x-2">
              <CreditCard className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">Total Payments</p>
                <p className="text-lg font-bold text-blue-600 dark:text-blue-400">₹47,970</p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 bg-green-500 rounded-full"></div>
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">Successful</p>
                <p className="text-lg font-bold text-green-600 dark:text-green-400">1</p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 bg-yellow-500 rounded-full"></div>
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">Pending</p>
                <p className="text-lg font-bold text-yellow-600 dark:text-yellow-400">1</p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 bg-red-500 rounded-full"></div>
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">Failed</p>
                <p className="text-lg font-bold text-red-600 dark:text-red-400">1</p>
              </div>
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-gray-200 dark:border-gray-700">
              <tr>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                  Payment Type
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                  Payment ID
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                  Order ID
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                  Username
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                  Amount
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                  Status
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                  Date
                </th>
                <th className="text-right py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {filteredRecords.length > 0 ? (
                filteredRecords.map((record) => (
                  <tr 
                    key={record.id}
                    className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors duration-150"
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                          {getPaymentIcon(record.paymentType)}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {record.paymentType}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            {record.method}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-sm font-mono text-blue-600 dark:text-blue-400">
                        {record.paymentId}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-sm font-mono text-purple-600 dark:text-purple-400">
                        {record.orderId}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-sm text-gray-900 dark:text-white">
                        {record.username}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        {record.amount}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      {getStatusBadge(record.status)}
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {new Date(record.date).toLocaleDateString('en-IN')}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewPayment(record.paymentId)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-8 text-center">
                    <div className="text-gray-500 dark:text-gray-400">
                      <Banknote className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No payment records found</p>
                      <p className="text-sm">Try adjusting your filters</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}