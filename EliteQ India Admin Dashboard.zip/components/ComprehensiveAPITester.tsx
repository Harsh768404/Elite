import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { ScrollArea } from './ui/scroll-area';
import { 
  Globe, 
  ShoppingCart, 
  Package, 
  Users, 
  FileText, 
  Settings,
  Play,
  CheckCircle,
  XCircle,
  Clock,
  Zap,
  Database,
  BarChart3,
  Layers,
  MessageSquare
} from 'lucide-react';
import { ALL_ENDPOINTS, getAllEndpoints } from '../config/wordpress-endpoints';
import { wordpressAPI } from '../utils/comprehensive-wordpress-api';

interface TestResult {
  endpoint: string;
  method: string;
  status: 'success' | 'error' | 'pending';
  response?: any;
  error?: string;
  timestamp: string;
  duration?: number;
}

interface EndpointCategory {
  name: string;
  icon: React.ElementType;
  endpoints: Record<string, string>;
  color: string;
}

const ENDPOINT_CATEGORIES: EndpointCategory[] = [
  {
    name: 'WordPress Core',
    icon: Globe,
    endpoints: ALL_ENDPOINTS.core,
    color: 'bg-blue-500',
  },
  {
    name: 'WooCommerce',
    icon: ShoppingCart,
    endpoints: ALL_ENDPOINTS.woocommerce,
    color: 'bg-purple-500',
  },
  {
    name: 'Products & Catalog',
    icon: Package,
    endpoints: {
      products: ALL_ENDPOINTS.woocommerce.products,
      variations: ALL_ENDPOINTS.woocommerce.variations,
      productCategories: ALL_ENDPOINTS.taxonomies.productCategories,
      productTags: ALL_ENDPOINTS.taxonomies.productTags,
    },
    color: 'bg-green-500',
  },
  {
    name: 'Users & Customers',
    icon: Users,
    endpoints: {
      users: ALL_ENDPOINTS.users.users,
      customers: ALL_ENDPOINTS.woocommerce.wcCustomers,
    },
    color: 'bg-orange-500',
  },
  {
    name: 'Content Management',
    icon: FileText,
    endpoints: {
      posts: ALL_ENDPOINTS.core.posts,
      pages: ALL_ENDPOINTS.core.pages,
      media: ALL_ENDPOINTS.core.media,
    },
    color: 'bg-indigo-500',
  },
  {
    name: 'Dokan Multivendor',
    icon: Database,
    endpoints: ALL_ENDPOINTS.dokan,
    color: 'bg-teal-500',
  },
  {
    name: 'WoodMart Theme',
    icon: Layers,
    endpoints: ALL_ENDPOINTS.woodmart,
    color: 'bg-amber-500',
  },
  {
    name: 'Forms & Communication',
    icon: MessageSquare,
    endpoints: ALL_ENDPOINTS.communication,
    color: 'bg-pink-500',
  },
];

export function ComprehensiveAPITester() {
  const [selectedCategory, setSelectedCategory] = useState(ENDPOINT_CATEGORIES[0]);
  const [selectedEndpoint, setSelectedEndpoint] = useState('');
  const [method, setMethod] = useState<'GET' | 'POST' | 'PUT' | 'DELETE'>('GET');
  const [requestBody, setRequestBody] = useState('');
  const [queryParams, setQueryParams] = useState('');
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [healthStatus, setHealthStatus] = useState<any>(null);

  // Initialize with first endpoint
  useEffect(() => {
    const firstEndpoint = Object.keys(selectedCategory.endpoints)[0];
    if (firstEndpoint) {
      setSelectedEndpoint(selectedCategory.endpoints[firstEndpoint]);
    }
  }, [selectedCategory]);

  // Run health check on component mount
  useEffect(() => {
    checkAPIHealth();
  }, []);

  const checkAPIHealth = async () => {
    try {
      const health = await wordpressAPI.healthCheck();
      setHealthStatus(health);
    } catch (error) {
      console.error('Health check failed:', error);
      setHealthStatus({ error: 'Health check failed' });
    }
  };

  const executeTest = async () => {
    if (!selectedEndpoint) return;

    setIsLoading(true);
    const startTime = Date.now();

    const testResult: TestResult = {
      endpoint: selectedEndpoint,
      method,
      status: 'pending',
      timestamp: new Date().toISOString(),
    };

    try {
      let url = selectedEndpoint;
      
      // Add query parameters
      if (queryParams) {
        const params = new URLSearchParams(queryParams);
        url += (url.includes('?') ? '&' : '?') + params.toString();
      }

      let response;
      switch (method) {
        case 'GET':
          response = await wordpressAPI.getEndpointData(url);
          break;
        case 'POST':
          const postData = requestBody ? JSON.parse(requestBody) : {};
          response = await wordpressAPI.postToEndpoint(url, postData);
          break;
        case 'PUT':
          // Handle PUT request
          response = await fetch(url, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: requestBody || '{}',
          }).then(res => res.json());
          break;
        case 'DELETE':
          // Handle DELETE request
          response = await fetch(url, {
            method: 'DELETE',
          }).then(res => res.json());
          break;
      }

      testResult.status = 'success';
      testResult.response = response;
      testResult.duration = Date.now() - startTime;
    } catch (error) {
      testResult.status = 'error';
      testResult.error = error instanceof Error ? error.message : 'Unknown error';
      testResult.duration = Date.now() - startTime;
    }

    setTestResults(prev => [testResult, ...prev.slice(0, 19)]); // Keep last 20 results
    setIsLoading(false);
  };

  const runBatchTest = async () => {
    setIsLoading(true);
    
    // Test key endpoints from each category
    const keyEndpoints = [
      { endpoint: ALL_ENDPOINTS.core.posts + '?per_page=1', method: 'GET' },
      { endpoint: ALL_ENDPOINTS.woocommerce.products + '?per_page=1', method: 'GET' },
      { endpoint: ALL_ENDPOINTS.woocommerce.orders + '?per_page=1', method: 'GET' },
      { endpoint: ALL_ENDPOINTS.taxonomies.categories + '?per_page=5', method: 'GET' },
      { endpoint: ALL_ENDPOINTS.dokan.stores + '?per_page=5', method: 'GET' },
    ];

    const results = await wordpressAPI.batchRequest(keyEndpoints);
    
    results.forEach((result, index) => {
      const testResult: TestResult = {
        endpoint: keyEndpoints[index].endpoint,
        method: keyEndpoints[index].method,
        status: result.error ? 'error' : 'success',
        response: result.error ? undefined : result,
        error: result.error,
        timestamp: new Date().toISOString(),
      };
      
      setTestResults(prev => [testResult, ...prev]);
    });

    setIsLoading(false);
  };

  const clearResults = () => {
    setTestResults([]);
  };

  const formatJSON = (obj: any) => {
    try {
      return JSON.stringify(obj, null, 2);
    } catch {
      return String(obj);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Comprehensive API Tester</h1>
          <p className="text-gray-600">Test all WordPress/WooCommerce endpoints for EliteQ India</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={checkAPIHealth} variant="outline">
            <Zap className="w-4 h-4 mr-2" />
            Health Check
          </Button>
          <Button onClick={runBatchTest} disabled={isLoading}>
            <BarChart3 className="w-4 h-4 mr-2" />
            Batch Test
          </Button>
        </div>
      </div>

      {/* Health Status */}
      {healthStatus && (
        <Alert>
          <CheckCircle className="w-4 h-4" />
          <AlertDescription>
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div className={`flex items-center gap-2 ${healthStatus.wordpress ? 'text-green-600' : 'text-red-600'}`}>
                {healthStatus.wordpress ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                WordPress: {healthStatus.wordpress ? 'Online' : 'Offline'}
              </div>
              <div className={`flex items-center gap-2 ${healthStatus.woocommerce ? 'text-green-600' : 'text-red-600'}`}>
                {healthStatus.woocommerce ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                WooCommerce: {healthStatus.woocommerce ? 'Online' : 'Offline'}
              </div>
              <div className={`flex items-center gap-2 ${healthStatus.api ? 'text-green-600' : 'text-red-600'}`}>
                {healthStatus.api ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                API: {healthStatus.api ? 'Online' : 'Offline'}
              </div>
            </div>
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="tester" className="space-y-6">
        <TabsList>
          <TabsTrigger value="tester">API Tester</TabsTrigger>
          <TabsTrigger value="results">Test Results ({testResults.length})</TabsTrigger>
          <TabsTrigger value="explorer">Endpoint Explorer</TabsTrigger>
        </TabsList>

        {/* API Tester Tab */}
        <TabsContent value="tester" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Test Configuration */}
            <Card>
              <CardHeader>
                <CardTitle>Test Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Category Selection */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Endpoint Category</label>
                  <div className="grid grid-cols-2 gap-2">
                    {ENDPOINT_CATEGORIES.map((category) => {
                      const Icon = category.icon;
                      return (
                        <Button
                          key={category.name}
                          variant={selectedCategory.name === category.name ? "default" : "outline"}
                          className="justify-start h-auto p-3"
                          onClick={() => setSelectedCategory(category)}
                        >
                          <Icon className="w-4 h-4 mr-2" />
                          <div className="text-left">
                            <div className="font-medium text-xs">{category.name}</div>
                            <div className="text-xs text-gray-500">{Object.keys(category.endpoints).length} endpoints</div>
                          </div>
                        </Button>
                      );
                    })}
                  </div>
                </div>

                {/* Endpoint Selection */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Endpoint</label>
                  <Select value={selectedEndpoint} onValueChange={setSelectedEndpoint}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select an endpoint" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(selectedCategory.endpoints).map(([key, url]) => (
                        <SelectItem key={key} value={url}>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">{key}</Badge>
                            <span className="text-xs text-gray-500 truncate">{url}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* HTTP Method */}
                <div>
                  <label className="text-sm font-medium mb-2 block">HTTP Method</label>
                  <Select value={method} onValueChange={(value: any) => setMethod(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="GET">GET</SelectItem>
                      <SelectItem value="POST">POST</SelectItem>
                      <SelectItem value="PUT">PUT</SelectItem>
                      <SelectItem value="DELETE">DELETE</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Query Parameters */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Query Parameters</label>
                  <Input
                    placeholder="per_page=10&status=publish"
                    value={queryParams}
                    onChange={(e) => setQueryParams(e.target.value)}
                  />
                  <p className="text-xs text-gray-500 mt-1">Format: key=value&key2=value2</p>
                </div>

                {/* Request Body (for POST/PUT) */}
                {(method === 'POST' || method === 'PUT') && (
                  <div>
                    <label className="text-sm font-medium mb-2 block">Request Body (JSON)</label>
                    <Textarea
                      placeholder='{"title": "Test Post", "content": "This is a test"}'
                      value={requestBody}
                      onChange={(e) => setRequestBody(e.target.value)}
                      rows={4}
                    />
                  </div>
                )}

                {/* Execute Button */}
                <Button 
                  onClick={executeTest} 
                  disabled={isLoading || !selectedEndpoint}
                  className="w-full"
                >
                  {isLoading ? (
                    <>
                      <Clock className="w-4 h-4 mr-2 animate-spin" />
                      Testing...
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Execute Test
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Latest Result */}
            <Card>
              <CardHeader>
                <CardTitle>Latest Test Result</CardTitle>
              </CardHeader>
              <CardContent>
                {testResults.length > 0 ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Badge 
                        variant={testResults[0].status === 'success' ? 'default' : 'destructive'}
                        className="flex items-center gap-1"
                      >
                        {testResults[0].status === 'success' ? (
                          <CheckCircle className="w-3 h-3" />
                        ) : (
                          <XCircle className="w-3 h-3" />
                        )}
                        {testResults[0].status.toUpperCase()}
                      </Badge>
                      <span className="text-xs text-gray-500">
                        {testResults[0].duration}ms
                      </span>
                    </div>
                    
                    <div className="text-xs">
                      <strong>Endpoint:</strong> {testResults[0].endpoint}
                    </div>
                    
                    {testResults[0].error ? (
                      <Alert variant="destructive">
                        <AlertDescription className="text-xs">
                          {testResults[0].error}
                        </AlertDescription>
                      </Alert>
                    ) : (
                      <ScrollArea className="h-64 w-full border rounded p-2">
                        <pre className="text-xs whitespace-pre-wrap">
                          {formatJSON(testResults[0].response)}
                        </pre>
                      </ScrollArea>
                    )}
                  </div>
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    No tests run yet. Select an endpoint and click "Execute Test" to begin.
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Test Results Tab */}
        <TabsContent value="results" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Test History</h3>
            <Button onClick={clearResults} variant="outline" size="sm">
              Clear Results
            </Button>
          </div>
          
          <div className="space-y-2">
            {testResults.map((result, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge variant={result.status === 'success' ? 'default' : 'destructive'}>
                        {result.method} {result.status}
                      </Badge>
                      <span className="text-sm text-gray-600">
                        {new Date(result.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">
                      {result.duration}ms
                    </span>
                  </div>
                  
                  <div className="text-xs text-gray-700 mb-2 break-all">
                    {result.endpoint}
                  </div>
                  
                  {result.error && (
                    <Alert variant="destructive" className="mt-2">
                      <AlertDescription className="text-xs">
                        {result.error}
                      </AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>
            ))}
            
            {testResults.length === 0 && (
              <div className="text-center text-gray-500 py-8">
                No test results yet.
              </div>
            )}
          </div>
        </TabsContent>

        {/* Endpoint Explorer Tab */}
        <TabsContent value="explorer" className="space-y-4">
          <h3 className="text-lg font-semibold">All Available Endpoints</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {ENDPOINT_CATEGORIES.map((category) => {
              const Icon = category.icon;
              return (
                <Card key={category.name}>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <div className={`w-8 h-8 ${category.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="w-4 h-4 text-white" />
                      </div>
                      {category.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {Object.entries(category.endpoints).map(([key, url]) => (
                        <div key={key} className="p-2 bg-gray-50 rounded text-xs">
                          <div className="font-medium">{key}</div>
                          <div className="text-gray-600 break-all">{url}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}