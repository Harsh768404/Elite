import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { 
  RefreshCw, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  Database, 
  Package, 
  ShoppingCart,
  Users,
  FileText,
  Image,
  Settings,
  TrendingUp,
  Search,
  Filter,
  Download,
  Upload
} from 'lucide-react';
import { 
  apiService,
  WooCommerceProduct,
  WooCommerceOrder,
  WordPressPost,
  WordPressPage,
  WordPressMedia,
  WordPressUser,
  WordPressTaxonomy
} from '../utils/comprehensive-api-service';

interface APITestResult {
  endpoint: string;
  status: 'success' | 'error' | 'loading';
  data?: any;
  error?: string;
  duration?: number;
}

const ComprehensiveAPIDemo: React.FC = () => {
  const [testResults, setTestResults] = useState<Record<string, APITestResult>>({});
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [healthStatus, setHealthStatus] = useState<any>(null);
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Sample data state for different endpoints
  const [products, setProducts] = useState<WooCommerceProduct[]>([]);
  const [orders, setOrders] = useState<WooCommerceOrder[]>([]);
  const [posts, setPosts] = useState<WordPressPost[]>([]);
  const [pages, setPages] = useState<WordPressPage[]>([]);
  const [media, setMedia] = useState<WordPressMedia[]>([]);
  const [users, setUsers] = useState<WordPressUser[]>([]);
  const [categories, setCategories] = useState<WordPressTaxonomy[]>([]);

  // Check authentication status on mount
  useEffect(() => {
    setIsAuthenticated(apiService.isAuthenticated());
  }, []);

  // API test configurations
  const apiTests = [
    // WordPress Core
    { name: 'Posts', endpoint: 'posts', icon: FileText, category: 'WordPress Core' },
    { name: 'Pages', endpoint: 'pages', icon: FileText, category: 'WordPress Core' },
    { name: 'Media', endpoint: 'media', icon: Image, category: 'WordPress Core' },
    { name: 'Users', endpoint: 'users', icon: Users, category: 'WordPress Core' },
    { name: 'Categories', endpoint: 'categories', icon: Filter, category: 'WordPress Core' },
    { name: 'Tags', endpoint: 'tags', icon: Filter, category: 'WordPress Core' },
    
    // WooCommerce
    { name: 'Products', endpoint: 'products', icon: Package, category: 'WooCommerce' },
    { name: 'Orders', endpoint: 'orders', icon: ShoppingCart, category: 'WooCommerce' },
    { name: 'Customers', endpoint: 'customers', icon: Users, category: 'WooCommerce' },
    { name: 'Product Categories', endpoint: 'product-categories', icon: Filter, category: 'WooCommerce' },
    { name: 'Product Tags', endpoint: 'product-tags', icon: Filter, category: 'WooCommerce' },
    { name: 'System Status', endpoint: 'system-status', icon: Settings, category: 'WooCommerce' },
    
    // Custom Post Types
    { name: 'Elementor Templates', endpoint: 'elementor-templates', icon: Settings, category: 'Custom Types' },
    { name: 'WoodMart Layouts', endpoint: 'woodmart-layouts', icon: Settings, category: 'Custom Types' },
    { name: 'WoodMart Slides', endpoint: 'woodmart-slides', icon: Settings, category: 'Custom Types' },
    
    // Reports
    { name: 'Sales Report', endpoint: 'sales-report', icon: TrendingUp, category: 'Reports' },
    { name: 'Top Sellers', endpoint: 'top-sellers', icon: TrendingUp, category: 'Reports' }
  ];

  const runSingleTest = async (testConfig: typeof apiTests[0]): Promise<APITestResult> => {
    const startTime = Date.now();
    
    try {
      let data;
      const params = { per_page: 5 }; // Limit results for demo
      
      switch (testConfig.endpoint) {
        case 'posts':
          data = await apiService.getPosts(params);
          setPosts(data);
          break;
        case 'pages':
          data = await apiService.getPages(params);
          setPages(data);
          break;
        case 'media':
          data = await apiService.getMedia(params);
          setMedia(data);
          break;
        case 'users':
          data = await apiService.getUsers(params);
          setUsers(data);
          break;
        case 'categories':
          data = await apiService.getCategories(params);
          setCategories(data);
          break;
        case 'tags':
          data = await apiService.getTags(params);
          break;
        case 'products':
          data = await apiService.getProducts(params);
          setProducts(data);
          break;
        case 'orders':
          data = await apiService.getOrders(params);
          setOrders(data);
          break;
        case 'customers':
          data = await apiService.getCustomers(params);
          break;
        case 'product-categories':
          data = await apiService.getProductCategories(params);
          break;
        case 'product-tags':
          data = await apiService.getProductTags(params);
          break;
        case 'system-status':
          data = await apiService.getSystemStatus();
          break;
        case 'elementor-templates':
          data = await apiService.getElementorTemplates(params);
          break;
        case 'woodmart-layouts':
          data = await apiService.getWoodMartLayouts(params);
          break;
        case 'woodmart-slides':
          data = await apiService.getWoodMartSlides(params);
          break;
        case 'sales-report':
          data = await apiService.getProductSalesReport({ period: 'week' });
          break;
        case 'top-sellers':
          data = await apiService.getTopSellersReport({ period: 'week' });
          break;
        default:
          throw new Error(`Unknown endpoint: ${testConfig.endpoint}`);
      }
      
      const duration = Date.now() - startTime;
      
      return {
        endpoint: testConfig.endpoint,
        status: 'success',
        data,
        duration
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      
      return {
        endpoint: testConfig.endpoint,
        status: 'error',
        error: error instanceof Error ? error.message : 'Unknown error',
        duration
      };
    }
  };

  const runAllTests = async () => {
    setIsRunningTests(true);
    setTestResults({});
    
    for (const testConfig of apiTests) {
      // Update loading state
      setTestResults(prev => ({
        ...prev,
        [testConfig.endpoint]: {
          endpoint: testConfig.endpoint,
          status: 'loading'
        }
      }));
      
      // Run test
      const result = await runSingleTest(testConfig);
      
      // Update with result
      setTestResults(prev => ({
        ...prev,
        [testConfig.endpoint]: result
      }));
      
      // Small delay between requests to avoid overwhelming the server
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    setIsRunningTests(false);
  };

  const runHealthCheck = async () => {
    try {
      const health = await apiService.healthCheck();
      setHealthStatus(health);
    } catch (error) {
      setHealthStatus({
        status: 'error',
        timestamp: new Date().toISOString(),
        services: {},
        error: error instanceof Error ? error.message : 'Health check failed'
      });
    }
  };

  const handleSearch = async (query: string, endpoint: string) => {
    if (!query.trim()) return;
    
    try {
      let results;
      
      switch (endpoint) {
        case 'products':
          results = await apiService.searchProducts(query, { per_page: 10 });
          setProducts(results);
          break;
        case 'posts':
          results = await apiService.searchPosts(query, { per_page: 10 });
          setPosts(results);
          break;
        case 'orders':
          results = await apiService.searchOrders(query, { per_page: 10 });
          setOrders(results);
          break;
      }
    } catch (error) {
      console.error('Search failed:', error);
    }
  };

  const formatData = (data: any): string => {
    if (!data) return 'No data';
    
    if (Array.isArray(data)) {
      return `Array with ${data.length} items`;
    }
    
    if (typeof data === 'object') {
      const keys = Object.keys(data).slice(0, 5);
      return `Object with keys: ${keys.join(', ')}${keys.length < Object.keys(data).length ? '...' : ''}`;
    }
    
    return String(data);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'loading':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const groupedTests = apiTests.reduce((acc, test) => {
    if (!acc[test.category]) {
      acc[test.category] = [];
    }
    acc[test.category].push(test);
    return acc;
  }, {} as Record<string, typeof apiTests>);

  return (
    <div className="w-full max-w-7xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">EliteQ Comprehensive API Integration</h1>
        <p className="text-muted-foreground">
          Complete WordPress + WooCommerce + Custom Endpoints Integration Test Suite
        </p>
      </div>

      {/* Authentication Status */}
      <Alert className={isAuthenticated ? "border-green-200" : "border-yellow-200"}>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Authentication Status</AlertTitle>
        <AlertDescription>
          {isAuthenticated 
            ? "✅ Authenticated with JWT token - All endpoints available"
            : "⚠️ Not authenticated - Some endpoints may require authentication"
          }
        </AlertDescription>
      </Alert>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-4 items-center justify-center">
        <Button 
          onClick={runAllTests} 
          disabled={isRunningTests}
          className="gap-2"
        >
          {isRunningTests ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <Database className="h-4 w-4" />
          )}
          {isRunningTests ? 'Running Tests...' : 'Test All Endpoints'}
        </Button>
        
        <Button variant="outline" onClick={runHealthCheck} className="gap-2">
          <CheckCircle className="h-4 w-4" />
          Health Check
        </Button>
        
        <div className="flex gap-2 items-center">
          <input
            type="text"
            placeholder="Search query..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="px-3 py-2 border rounded-md"
          />
          <Button 
            variant="outline" 
            onClick={() => handleSearch(searchQuery, 'products')}
            className="gap-2"
          >
            <Search className="h-4 w-4" />
            Search Products
          </Button>
        </div>
      </div>

      {/* Health Status */}
      {healthStatus && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              System Health Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <Badge 
                  variant={healthStatus.status === 'healthy' ? 'default' : 'destructive'}
                  className="mb-2"
                >
                  {healthStatus.status}
                </Badge>
                <p className="text-sm text-muted-foreground">Overall Status</p>
              </div>
              
              {Object.entries(healthStatus.services).map(([service, status]) => (
                <div key={service} className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    {status ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-500" />
                    )}
                    <span className="capitalize">{service}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {status ? 'Operational' : 'Down'}
                  </p>
                </div>
              ))}
            </div>
            
            <div className="mt-4 text-xs text-muted-foreground text-center">
              Last checked: {new Date(healthStatus.timestamp).toLocaleString()}
            </div>
          </CardContent>
        </Card>
      )}

      {/* API Test Results */}
      <Tabs defaultValue="tests" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="tests">API Tests</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="content">Content</TabsTrigger>
          <TabsTrigger value="raw">Raw Data</TabsTrigger>
        </TabsList>

        {/* API Tests Tab */}
        <TabsContent value="tests" className="space-y-6">
          {Object.entries(groupedTests).map(([category, tests]) => (
            <Card key={category}>
              <CardHeader>
                <CardTitle>{category}</CardTitle>
                <CardDescription>
                  {tests.length} endpoints in this category
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {tests.map((test) => {
                    const result = testResults[test.endpoint];
                    const Icon = test.icon;
                    
                    return (
                      <div 
                        key={test.endpoint} 
                        className="border rounded-lg p-4 space-y-2 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Icon className="h-4 w-4" />
                            <span className="font-medium">{test.name}</span>
                          </div>
                          {result && getStatusIcon(result.status)}
                        </div>
                        
                        {result && (
                          <div className="text-sm space-y-1">
                            {result.status === 'success' && (
                              <>
                                <p className="text-green-600">
                                  ✅ {formatData(result.data)}
                                </p>
                                <p className="text-muted-foreground">
                                  Response time: {result.duration}ms
                                </p>
                              </>
                            )}
                            
                            {result.status === 'error' && (
                              <p className="text-red-600">
                                ❌ {result.error}
                              </p>
                            )}
                            
                            {result.status === 'loading' && (
                              <p className="text-blue-600">
                                🔄 Testing endpoint...
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Products Tab */}
        <TabsContent value="products">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                WooCommerce Products ({products.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {products.map((product) => (
                    <div key={product.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium">{product.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            SKU: {product.sku || 'N/A'} | ID: {product.id}
                          </p>
                          <div className="flex gap-2 mt-2">
                            <Badge variant={product.status === 'publish' ? 'default' : 'secondary'}>
                              {product.status}
                            </Badge>
                            <Badge variant={product.stock_status === 'instock' ? 'default' : 'destructive'}>
                              {product.stock_status}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{product.price}</p>
                          <p className="text-sm text-muted-foreground">
                            Sales: {product.total_sales}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Orders Tab */}
        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="h-5 w-5" />
                WooCommerce Orders ({orders.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {orders.map((order) => (
                    <div key={order.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium">Order #{order.number || order.id}</h3>
                          <p className="text-sm text-muted-foreground">
                            Customer: {order.billing.first_name} {order.billing.last_name}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Date: {new Date(order.date_created).toLocaleDateString()}
                          </p>
                          <Badge 
                            variant={
                              order.status === 'completed' ? 'default' :
                              order.status === 'processing' ? 'secondary' : 'destructive'
                            }
                            className="mt-2"
                          >
                            {order.status}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{order.currency} {order.total}</p>
                          <p className="text-sm text-muted-foreground">
                            Items: {order.line_items?.length || 0}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Content Tab */}
        <TabsContent value="content">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Posts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  WordPress Posts ({posts.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-3">
                    {posts.map((post) => (
                      <div key={post.id} className="border-b pb-3 last:border-b-0">
                        <h4 className="font-medium">{post.title.rendered}</h4>
                        <p className="text-sm text-muted-foreground">
                          {new Date(post.date).toLocaleDateString()}
                        </p>
                        <Badge variant="outline">{post.status}</Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Pages */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  WordPress Pages ({pages.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-3">
                    {pages.map((page) => (
                      <div key={page.id} className="border-b pb-3 last:border-b-0">
                        <h4 className="font-medium">{page.title.rendered}</h4>
                        <p className="text-sm text-muted-foreground">
                          {new Date(page.date).toLocaleDateString()}
                        </p>
                        <Badge variant="outline">{page.status}</Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Media */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Image className="h-5 w-5" />
                  Media Library ({media.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="grid grid-cols-2 gap-2">
                    {media.map((item) => (
                      <div key={item.id} className="text-center space-y-1">
                        {item.media_type === 'image' && (
                          <img 
                            src={item.source_url} 
                            alt={item.alt_text}
                            className="w-full h-20 object-cover rounded"
                          />
                        )}
                        <p className="text-xs truncate">{item.title.rendered}</p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Users */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Users ({users.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-3">
                    {users.map((user) => (
                      <div key={user.id} className="border-b pb-3 last:border-b-0">
                        <h4 className="font-medium">{user.name}</h4>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                        <div className="flex gap-1 mt-1">
                          {user.roles.map((role) => (
                            <Badge key={role} variant="outline" className="text-xs">
                              {role}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Raw Data Tab */}
        <TabsContent value="raw">
          <Card>
            <CardHeader>
              <CardTitle>Raw API Response Data</CardTitle>
              <CardDescription>
                Select an endpoint to view the raw JSON response
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <select 
                  value={selectedEndpoint}
                  onChange={(e) => setSelectedEndpoint(e.target.value)}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="">Select an endpoint...</option>
                  {Object.keys(testResults).map((endpoint) => (
                    <option key={endpoint} value={endpoint}>
                      {endpoint}
                    </option>
                  ))}
                </select>

                {selectedEndpoint && testResults[selectedEndpoint] && (
                  <ScrollArea className="h-96">
                    <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-4 rounded-md overflow-auto">
                      {JSON.stringify(testResults[selectedEndpoint], null, 2)}
                    </pre>
                  </ScrollArea>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Statistics */}
      <Card>
        <CardHeader>
          <CardTitle>API Integration Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-green-600">
                {Object.values(testResults).filter(r => r.status === 'success').length}
              </p>
              <p className="text-sm text-muted-foreground">Successful Endpoints</p>
            </div>
            
            <div>
              <p className="text-2xl font-bold text-red-600">
                {Object.values(testResults).filter(r => r.status === 'error').length}
              </p>
              <p className="text-sm text-muted-foreground">Failed Endpoints</p>
            </div>
            
            <div>
              <p className="text-2xl font-bold text-blue-600">
                {apiTests.length}
              </p>
              <p className="text-sm text-muted-foreground">Total Endpoints</p>
            </div>
            
            <div>
              <p className="text-2xl font-bold text-purple-600">
                {Object.values(testResults)
                  .filter(r => r.duration)
                  .reduce((acc, r) => acc + (r.duration || 0), 0) / 
                 Math.max(Object.values(testResults).filter(r => r.duration).length, 1)}ms
              </p>
              <p className="text-sm text-muted-foreground">Avg Response Time</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ComprehensiveAPIDemo;