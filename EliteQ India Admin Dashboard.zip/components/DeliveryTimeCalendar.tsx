import React, { useState } from 'react';
import { 
  Calendar, Clock, Timer, ChevronLeft, ChevronRight, Filter,
  List, CalendarDays, Eye, MapPin, Package, CheckCircle,
  AlertTriangle, Truck, Store, Plus, Search
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface DeliveryEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  type: 'delivery' | 'pickup' | 'custom';
  status: 'scheduled' | 'in-transit' | 'delivered' | 'delayed';
  orderId: string;
  customer: string;
  location: string;
}

const mockEvents: DeliveryEvent[] = [
  {
    id: '1',
    title: 'Product Delivery - Electronics',
    date: '2024-01-15',
    time: '10:30 AM',
    type: 'delivery',
    status: 'scheduled',
    orderId: '#12345',
    customer: 'John Doe',
    location: 'Mumbai, MH'
  },
  {
    id: '2',
    title: 'Store Pickup - Fashion Items',
    date: '2024-01-15',
    time: '2:15 PM',
    type: 'pickup',
    status: 'scheduled',
    orderId: '#12346',
    customer: 'Jane Smith',
    location: 'Delhi Store'
  },
  {
    id: '3',
    title: 'Express Delivery - Books',
    date: '2024-01-16',
    time: '9:00 AM',
    type: 'delivery',
    status: 'in-transit',
    orderId: '#12347',
    customer: 'Mike Johnson',
    location: 'Bangalore, KA'
  },
  {
    id: '4',
    title: 'Bulk Order Delivery',
    date: '2024-01-16',
    time: '3:45 PM',
    type: 'delivery',
    status: 'delayed',
    orderId: '#12348',
    customer: 'Corporate Client',
    location: 'Chennai, TN'
  }
];

export function DeliveryTimeCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedView, setSelectedView] = useState<'today' | 'day' | 'week' | 'month' | 'year' | 'list'>('month');
  const [eventFilter, setEventFilter] = useState<'all' | 'delivery' | 'pickup' | 'custom'>('all');
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [searchTerm, setSearchTerm] = useState('');

  const filteredEvents = mockEvents.filter(event => {
    const matchesFilter = eventFilter === 'all' || event.type === eventFilter;
    const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         event.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         event.orderId.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'in-transit': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400';
      case 'delayed': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'delivery': return <Truck className="h-4 w-4" />;
      case 'pickup': return <Store className="h-4 w-4" />;
      default: return <Package className="h-4 w-4" />;
    }
  };

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    switch (selectedView) {
      case 'day':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1));
        break;
      case 'week':
        newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7));
        break;
      case 'month':
        newDate.setMonth(newDate.getMonth() + (direction === 'next' ? 1 : -1));
        break;
      case 'year':
        newDate.setFullYear(newDate.getFullYear() + (direction === 'next' ? 1 : -1));
        break;
    }
    setCurrentDate(newDate);
  };

  const formatDateHeader = () => {
    switch (selectedView) {
      case 'today':
        return new Date().toLocaleDateString('en-US', { 
          weekday: 'long', 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        });
      case 'day':
        return currentDate.toLocaleDateString('en-US', { 
          weekday: 'long', 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        });
      case 'week':
        const weekStart = new Date(currentDate);
        weekStart.setDate(currentDate.getDate() - currentDate.getDay());
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 6);
        return `${weekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${weekEnd.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
      case 'month':
        return currentDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
      case 'year':
        return currentDate.getFullYear().toString();
      default:
        return 'List View';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-lg p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-3 mb-2">
              <Timer className="h-6 w-6 text-blue-600" />
              Delivery Time Management
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Monitor and manage delivery schedules with interactive calendar views
            </p>
          </div>
          
          {/* Quick Stats */}
          <div className="flex gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">94.2%</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">On-Time</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">2.3</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Avg Days</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">8</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Delayed</div>
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
            {/* View Mode Tabs */}
            <Tabs value={selectedView} onValueChange={(value) => setSelectedView(value as any)} className="w-full lg:w-auto">
              <TabsList className="grid grid-cols-3 lg:grid-cols-6 w-full lg:w-auto">
                <TabsTrigger value="today" className="text-xs">Today</TabsTrigger>
                <TabsTrigger value="day" className="text-xs">Day</TabsTrigger>
                <TabsTrigger value="week" className="text-xs">Week</TabsTrigger>
                <TabsTrigger value="month" className="text-xs">Month</TabsTrigger>
                <TabsTrigger value="year" className="text-xs">Year</TabsTrigger>
                <TabsTrigger value="list" className="text-xs">List</TabsTrigger>
              </TabsList>
            </Tabs>

            {/* Filters and Search */}
            <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search events..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-full sm:w-48"
                />
              </div>
              
              <Select value={eventFilter} onValueChange={(value) => setEventFilter(value as any)}>
                <SelectTrigger className="w-full sm:w-40">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Events</SelectItem>
                  <SelectItem value="delivery">Only Delivery</SelectItem>
                  <SelectItem value="pickup">Only Pickup</SelectItem>
                  <SelectItem value="custom">Custom Events</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Navigation and Date Display */}
      {selectedView !== 'list' && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigateDate('prev')}
                className="flex items-center gap-2"
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>
              
              <div className="flex items-center gap-4">
                <h3 className="text-lg font-semibold">{formatDateHeader()}</h3>
                
                {(selectedView === 'year' || selectedView === 'month') && (
                  <Select value={selectedYear.toString()} onValueChange={(value) => {
                    setSelectedYear(parseInt(value));
                    const newDate = new Date(currentDate);
                    newDate.setFullYear(parseInt(value));
                    setCurrentDate(newDate);
                  }}>
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 10 }, (_, i) => new Date().getFullYear() - 5 + i).map(year => (
                        <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigateDate('next')}
                className="flex items-center gap-2"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Calendar/List Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Calendar View */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarDays className="h-5 w-5" />
                {selectedView === 'list' ? 'Event List' : 'Calendar View'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedView === 'list' ? (
                <div className="space-y-4">
                  {filteredEvents.map((event) => (
                    <div key={event.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/20">
                          {getTypeIcon(event.type)}
                        </div>
                        <div>
                          <h4 className="font-medium">{event.title}</h4>
                          <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                            <span>{event.date} at {event.time}</span>
                            <span>•</span>
                            <span>{event.customer}</span>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {event.location}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={getStatusColor(event.status)}>
                          {event.status}
                        </Badge>
                        <span className="text-sm text-gray-500">{event.orderId}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 text-center">
                  <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-600 dark:text-gray-400 mb-2">
                    Calendar View - {selectedView.toUpperCase()}
                  </h3>
                  <p className="text-gray-500 dark:text-gray-500">
                    Interactive calendar component would be implemented here with full month/week/day view functionality
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar - Today's Events & Quick Actions */}
        <div className="space-y-6">
          {/* Today's Events */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Today's Schedule
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {filteredEvents.slice(0, 3).map((event) => (
                <div key={event.id} className="flex items-center gap-3 p-3 border rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/20">
                    {getTypeIcon(event.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{event.title}</p>
                    <p className="text-xs text-gray-600 dark:text-gray-400">{event.time}</p>
                  </div>
                  <Badge className={`text-xs ${getStatusColor(event.status)}`}>
                    {event.status}
                  </Badge>
                </div>
              ))}
              <Button variant="outline" size="sm" className="w-full">
                <Eye className="h-4 w-4 mr-2" />
                View All Events
              </Button>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start" variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Add New Event
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <Truck className="h-4 w-4 mr-2" />
                Schedule Delivery
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <Store className="h-4 w-4 mr-2" />
                Arrange Pickup
              </Button>
            </CardContent>
          </Card>

          {/* Performance Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Performance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">On-Time Rate</span>
                <span className="font-medium text-green-600">94.2%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Avg Delivery Time</span>
                <span className="font-medium">2.3 days</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Customer Rating</span>
                <span className="font-medium text-blue-600">4.8/5</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}