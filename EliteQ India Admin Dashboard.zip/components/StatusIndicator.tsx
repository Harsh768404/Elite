import React from 'react';
import { CheckCircle, Clock, XCircle, AlertTriangle, Package } from 'lucide-react';

export type StatusType = 'success' | 'warning' | 'error' | 'pending' | 'info';

interface StatusIndicatorProps {
  status: StatusType;
  text: string;
  showIcon?: boolean;
  size?: 'sm' | 'md' | 'lg';
  animated?: boolean;
}

const statusConfig = {
  success: {
    icon: CheckCircle,
    bgColor: 'bg-green-100 dark:bg-green-900/20',
    textColor: 'text-green-800 dark:text-green-200',
    iconColor: 'text-green-600 dark:text-green-400',
    borderColor: 'border-green-200 dark:border-green-800'
  },
  warning: {
    icon: AlertTriangle,
    bgColor: 'bg-yellow-100 dark:bg-yellow-900/20',
    textColor: 'text-yellow-800 dark:text-yellow-200',
    iconColor: 'text-yellow-600 dark:text-yellow-400',
    borderColor: 'border-yellow-200 dark:border-yellow-800'
  },
  error: {
    icon: XCircle,
    bgColor: 'bg-red-100 dark:bg-red-900/20',
    textColor: 'text-red-800 dark:text-red-200',
    iconColor: 'text-red-600 dark:text-red-400',
    borderColor: 'border-red-200 dark:border-red-800'
  },
  pending: {
    icon: Clock,
    bgColor: 'bg-blue-100 dark:bg-blue-900/20',
    textColor: 'text-blue-800 dark:text-blue-200',
    iconColor: 'text-blue-600 dark:text-blue-400',
    borderColor: 'border-blue-200 dark:border-blue-800'
  },
  info: {
    icon: Package,
    bgColor: 'bg-gray-100 dark:bg-gray-800',
    textColor: 'text-gray-800 dark:text-gray-200',
    iconColor: 'text-gray-600 dark:text-gray-400',
    borderColor: 'border-gray-200 dark:border-gray-700'
  }
};

const sizeConfig = {
  sm: {
    padding: 'px-2 py-1',
    textSize: 'text-xs',
    iconSize: 'h-3 w-3'
  },
  md: {
    padding: 'px-3 py-2',
    textSize: 'text-sm',
    iconSize: 'h-4 w-4'
  },
  lg: {
    padding: 'px-4 py-3',
    textSize: 'text-base',
    iconSize: 'h-5 w-5'
  }
};

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  status,
  text,
  showIcon = true,
  size = 'md',
  animated = true
}) => {
  const config = statusConfig[status];
  const sizeStyles = sizeConfig[size];
  const Icon = config.icon;

  return (
    <div className={`
      inline-flex items-center gap-2 rounded-full border
      ${config.bgColor} 
      ${config.textColor} 
      ${config.borderColor}
      ${sizeStyles.padding}
      ${animated ? 'transition-all duration-300 hover:scale-105' : ''}
    `}>
      {showIcon && (
        <Icon className={`
          ${sizeStyles.iconSize} 
          ${config.iconColor}
          ${animated && status === 'pending' ? 'animate-spin' : ''}
          ${animated && status === 'success' ? 'animate-bounce' : ''}
        `} />
      )}
      <span className={`font-medium ${sizeStyles.textSize}`}>
        {text}
      </span>
    </div>
  );
};

// Preset status indicators for common use cases
export const OrderStatus: React.FC<{ status: string }> = ({ status }) => {
  const statusMap: Record<string, { type: StatusType; text: string }> = {
    'completed': { type: 'success', text: 'Completed' },
    'processing': { type: 'pending', text: 'Processing' },
    'pending': { type: 'warning', text: 'Pending Payment' },
    'cancelled': { type: 'error', text: 'Cancelled' },
    'refunded': { type: 'info', text: 'Refunded' }
  };

  const config = statusMap[status] || { type: 'info', text: status };
  
  return <StatusIndicator status={config.type} text={config.text} size="sm" />;
};

export const ProductStatus: React.FC<{ status: string; stock?: number }> = ({ status, stock }) => {
  const getStatusConfig = () => {
    if (status === 'published' && (stock === undefined || stock > 0)) {
      return { type: 'success' as StatusType, text: 'Published' };
    }
    if (status === 'published' && stock === 0) {
      return { type: 'warning' as StatusType, text: 'Out of Stock' };
    }
    if (status === 'pending') {
      return { type: 'pending' as StatusType, text: 'Pending Review' };
    }
    if (status === 'draft') {
      return { type: 'info' as StatusType, text: 'Draft' };
    }
    return { type: 'error' as StatusType, text: 'Inactive' };
  };

  const config = getStatusConfig();
  return <StatusIndicator status={config.type} text={config.text} size="sm" />;
};

export default StatusIndicator;