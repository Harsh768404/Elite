import React, { useState, useEffect } from 'react';

interface WelcomeBannerProps {
  currentRole: 'vendor' | 'admin';
  userName?: string;
}

export function WelcomeBanner({ currentRole, userName = 'Harsh' }: WelcomeBannerProps) {
  const [greeting, setGreeting] = useState('');

  useEffect(() => {
    const updateGreeting = () => {
      const hour = new Date().getHours();
      let timeGreeting = '';

      if (hour < 12) {
        timeGreeting = 'Good Morning';
      } else if (hour < 18) {
        timeGreeting = 'Good Afternoon';
      } else {
        timeGreeting = 'Good Evening';
      }

      const roleDisplay = currentRole === 'admin' ? 'Admin' : 'Vendor';
      setGreeting(`${timeGreeting}, ${userName} (${roleDisplay}) 👋`);
    };

    updateGreeting();
    // Update greeting every minute to keep it current
    const interval = setInterval(updateGreeting, 60000);

    return () => clearInterval(interval);
  }, [currentRole, userName]);

  return (
    <div className="bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-200 p-3 rounded-md shadow-sm mb-4 text-sm md:text-base transition-colors duration-300 animate-fade-in">
      <div className="flex items-center justify-between">
        <span className="font-medium">{greeting}</span>
        <div className="hidden sm:flex items-center text-xs text-blue-600 dark:text-blue-400">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2"></div>
          Online
        </div>
      </div>
    </div>
  );
}

export default WelcomeBanner;