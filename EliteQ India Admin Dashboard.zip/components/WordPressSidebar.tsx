import React from 'react';
import { 
  LayoutDashboard, Package, ShoppingCart, Users, Webhook, Settings,
  Shield, BarChart3, Database, Activity, CheckCircle, XCircle,
  AlertTriangle, Zap, Key, RefreshCw, UserCheck
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

interface WordPressSidebarProps {
  activeModule: 'dashboard' | 'customers' | 'products' | 'orders' | 'vendors' | 'webhooks' | 'settings';
  setActiveModule: (module: 'dashboard' | 'customers' | 'products' | 'orders' | 'vendors' | 'webhooks' | 'settings') => void;
  darkMode: boolean;
  userRole: 'administrator' | 'vendor';
  wpConnection: {
    status: 'connected' | 'error' | 'warning';
    apiKeys: boolean;
    webhooks: number;
    lastPing: string;
  };
}

export const WordPressSidebar: React.FC<WordPressSidebarProps> = ({ 
  activeModule, 
  setActiveModule, 
  darkMode,
  userRole,
  wpConnection
}) => {
  // Filter menu items based on user role
  const allMenuItems = [
    {
      id: 'dashboard' as const,
      label: 'Dashboard',
      icon: LayoutDashboard,
      description: userRole === 'administrator' ? 'Overview & Analytics' : 'Store Performance',
      badge: null,
      roles: ['administrator', 'vendor']
    },
    {
      id: 'customers' as const,
      label: 'Customers',
      icon: Users,
      description: 'Manage Customer Accounts',
      badge: '1,247',
      roles: ['administrator']
    },
    {
      id: 'products' as const,
      label: 'Products',
      icon: Package,
      description: userRole === 'administrator' ? 'Manage WooCommerce Products' : 'Manage Your Products',
      badge: userRole === 'administrator' ? '156' : '12',
      roles: ['administrator', 'vendor']
    },
    {
      id: 'orders' as const,
      label: 'Orders',
      icon: ShoppingCart,
      description: userRole === 'administrator' ? 'Process Customer Orders' : 'Your Store Orders',
      badge: userRole === 'administrator' ? '23' : '5',
      roles: ['administrator', 'vendor']
    },
    {
      id: 'vendors' as const,
      label: 'Vendors & KYC',
      icon: UserCheck,
      description: 'Dokan Vendor Management',
      badge: '5 Pending',
      roles: ['administrator']
    },
    {
      id: 'webhooks' as const,
      label: 'Webhook Logs',
      icon: Webhook,
      description: 'API Event Monitoring',
      badge: '47',
      roles: ['administrator']
    },
    {
      id: 'settings' as const,
      label: 'Settings & Config',
      icon: Settings,
      description: 'System Configuration',
      badge: null,
      roles: ['administrator']
    }
  ];

  const menuItems = allMenuItems.filter(item => item.roles.includes(userRole));

  const quickStats = userRole === 'administrator' ? [
    {
      label: 'Customers',
      value: '1,247',
      change: '+89',
      icon: Users,
      color: 'text-blue-600 bg-blue-100 dark:bg-blue-900/20'
    },
    {
      label: 'Products',
      value: '156',
      change: '+12',
      icon: Package,
      color: 'text-green-600 bg-green-100 dark:bg-green-900/20'
    },
    {
      label: 'Orders',
      value: '89',
      change: '+23',
      icon: ShoppingCart,
      color: 'text-purple-600 bg-purple-100 dark:bg-purple-900/20'
    }
  ] : [
    {
      label: 'My Products',
      value: '12',
      change: '+2',
      icon: Package,
      color: 'text-blue-600 bg-blue-100 dark:bg-blue-900/20'
    },
    {
      label: 'Orders',
      value: '5',
      change: '+1',
      icon: ShoppingCart,
      color: 'text-green-600 bg-green-100 dark:bg-green-900/20'
    },
    {
      label: 'Revenue',
      value: '₹8,542',
      change: '+₹1,245',
      icon: Database,
      color: 'text-purple-600 bg-purple-100 dark:bg-purple-900/20'
    }
  ];

  const getConnectionStatusIcon = () => {
    switch (wpConnection.status) {
      case 'connected':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-600" />;
    }
  };

  const getConnectionStatusColor = () => {
    switch (wpConnection.status) {
      case 'connected':
        return 'text-green-600 bg-green-50 dark:bg-green-900/20';
      case 'warning':
        return 'text-yellow-600 bg-yellow-50 dark:bg-yellow-900/20';
      case 'error':
        return 'text-red-600 bg-red-50 dark:bg-red-900/20';
    }
  };

  return (
    <div className="h-full bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 overflow-y-auto">
      <div className="flex flex-col h-full">
        
        {/* WordPress Connection Status */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="h-5 w-5 text-blue-600" />
            <h2 className="font-semibold text-gray-900 dark:text-white">
              {userRole === 'administrator' ? 'WordPress Panel' : 'Vendor Panel'}
            </h2>
          </div>
          
          <div className={`p-3 rounded-lg ${getConnectionStatusColor()}`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                {getConnectionStatusIcon()}
                <span className="font-medium text-sm">
                  {wpConnection.status === 'connected' ? 'Connected' : 
                   wpConnection.status === 'warning' ? 'Issues' : 'Disconnected'}
                </span>
              </div>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                <RefreshCw className="h-3 w-3" />
              </Button>
            </div>
            
            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span>API Keys:</span>
                <span className={wpConnection.apiKeys ? 'text-green-600' : 'text-red-600'}>
                  {wpConnection.apiKeys ? 'Valid' : 'Invalid'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Webhooks:</span>
                <span>{wpConnection.webhooks} Active</span>
              </div>
              <div className="flex justify-between">
                <span>Last Ping:</span>
                <span>{wpConnection.lastPing}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 p-4 space-y-2">
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
              {userRole === 'administrator' ? 'WordPress Management' : 'Vendor Tools'}
            </h3>
            
            <div className="space-y-1">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeModule === item.id;
                
                return (
                  <Button
                    key={item.id}
                    variant={isActive ? "default" : "ghost"}
                    onClick={() => setActiveModule(item.id)}
                    className={`w-full justify-start p-4 h-auto transition-all duration-200 ${
                      isActive 
                        ? 'bg-blue-600 text-white shadow-lg' 
                        : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <div className="flex items-center gap-3">
                        <Icon className={`h-5 w-5 ${isActive ? 'text-white' : 'text-gray-500'}`} />
                        <div className="text-left">
                          <div className={`font-medium ${isActive ? 'text-white' : 'text-gray-900 dark:text-white'}`}>
                            {item.label}
                          </div>
                          <div className={`text-xs ${isActive ? 'text-blue-100' : 'text-gray-500 dark:text-gray-400'}`}>
                            {item.description}
                          </div>
                        </div>
                      </div>
                      
                      {item.badge && (
                        <Badge 
                          variant={isActive ? "secondary" : "outline"}
                          className={`text-xs ${
                            isActive 
                              ? 'bg-white/20 text-white border-white/30' 
                              : 'bg-gray-100 dark:bg-gray-800'
                          }`}
                        >
                          {item.badge}
                        </Badge>
                      )}
                    </div>
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              Live Statistics
            </h3>
            
            {quickStats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index} className="bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-baseline gap-2">
                          <div className="text-xl font-bold text-gray-900 dark:text-white">
                            {stat.value}
                          </div>
                          <div className="text-xs text-green-600 font-medium">
                            {stat.change}
                          </div>
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          {stat.label}
                        </div>
                      </div>
                      <div className={`p-2 rounded-lg ${stat.color}`}>
                        <Icon className="h-4 w-4" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* System Health */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              System Health
            </h3>
            
            <Card className="bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700">
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Overall Health</span>
                    <span className="font-medium text-green-600">98%</span>
                  </div>
                  <Progress value={98} className="h-2" />
                  
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span>WordPress:</span>
                      <div className="flex items-center gap-1">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                        <span>Healthy</span>
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <span>WooCommerce:</span>
                      <div className="flex items-center gap-1">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                        <span>Active</span>
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <span>Dokan Pro:</span>
                      <div className="flex items-center gap-1">
                        <AlertTriangle className="h-3 w-3 text-yellow-600" />
                        <span>5 KYC Pending</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </nav>

        {/* Footer Actions */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700 space-y-3">
          {userRole === 'administrator' && (
            <Button 
              variant="outline" 
              className="w-full justify-start text-sm"
              onClick={() => setActiveModule('settings')}
            >
              <Key className="h-4 w-4 mr-2" />
              API Configuration
            </Button>
          )}
          
          <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
            <Database className="h-4 w-4" />
            <span>{userRole === 'administrator' ? 'WordPress Connected' : 'Store Connected'}</span>
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse ml-auto"></div>
          </div>
        </div>
      </div>
    </div>
  );
};