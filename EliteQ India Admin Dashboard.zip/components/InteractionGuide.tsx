import React, { useState } from 'react';
import { 
  Code, FileText, Globe, Database, Key, Link, 
  ArrowRight, Copy, CheckCircle, ExternalLink,
  BookOpen, Zap, Shield, Settings, Activity,
  GitBranch, Terminal, Layers, RefreshCw
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';

interface CodeExample {
  title: string;
  description: string;
  code: string;
  language: string;
}

const InteractionGuide: React.FC = () => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const copyToClipboard = async (code: string, title: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(title);
      setTimeout(() => setCopiedCode(null), 2000);
    } catch (error) {
      console.error('Failed to copy to clipboard:', error);
    }
  };

  const backendFiles = [
    {
      path: '/utils/api-integration-manager.ts',
      purpose: 'Central API integration manager with comprehensive WordPress/WooCommerce endpoints',
      description: 'Manages all API calls, caching, and data synchronization with error handling and retry logic',
      type: 'API Manager'
    },
    {
      path: '/utils/jwt-auth.ts',
      purpose: 'JWT authentication service for WordPress login and token management',
      description: 'Handles secure login, token refresh, and role-based authentication',
      type: 'Authentication'
    },
    {
      path: '/utils/woocommerce-api.ts',
      purpose: 'WooCommerce REST API wrapper with typed interfaces',
      description: 'Provides typed methods for all WooCommerce operations (products, orders, customers)',
      type: 'API Wrapper'
    },
    {
      path: '/utils/comprehensive-api-service.ts',
      purpose: 'Comprehensive API service with real-time data fetching',
      description: 'Advanced service layer with background sync and real-time updates',
      type: 'Service Layer'
    },
    {
      path: '/contexts/AuthContext.tsx',
      purpose: 'React context for managing authentication state across the application',
      description: 'Provides user state, role detection, and authentication methods to all components',
      type: 'State Management'
    }
  ];

  const apiEndpoints = [
    {
      endpoint: '/wp-json/wc/v3/customers',
      method: 'GET',
      purpose: 'Fetch customer data for Users → Customers section',
      authentication: 'Consumer Key + Secret',
      returns: 'Array of customer objects with roles, registration dates, and billing info'
    },
    {
      endpoint: '/wp-json/dokan/v1/stores',
      method: 'GET',
      purpose: 'Fetch vendor data for Users → Vendors section',
      authentication: 'Consumer Key + Secret',
      returns: 'Array of vendor store objects with ratings, commission, and status'
    },
    {
      endpoint: '/wp-json/wc/v3/products',
      method: 'GET',
      purpose: 'Fetch product catalog for Products management',
      authentication: 'Consumer Key + Secret',
      returns: 'Array of products with inventory, pricing, and vendor information'
    },
    {
      endpoint: '/wp-json/wc/v3/orders',
      method: 'GET',
      purpose: 'Fetch orders for Order management',
      authentication: 'Consumer Key + Secret',
      returns: 'Array of orders with customer details, items, and status'
    },
    {
      endpoint: '/wp-json/jwt-auth/v1/token',
      method: 'POST',
      purpose: 'Authenticate admin/vendor users and get JWT token',
      authentication: 'Username + Password',
      returns: 'JWT token with user roles and permissions'
    }
  ];

  const codeExamples: CodeExample[] = [
    {
      title: 'Fetch Customers with JWT Authentication',
      description: 'Example of how customer data is fetched and rendered in the Customers component',
      language: 'typescript',
      code: `// From /components/CustomersManagement.tsx
const fetchCustomers = async (page = 1, search = '', role = 'all') => {
  try {
    // Get credentials from environment
    const baseUrl = (window as any).ENV?.WORDPRESS_BASE_URL || 'https://eliteq.in';
    const consumerKey = (window as any).ENV?.WOOCOMMERCE_CONSUMER_KEY;
    const consumerSecret = (window as any).ENV?.WOOCOMMERCE_CONSUMER_SECRET;

    // Build API parameters
    const params = new URLSearchParams({
      consumer_key: consumerKey,
      consumer_secret: consumerSecret,
      page: page.toString(),
      per_page: '20',
      orderby: 'date_registered',
      order: 'desc'
    });

    if (search.trim()) params.append('search', search.trim());
    if (role !== 'all') params.append('role', role);

    // Make API call to WooCommerce customers endpoint
    const response = await fetch(\`\${baseUrl}/wp-json/wc/v3/customers?\${params}\`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    if (!response.ok) throw new Error(\`HTTP error! status: \${response.status}\`);

    const customers = await response.json();
    const totalCustomers = parseInt(response.headers.get('X-WP-Total') || '0');

    setCustomers(customers);
    console.log('✅ Customers loaded:', customers.length);
    
  } catch (error) {
    console.error('❌ Failed to fetch customers:', error);
    setError(error.message);
  }
};`
    },
    {
      title: 'JWT Authentication Flow',
      description: 'How JWT tokens are obtained and used for authenticated requests',
      language: 'typescript',
      code: `// From /utils/jwt-auth.ts
export const authenticateUser = async (username: string, password: string) => {
  try {
    const baseUrl = (window as any).ENV?.WORDPRESS_BASE_URL;
    
    const response = await fetch(\`\${baseUrl}/wp-json/jwt-auth/v1/token\`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username,
        password,
      }),
    });

    if (!response.ok) {
      throw new Error('Authentication failed');
    }

    const data = await response.json();
    
    // Store JWT token in localStorage
    localStorage.setItem('eliteq_jwt_token', data.token);
    localStorage.setItem('eliteq_user_roles', JSON.stringify(data.user_roles));
    
    return {
      success: true,
      token: data.token,
      user: data.user_data,
      roles: data.user_roles
    };
    
  } catch (error) {
    console.error('JWT Authentication error:', error);
    return { success: false, error: error.message };
  }
};

// Use JWT token for authenticated requests
export const makeAuthenticatedRequest = async (url: string, options = {}) => {
  const token = localStorage.getItem('eliteq_jwt_token');
  
  return fetch(url, {
    ...options,
    headers: {
      'Authorization': \`Bearer \${token}\`,
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });
};`
    },
    {
      title: 'Add New API Endpoint Integration',
      description: 'Template for adding new WordPress/WooCommerce endpoints to the system',
      language: 'typescript',
      code: `// Step 1: Add to /utils/comprehensive-api-service.ts
export class ComprehensiveAPIService {
  // Add your new endpoint method
  async fetchNewEndpointData(params = {}) {
    try {
      const baseUrl = this.getBaseUrl();
      const credentials = this.getCredentials();
      
      const queryParams = new URLSearchParams({
        consumer_key: credentials.consumerKey,
        consumer_secret: credentials.consumerSecret,
        ...params
      });

      const response = await fetch(
        \`\${baseUrl}/wp-json/your-plugin/v1/endpoint?\${queryParams}\`,
        {
          method: 'GET',
          headers: this.getHeaders(),
        }
      );

      if (!response.ok) {
        throw new Error(\`API error: \${response.status}\`);
      }

      const data = await response.json();
      
      // Cache the result
      this.cacheManager.set('new_endpoint_data', data);
      
      return data;
      
    } catch (error) {
      console.error('❌ New endpoint fetch failed:', error);
      throw error;
    }
  }
}

// Step 2: Add to your component
const YourNewComponent = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const apiService = ComprehensiveAPIService.getInstance();
        const result = await apiService.fetchNewEndpointData({
          page: 1,
          per_page: 20
        });
        setData(result);
      } catch (error) {
        console.error('Failed to load data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  return (
    <div>
      {/* Render your data here */}
    </div>
  );
};`
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <GitBranch className="w-6 h-6 text-purple-600" />
            Backend ↔ Frontend Interaction
          </h2>
          <p className="text-muted-foreground">
            Developer guide for understanding API integration and system architecture
          </p>
        </div>
        <Badge variant="outline" className="px-3 py-1">
          <Code className="w-4 h-4 mr-1" />
          Developer Guide
        </Badge>
      </div>

      {/* Architecture Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-blue-600" />
            System Architecture Overview
          </CardTitle>
          <CardDescription>
            How the EliteQ Admin Panel connects to WordPress + WooCommerce + Dokan Pro
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <Activity className="w-4 h-4" />
            <AlertDescription>
              <strong>Live Connection:</strong> This admin panel connects directly to your WordPress site at <code>eliteq.in</code> using REST APIs and JWT authentication. All data is fetched in real-time from your live store.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="border-blue-200 bg-blue-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Globe className="w-5 h-5 text-blue-600" />
                  <h4 className="font-semibold">Frontend (React)</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  This admin panel built with React + TypeScript + Tailwind CSS
                </p>
              </CardContent>
            </Card>

            <Card className="border-green-200 bg-green-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <ArrowRight className="w-5 h-5 text-green-600" />
                  <h4 className="font-semibold">API Bridge</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  REST API calls with JWT authentication and WooCommerce credentials
                </p>
              </CardContent>
            </Card>

            <Card className="border-purple-200 bg-purple-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Database className="w-5 h-5 text-purple-600" />
                  <h4 className="font-semibold">Backend (WordPress)</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  WordPress + WooCommerce + Dokan Pro at eliteq.in
                </p>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="files" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="files">Key Files</TabsTrigger>
          <TabsTrigger value="endpoints">API Endpoints</TabsTrigger>
          <TabsTrigger value="examples">Code Examples</TabsTrigger>
          <TabsTrigger value="guide">Adding Endpoints</TabsTrigger>
        </TabsList>

        {/* Key Files Tab */}
        <TabsContent value="files" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-orange-600" />
                Files That Control API Interaction
              </CardTitle>
              <CardDescription>
                Core files responsible for backend connectivity and data management
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {backendFiles.map((file, index) => (
                  <div key={index} className="flex items-start gap-4 p-4 border rounded-lg">
                    <div className="w-2 h-2 rounded-full bg-blue-500 mt-3 flex-shrink-0"></div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono">
                          {file.path}
                        </code>
                        <Badge variant="outline" className="text-xs">
                          {file.type}
                        </Badge>
                      </div>
                      <h4 className="font-medium mb-1">{file.purpose}</h4>
                      <p className="text-sm text-muted-foreground">{file.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* API Endpoints Tab */}
        <TabsContent value="endpoints" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Link className="w-5 h-5 text-green-600" />
                WordPress/WooCommerce API Endpoints
              </CardTitle>
              <CardDescription>
                Live endpoints used to fetch and manage data
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {apiEndpoints.map((endpoint, index) => (
                  <div key={index} className="border rounded-lg p-4 space-y-2">
                    <div className="flex items-center gap-2">
                      <Badge variant={endpoint.method === 'GET' ? 'secondary' : 'default'}>
                        {endpoint.method}
                      </Badge>
                      <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono flex-1">
                        {endpoint.endpoint}
                      </code>
                      <Badge variant="outline" className="text-xs">
                        <Shield className="w-3 h-3 mr-1" />
                        {endpoint.authentication}
                      </Badge>
                    </div>
                    <div className="text-sm">
                      <strong>Purpose:</strong> {endpoint.purpose}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <strong>Returns:</strong> {endpoint.returns}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Code Examples Tab */}
        <TabsContent value="examples" className="space-y-4">
          {codeExamples.map((example, index) => (
            <Card key={index}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Terminal className="w-5 h-5 text-blue-600" />
                    {example.title}
                  </CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(example.code, example.title)}
                  >
                    {copiedCode === example.title ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
                <CardDescription>{example.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <pre className="bg-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                  <code>{example.code}</code>
                </pre>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Guide Tab */}
        <TabsContent value="guide" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-purple-600" />
                Adding New API Endpoints
              </CardTitle>
              <CardDescription>
                Step-by-step guide for integrating new WordPress/WooCommerce endpoints
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-semibold text-sm">
                    1
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Identify the WordPress/WooCommerce Endpoint</h4>
                    <p className="text-sm text-muted-foreground">
                      Research the WordPress REST API documentation or WooCommerce REST API docs to find the endpoint you need.
                    </p>
                    <div className="mt-2">
                      <Badge variant="outline" className="text-xs">
                        <ExternalLink className="w-3 h-3 mr-1" />
                        <a href="https://developer.wordpress.org/rest-api/" target="_blank" rel="noopener noreferrer">
                          WordPress REST API Docs
                        </a>
                      </Badge>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-600 font-semibold text-sm">
                    2
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Add to API Service</h4>
                    <p className="text-sm text-muted-foreground">
                      Add your new endpoint method to <code>/utils/comprehensive-api-service.ts</code> following the established patterns.
                    </p>
                  </div>
                </div>

                <Separator />

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-600 font-semibold text-sm">
                    3
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Create Component</h4>
                    <p className="text-sm text-muted-foreground">
                      Create a new React component in <code>/components/</code> that uses your API method to fetch and display data.
                    </p>
                  </div>
                </div>

                <Separator />

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-semibold text-sm">
                    4
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Update Sidebar/Navigation</h4>
                    <p className="text-sm text-muted-foreground">
                      Add your new component to the sidebar navigation in <code>/components/ModernVendorSidebar.tsx</code> or the admin dashboard tabs.
                    </p>
                  </div>
                </div>

                <Separator />

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center text-red-600 font-semibold text-sm">
                    5
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Test & Document</h4>
                    <p className="text-sm text-muted-foreground">
                      Test your new endpoint integration thoroughly and update this interaction guide with your new endpoint details.
                    </p>
                  </div>
                </div>
              </div>

              <Alert>
                <Zap className="w-4 h-4" />
                <AlertDescription>
                  <strong>Pro Tip:</strong> Always use the existing JWT authentication and WooCommerce credentials. Follow the error handling patterns established in existing components.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Current Integration Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-green-600" />
            Current Integration Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm">JWT Authentication ✓</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm">WooCommerce API ✓</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm">Customers Management ✓</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm">Vendors Management ✓</span>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm">Products API ✓</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm">Orders API ✓</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm">Real-time Data ✓</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm">Error Handling ✓</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InteractionGuide;