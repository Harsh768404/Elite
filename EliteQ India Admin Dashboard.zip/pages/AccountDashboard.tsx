import React, { useState, useEffect } from 'react';
import { 
  User, Mail, Shield, Calendar, Settings, Bell, 
  CreditCard, FileText, HelpCircle, LogOut, Edit,
  Phone, MapPin, Globe, Lock, Eye, EyeOff, RefreshCw
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '../components/ui/avatar';
import { useAuth } from '../contexts/AuthContext';
import EliteQTopNavbar from '../components/EliteQTopNavbar';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Switch } from '../components/ui/switch';
import { wordpressAPI } from '../utils/comprehensive-wordpress-api';
import { eliteqDataService } from '../utils/eliteq-real-data-service';

interface RealUserData {
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  display_name: string;
  roles: string[];
  capabilities: Record<string, boolean>;
  avatar_urls: Record<string, string>;
  meta: Record<string, any>;
  date_registered?: string;
  dokan_store_info?: any;
  is_verified?: boolean;
  user_login?: string;
}

const AccountDashboard: React.FC = () => {
  const { user, logout, getDisplayName, getAvatarUrl } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [realUserData, setRealUserData] = useState<RealUserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch real user data from EliteQ.in WordPress API
  useEffect(() => {
    const fetchRealUserData = async () => {
      if (!user) return;

      try {
        setIsLoading(true);
        setError(null);
        
        console.log('🔄 Fetching real user data from EliteQ.in WordPress API...');
        console.log('👤 Current user ID:', user.id);

        // Get current user data with roles and meta
        const userData = await wordpressAPI.getUserWithRoles(user.id);
        
        console.log('✅ Real user data fetched:', userData);

        // For vendors, try to fetch Dokan store information
        let dokanStoreInfo = null;
        if (userData.roles?.includes('dokan_vendor') || userData.roles?.includes('vendor') || userData.roles?.includes('seller')) {
          try {
            console.log('🏪 Fetching Dokan store info for vendor...');
            const vendorData = await eliteqDataService.getVendorDashboardData(user.id);
            dokanStoreInfo = vendorData;
            console.log('✅ Dokan store info fetched:', dokanStoreInfo);
          } catch (dokanError) {
            console.warn('⚠️ Could not fetch Dokan store info:', dokanError);
          }
        }

        // Check if user is verified from meta data
        const isVerified = userData.meta?._is_verified === '1' || userData.meta?._is_verified === 1;

        const mappedUserData: RealUserData = {
          id: userData.id || user.id,
          // Username mapping: user_login -> Username
          username: userData.user_login || userData.username || user.username || '—',
          // Email mapping: user_email -> Email Address  
          email: userData.user_email || userData.email || user.email || '—',
          // First Name mapping: first_name (from user meta endpoint) -> First Name
          first_name: userData.first_name || userData.meta?.first_name || user.first_name || '—',
          // Last Name mapping: last_name (from user meta endpoint) -> Last Name
          last_name: userData.last_name || userData.meta?.last_name || user.last_name || '—',
          // Display Name mapping: display_name -> Display Name
          display_name: userData.display_name || userData.name || user.display_name || '—',
          roles: userData.roles || user.roles || [],
          capabilities: userData.capabilities || {},
          avatar_urls: userData.avatar_urls || {},
          meta: userData.meta || {},
          date_registered: userData.date_registered || userData.registered || user.authenticated_at,
          dokan_store_info: dokanStoreInfo,
          is_verified: isVerified,
          user_login: userData.user_login || userData.username || user.username
        };

        setRealUserData(mappedUserData);
        console.log('✅ Real user data mapped successfully:', mappedUserData);

      } catch (fetchError) {
        console.error('❌ Failed to fetch real user data:', fetchError);
        setError(fetchError instanceof Error ? fetchError.message : 'Failed to load user data');
        
        // Fallback to existing user data with proper mapping
        setRealUserData({
          id: user.id,
          username: user.user_login || user.username || '—',
          email: user.user_email || user.email || '—',
          first_name: user.first_name || '—',
          last_name: user.last_name || '—',
          display_name: user.display_name || '—',
          roles: user.roles || [],
          capabilities: user.capabilities || {},
          avatar_urls: user.avatar_urls || {},
          meta: {},
          is_verified: false,
          user_login: user.user_login || user.username || '—'
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchRealUserData();
  }, [user]);

  // Helper function to determine the correct account role
  const getAccountRole = (userData: RealUserData): string => {
    const roles = userData.roles || [];
    const capabilities = userData.capabilities || {};

    console.log('🎭 Determining account role from real data:', roles);
    console.log('🔑 User capabilities:', capabilities);

    // Check for admin roles first (highest priority)
    if (roles.includes('administrator') || capabilities.manage_options) {
      console.log('✅ Role resolved: Administrator (from admin role or manage_options capability)');
      return 'Administrator';
    }

    if (roles.includes('editor') || capabilities.edit_posts) {
      console.log('✅ Role resolved: Editor (from editor role or edit_posts capability)');
      return 'Editor';
    }

    if (roles.includes('shop_manager') || capabilities.manage_woocommerce) {
      console.log('✅ Role resolved: Shop Manager (from shop_manager role or manage_woocommerce capability)');
      return 'Shop Manager';
    }

    // Check for vendor roles (cross-check with Dokan/vendor capabilities)
    if (roles.includes('dokan_vendor') || 
        roles.includes('vendor') || 
        roles.includes('seller') || 
        capabilities.dokan_view_store_dashboard ||
        capabilities.dokan_view_overview_menu ||
        capabilities.dokan_view_product_menu) {
      console.log('✅ Role resolved: Vendor (from Dokan/vendor role or capabilities)');
      return 'Vendor';
    }

    if (roles.includes('wcfm_vendor')) {
      console.log('✅ Role resolved: WCFM Vendor');
      return 'WCFM Vendor';
    }

    // Check for customer
    if (roles.includes('customer')) {
      console.log('✅ Role resolved: Customer');
      return 'Customer';
    }

    // Check for subscriber (only if no other roles and specifically subscriber)
    if (roles.includes('subscriber') && roles.length === 1) {
      console.log('✅ Role resolved: Subscriber (only subscriber role, no other roles)');
      return 'Subscriber';
    }

    // Role mismatch detection - if shows "subscriber" for admin/vendor, cross-check capabilities
    if (roles.includes('subscriber') && Object.keys(capabilities).length > 0) {
      // Check capabilities to determine correct role
      if (capabilities.manage_options || capabilities.administrator) {
        console.log('🔧 Role mismatch detected: subscriber with admin capabilities - correcting to Administrator');
        return 'Administrator';
      }
      if (capabilities.manage_woocommerce || capabilities.shop_manager) {
        console.log('🔧 Role mismatch detected: subscriber with shop manager capabilities - correcting to Shop Manager');
        return 'Shop Manager';
      }
      if (capabilities.dokan_view_store_dashboard || capabilities.dokan_view_overview_menu) {
        console.log('🔧 Role mismatch detected: subscriber with vendor capabilities - correcting to Vendor');
        return 'Vendor';
      }
    }

    // Default fallback
    const fallbackRole = userData.roles[0] || 'User';
    console.log(`⚠️ Using fallback role: ${fallbackRole}`);
    return fallbackRole;
  };

  // Helper function to get membership badges
  const getMembershipBadges = (userData: RealUserData) => {
    const badges = [];
    const roles = userData.roles || [];
    const capabilities = userData.capabilities || {};

    // Verified Account badge (shows if custom meta _is_verified = 1)
    if (userData.is_verified) {
      badges.push({
        text: 'Verified Account',
        color: 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-700',
        icon: Shield
      });
    }

    // EliteQ Member badge (shows if role = vendor or admin)
    const hasVendorRole = roles.includes('vendor') || 
                         roles.includes('dokan_vendor') || 
                         roles.includes('seller') || 
                         roles.includes('wcfm_vendor') ||
                         capabilities.dokan_view_store_dashboard;
    
    const hasAdminRole = roles.includes('administrator') || 
                        roles.includes('editor') ||
                        roles.includes('shop_manager') ||
                        capabilities.manage_options ||
                        capabilities.manage_woocommerce;

    if (hasVendorRole || hasAdminRole) {
      badges.push({
        text: 'EliteQ Member',
        color: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-700',
        icon: Globe
      });
    }

    // Subscriber badge (only if WP role is subscriber and no Dokan/Custom role exists)
    const isOnlySubscriber = roles.includes('subscriber') && 
                             roles.length === 1 && 
                             !hasVendorRole && 
                             !hasAdminRole;

    if (isOnlySubscriber) {
      badges.push({
        text: 'Subscriber',
        color: 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-900/20 dark:text-gray-400 dark:border-gray-700',
        icon: User
      });
    }

    return badges;
  };

  const handleRefresh = async () => {
    if (!user) return;
    
    setIsLoading(true);
    setError(null);
    
    // Force refresh by calling the fetch function again
    try {
      const userData = await wordpressAPI.getUserWithRoles(user.id);
      
      let dokanStoreInfo = null;
      if (userData.roles?.includes('dokan_vendor') || userData.roles?.includes('vendor')) {
        try {
          const vendorData = await eliteqDataService.getVendorDashboardData(user.id);
          dokanStoreInfo = vendorData;
        } catch (dokanError) {
          console.warn('⚠️ Could not fetch Dokan store info:', dokanError);
        }
      }

      const isVerified = userData.meta?._is_verified === '1' || userData.meta?._is_verified === 1;

      const mappedUserData: RealUserData = {
        id: userData.id || user.id,
        // Username mapping: user_login -> Username
        username: userData.user_login || userData.username || user.username || '—',
        // Email mapping: user_email -> Email Address
        email: userData.user_email || userData.email || user.email || '—',
        // First Name mapping: first_name (from user meta endpoint) -> First Name
        first_name: userData.first_name || userData.meta?.first_name || user.first_name || '—',
        // Last Name mapping: last_name (from user meta endpoint) -> Last Name
        last_name: userData.last_name || userData.meta?.last_name || user.last_name || '—',
        // Display Name mapping: display_name -> Display Name
        display_name: userData.display_name || userData.name || user.display_name || '—',
        roles: userData.roles || user.roles || [],
        capabilities: userData.capabilities || {},
        avatar_urls: userData.avatar_urls || {},
        meta: userData.meta || {},
        date_registered: userData.date_registered || userData.registered || user.authenticated_at,
        dokan_store_info: dokanStoreInfo,
        is_verified: isVerified,
        user_login: userData.user_login || userData.username || user.username
      };

      setRealUserData(mappedUserData);
      console.log('🔄 User data refreshed successfully');
    } catch (refreshError) {
      console.error('❌ Failed to refresh user data:', refreshError);
      setError('Failed to refresh user data');
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return null; // This shouldn't happen due to route protection
  }

  // Use real user data if available, fallback to context user data with proper mapping
  const displayData = realUserData || {
    id: user.id,
    username: user.user_login || user.username || '—',
    email: user.user_email || user.email || '—',
    first_name: user.first_name || '—',
    last_name: user.last_name || '—',
    display_name: user.display_name || '—',
    roles: user.roles || [],
    capabilities: user.capabilities || {},
    avatar_urls: user.avatar_urls || {},
    meta: {},
    is_verified: false,
    user_login: user.user_login || user.username || '—'
  };

  console.log('👤 ===== ELITEQ INDIA ACCOUNT DASHBOARD LOADED WITH REAL DATA =====');
  console.log('👤 Display Name:', displayData.display_name);
  console.log('📧 Email:', displayData.email);
  console.log('🎭 Real Roles:', displayData.roles);
  console.log('🆔 User ID:', displayData.id);
  console.log('✅ Verified:', displayData.is_verified);

  const getInitials = (name: string): string => {
    if (!name || name === '—') return 'U';
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleLogout = () => {
    console.log('🚪 User initiated logout from account dashboard');
    logout();
  };

  const accountRole = getAccountRole(displayData);
  const membershipBadges = getMembershipBadges(displayData);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Fixed Top Navbar */}
      <EliteQTopNavbar showMenuButton={false} />
      
      {/* Main Content with top padding for fixed navbar */}
      <div className="pt-16 p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          
          {/* Header */}
          <div className="bg-gradient-to-r from-white via-blue-50 to-indigo-50 dark:from-gray-800 dark:via-blue-900/10 dark:to-indigo-900/10 rounded-2xl shadow-xl border-0 p-8">
            <div className="flex flex-col lg:flex-row items-start lg:items-center gap-6">
              
              {/* User Avatar and Info */}
              <div className="flex items-center gap-6">
                <div className="relative">
                  <Avatar className="h-24 w-24 ring-4 ring-blue-500/20 shadow-xl">
                    <AvatarImage 
                      src={displayData.avatar_urls?.['96'] || displayData.avatar_urls?.['48'] || getAvatarUrl()} 
                      alt={displayData.display_name}
                      className="object-cover"
                    />
                    <AvatarFallback className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white text-xl font-bold">
                      {getInitials(displayData.display_name)}
                    </AvatarFallback>
                  </Avatar>
                  
                  {/* Online status */}
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-4 border-white dark:border-gray-800 flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div>
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-blue-600 dark:from-white dark:to-blue-300 bg-clip-text text-transparent">
                      Account Dashboard
                    </h1>
                    <p className="text-xl text-gray-600 dark:text-gray-400 mt-1">
                      Welcome back, {displayData.display_name !== '—' ? displayData.display_name : 'User'}
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Mail className="h-5 w-5 text-blue-600" />
                      <span className="text-gray-600 dark:text-gray-400">{displayData.email}</span>
                    </div>
                    
                    {membershipBadges.length > 0 && (
                      <div className="flex items-center gap-1">
                        <Globe className="h-5 w-5 text-green-500" />
                        <span className="text-sm text-gray-500">EliteQ Member</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-3 flex-wrap">
                    <Badge className="bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 text-white border-0 shadow-lg">
                      <User className="h-3 w-3 mr-2" />
                      {accountRole}
                    </Badge>
                    
                    {membershipBadges.map((badge, index) => (
                      <Badge key={index} variant="outline" className={badge.color}>
                        <badge.icon className="h-3 w-3 mr-2" />
                        {badge.text}
                      </Badge>
                    ))}
                    
                    <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900/20 dark:text-orange-400 dark:border-orange-700">
                      ID: {displayData.id}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex-1 flex justify-end">
                <div className="flex items-center gap-3">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleRefresh}
                    disabled={isLoading}
                    className="hover:bg-green-600 hover:text-white transition-colors border-green-200"
                  >
                    <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    Refresh
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setIsEditing(!isEditing)}
                    className="hover:bg-blue-600 hover:text-white transition-colors border-blue-200"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    {isEditing ? 'Cancel Edit' : 'Edit Profile'}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleLogout}
                    className="hover:bg-red-600 hover:text-white transition-colors border-red-200"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </Button>
                </div>
              </div>
            </div>

            {/* Loading/Error States */}
            {isLoading && (
              <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700">
                <div className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  <span className="text-sm">Loading real user data from EliteQ.in...</span>
                </div>
              </div>
            )}

            {error && (
              <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-700">
                <div className="flex items-center gap-2 text-yellow-700 dark:text-yellow-400">
                  <HelpCircle className="h-4 w-4" />
                  <span className="text-sm">Using cached data: {error}</span>
                </div>
              </div>
            )}
          </div>

          {/* Account Management Tabs */}
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="profile" className="flex items-center gap-2">
                <User className="h-4 w-4" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center gap-2">
                <Lock className="h-4 w-4" />
                Security
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="billing" className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Billing
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Personal Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="displayName">Display Name</Label>
                      <Input
                        id="displayName"
                        value={displayData.display_name || ''}
                        disabled={!isEditing}
                        className={isEditing ? '' : 'bg-gray-50 dark:bg-gray-800'}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input
                        id="username"
                        value={displayData.username || ''}
                        disabled={true}
                        className="bg-gray-50 dark:bg-gray-800"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        value={displayData.email || ''}
                        disabled={!isEditing}
                        className={isEditing ? '' : 'bg-gray-50 dark:bg-gray-800'}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={displayData.first_name || ''}
                        disabled={!isEditing}
                        className={isEditing ? '' : 'bg-gray-50 dark:bg-gray-800'}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={displayData.last_name || ''}
                        disabled={!isEditing}
                        className={isEditing ? '' : 'bg-gray-50 dark:bg-gray-800'}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="role">Account Role</Label>
                      <Input
                        id="role"
                        value={accountRole}
                        disabled={true}
                        className="bg-gray-50 dark:bg-gray-800 capitalize"
                      />
                    </div>
                  </div>

                  {isEditing && (
                    <div className="flex gap-3 pt-4">
                      <Button>
                        Save Changes
                      </Button>
                      <Button variant="outline" onClick={() => setIsEditing(false)}>
                        Cancel
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* WordPress Role Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    WordPress Roles & Permissions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Assigned Roles</Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {displayData.roles.map((role: string, index: number) => (
                          <Badge key={index} variant="outline" className="text-sm">
                            {role}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Account Created</Label>
                      <div className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                        {displayData.date_registered ? new Date(displayData.date_registered).toLocaleDateString() : 'Unknown'}
                      </div>
                    </div>

                    {/* Real capabilities display */}
                    <div>
                      <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Key Capabilities</Label>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {Object.entries(displayData.capabilities)
                          .filter(([_, hasCapability]) => hasCapability)
                          .slice(0, 8)
                          .map(([capability, _], index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {capability.replace(/_/g, ' ')}
                            </Badge>
                          ))}
                      </div>
                    </div>

                    {/* Dokan store info for vendors */}
                    {displayData.dokan_store_info && (
                      <div>
                        <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Store Information</Label>
                        <div className="mt-2 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <div className="text-sm space-y-1">
                            <div><strong>Products:</strong> {displayData.dokan_store_info.stats?.total_products || 0}</div>
                            <div><strong>Orders:</strong> {displayData.dokan_store_info.stats?.total_orders || 0}</div>
                            <div><strong>Sales:</strong> ₹{displayData.dokan_store_info.stats?.total_sales?.toLocaleString('en-IN') || 0}</div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Real API Data Status */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-5 w-5" />
                    EliteQ.in Data Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Data Source</span>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        {realUserData ? 'Live EliteQ.in API' : 'Cached Data'}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Last Updated</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {new Date().toLocaleTimeString()}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Account Verification</span>
                      <Badge variant={displayData.is_verified ? "default" : "secondary"}>
                        {displayData.is_verified ? 'Verified' : 'Unverified'}
                      </Badge>
                    </div>

                    {error && (
                      <div className="mt-3 p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded text-sm text-yellow-700 dark:text-yellow-400">
                        <strong>Note:</strong> Some data may be cached due to API limitations
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Security Tab */}
            <TabsContent value="security" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lock className="h-5 w-5" />
                    Security Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Two-Factor Authentication</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Add an extra layer of security to your account</p>
                      </div>
                      <Switch />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Email Notifications</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Get notified of login attempts</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="pt-4">
                      <Button variant="outline">
                        Change Password
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="h-5 w-5" />
                    Notification Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Email Notifications</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Receive updates via email</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">SMS Notifications</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Receive updates via SMS</p>
                      </div>
                      <Switch />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Marketing Communications</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Receive promotional content</p>
                      </div>
                      <Switch />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Billing Tab */}
            <TabsContent value="billing" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Billing Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <CreditCard className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                      No Billing Information
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      You don't have any billing information on file.
                    </p>
                    <Button variant="outline">
                      Add Payment Method
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

        </div>
      </div>
    </div>
  );
};

export default AccountDashboard;