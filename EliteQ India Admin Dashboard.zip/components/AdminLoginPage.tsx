import React, { useState } from 'react';
import { Shield, Eye, EyeOff, Lock, User, AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { EliteQLogo } from './EliteQLogo';

interface AdminLoginPageProps {
  onLogin: () => void;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ onLogin }) => {
  const [credentials, setCredentials] = useState({
    username: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Enhanced admin validation
    setTimeout(() => {
      // Check for vendor/seller keywords in username
      const vendorKeywords = ['vendor', 'seller', 'shop', 'store', 'merchant'];
      const isVendorAccount = vendorKeywords.some(keyword => 
        credentials.username.toLowerCase().includes(keyword)
      );

      if (isVendorAccount) {
        setError('❌ Access Denied — Only Admin Credentials Are Allowed. Vendor-level accounts cannot access this system.');
        setIsLoading(false);
        return;
      }

      // Admin credentials validation
      if (credentials.username === 'admin' && credentials.password === 'admin123') {
        onLogin();
      } else if (credentials.username === 'eliteq_admin' && credentials.password === 'Elite@2024') {
        onLogin();
      } else {
        setError('Invalid admin credentials. Please verify your WordPress administrator username and password.');
      }
      setIsLoading(false);
    }, 1500);
  };

  const handleInputChange = (field: 'username' | 'password') => (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setCredentials(prev => ({
      ...prev,
      [field]: e.target.value
    }));
    if (error) setError(''); // Clear error when user starts typing
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 dark:from-gray-950 dark:via-gray-900 dark:to-blue-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        
        {/* Logo and Header */}
        <div className="text-center space-y-6">
          <div className="flex justify-center">
            <div className="p-4 bg-white dark:bg-gray-800 rounded-2xl shadow-lg">
              <EliteQLogo size="lg" animated={true} />
            </div>
          </div>
          
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              Admin Control System
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              WooCommerce + Dokan Integration Portal
            </p>
          </div>
        </div>

        {/* Security Notice */}
        <Alert className="border-blue-200 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-800">
          <Shield className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800 dark:text-blue-200">
            <div className="space-y-1">
              <div className="font-semibold">🔐 Administrator Access Only</div>
              <div className="text-sm">
                This system requires WordPress <strong>administrator privileges</strong>. 
                Vendor, editor, or contributor accounts will be automatically rejected.
              </div>
            </div>
          </AlertDescription>
        </Alert>

        {/* Login Form */}
        <Card className="shadow-xl border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-2xl text-center flex items-center justify-center gap-2">
              <Shield className="h-6 w-6 text-blue-600" />
              Administrator Login
            </CardTitle>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Error Alert */}
              {error && (
                <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-800">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-700 dark:text-red-400">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              {/* Username Field */}
              <div className="space-y-2">
                <Label htmlFor="username" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  WordPress Admin Username
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="Enter admin username"
                    value={credentials.username}
                    onChange={handleInputChange('username')}
                    className="pl-10 h-12 bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <p className="text-xs text-gray-500">
                  Only WordPress administrator accounts accepted
                </p>
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Admin Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter admin password"
                    value={credentials.password}
                    onChange={handleInputChange('password')}
                    className="pl-10 pr-10 h-12 bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Login Button */}
              <Button
                type="submit"
                disabled={isLoading || !credentials.username || !credentials.password}
                className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white font-medium transition-all duration-200 disabled:opacity-50"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Verifying Admin Access...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Sign In as Administrator
                  </div>
                )}
              </Button>

              {/* Demo Credentials Info */}
              <div className="text-center">
                <div className="text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 rounded-lg p-3">
                  <strong>Demo Admin Credentials:</strong><br />
                  Username: <code>admin</code> | Password: <code>admin123</code><br />
                  <em>Or</em><br />
                  Username: <code>eliteq_admin</code> | Password: <code>Elite@2024</code>
                </div>
              </div>

              {/* Security Features */}
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Security Features:</h4>
                <div className="space-y-1 text-xs text-gray-600 dark:text-gray-400">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span>JWT Authentication</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span>Role-based Access Control</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span>Encrypted API Keys</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span>Activity Logging</span>
                  </div>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-gray-500 dark:text-gray-400">
          <p>© 2024 EliteQ India. All rights reserved.</p>
          <p className="mt-1">WooCommerce + Dokan Pro Integration System</p>
          <p className="mt-1 text-xs">🔐 Admin-Only Access | All Actions Logged</p>
        </div>
      </div>
    </div>
  );
};