import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Users, Package, ShoppingCart, Settings } from 'lucide-react';
import { QUICK_ACTIONS } from '../../constants/dashboard-config';

const iconMap = {
  Users,
  Package,
  ShoppingCart,
  Settings
};

export const QuickActionsCard: React.FC = () => {
  const handleActionClick = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
        <CardDescription>
          Common administrative tasks
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {QUICK_ACTIONS.map((action) => {
          const IconComponent = iconMap[action.icon as keyof typeof iconMap];
          return (
            <Button 
              key={action.id}
              variant="outline" 
              className="h-20 flex flex-col gap-2"
              onClick={() => handleActionClick(action.url)}
            >
              <IconComponent className="w-6 h-6" />
              <span>{action.label}</span>
            </Button>
          );
        })}
      </CardContent>
    </Card>
  );
};

export default QuickActionsCard;