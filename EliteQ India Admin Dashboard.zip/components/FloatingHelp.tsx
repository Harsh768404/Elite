import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { HelpCircle, MessageSquare, Phone, Mail, X, ExternalLink } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from './ui/dialog';

interface HelpOption {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  action: () => void;
  color: string;
}

export const FloatingHelp: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const helpOptions: HelpOption[] = [
    {
      id: 'live-chat',
      title: 'Live Chat',
      description: 'Chat with our support team',
      icon: MessageSquare,
      color: 'bg-blue-600 hover:bg-blue-700',
      action: () => {
        // In a real app, this would open a chat widget
        console.log('Opening live chat...');
        setIsOpen(false);
      }
    },
    {
      id: 'phone-support',
      title: 'Phone Support',
      description: 'Call us at +91-8000-123-456',
      icon: Phone,
      color: 'bg-green-600 hover:bg-green-700',
      action: () => {
        window.open('tel:+918000123456');
        setIsOpen(false);
      }
    },
    {
      id: 'email-support',
      title: 'Email Support',
      description: 'Send us an email',
      icon: Mail,
      color: 'bg-purple-600 hover:bg-purple-700',
      action: () => {
        window.open('mailto:support@eliteq.in?subject=Vendor Dashboard Support');
        setIsOpen(false);
      }
    },
    {
      id: 'documentation',
      title: 'Documentation',
      description: 'Browse our help articles',
      icon: ExternalLink,
      color: 'bg-orange-600 hover:bg-orange-700',
      action: () => {
        window.open('https://eliteq.in/docs', '_blank');
        setIsOpen(false);
      }
    }
  ];

  return (
    <>
      {/* Floating Help Button */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button
            className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 z-50"
            size="icon"
          >
            <HelpCircle className="h-6 w-6 text-white" />
          </Button>
        </DialogTrigger>

        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <HelpCircle className="h-6 w-6 text-blue-600" />
              How can we help you?
            </DialogTitle>
            <DialogDescription>
              Choose how you'd like to get support for your EliteQ India dashboard.
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 gap-3 mt-4">
            {helpOptions.map((option) => (
              <Button
                key={option.id}
                onClick={option.action}
                className={`${option.color} text-white border-0 h-auto p-4 flex items-center gap-3 justify-start group transition-all duration-300 hover:scale-105`}
                variant="default"
              >
                <option.icon className="h-5 w-5 group-hover:scale-110 transition-transform duration-300" />
                <div className="text-left">
                  <div className="font-semibold">{option.title}</div>
                  <div className="text-xs opacity-90">{option.description}</div>
                </div>
              </Button>
            ))}
          </div>

          <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <h4 className="font-semibold text-sm mb-2">Quick Tips:</h4>
            <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
              <li>• Check our FAQ section for common questions</li>
              <li>• Use the search feature to find specific help topics</li>
              <li>• Our support team is available 24/7</li>
            </ul>
          </div>
        </DialogContent>
      </Dialog>

      {/* Floating Badge with Notification */}
      <div className="fixed bottom-20 right-6 z-40">
        <div className="relative">
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-ping"></div>
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></div>
        </div>
      </div>
    </>
  );
};

export default FloatingHelp;