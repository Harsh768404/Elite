// Network Connectivity Manager for EliteQ India - Handles Network Issues and Timeouts
export interface ConnectionStatus {
  isOnline: boolean;
  isWordPressReachable: boolean;
  isWooCommerceReachable: boolean;
  latency: number;
  lastChecked: Date;
  errorCount: number;
  consecutiveFailures: number;
}

export interface RetryConfig {
  maxAttempts: number;
  baseDelay: number;
  maxDelay: number;
  timeoutMs: number;
  backoffMultiplier: number;
}

export interface NetworkError {
  type: 'timeout' | 'fetch_failed' | 'server_error' | 'network_error' | 'cors_error';
  message: string;
  endpoint: string;
  timestamp: Date;
  retryable: boolean;
}

class NetworkConnectivityManager {
  private connectionStatus: ConnectionStatus = {
    isOnline: navigator.onLine,
    isWordPressReachable: false,
    isWooCommerceReachable: false,
    latency: 0,
    lastChecked: new Date(),
    errorCount: 0,
    consecutiveFailures: 0
  };

  private healthCheckInterval: NodeJS.Timeout | null = null;
  private listeners: ((status: ConnectionStatus) => void)[] = [];
  private recentErrors: NetworkError[] = [];
  private maxErrorHistory = 50;

  // Conservative retry configuration for EliteQ's network conditions
  private defaultRetryConfig: RetryConfig = {
    maxAttempts: 1,       // Reduced attempts to avoid overwhelming server
    baseDelay: 3000,      // Start with 3 seconds
    maxDelay: 20000,      // Max 20 seconds
    timeoutMs: 35000,     // Increased to 35s for slow networks
    backoffMultiplier: 1.8 // Less aggressive backoff
  };

  constructor() {
    this.initializeNetworkListeners();
    this.startHealthMonitoring();
    console.log('🌐 Network Connectivity Manager initialized');
  }

  private initializeNetworkListeners(): void {
    // Listen for online/offline events
    window.addEventListener('online', () => {
      console.log('🌐 Network connection restored');
      this.connectionStatus.isOnline = true;
      this.connectionStatus.consecutiveFailures = 0;
      this.notifyListeners();
      this.performHealthCheck();
    });

    window.addEventListener('offline', () => {
      console.log('🌐 Network connection lost');
      this.connectionStatus.isOnline = false;
      this.notifyListeners();
    });

    // Listen for visibility change to check connection when user returns
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && this.connectionStatus.isOnline) {
        this.performHealthCheck();
      }
    });
  }

  private startHealthMonitoring(): void {
    // Check connection health every 30 seconds
    this.healthCheckInterval = setInterval(() => {
      if (this.connectionStatus.isOnline) {
        this.performHealthCheck();
      }
    }, 30000);

    // Initial health check
    setTimeout(() => this.performHealthCheck(), 2000);
  }

  private async performHealthCheck(): Promise<void> {
    console.log('🏥 Performing network health check...');
    
    const startTime = Date.now();
    let wordpressReachable = false;
    let woocommerceReachable = false;

    try {
      // Test WordPress connectivity with minimal endpoint
      await this.testEndpoint('https://eliteq.in/wp-json/', 8000);
      wordpressReachable = true;
      console.log('✅ WordPress endpoint reachable');
    } catch (error) {
      console.warn('⚠️ WordPress endpoint not reachable:', error);
      this.recordError({
        type: 'network_error',
        message: 'WordPress health check failed',
        endpoint: 'https://eliteq.in/wp-json/',
        timestamp: new Date(),
        retryable: true
      });
    }

    try {
      // Test WooCommerce connectivity with simple endpoint
      await this.testEndpoint('https://eliteq.in/wp-json/wc/v3/', 8000);
      woocommerceReachable = true;
      console.log('✅ WooCommerce endpoint reachable');
    } catch (error) {
      console.warn('⚠️ WooCommerce endpoint not reachable:', error);
      this.recordError({
        type: 'network_error',
        message: 'WooCommerce health check failed',
        endpoint: 'https://eliteq.in/wp-json/wc/v3/',
        timestamp: new Date(),
        retryable: true
      });
    }

    const latency = Date.now() - startTime;

    // Update connection status
    this.connectionStatus = {
      ...this.connectionStatus,
      isWordPressReachable: wordpressReachable,
      isWooCommerceReachable: woocommerceReachable,
      latency: latency,
      lastChecked: new Date(),
      consecutiveFailures: wordpressReachable || woocommerceReachable ? 0 : this.connectionStatus.consecutiveFailures + 1
    };

    this.notifyListeners();
    
    console.log('🏥 Health check complete:', {
      wordpress: wordpressReachable,
      woocommerce: woocommerceReachable,
      latency: `${latency}ms`,
      consecutiveFailures: this.connectionStatus.consecutiveFailures
    });
  }

  private async testEndpoint(url: string, timeoutMs: number): Promise<void> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(url, {
        method: 'HEAD', // Use HEAD to minimize data transfer
        signal: controller.signal,
        mode: 'cors',
        cache: 'no-cache'
      });

      clearTimeout(timeoutId);
      
      if (!response.ok && response.status !== 405) { // 405 is OK for HEAD requests
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      clearTimeout(timeoutId);
      throw error;
    }
  }

  public async fetchWithRetry<T>(
    url: string,
    options: RequestInit = {},
    retryConfig: Partial<RetryConfig> = {}
  ): Promise<T> {
    const config = { ...this.defaultRetryConfig, ...retryConfig };
    let lastError: Error | null = null;

    console.log(`🔄 Fetching with retry: ${url}`);
    console.log(`⚙️ Config: ${config.maxAttempts} attempts, ${config.timeoutMs}ms timeout`);

    for (let attempt = 1; attempt <= config.maxAttempts; attempt++) {
      try {
        console.log(`🔄 Attempt ${attempt}/${config.maxAttempts} for ${url}`);
        
        // Check network status before attempting
        if (!this.connectionStatus.isOnline) {
          throw new Error('Network offline');
        }

        const result = await this.fetchWithTimeout<T>(url, options, config.timeoutMs);
        
        // Success - reset consecutive failures
        this.connectionStatus.consecutiveFailures = 0;
        this.connectionStatus.errorCount = Math.max(0, this.connectionStatus.errorCount - 1);
        
        console.log(`✅ Request successful on attempt ${attempt}`);
        return result;

      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        
        console.warn(`⚠️ Attempt ${attempt} failed:`, lastError.message);
        
        // Record the error
        this.recordError({
          type: this.classifyError(lastError),
          message: lastError.message,
          endpoint: url,
          timestamp: new Date(),
          retryable: attempt < config.maxAttempts
        });

        // Update error counts
        this.connectionStatus.errorCount++;
        this.connectionStatus.consecutiveFailures++;

        // Don't retry on the last attempt
        if (attempt === config.maxAttempts) {
          break;
        }

        // Check if error is retryable
        if (!this.isRetryableError(lastError)) {
          console.warn(`❌ Non-retryable error, stopping attempts`);
          break;
        }

        // Calculate delay with exponential backoff
        const delay = Math.min(
          config.baseDelay * Math.pow(config.backoffMultiplier, attempt - 1),
          config.maxDelay
        );

        console.log(`⏳ Waiting ${delay}ms before retry ${attempt + 1}`);
        await this.delay(delay);
      }
    }

    // All attempts failed
    console.error(`❌ All ${config.maxAttempts} attempts failed for ${url}`);
    throw lastError || new Error('Request failed after all retries');
  }

  private async fetchWithTimeout<T>(
    url: string,
    options: RequestInit,
    timeoutMs: number
  ): Promise<T> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
      console.warn(`⏱️ Request timeout after ${timeoutMs}ms: ${url}`);
      controller.abort();
    }, timeoutMs);

    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
        headers: {
          ...options.headers,
          'User-Agent': 'EliteQ-Admin-Panel/1.0'
        }
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
        
        try {
          const errorText = await response.text();
          if (errorText.includes('critical error')) {
            errorMessage = 'WordPress critical error detected';
          } else if (errorText.includes('500') || errorText.includes('Internal Server Error')) {
            errorMessage = 'WordPress internal server error';
          }
        } catch {
          // Ignore error text parsing failures
        }
        
        throw new Error(errorMessage);
      }

      const data = await response.json();
      return data;

    } catch (error) {
      clearTimeout(timeoutId);
      
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          throw new Error(`Request timeout after ${timeoutMs}ms`);
        }
        throw error;
      }
      
      throw new Error('Network request failed');
    }
  }

  private classifyError(error: Error): NetworkError['type'] {
    const message = error.message.toLowerCase();
    
    if (message.includes('timeout')) {
      return 'timeout';
    }
    if (message.includes('failed to fetch')) {
      return 'fetch_failed';
    }
    if (message.includes('cors')) {
      return 'cors_error';
    }
    if (message.includes('500') || message.includes('critical error')) {
      return 'server_error';
    }
    
    return 'network_error';
  }

  private isRetryableError(error: Error): boolean {
    const nonRetryableMessages = [
      'unauthorized',
      'forbidden', 
      'not found',
      'method not allowed',
      'cors',
      'critical error',
      'wordpress critical error detected',
      'http 404:',
      'http 403:',
      'http 401:',
      'http 405:',
      'vendors api error: 500',
      'all 1 attempts failed'
    ];

    const message = error.message.toLowerCase();
    const isNonRetryable = nonRetryableMessages.some(msg => message.includes(msg));
    
    if (isNonRetryable) {
      console.warn(`❌ Non-retryable error detected: ${message}`);
    }
    
    return !isNonRetryable;
  }

  private recordError(error: NetworkError): void {
    this.recentErrors.unshift(error);
    
    // Keep only recent errors
    if (this.recentErrors.length > this.maxErrorHistory) {
      this.recentErrors = this.recentErrors.slice(0, this.maxErrorHistory);
    }
    
    console.warn('🚨 Network error recorded:', error);
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private notifyListeners(): void {
    this.listeners.forEach(listener => {
      try {
        listener(this.connectionStatus);
      } catch (error) {
        console.error('❌ Error notifying connection status listener:', error);
      }
    });
  }

  // Public API
  public getConnectionStatus(): ConnectionStatus {
    return { ...this.connectionStatus };
  }

  public getRecentErrors(): NetworkError[] {
    return [...this.recentErrors];
  }

  public onStatusChange(listener: (status: ConnectionStatus) => void): () => void {
    this.listeners.push(listener);
    
    // Return unsubscribe function
    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  public async testConnection(): Promise<ConnectionStatus> {
    await this.performHealthCheck();
    return this.getConnectionStatus();
  }

  public getAdaptiveTimeout(): number {
    // Adapt timeout based on current connection quality
    const { latency, consecutiveFailures } = this.connectionStatus;
    
    let timeout = this.defaultRetryConfig.timeoutMs;
    
    // Increase timeout for slow connections
    if (latency > 5000) {
      timeout *= 1.5;
    } else if (latency > 10000) {
      timeout *= 2;
    }
    
    // Increase timeout if we've had recent failures
    if (consecutiveFailures > 0) {
      timeout *= (1 + consecutiveFailures * 0.3);
    }
    
    // Cap at maximum
    return Math.min(timeout, 45000);
  }

  public getConnectionQuality(): 'excellent' | 'good' | 'poor' | 'offline' {
    if (!this.connectionStatus.isOnline) return 'offline';
    
    const { latency, consecutiveFailures, isWordPressReachable, isWooCommerceReachable } = this.connectionStatus;
    
    if (!isWordPressReachable && !isWooCommerceReachable) return 'offline';
    if (consecutiveFailures > 3) return 'poor';
    if (latency > 8000) return 'poor';
    if (latency > 3000 || consecutiveFailures > 0) return 'good';
    
    return 'excellent';
  }

  public reset(): void {
    this.connectionStatus.errorCount = 0;
    this.connectionStatus.consecutiveFailures = 0;
    this.recentErrors = [];
    console.log('🔄 Network connectivity manager reset');
  }

  public destroy(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
    this.listeners = [];
    console.log('🛑 Network connectivity manager destroyed');
  }
}

// Create singleton instance
export const networkManager = new NetworkConnectivityManager();

// Export utilities
export const createAdaptiveRetryConfig = (baseConfig: Partial<RetryConfig> = {}): RetryConfig => {
  const quality = networkManager.getConnectionQuality();
  
  const qualityConfig = {
    excellent: { maxAttempts: 1, timeoutMs: 25000 },
    good: { maxAttempts: 1, timeoutMs: 30000 },
    poor: { maxAttempts: 1, timeoutMs: 40000 },
    offline: { maxAttempts: 1, timeoutMs: 15000 }
  };
  
  return {
    maxAttempts: 1,
    baseDelay: 3000,
    maxDelay: 20000,
    timeoutMs: 35000,
    backoffMultiplier: 1.8,
    ...qualityConfig[quality],
    ...baseConfig
  };
};

export default NetworkConnectivityManager;