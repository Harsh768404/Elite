// Environment Configuration for EliteQ India
// Safely exposes environment variables to the frontend

export interface EnvConfig {
  // WooCommerce API credentials
  WOOCOMMERCE_CONSUMER_KEY?: string;
  WOOCOMMERCE_CONSUMER_SECRET?: string;
  WOOCOMMERCE_WEBHOOK_SECRET?: string;
  
  // WordPress credentials
  WORDPRESS_BASE_URL?: string;
  JWT_AUTH_SECRET_KEY?: string;
  
  // Other API keys
  CONSUMER_KEY?: string;
  CONSUMER_SECRET?: string;
  
  // Database
  MYSQL_HOST?: string;
}

// Check if we're in a browser environment
const isBrowser = typeof window !== 'undefined';
const isNode = typeof process !== 'undefined' && typeof process.env !== 'undefined';

// Function to safely get environment variables with React App prefix support
const getEnvVar = (key: string): string | undefined => {
  try {
    // List of possible variable names (with and without REACT_APP_ prefix)
    const possibleKeys = [
      key,
      `REACT_APP_${key}`,
      key.replace(/^REACT_APP_/, ''), // Remove prefix if present
    ];
    
    // Check window.ENV first (for runtime configuration)
    if (isBrowser && typeof window !== 'undefined' && (window as any).ENV) {
      for (const possibleKey of possibleKeys) {
        const value = (window as any).ENV[possibleKey];
        if (value) {
          console.log(`🔧 Found ${key} in window.ENV as ${possibleKey}`);
          return value;
        }
      }
    }
    
    // Check process.env if available
    if (isNode && typeof process !== 'undefined' && process.env) {
      for (const possibleKey of possibleKeys) {
        const value = process.env[possibleKey];
        if (value) {
          console.log(`🔧 Found ${key} in process.env as ${possibleKey}`);
          return value;
        }
      }
    }
    
  } catch (error) {
    console.warn(`⚠️ Could not access environment variable ${key}:`, error);
  }
  
  return undefined;
};

// Initialize environment configuration object
const initializeEnvConfig = (): EnvConfig => {
  console.log('🔧 ===== INITIALIZING ENVIRONMENT CONFIGURATION =====');
  console.log('🌐 Environment Type:', isBrowser ? 'Browser' : 'Server');
  console.log('📦 Node.js Available:', isNode ? '✅' : '❌');
  console.log('🌍 Window Available:', isBrowser ? '✅' : '❌');

  const config: EnvConfig = {
    WOOCOMMERCE_CONSUMER_KEY: getEnvVar('WOOCOMMERCE_CONSUMER_KEY') || getEnvVar('WC_CONSUMER_KEY'),
    WOOCOMMERCE_CONSUMER_SECRET: getEnvVar('WOOCOMMERCE_CONSUMER_SECRET') || getEnvVar('WC_CONSUMER_SECRET'),
    WOOCOMMERCE_WEBHOOK_SECRET: getEnvVar('WOOCOMMERCE_WEBHOOK_SECRET'),
    WORDPRESS_BASE_URL: getEnvVar('WORDPRESS_BASE_URL') || getEnvVar('WORDPRESS_URL') || 'https://eliteq.in',
    JWT_AUTH_SECRET_KEY: getEnvVar('JWT_AUTH_SECRET_KEY'),
    CONSUMER_KEY: getEnvVar('CONSUMER_KEY') || getEnvVar('WOOCOMMERCE_CONSUMER_KEY') || getEnvVar('WC_CONSUMER_KEY'),
    CONSUMER_SECRET: getEnvVar('CONSUMER_SECRET') || getEnvVar('WOOCOMMERCE_CONSUMER_SECRET') || getEnvVar('WC_CONSUMER_SECRET'),
    MYSQL_HOST: getEnvVar('MYSQL_HOST')
  };

  console.log('📊 Configuration initialized with', Object.keys(config).length, 'variables');
  return config;
};

// Create environment configuration object
export const envConfig: EnvConfig = initializeEnvConfig();

// Helper functions
export const envHelpers = {
  // Check if all required WooCommerce credentials are available
  hasWooCommerceCredentials: (): boolean => {
    return !!(envConfig.WOOCOMMERCE_CONSUMER_KEY && envConfig.WOOCOMMERCE_CONSUMER_SECRET);
  },

  // Check if WordPress JWT credentials are available
  hasWordPressJWTCredentials: (): boolean => {
    return !!envConfig.JWT_AUTH_SECRET_KEY;
  },

  // Get WooCommerce credentials
  getWooCommerceCredentials: (): { consumer_key: string; consumer_secret: string } | null => {
    if (!envConfig.WOOCOMMERCE_CONSUMER_KEY || !envConfig.WOOCOMMERCE_CONSUMER_SECRET) {
      return null;
    }
    return {
      consumer_key: envConfig.WOOCOMMERCE_CONSUMER_KEY,
      consumer_secret: envConfig.WOOCOMMERCE_CONSUMER_SECRET
    };
  },

  // Get masked credential preview (for debugging)
  getMaskedCredentials: (): Record<string, string> => {
    const maskCredential = (credential?: string): string => {
      if (!credential) return 'Not configured';
      if (credential.length <= 8) return '***';
      return `${credential.substring(0, 4)}...${credential.slice(-4)}`;
    };

    return {
      WOOCOMMERCE_CONSUMER_KEY: maskCredential(envConfig.WOOCOMMERCE_CONSUMER_KEY),
      WOOCOMMERCE_CONSUMER_SECRET: maskCredential(envConfig.WOOCOMMERCE_CONSUMER_SECRET),
      WOOCOMMERCE_WEBHOOK_SECRET: maskCredential(envConfig.WOOCOMMERCE_WEBHOOK_SECRET),
      JWT_AUTH_SECRET_KEY: maskCredential(envConfig.JWT_AUTH_SECRET_KEY),
      CONSUMER_KEY: maskCredential(envConfig.CONSUMER_KEY),
      CONSUMER_SECRET: maskCredential(envConfig.CONSUMER_SECRET)
    };
  },

  // Log environment configuration (safely)
  logEnvStatus: (): void => {
    console.log('🔧 ===== ENVIRONMENT CONFIGURATION STATUS =====');
    console.log('🛠️ Environment Type:', isBrowser ? 'Browser' : 'Server');
    console.log('📦 Process Available:', isNode ? '✅' : '❌');
    console.log('🌍 Window Available:', isBrowser ? '✅' : '❌');
    console.log('📊 Configuration Status:');
    
    const maskedCreds = envHelpers.getMaskedCredentials();
    Object.entries(maskedCreds).forEach(([key, value]) => {
      const status = value === 'Not configured' ? '❌' : '✅';
      console.log(`   ${status} ${key}: ${value}`);
    });
    
    console.log('🔗 WooCommerce Ready:', envHelpers.hasWooCommerceCredentials() ? '✅' : '❌');
    console.log('🔐 WordPress JWT Ready:', envHelpers.hasWordPressJWTCredentials() ? '✅' : '❌');
    console.log('=====================================');
  },

  // Initialize window.ENV for runtime configuration (browser-safe)
  initializeWindowEnv: (): void => {
    if (!isBrowser) {
      console.log('🚫 Not in browser environment, skipping window.ENV initialization');
      return;
    }

    try {
      // Initialize window.ENV if it doesn't exist
      if (!(window as any).ENV) {
        (window as any).ENV = {};
        console.log('🌐 Initialized empty window.ENV object');
      }
      
      // Only attempt to copy from process.env if we're in a Node.js environment
      // In pure browser environments, we rely on window.ENV being set by build tools or server
      if (isNode && typeof process !== 'undefined' && process.env) {
        console.log('📋 Copying environment variables from process.env to window.ENV');
        
        // Environment variables that should be available to the frontend
        const frontendEnvVars = [
          'WOOCOMMERCE_CONSUMER_KEY',
          'WOOCOMMERCE_CONSUMER_SECRET', 
          'WOOCOMMERCE_WEBHOOK_SECRET',
          'WORDPRESS_BASE_URL',
          'JWT_AUTH_SECRET_KEY',
          'CONSUMER_KEY',
          'CONSUMER_SECRET',
          'REACT_APP_WC_CONSUMER_KEY',
          'REACT_APP_WC_CONSUMER_SECRET',
          'REACT_APP_WORDPRESS_URL',
          'REACT_APP_JWT_SECRET_KEY',
          'WC_CONSUMER_KEY',
          'WC_CONSUMER_SECRET',
          'WORDPRESS_URL'
        ];

        let copiedCount = 0;
        frontendEnvVars.forEach(varName => {
          try {
            if (typeof process !== 'undefined' && process.env && process.env[varName] && !(window as any).ENV[varName]) {
              (window as any).ENV[varName] = process.env[varName];
              copiedCount++;
            }
          } catch (error) {
            console.warn(`⚠️ Could not copy ${varName} to window.ENV:`, error);
          }
        });

        console.log(`✅ Copied ${copiedCount} environment variables to window.ENV`);
      } else {
        console.log('📝 Running in pure browser environment - relying on pre-configured window.ENV');
        console.log('🔧 Available window.ENV keys:', Object.keys((window as any).ENV || {}));
      }

    } catch (error) {
      console.error('❌ Error initializing window.ENV:', error);
    }
  },

  // Get current environment info
  getEnvironmentInfo: () => {
    return {
      isBrowser,
      isNode,
      hasWindowEnv: isBrowser && typeof window !== 'undefined' && !!(window as any).ENV,
      windowEnvKeys: isBrowser && typeof window !== 'undefined' ? Object.keys((window as any).ENV || {}) : [],
      processEnvAvailable: isNode,
      configuredVariables: Object.entries(envConfig).filter(([_, value]) => !!value).length
    };
  },

  // Test environment variable access
  testEnvAccess: (): { success: boolean; details: any } => {
    try {
      const info = envHelpers.getEnvironmentInfo();
      const testResults = {
        canAccessWindow: isBrowser,
        canAccessProcess: isNode,
        windowEnvSet: info.hasWindowEnv,
        variablesFound: info.configuredVariables,
        totalVariables: Object.keys(envConfig).length,
        maskedCredentials: envHelpers.getMaskedCredentials()
      };

      console.log('🧪 Environment access test results:', testResults);

      return {
        success: true,
        details: testResults
      };
    } catch (error) {
      console.error('❌ Environment access test failed:', error);
      return {
        success: false,
        details: { error: error instanceof Error ? error.message : 'Unknown error' }
      };
    }
  }
};

// Auto-initialize window.ENV on import (in browser) - with error handling
try {
  if (isBrowser) {
    envHelpers.initializeWindowEnv();
  }
} catch (error) {
  console.error('❌ Failed to auto-initialize window.ENV:', error);
}

// Log current status - with error handling
try {
  envHelpers.logEnvStatus();
} catch (error) {
  console.error('❌ Failed to log environment status:', error);
}

export default envConfig;