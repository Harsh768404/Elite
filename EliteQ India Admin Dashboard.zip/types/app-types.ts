export interface ConnectionStatus {
  wordpress: boolean;
  woocommerce: boolean;
  woocommercePermissions: boolean;
  wpUsersPermissions: boolean;
  webhooks: boolean;
  jwt: boolean;
}

export interface UserInfo {
  id: number;
  username: string;
  display_name: string;
  user_email: string;
  user_type: 'administrator' | 'vendor' | 'customer' | 'unknown';
  roles: string[];
  avatar_urls?: { [key: string]: string };
  vendor_data?: any;
  billing_address?: any;
  profile_complete: boolean;
  last_fetched: Date;
}

export interface CurrentUser {
  name: string;
  email: string;
  role: string;
  avatar: string | null;
  isVendor: boolean;
  isAdmin: boolean;
  profileComplete: boolean;
}

export interface ConnectionInfo {
  color: string;
  text: string;
  description: string;
}