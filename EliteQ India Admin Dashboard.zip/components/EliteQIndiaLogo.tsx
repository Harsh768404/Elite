import React from 'react';
import { Zap, ShoppingBag, Shield } from 'lucide-react';

interface EliteQIndiaLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'full' | 'icon' | 'text';
  className?: string;
  showTagline?: boolean;
}

export const EliteQIndiaLogo: React.FC<EliteQIndiaLogoProps> = ({
  size = 'md',
  variant = 'full',
  className = '',
  showTagline = false
}) => {
  const sizes = {
    sm: { container: 'h-8', icon: 'h-5 w-5', text: 'text-lg', tagline: 'text-xs' },
    md: { container: 'h-12', icon: 'h-7 w-7', text: 'text-2xl', tagline: 'text-sm' },
    lg: { container: 'h-16', icon: 'h-10 w-10', text: 'text-3xl', tagline: 'text-base' },
    xl: { container: 'h-20', icon: 'h-12 w-12', text: 'text-4xl', tagline: 'text-lg' }
  };

  const currentSize = sizes[size];

  const LogoIcon = () => (
    <div className="relative">
      {/* Main container with premium gradient */}
      <div className={`${currentSize.container} aspect-square bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 rounded-xl shadow-lg flex items-center justify-center relative overflow-hidden`}>
        {/* Background pattern */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="absolute -top-2 -right-2 w-8 h-8 bg-white/5 rounded-full"></div>
        <div className="absolute -bottom-1 -left-1 w-6 h-6 bg-white/5 rounded-full"></div>
        
        {/* Main icon - Electronic/Shopping theme */}
        <div className="relative z-10 flex items-center justify-center">
          <Zap className={`${currentSize.icon} text-white drop-shadow-sm`} />
          <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-orange-400 rounded-full shadow-sm animate-pulse"></div>
        </div>
      </div>
      
      {/* Premium indicator dot */}
      <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-br from-green-400 to-green-500 rounded-full border-2 border-white shadow-sm flex items-center justify-center">
        <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
      </div>
    </div>
  );

  const LogoText = () => (
    <div className="flex flex-col">
      <div className={`${currentSize.text} font-bold bg-gradient-to-r from-blue-800 via-blue-700 to-blue-600 bg-clip-text text-transparent leading-tight`}>
        EliteQ
        <span className="ml-1 text-orange-500 font-extrabold">India</span>
      </div>
      {showTagline && (
        <div className={`${currentSize.tagline} text-gray-600 dark:text-gray-400 font-medium leading-tight mt-0.5`}>
          Trusted Electronics Marketplace
        </div>
      )}
    </div>
  );

  if (variant === 'icon') {
    return (
      <div className={`flex items-center ${className}`}>
        <LogoIcon />
      </div>
    );
  }

  if (variant === 'text') {
    return (
      <div className={`flex items-center ${className}`}>
        <LogoText />
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <LogoIcon />
      <LogoText />
    </div>
  );
};

// Compact navbar version
export const EliteQNavbarLogo: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="h-8 w-8 bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 rounded-lg shadow-md flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <Zap className="h-4 w-4 text-white drop-shadow-sm" />
        <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-orange-400 rounded-full animate-pulse"></div>
      </div>
      <div className="flex flex-col">
        <div className="text-lg font-bold bg-gradient-to-r from-blue-800 to-blue-600 bg-clip-text text-transparent leading-none">
          EliteQ<span className="text-orange-500">India</span>
        </div>
        <div className="text-xs text-gray-500 dark:text-gray-400 leading-none">Electronics</div>
      </div>
    </div>
  );
};

export default EliteQIndiaLogo;