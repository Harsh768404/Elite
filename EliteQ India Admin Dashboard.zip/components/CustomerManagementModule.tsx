import React, { useState, useEffect } from 'react';
import { 
  Users, Search, Filter, Eye, Edit, Mail, 
  Download, RefreshCw, Loader2, AlertTriangle, 
  UserCheck, Phone, MapPin, Calendar, ShoppingBag,
  DollarSign, Star, Shield
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Alert, AlertDescription } from './ui/alert';
import { Skeleton } from './ui/skeleton';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';

interface Customer {
  id: number;
  date_created: string;
  date_created_gmt: string;
  date_modified: string;
  date_modified_gmt: string;
  email: string;
  first_name: string;
  last_name: string;
  role: string;
  username: string;
  billing: {
    first_name: string;
    last_name: string;
    company: string;
    address_1: string;
    address_2: string;
    city: string;
    state: string;
    postcode: string;
    country: string;
    email: string;
    phone: string;
  };
  shipping: {
    first_name: string;
    last_name: string;
    company: string;
    address_1: string;
    address_2: string;
    city: string;
    state: string;
    postcode: string;
    country: string;
  };
  is_paying_customer: boolean;
  avatar_url: string;
  meta_data: Array<{
    id: number;
    key: string;
    value: any;
  }>;
}

interface CustomerStats {
  total: number;
  payingCustomers: number;
  newThisMonth: number;
  totalOrders: number;
  averageOrderValue: number;
}

interface CustomerManagementModuleProps {
  userRole: string;
}

const CustomerManagementModule: React.FC<CustomerManagementModuleProps> = ({ userRole }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState<CustomerStats>({
    total: 0,
    payingCustomers: 0,
    newThisMonth: 0,
    totalOrders: 0,
    averageOrderValue: 0
  });

  const customersPerPage = 20;

  // Fetch customers from WooCommerce API
  const fetchCustomers = async (page = 1, search = '', role = 'all') => {
    try {
      setLoading(page === 1);
      setError(null);

      // Get credentials from environment
      const baseUrl = (window as any).ENV?.WORDPRESS_BASE_URL || 'https://eliteq.in';
      const consumerKey = (window as any).ENV?.WOOCOMMERCE_CONSUMER_KEY;
      const consumerSecret = (window as any).ENV?.WOOCOMMERCE_CONSUMER_SECRET;

      if (!consumerKey || !consumerSecret) {
        throw new Error('WooCommerce credentials not found');
      }

      // Build API parameters
      const params = new URLSearchParams({
        consumer_key: consumerKey,
        consumer_secret: consumerSecret,
        page: page.toString(),
        per_page: customersPerPage.toString(),
        orderby: 'date_registered',
        order: 'desc'
      });

      if (search.trim()) {
        params.append('search', search.trim());
      }

      if (role !== 'all') {
        params.append('role', role);
      }

      const response = await fetch(`${baseUrl}/wp-json/wc/v3/customers?${params}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const totalCustomers = parseInt(response.headers.get('X-WP-Total') || '0');
      const totalPagesCount = parseInt(response.headers.get('X-WP-TotalPages') || '1');

      setCustomers(data);
      setTotalPages(totalPagesCount);

      // Calculate stats
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      
      const newStats: CustomerStats = {
        total: totalCustomers,
        payingCustomers: data.filter((c: Customer) => c.is_paying_customer).length,
        newThisMonth: data.filter((c: Customer) => {
          const customerDate = new Date(c.date_created);
          return customerDate.getMonth() === currentMonth && customerDate.getFullYear() === currentYear;
        }).length,
        totalOrders: 0, // Would need separate API call to calculate
        averageOrderValue: 0 // Would need separate API call to calculate
      };
      setStats(newStats);

      console.log('✅ Customers loaded successfully:', {
        count: data.length,
        total: totalCustomers,
        pages: totalPagesCount,
        stats: newStats
      });

    } catch (error) {
      console.error('❌ Failed to fetch customers:', error);
      setError(error instanceof Error ? error.message : 'Failed to fetch customers');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchCustomers(currentPage, searchTerm, roleFilter);
  }, [currentPage, roleFilter]);

  // Search handler with debouncing
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchTerm !== '') {
        setCurrentPage(1);
        fetchCustomers(1, searchTerm, roleFilter);
      } else if (searchTerm === '') {
        fetchCustomers(currentPage, '', roleFilter);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchTerm]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchCustomers(currentPage, searchTerm, roleFilter);
  };

  const handleCustomerAction = (customerId: number, action: string) => {
    console.log(`Customer ${action} action for ID:`, customerId);
    // Implement actions based on the action type
    switch (action) {
      case 'view':
        alert(`View customer details for ID: ${customerId}`);
        break;
      case 'edit':
        alert(`Edit customer for ID: ${customerId}`);
        break;
      case 'suspend':
        alert(`Suspend customer for ID: ${customerId}`);
        break;
      default:
        break;
    }
  };

  const getRoleBadgeVariant = (role: string) => {
    switch (role.toLowerCase()) {
      case 'customer':
        return 'default';
      case 'subscriber':
        return 'secondary';
      case 'administrator':
        return 'destructive';
      case 'shop_manager':
        return 'outline';
      default:
        return 'outline';
    }
  };

  const getCustomerName = (customer: Customer) => {
    if (customer.first_name || customer.last_name) {
      return `${customer.first_name || ''} ${customer.last_name || ''}`.trim();
    }
    return customer.username || customer.email;
  };

  const getCustomerLocation = (customer: Customer) => {
    const { billing } = customer;
    if (billing.city && billing.state) {
      return `${billing.city}, ${billing.state}`;
    } else if (billing.city || billing.state) {
      return billing.city || billing.state;
    } else if (billing.country) {
      return billing.country;
    }
    return 'Location not provided';
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return 'Invalid date';
    }
  };

  if (loading && customers.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Customer Management</h2>
            <p className="text-muted-foreground">Manage your store customers</p>
          </div>
          <Skeleton className="h-10 w-32" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>

        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48" />
          </CardHeader>
          <CardContent className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Users className="w-6 h-6 text-blue-600" />
            Customer Management
          </h2>
          <p className="text-muted-foreground">
            Manage your WooCommerce customers and their information
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleRefresh}
            disabled={refreshing}
          >
            {refreshing ? (
              <Loader2 className="w-4 h-4 animate-spin mr-1" />
            ) : (
              <RefreshCw className="w-4 h-4 mr-1" />
            )}
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-1" />
            Export
          </Button>
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription>
            <strong>Error loading customers:</strong> {error}
          </AlertDescription>
        </Alert>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm text-muted-foreground">Total Customers</p>
                <p className="text-2xl font-bold">{stats.total.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm text-muted-foreground">Paying Customers</p>
                <p className="text-2xl font-bold">{stats.payingCustomers.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-orange-600" />
              <div>
                <p className="text-sm text-muted-foreground">New This Month</p>
                <p className="text-2xl font-bold">{stats.newThisMonth.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-sm text-muted-foreground">Total Orders</p>
                <p className="text-2xl font-bold">{stats.totalOrders.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-indigo-600" />
              <div>
                <p className="text-sm text-muted-foreground">Avg Order Value</p>
                <p className="text-2xl font-bold">₹{stats.averageOrderValue.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search customers by name, email, or username..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="customer">Customer</SelectItem>
                <SelectItem value="subscriber">Subscriber</SelectItem>
                <SelectItem value="shop_manager">Shop Manager</SelectItem>
                <SelectItem value="administrator">Administrator</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Customers Table */}
      <Card>
        <CardHeader>
          <CardTitle>Customers List</CardTitle>
          <CardDescription>
            Showing {customers.length} of {stats.total} customers
          </CardDescription>
        </CardHeader>
        <CardContent>
          {customers.length === 0 ? (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground">No customers found</p>
            </div>
          ) : (
            <div className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Customer</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Registered</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customers.map((customer) => (
                    <TableRow key={customer.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white font-medium">
                            {getCustomerName(customer)[0]?.toUpperCase() || 'C'}
                          </div>
                          <div>
                            <div className="font-medium">{getCustomerName(customer)}</div>
                            <div className="text-sm text-muted-foreground">
                              @{customer.username} (ID: {customer.id})
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Mail className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm">{customer.email}</span>
                          </div>
                          {customer.billing.phone && (
                            <div className="flex items-center gap-2">
                              <Phone className="w-4 h-4 text-muted-foreground" />
                              <span className="text-sm">{customer.billing.phone}</span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getRoleBadgeVariant(customer.role)}>
                          <Shield className="w-3 h-3 mr-1" />
                          {customer.role.charAt(0).toUpperCase() + customer.role.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{getCustomerLocation(customer)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {customer.is_paying_customer ? (
                            <Badge variant="default" className="bg-green-100 text-green-700 border-green-300">
                              <ShoppingBag className="w-3 h-3 mr-1" />
                              Paying Customer
                            </Badge>
                          ) : (
                            <Badge variant="outline">
                              New Customer
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">{formatDate(customer.date_created)}</div>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              Actions
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleCustomerAction(customer.id, 'view')}>
                              <Eye className="w-4 h-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleCustomerAction(customer.id, 'edit')}>
                              <Edit className="w-4 h-4 mr-2" />
                              Edit Customer
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleCustomerAction(customer.id, 'suspend')}>
                              <AlertTriangle className="w-4 h-4 mr-2" />
                              Suspend
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    Page {currentPage} of {totalPages}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1 || loading}
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                      disabled={currentPage === totalPages || loading}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CustomerManagementModule;