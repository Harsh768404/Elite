import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  Clock, 
  Pause, 
  Truck, 
  CheckCircle, 
  XCircle, 
  CreditCard,
  Zap,
  RefreshCw,
  AlertTriangle,
  Info,
  Sparkles,
  Activity
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Skeleton } from './ui/skeleton';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';

// Don't Touch – EliteQ Admin Rule: Order status interface maintained as-is
interface OrderStatusData {
  status: string;
  label: string;
  count: number;
  icon: React.ElementType;
  primaryColor: string;
  secondaryColor: string;
  bgGradient: string;
  accentColor: string;
  borderColor: string;
  clickable?: boolean;
}

interface OrderStatusOverviewSectionProps {
  userRole: 'admin' | 'vendor';
}

export function OrderStatusOverviewSection({ userRole }: OrderStatusOverviewSectionProps) {
  const [statusData, setStatusData] = useState<OrderStatusData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Don't Touch – EliteQ Admin Rule: Premium order status definitions with futuristic colors
  const orderStatuses: OrderStatusData[] = [
    {
      status: 'new',
      label: 'New Orders',
      count: 0,
      icon: ShoppingBag,
      primaryColor: '#1e40af', // Blue
      secondaryColor: '#3b82f6',
      bgGradient: 'linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #60a5fa 100%)',
      accentColor: 'rgba(30, 64, 175, 0.2)',
      borderColor: 'border-blue-200 dark:border-blue-700',
      clickable: true
    },
    {
      status: 'processing',
      label: 'Processing',
      count: 0,
      icon: Clock,
      primaryColor: '#059669', // Emerald
      secondaryColor: '#10b981',
      bgGradient: 'linear-gradient(135deg, #059669 0%, #10b981 50%, #34d399 100%)',
      accentColor: 'rgba(5, 150, 105, 0.2)',
      borderColor: 'border-emerald-200 dark:border-emerald-700',
      clickable: true
    },
    {
      status: 'on-hold',
      label: 'On-Hold',
      count: 0,
      icon: Pause,
      primaryColor: '#d97706', // Amber
      secondaryColor: '#f59e0b',
      bgGradient: 'linear-gradient(135deg, #d97706 0%, #f59e0b 50%, #fbbf24 100%)',
      accentColor: 'rgba(217, 119, 6, 0.2)',
      borderColor: 'border-amber-200 dark:border-amber-700',
      clickable: true
    },
    {
      status: 'shipped',
      label: 'Shipped',
      count: 0,
      icon: Truck,
      primaryColor: '#7c3aed', // Violet
      secondaryColor: '#8b5cf6',
      bgGradient: 'linear-gradient(135deg, #7c3aed 0%, #8b5cf6 50%, #a78bfa 100%)',
      accentColor: 'rgba(124, 58, 237, 0.2)',
      borderColor: 'border-violet-200 dark:border-violet-700',
      clickable: true
    },
    {
      status: 'delivered',
      label: 'Delivered',
      count: 0,
      icon: CheckCircle,
      primaryColor: '#0284c7', // Sky
      secondaryColor: '#0ea5e9',
      bgGradient: 'linear-gradient(135deg, #0284c7 0%, #0ea5e9 50%, #38bdf8 100%)',
      accentColor: 'rgba(2, 132, 199, 0.2)',
      borderColor: 'border-sky-200 dark:border-sky-700',
      clickable: true
    },
    {
      status: 'cancelled',
      label: 'Cancelled',
      count: 0,
      icon: XCircle,
      primaryColor: '#dc2626', // Red
      secondaryColor: '#ef4444',
      bgGradient: 'linear-gradient(135deg, #dc2626 0%, #ef4444 50%, #f87171 100%)',
      accentColor: 'rgba(220, 38, 38, 0.2)',
      borderColor: 'border-red-200 dark:border-red-700',
      clickable: true
    },
    {
      status: 'pending-payment',
      label: 'Pending Payment',
      count: 0,
      icon: CreditCard,
      primaryColor: '#ca8a04', // Yellow
      secondaryColor: '#eab308',
      bgGradient: 'linear-gradient(135deg, #ca8a04 0%, #eab308 50%, #facc15 100%)',
      accentColor: 'rgba(202, 138, 4, 0.2)',
      borderColor: 'border-yellow-200 dark:border-yellow-700',
      clickable: true
    },
    {
      status: 'failed',
      label: 'Failed',
      count: 0,
      icon: Zap, // Boom icon equivalent
      primaryColor: '#92400e', // Brown
      secondaryColor: '#b45309',
      bgGradient: 'linear-gradient(135deg, #92400e 0%, #b45309 50%, #d97706 100%)',
      accentColor: 'rgba(146, 64, 14, 0.2)',
      borderColor: 'border-orange-200 dark:border-orange-700',
      clickable: true
    }
  ];

  // Don't Touch – EliteQ Admin Rule: API data loading with real-time updates
  useEffect(() => {
    loadOrderStatusData();
    
    // Set up real-time updates every 2 minutes for order status
    const interval = setInterval(() => {
      if (!isLoading && !isRefreshing) {
        loadOrderStatusData(true);
      }
    }, 120000); // 2 minutes

    return () => clearInterval(interval);
  }, [userRole]);

  const loadOrderStatusData = async (isBackgroundUpdate = false) => {
    try {
      if (!isBackgroundUpdate) {
        setIsLoading(true);
      }
      setHasError(false);

      // Don't Touch – EliteQ Admin Rule: Simulate API call with realistic delay
      await new Promise(resolve => setTimeout(resolve, isBackgroundUpdate ? 300 : 1200));
      
      // Don't Touch – EliteQ Admin Rule: In real implementation, this would call WooCommerce Orders API
      // Mock data with some realistic counts for demonstration
      const updatedStatusData = orderStatuses.map(status => ({
        ...status,
        count: Math.floor(Math.random() * 25) // Random counts for demo
      }));

      setStatusData(updatedStatusData);
      setLastUpdated(new Date());
      
      console.log('📦 Order status data loaded successfully');
    } catch (error) {
      console.error('❌ Failed to load order status data:', error);
      setHasError(true);
      setStatusData(orderStatuses); // Fallback to default data
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    loadOrderStatusData();
  };

  const handleStatusCardClick = (status: string) => {
    if (statusData.find(s => s.status === status)?.clickable) {
      console.log(`🔍 Navigating to ${status} orders view`);
      // Don't Touch – EliteQ Admin Rule: Future detail view navigation would go here
      alert(`Future: Navigate to ${status} orders detail view`);
    }
  };

  const getTotalOrders = () => {
    return statusData.reduce((total, status) => total + status.count, 0);
  };

  const getTimeSinceUpdate = () => {
    const now = new Date();
    const diffMs = now.getTime() - lastUpdated.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins === 1) return '1 min ago';
    return `${diffMins} mins ago`;
  };

  // Don't Touch – EliteQ Admin Rule: Premium loading state with 3D skeleton cards
  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <Skeleton className="h-6 w-44 mb-2" />
            <Skeleton className="h-4 w-60" />
          </div>
          <Skeleton className="h-8 w-20" />
        </div>
        
        {/* Premium loading skeleton - 2 cards per row on desktop, 1 on mobile */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(8)].map((_, index) => (
            <div 
              key={index} 
              className="h-[130px] p-6 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900 rounded-2xl shadow-lg animate-pulse"
              style={{
                transform: 'perspective(1000px) rotateX(3deg)',
                boxShadow: '0 15px 35px -5px rgba(0, 0, 0, 0.1), 0 8px 20px -3px rgba(0, 0, 0, 0.05)'
              }}
            >
              <div className="flex items-center h-full">
                <Skeleton className="h-12 w-12 rounded-xl mr-4" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-6 w-12 mb-2" />
                  <Skeleton className="h-3 w-20" />
                </div>
                <div className="ml-auto">
                  <Skeleton className="h-3 w-3 rounded-full" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Don't Touch – EliteQ Admin Rule: Premium error state
  if (hasError) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Order Status Overview
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Premium 3D order status tracking
            </p>
          </div>
        </div>
        
        <Card 
          className="h-[130px] p-8 border-red-200 dark:border-red-800 bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/10 dark:to-red-800/20 rounded-2xl shadow-lg"
          style={{
            transform: 'perspective(1000px) rotateX(3deg)',
            boxShadow: '0 20px 40px -10px rgba(239, 68, 68, 0.2), 0 10px 20px -5px rgba(239, 68, 68, 0.1)'
          }}
        >
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="relative mb-4">
                <AlertTriangle className="w-10 h-10 text-red-500 mx-auto" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-400 rounded-full animate-ping"></div>
              </div>
              <p className="text-red-700 dark:text-red-400 font-medium mb-3">
                Status info unavailable. Retry.
              </p>
              <Button 
                onClick={handleRefresh}
                disabled={isRefreshing}
                variant="outline"
                size="sm"
                className="border-red-300 text-red-700 hover:bg-red-100 dark:border-red-700 dark:text-red-400 rounded-xl"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                Retry
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  // Don't Touch – EliteQ Admin Rule: Premium empty state
  if (statusData.length === 0) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Order Status Overview
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Premium 3D order status tracking
            </p>
          </div>
        </div>
        
        <Card 
          className="h-[130px] p-8 border-dashed border-2 border-gray-300 dark:border-gray-600 rounded-2xl bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900"
          style={{
            transform: 'perspective(1000px) rotateX(3deg)',
            boxShadow: '0 15px 30px -5px rgba(0, 0, 0, 0.1), 0 5px 15px -3px rgba(0, 0, 0, 0.05)'
          }}
        >
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="relative mb-4">
                <ShoppingBag className="w-10 h-10 text-gray-400 mx-auto" />
                <Sparkles className="w-4 h-4 text-blue-400 absolute -top-1 -right-1 animate-pulse" />
              </div>
              <p className="text-gray-600 dark:text-gray-400 font-medium">
                No orders in this status yet.
              </p>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="mb-8">
      {/* Premium Section Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between mb-8 space-y-3 lg:space-y-0">
        <div>
          <div className="flex items-center space-x-3 mb-2">
            <div className="p-2 bg-gradient-to-r from-green-500 to-blue-600 rounded-xl shadow-lg">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              Order Status Overview
            </h2>
          </div>
          <div className="flex items-center space-x-3">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Premium 3D order status tracking
            </p>
            <Badge variant="secondary" className="text-xs px-3 py-1 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/20 dark:to-purple-900/20">
              {getTotalOrders()} Orders
            </Badge>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center space-x-2 px-3 py-1 bg-gradient-to-r from-green-100 to-blue-100 dark:from-green-900/20 dark:to-blue-900/20 rounded-full cursor-help">
                  <Info className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                  <span className="text-xs text-gray-600 dark:text-gray-400">
                    Updated {getTimeSinceUpdate()}
                  </span>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Last updated: {lastUpdated.toLocaleString()}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <Button
            onClick={handleRefresh}
            disabled={isRefreshing}
            variant="outline"
            size="sm"
            className="h-9 px-4 rounded-xl border-green-200 dark:border-green-800 hover:bg-green-50 dark:hover:bg-green-900/20"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Premium 3D Order Status Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {statusData.map((statusItem, index) => {
          const Icon = statusItem.icon;
          
          return (
            <Card 
              key={statusItem.status}
              className={`group relative h-[130px] p-0 overflow-hidden rounded-2xl border-0 transition-all duration-500 ease-out animate-fade-in
                ${statusItem.clickable 
                  ? 'cursor-pointer' 
                  : 'cursor-default'
                }
              `}
              style={{ 
                animationDelay: `${index * 0.1}s`,
                background: statusItem.bgGradient,
                transform: 'perspective(1000px) rotateX(3deg)',
                boxShadow: `0 15px 35px -5px ${statusItem.accentColor}, 0 8px 20px -3px rgba(0, 0, 0, 0.1)`,
                transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)'
              }}
              onClick={() => handleStatusCardClick(statusItem.status)}
              onMouseEnter={(e) => {
                if (statusItem.clickable) {
                  e.currentTarget.style.transform = 'perspective(1000px) rotateX(6deg) translateY(-6px)';
                  e.currentTarget.style.boxShadow = `0 25px 50px -5px ${statusItem.accentColor}, 0 15px 30px -3px rgba(0, 0, 0, 0.15)`;
                }
              }}
              onMouseLeave={(e) => {
                if (statusItem.clickable) {
                  e.currentTarget.style.transform = 'perspective(1000px) rotateX(3deg)';
                  e.currentTarget.style.boxShadow = `0 15px 35px -5px ${statusItem.accentColor}, 0 8px 20px -3px rgba(0, 0, 0, 0.1)`;
                }
              }}
            >
              {/* Animated Background Elements */}
              <div className="absolute inset-0 overflow-hidden">
                <div className="absolute -top-8 -right-8 w-24 h-24 bg-white/10 rounded-full animate-float"></div>
                <div className="absolute -bottom-6 -left-6 w-20 h-20 bg-white/5 rounded-full animate-float" style={{ animationDelay: '1.5s' }}></div>
                <div className="absolute top-1/3 left-1/3 w-32 h-32 bg-white/5 rounded-full animate-pulse"></div>
              </div>

              {/* Content Layer */}
              <div className="relative z-10 flex items-center h-full p-6">
                {/* Icon Section */}
                <div className="flex-shrink-0 mr-5">
                  <div 
                    className={`w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center shadow-lg 
                      ${statusItem.clickable ? 'group-hover:scale-110' : ''} 
                      transition-transform duration-300`}
                    style={{
                      background: 'rgba(255, 255, 255, 0.15)',
                      backdropFilter: 'blur(10px)',
                      border: '1px solid rgba(255, 255, 255, 0.2)'
                    }}
                  >
                    <Icon className="w-7 h-7 text-white drop-shadow-sm" />
                  </div>
                </div>
                
                {/* Content Section */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-medium text-white/80 mb-1 truncate tracking-wide">
                    {statusItem.label}
                  </h3>
                  <div className="text-3xl font-bold text-white mb-2 drop-shadow-sm tracking-tight">
                    {statusItem.count}
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 rounded-full bg-white/60 shadow-sm"></div>
                    <span className="text-xs text-white/70 font-medium">
                      {statusItem.status.replace('-', ' ')}
                    </span>
                  </div>
                </div>
                
                {/* Status Indicator */}
                <div className="flex-shrink-0 ml-4">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div 
                          className={`w-4 h-4 rounded-full bg-white/80 shadow-lg 
                            ${statusItem.clickable ? 'group-hover:scale-125' : ''} 
                            transition-transform duration-300`}
                          style={{
                            background: 'rgba(255, 255, 255, 0.8)',
                            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)'
                          }}
                        ></div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Click to view {statusItem.label.toLowerCase()}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>

              {/* Shimmer Effect */}
              {statusItem.clickable && (
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <div 
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent transform -skew-x-12"
                    style={{
                      animation: 'shimmer 2s infinite'
                    }}
                  ></div>
                </div>
              )}

              {/* Floating Sparkles */}
              <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <Sparkles className="w-4 h-4 text-white/60 animate-pulse" />
              </div>
            </Card>
          );
        })}
      </div>

      {/* Premium Summary Stats */}
      <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div 
          className="text-center p-4 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800/50 dark:to-gray-900/50 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700"
          style={{
            transform: 'perspective(1000px) rotateX(2deg)',
            boxShadow: '0 8px 16px -4px rgba(0, 0, 0, 0.1)'
          }}
        >
          <div className="text-xl font-bold text-gray-900 dark:text-white">
            {getTotalOrders()}
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
            Total Orders
          </div>
        </div>
        
        <div 
          className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/10 dark:to-blue-800/20 rounded-xl shadow-lg border border-blue-200 dark:border-blue-700"
          style={{
            transform: 'perspective(1000px) rotateX(2deg)',
            boxShadow: '0 8px 16px -4px rgba(59, 130, 246, 0.2)'
          }}
        >
          <div className="text-xl font-bold text-blue-600 dark:text-blue-400">
            {statusData.filter(s => ['new', 'processing', 'shipped'].includes(s.status))
              .reduce((total, s) => total + s.count, 0)}
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
            Active
          </div>
        </div>
        
        <div 
          className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/10 dark:to-green-800/20 rounded-xl shadow-lg border border-green-200 dark:border-green-700"
          style={{
            transform: 'perspective(1000px) rotateX(2deg)',
            boxShadow: '0 8px 16px -4px rgba(34, 197, 94, 0.2)'
          }}
        >
          <div className="text-xl font-bold text-green-600 dark:text-green-400">
            {statusData.find(s => s.status === 'delivered')?.count || 0}
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
            Completed
          </div>
        </div>
        
        <div 
          className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/10 dark:to-purple-800/20 rounded-xl shadow-lg border border-purple-200 dark:border-purple-700"
          style={{
            transform: 'perspective(1000px) rotateX(2deg)',
            boxShadow: '0 8px 16px -4px rgba(147, 51, 234, 0.2)'
          }}
        >
          <div className="text-xl font-bold text-purple-600 dark:text-purple-400">
            {getTotalOrders() > 0 ? Math.round((statusData.find(s => s.status === 'delivered')?.count || 0) / getTotalOrders() * 100) : 0}%
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
            Success Rate
          </div>
        </div>
      </div>

      {/* Custom CSS for animations */}
      <style jsx>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%) skewX(-12deg); }
          100% { transform: translateX(200%) skewX(-12deg); }
        }
        
        @keyframes float {
          0%, 100% { 
            transform: translateY(0px) rotate(0deg); 
          }
          33% { 
            transform: translateY(-8px) rotate(3deg); 
          }
          66% { 
            transform: translateY(-4px) rotate(-2deg); 
          }
        }
      `}</style>
    </div>
  );
}