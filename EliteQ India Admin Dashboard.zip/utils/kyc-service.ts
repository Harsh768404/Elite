import { projectId, publicAnonKey } from './supabase/info';

// KYC Service for handling vendor KYC verification process
export interface KYCStatus {
  status: 'pending' | 'approved' | 'rejected' | 'not_submitted' | 'under_review';
  submittedAt?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  documents: {
    aadhaar: boolean;
    pan: boolean;
    bank_statement: boolean;
    gst_certificate: boolean;
    udyam_aadhar: boolean;
  };
}

export interface KYCDocument {
  id: string;
  name: string;
  file?: File;
  uploaded: boolean;
  progress: number;
  error?: string;
}

class KYCService {
  private baseUrl: string;
  private headers: HeadersInit;

  constructor() {
    this.baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-b399bee0`;
    this.headers = {
      'Authorization': `Bearer ${publicAnonKey}`,
      'Content-Type': 'application/json',
    };
  }

  /**
   * Get current KYC status for the vendor
   */
  async getKYCStatus(): Promise<KYCStatus> {
    try {
      const vendorId = this.getVendorId();
      const response = await fetch(`${this.baseUrl}/kyc/status/${vendorId}`, {
        method: 'GET',
        headers: this.headers,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Failed to fetch KYC status:', error);
      throw new Error('Failed to fetch KYC status');
    }
  }

  /**
   * Upload KYC documents
   */
  async uploadDocuments(documents: KYCDocument[]): Promise<{ success: boolean; message: string }> {
    try {
      const formData = new FormData();
      
      // Add each document to form data
      documents.forEach((doc) => {
        if (doc.file) {
          formData.append(doc.id, doc.file);
        }
      });

      // Add vendor information
      formData.append('vendor_id', this.getVendorId());
      formData.append('submission_timestamp', new Date().toISOString());

      const response = await fetch(`${this.baseUrl}/kyc/submit`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          // Don't set Content-Type for FormData, let browser set it with boundary
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result;
    } catch (error) {
      console.error('Failed to upload KYC documents:', error);
      throw new Error('Failed to upload documents. Please try again.');
    }
  }

  /**
   * Check if specific documents are required based on vendor type/location
   */
  async getRequiredDocuments(): Promise<string[]> {
    // This would typically be based on vendor location, business type, etc.
    return ['aadhaar', 'pan', 'bank_statement', 'gst_certificate'];
  }

  /**
   * Validate document file
   */
  validateDocument(file: File): { isValid: boolean; error?: string } {
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
    const maxSize = 2 * 1024 * 1024; // 2MB

    if (!allowedTypes.includes(file.type)) {
      return {
        isValid: false,
        error: 'Only PDF, JPG, and PNG files are allowed'
      };
    }

    if (file.size > maxSize) {
      return {
        isValid: false,
        error: 'File size must be less than 2MB'
      };
    }

    // Additional validations can be added here
    // e.g., image dimensions, PDF page count, etc.

    return { isValid: true };
  }

  /**
   * Get KYC submission history
   */
  async getKYCHistory(): Promise<Array<{
    submittedAt: string;
    status: string;
    reviewedAt?: string;
    documents: string[];
  }>> {
    try {
      const vendorId = this.getVendorId();
      const response = await fetch(`${this.baseUrl}/kyc/history/${vendorId}`, {
        method: 'GET',
        headers: this.headers,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Failed to fetch KYC history:', error);
      return [];
    }
  }

  /**
   * Resubmit rejected documents
   */
  async resubmitDocuments(documents: KYCDocument[]): Promise<{ success: boolean; message: string }> {
    // Similar to uploadDocuments but for resubmission
    return this.uploadDocuments(documents);
  }

  // Private helper methods
  private getVendorId(): string {
    // Get vendor ID from session, local storage, or context
    return 'vendor_123'; // Mock ID
  }



  /**
   * Send documents to secure storage/processing
   */
  private async sendToSecureStorage(formData: FormData): Promise<void> {
    // This would integrate with your secure file storage solution
    // e.g., AWS S3, Google Cloud Storage, etc.
    // and ensure proper encryption and access controls
  }

  /**
   * Notify relevant parties about KYC submission
   */
  private async notifyKYCTeam(vendorId: string, documents: string[]): Promise<void> {
    // Send notifications to KYC review team
    // This could be email, Slack, or internal notification system
  }
}

// Export singleton instance
export const kycService = new KYCService();

// Export types for use in components
export type { KYCStatus, KYCDocument };