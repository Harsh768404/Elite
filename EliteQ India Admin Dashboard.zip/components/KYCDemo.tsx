import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { KYCBanner } from './KYCBanner';
import { Settings, RefreshCw } from 'lucide-react';

interface KYCDemoProps {
  onClose?: () => void;
}

export const KYCDemo: React.FC<KYCDemoProps> = ({ onClose }) => {
  const [currentStatus, setCurrentStatus] = useState<'pending' | 'approved' | 'rejected' | 'not_submitted'>('pending');
  const [showDemo, setShowDemo] = useState(false);

  const handleDemoSubmit = async (documents: any[]) => {
    // Simulate successful submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    setCurrentStatus('under_review' as any);
    alert('Demo: Documents submitted successfully!');
  };

  const statusOptions = [
    { value: 'pending', label: 'Pending', color: 'bg-amber-100 text-amber-800' },
    { value: 'approved', label: 'Approved', color: 'bg-green-100 text-green-800' },
    { value: 'rejected', label: 'Rejected', color: 'bg-red-100 text-red-800' },
    { value: 'not_submitted', label: 'Not Submitted', color: 'bg-gray-100 text-gray-800' }
  ];

  if (!showDemo) {
    return (
      <Card className="mb-6 border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 flex items-center justify-center">
                <Settings className="h-5 w-5 text-white" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-blue-900">KYC Banner Demo</h4>
                <p className="text-sm text-blue-700">Test the KYC banner with different status states</p>
              </div>
            </div>
            <Button 
              onClick={() => setShowDemo(true)}
              variant="outline"
              className="border-blue-300 text-blue-700 hover:bg-blue-100"
            >
              View Demo
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6 mb-6">
      {/* Demo Controls */}
      <Card className="border-blue-200">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Settings className="h-5 w-5" />
              KYC Banner Demo Controls
            </CardTitle>
            <Button 
              onClick={() => setShowDemo(false)}
              variant="ghost" 
              size="sm"
              className="text-blue-600"
            >
              Hide Demo
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">
              Current KYC Status:
            </label>
            <div className="flex flex-wrap gap-2">
              {statusOptions.map((option) => (
                <Button
                  key={option.value}
                  onClick={() => setCurrentStatus(option.value as any)}
                  variant={currentStatus === option.value ? "default" : "outline"}
                  size="sm"
                  className={`${currentStatus === option.value ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge className={statusOptions.find(s => s.value === currentStatus)?.color}>
              {statusOptions.find(s => s.value === currentStatus)?.label}
            </Badge>
            <span className="text-sm text-gray-600">
              {currentStatus === 'pending' ? 'Banner will be shown' : 'Banner will be hidden'}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* KYC Banner Demo */}
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 bg-gray-50">
        <div className="flex items-center gap-2 mb-4">
          <RefreshCw className="h-4 w-4 text-gray-500" />
          <span className="text-sm font-medium text-gray-600">Live KYC Banner Preview:</span>
        </div>
        
        <div className="bg-white rounded-lg">
          <KYCBanner
            kycStatus={currentStatus}
            onSubmit={handleDemoSubmit}
            onClose={() => alert('Demo: Banner dismissed')}
          />
          
          {currentStatus !== 'pending' && (
            <div className="p-8 text-center text-gray-500">
              <p className="text-sm">
                KYC Banner is hidden for status: <strong>{currentStatus}</strong>
              </p>
              <p className="text-xs mt-1">
                Set status to "Pending" to see the banner
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Feature Showcase */}
      <Card>
        <CardHeader>
          <CardTitle className="text-gray-900">KYC Banner Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h5 className="font-semibold text-gray-800">✅ Core Features</h5>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Conditional display (only for pending KYC)</li>
                <li>• Expandable document upload form</li>
                <li>• File validation (PDF, JPG, PNG, 2MB limit)</li>
                <li>• Progress indicators for uploads</li>
                <li>• Real-time upload status feedback</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h5 className="font-semibold text-gray-800">🎨 Design Features</h5>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• EliteQ India branding (Royal Blue #0048ff)</li>
                <li>• Responsive mobile-friendly layout</li>
                <li>• Professional UI with smooth animations</li>
                <li>• Document type icons and validation badges</li>
                <li>• Security messaging and trust indicators</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};