import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  ShoppingCart, 
  Package, 
  Eye, 
  BarChart3, 
  FileText, 
  Tag, 
  Gift, 
  Users, 
  Trophy,
  RefreshCw,
  AlertTriangle,
  TrendingDown,
  Sparkles,
  Zap
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Skeleton } from './ui/skeleton';

// Don't Touch – EliteQ Admin Rule: API Integration maintained as-is
interface PerformanceMetric {
  id: string;
  title: string;
  value: string;
  change: number;
  changeType: 'increase' | 'decrease' | 'neutral';
  icon: React.ElementType;
  primaryColor: string;
  secondaryColor: string;
  bgGradient: string;
  accentColor: string;
  format: 'currency' | 'number' | 'percentage';
}

interface PerformanceOverviewSectionProps {
  userRole: 'admin' | 'vendor';
}

export function PerformanceOverviewSection({ userRole }: PerformanceOverviewSectionProps) {
  const [metrics, setMetrics] = useState<PerformanceMetric[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Don't Touch – EliteQ Admin Rule: Premium performance metrics with unique futuristic color schemes
  const performanceMetrics: PerformanceMetric[] = [
    {
      id: 'total_sales',
      title: 'Total Sales',
      value: '₹0.00',
      change: 0,
      changeType: 'neutral',
      icon: TrendingUp,
      primaryColor: '#6366f1', // Indigo
      secondaryColor: '#8b5cf6', // Violet
      bgGradient: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #a855f7 100%)',
      accentColor: 'rgba(99, 102, 241, 0.2)',
      format: 'currency'
    },
    {
      id: 'net_sales',
      title: 'Net Sales',
      value: '₹0.00',
      change: 0,
      changeType: 'neutral',
      icon: DollarSign,
      primaryColor: '#059669', // Emerald
      secondaryColor: '#0d9488', // Teal
      bgGradient: 'linear-gradient(135deg, #059669 0%, #0d9488 50%, #06b6d4 100%)',
      accentColor: 'rgba(5, 150, 105, 0.2)',
      format: 'currency'
    },
    {
      id: 'total_orders',
      title: 'Orders',
      value: '0',
      change: 0,
      changeType: 'neutral',
      icon: ShoppingCart,
      primaryColor: '#ea580c', // Orange
      secondaryColor: '#dc2626', // Red
      bgGradient: 'linear-gradient(135deg, #ea580c 0%, #dc2626 50%, #b91c1c 100%)',
      accentColor: 'rgba(234, 88, 12, 0.2)',
      format: 'number'
    },
    {
      id: 'products_sold',
      title: 'Products Sold',
      value: '0',
      change: 0,
      changeType: 'neutral',
      icon: Package,
      primaryColor: '#7c3aed', // Purple
      secondaryColor: '#9333ea', // Violet
      bgGradient: 'linear-gradient(135deg, #7c3aed 0%, #9333ea 50%, #a855f7 100%)',
      accentColor: 'rgba(124, 58, 237, 0.2)',
      format: 'number'
    },
    {
      id: 'visitors',
      title: 'Visitors',
      value: '1,721',
      change: 12.5,
      changeType: 'increase',
      icon: Eye,
      primaryColor: '#db2777', // Pink
      secondaryColor: '#e11d48', // Rose
      bgGradient: 'linear-gradient(135deg, #db2777 0%, #e11d48 50%, #f43f5e 100%)',
      accentColor: 'rgba(219, 39, 119, 0.2)',
      format: 'number'
    },
    {
      id: 'views',
      title: 'Views',
      value: '2,859',
      change: 8.7,
      changeType: 'increase',
      icon: BarChart3,
      primaryColor: '#0891b2', // Cyan
      secondaryColor: '#0284c7', // Sky
      bgGradient: 'linear-gradient(135deg, #0891b2 0%, #0284c7 50%, #0369a1 100%)',
      accentColor: 'rgba(8, 145, 178, 0.2)',
      format: 'number'
    },
    {
      id: 'marketplace_commission',
      title: 'Marketplace Comm.',
      value: 'N/A',
      change: 0,
      changeType: 'neutral',
      icon: FileText,
      primaryColor: '#84cc16', // Lime
      secondaryColor: '#65a30d', // Green
      bgGradient: 'linear-gradient(135deg, #84cc16 0%, #65a30d 50%, #16a34a 100%)',
      accentColor: 'rgba(132, 204, 22, 0.2)',
      format: 'currency'
    },
    {
      id: 'store_discount',
      title: 'Store Discount',
      value: 'N/A',
      change: 0,
      changeType: 'neutral',
      icon: Tag,
      primaryColor: '#92400e', // Amber
      secondaryColor: '#a16207', // Yellow
      bgGradient: 'linear-gradient(135deg, #92400e 0%, #a16207 50%, #ca8a04 100%)',
      accentColor: 'rgba(146, 64, 14, 0.2)',
      format: 'currency'
    },
    {
      id: 'marketplace_discount',
      title: 'Marketplace Discount',
      value: 'N/A',
      change: 0,
      changeType: 'neutral',
      icon: Gift,
      primaryColor: '#b91c1c', // Red
      secondaryColor: '#dc2626', // Red
      bgGradient: 'linear-gradient(135deg, #b91c1c 0%, #dc2626 50%, #ef4444 100%)',
      accentColor: 'rgba(185, 28, 28, 0.2)',
      format: 'currency'
    },
    {
      id: 'unique_customers',
      title: 'Unique Customers',
      value: '0',
      change: 0,
      changeType: 'neutral',
      icon: Users,
      primaryColor: '#4338ca', // Indigo
      secondaryColor: '#6366f1', // Indigo
      bgGradient: 'linear-gradient(135deg, #4338ca 0%, #6366f1 50%, #8b5cf6 100%)',
      accentColor: 'rgba(67, 56, 202, 0.2)',
      format: 'number'
    },
    {
      id: 'total_earnings',
      title: 'Total Earnings',
      value: 'N/A',
      change: 0,
      changeType: 'neutral',
      icon: Trophy,
      primaryColor: '#16a34a', // Green
      secondaryColor: '#15803d', // Green
      bgGradient: 'linear-gradient(135deg, #16a34a 0%, #15803d 50%, #166534 100%)',
      accentColor: 'rgba(22, 163, 74, 0.2)',
      format: 'currency'
    }
  ];

  // Don't Touch – EliteQ Admin Rule: API data loading simulation
  useEffect(() => {
    loadPerformanceData();
    
    // Set up real-time updates every 5 minutes
    const interval = setInterval(() => {
      if (!isLoading && !isRefreshing) {
        loadPerformanceData(true);
      }
    }, 300000); // 5 minutes

    return () => clearInterval(interval);
  }, [userRole]);

  const loadPerformanceData = async (isBackgroundUpdate = false) => {
    try {
      if (!isBackgroundUpdate) {
        setIsLoading(true);
      }
      setHasError(false);

      // Don't Touch – EliteQ Admin Rule: Simulate API call with realistic delay
      await new Promise(resolve => setTimeout(resolve, isBackgroundUpdate ? 500 : 1500));
      
      // Don't Touch – EliteQ Admin Rule: In real implementation, this would call actual APIs
      // Mock data with some realistic values
      const updatedMetrics = performanceMetrics.map(metric => {
        if (metric.id === 'visitors' || metric.id === 'views') {
          return {
            ...metric,
            change: Math.random() > 0.5 ? Math.random() * 20 : -Math.random() * 10,
            changeType: Math.random() > 0.3 ? 'increase' : 'decrease'
          };
        }
        return metric;
      }) as PerformanceMetric[];

      setMetrics(updatedMetrics);
      setLastUpdated(new Date());
      
      console.log('📊 Performance data loaded successfully');
    } catch (error) {
      console.error('❌ Failed to load performance data:', error);
      setHasError(true);
      setMetrics(performanceMetrics); // Fallback to default data
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    loadPerformanceData();
  };

  const formatChangeValue = (change: number, changeType: string) => {
    if (change === 0 || changeType === 'neutral') return '';
    const sign = changeType === 'increase' ? '+' : '-';
    return `${sign}${Math.abs(change).toFixed(1)}%`;
  };

  const getChangeIcon = (changeType: string) => {
    switch (changeType) {
      case 'increase':
        return <TrendingUp className="w-4 h-4 text-emerald-400" />;
      case 'decrease':
        return <TrendingDown className="w-4 h-4 text-red-400" />;
      default:
        return null;
    }
  };

  const getChangeColor = (changeType: string) => {
    switch (changeType) {
      case 'increase':
        return 'text-emerald-400';
      case 'decrease':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };

  // Don't Touch – EliteQ Admin Rule: Loading state with premium skeleton cards
  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <Skeleton className="h-6 w-48 mb-2" />
            <Skeleton className="h-4 w-64" />
          </div>
          <Skeleton className="h-8 w-20" />
        </div>
        
        {/* Premium loading skeleton with 3D effects */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(11)].map((_, index) => (
            <div 
              key={index} 
              className="h-[140px] p-6 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900 rounded-2xl shadow-lg animate-pulse"
              style={{
                transform: 'perspective(1000px) rotateX(5deg)',
                boxShadow: '0 20px 40px -10px rgba(0, 0, 0, 0.1), 0 10px 20px -5px rgba(0, 0, 0, 0.05)'
              }}
            >
              <div className="flex items-center h-full">
                <Skeleton className="h-14 w-14 rounded-xl mr-4" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-24 mb-3" />
                  <Skeleton className="h-7 w-20 mb-2" />
                  <Skeleton className="h-3 w-16" />
                </div>
                <div className="ml-auto">
                  <Skeleton className="h-6 w-16" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Don't Touch – EliteQ Admin Rule: Error state with premium styling
  if (hasError) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Performance Overview
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Premium 3D performance metrics dashboard
            </p>
          </div>
        </div>
        
        <Card 
          className="h-[140px] p-8 border-red-200 dark:border-red-800 bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/10 dark:to-red-800/20 rounded-2xl shadow-lg"
          style={{
            transform: 'perspective(1000px) rotateX(2deg)',
            boxShadow: '0 20px 40px -10px rgba(239, 68, 68, 0.2), 0 10px 20px -5px rgba(239, 68, 68, 0.1)'
          }}
        >
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="relative mb-4">
                <AlertTriangle className="w-12 h-12 text-red-500 mx-auto" />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-400 rounded-full animate-ping"></div>
              </div>
              <p className="text-red-700 dark:text-red-400 font-medium mb-3 text-lg">
                ❗ Data load failed. Tap to retry.
              </p>
              <Button 
                onClick={handleRefresh}
                disabled={isRefreshing}
                variant="outline"
                size="sm"
                className="border-red-300 text-red-700 hover:bg-red-100 dark:border-red-700 dark:text-red-400 rounded-xl px-6 py-2"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                Retry
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  // Don't Touch – EliteQ Admin Rule: Empty state with premium styling
  if (metrics.length === 0) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Performance Overview
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Premium 3D performance metrics dashboard
            </p>
          </div>
        </div>
        
        <Card 
          className="h-[140px] p-8 border-dashed border-2 border-gray-300 dark:border-gray-600 rounded-2xl bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900"
          style={{
            transform: 'perspective(1000px) rotateX(2deg)',
            boxShadow: '0 15px 30px -5px rgba(0, 0, 0, 0.1), 0 5px 15px -3px rgba(0, 0, 0, 0.05)'
          }}
        >
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="relative mb-4">
                <TrendingUp className="w-12 h-12 text-gray-400 mx-auto" />
                <Sparkles className="w-4 h-4 text-blue-400 absolute -top-1 -right-1 animate-pulse" />
              </div>
              <p className="text-gray-600 dark:text-gray-400 text-lg font-medium">
                No data available in this section.
              </p>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="mb-8">
      {/* Premium Section Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between mb-8 space-y-3 lg:space-y-0">
        <div>
          <div className="flex items-center space-x-3 mb-2">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl shadow-lg">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              Performance Overview
            </h2>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Premium 3D performance metrics for your {userRole === 'admin' ? 'marketplace' : 'store'}
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 px-3 py-1 bg-gradient-to-r from-green-100 to-blue-100 dark:from-green-900/20 dark:to-blue-900/20 rounded-full">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs text-gray-600 dark:text-gray-400">
              Updated: {lastUpdated.toLocaleTimeString('en-IN', { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}
            </span>
          </div>
          <Button
            onClick={handleRefresh}
            disabled={isRefreshing}
            variant="outline"
            size="sm"
            className="h-9 px-4 rounded-xl border-blue-200 dark:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-900/20"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Premium 3D Performance Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          
          return (
            <Card 
              key={metric.id}
              className="group relative h-[140px] p-0 overflow-hidden rounded-2xl border-0 cursor-pointer transition-all duration-500 ease-out animate-fade-in"
              style={{ 
                animationDelay: `${index * 0.1}s`,
                background: metric.bgGradient,
                transform: 'perspective(1000px) rotateX(5deg)',
                boxShadow: `0 20px 40px -10px ${metric.accentColor}, 0 10px 20px -5px rgba(0, 0, 0, 0.1)`,
                transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'perspective(1000px) rotateX(8deg) translateY(-8px)';
                e.currentTarget.style.boxShadow = `0 30px 60px -10px ${metric.accentColor}, 0 20px 30px -5px rgba(0, 0, 0, 0.15)`;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'perspective(1000px) rotateX(5deg)';
                e.currentTarget.style.boxShadow = `0 20px 40px -10px ${metric.accentColor}, 0 10px 20px -5px rgba(0, 0, 0, 0.1)`;
              }}
            >
              {/* Animated Background Elements */}
              <div className="absolute inset-0 overflow-hidden">
                <div className="absolute -top-10 -right-10 w-32 h-32 bg-white/10 rounded-full animate-float"></div>
                <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-white/5 rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
                <div className="absolute top-1/2 left-1/2 w-40 h-40 bg-white/5 rounded-full transform -translate-x-1/2 -translate-y-1/2 animate-pulse"></div>
              </div>

              {/* Content Layer */}
              <div className="relative z-10 flex items-center h-full p-6">
                {/* Icon Section */}
                <div className="flex-shrink-0 mr-6">
                  <div 
                    className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300"
                    style={{
                      background: 'rgba(255, 255, 255, 0.15)',
                      backdropFilter: 'blur(10px)',
                      border: '1px solid rgba(255, 255, 255, 0.2)'
                    }}
                  >
                    <Icon className="w-8 h-8 text-white drop-shadow-sm" />
                  </div>
                </div>
                
                {/* Content Section */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-medium text-white/80 mb-1 truncate tracking-wide">
                    {metric.title}
                  </h3>
                  <div className="text-3xl font-bold text-white mb-2 drop-shadow-sm tracking-tight">
                    {metric.value}
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-1 h-1 bg-white/60 rounded-full"></div>
                    <span className="text-xs text-white/70 font-medium">
                      Last 30 days
                    </span>
                  </div>
                </div>
                
                {/* Change Indicator */}
                {metric.changeType !== 'neutral' && metric.change !== 0 && (
                  <div className="flex-shrink-0 ml-4">
                    <div 
                      className="flex items-center space-x-2 px-3 py-2 rounded-xl shadow-lg"
                      style={{
                        background: 'rgba(255, 255, 255, 0.15)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(255, 255, 255, 0.2)'
                      }}
                    >
                      {getChangeIcon(metric.changeType)}
                      <span className={`text-sm font-bold ${getChangeColor(metric.changeType)}`}>
                        {formatChangeValue(metric.change, metric.changeType)}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Shimmer Effect */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <div 
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent transform -skew-x-12 animate-shimmer"
                  style={{
                    animation: 'shimmer 3s infinite'
                  }}
                ></div>
              </div>

              {/* Floating Sparkles */}
              <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <Sparkles className="w-4 h-4 text-white/60 animate-pulse" />
              </div>
            </Card>
          );
        })}
      </div>

      {/* Custom CSS for animations */}
      <style jsx>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%) skewX(-12deg); }
          100% { transform: translateX(200%) skewX(-12deg); }
        }
        
        @keyframes float {
          0%, 100% { 
            transform: translateY(0px) rotate(0deg); 
          }
          33% { 
            transform: translateY(-10px) rotate(5deg); 
          }
          66% { 
            transform: translateY(-5px) rotate(-3deg); 
          }
        }
      `}</style>
    </div>
  );
}