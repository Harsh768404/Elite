import React, { useState } from 'react';
import { 
  Home, 
  Package, 
  ShoppingCart, 
  Plus,
  Ticket,
  BarChart3,
  Clock,
  Star,
  CreditCard,
  Award,
  HelpCircle,
  RotateCcw,
  Users,
  UserPlus,
  Megaphone,
  TrendingUp,
  Wrench,
  Settings,
  Store,
  DollarSign,
  CheckCircle,
  Truck,
  User,
  Zap,
  Search,
  ChevronDown,
  ChevronRight,
  LogOut,
  ChevronLeft
} from 'lucide-react';
import { Button } from './ui/button';
import { cn } from './ui/utils';

interface EliteQComprehensiveSidebarProps {
  collapsed: boolean;
  userRole: 'admin' | 'vendor';
  onToggle: () => void;
}

interface NavigationItem {
  icon: React.ElementType;
  label: string;
  href: string;
  badge?: number;
  active?: boolean;
  adminOnly?: boolean;
  children?: NavigationItem[];
}

export function EliteQComprehensiveSidebar({ collapsed, userRole, onToggle }: EliteQComprehensiveSidebarProps) {
  const [activeItem, setActiveItem] = useState('dashboard');
  const [expandedItems, setExpandedItems] = useState<string[]>([]); // Start with all sections collapsed

  const navigationItems: NavigationItem[] = [
    {
      icon: Home,
      label: 'Dashboard',
      href: '/dashboard',
      active: activeItem === 'dashboard'
    },
    {
      icon: Package,
      label: 'Products',
      href: '/products',
      active: activeItem === 'products'
    },
    {
      icon: ShoppingCart,
      label: 'Orders',
      href: '/orders',
      badge: 5,
      active: activeItem === 'orders',
      children: [
        {
          icon: ShoppingCart,
          label: 'All Orders',
          href: '/orders/all',
          active: activeItem === 'all-orders'
        },
        {
          icon: Plus,
          label: 'Add New Order',
          href: '/orders/new',
          active: activeItem === 'new-order'
        }
      ]
    },
    {
      icon: Ticket,
      label: 'Coupon',
      href: '/coupons',
      active: activeItem === 'coupons'
    },
    {
      icon: BarChart3,
      label: 'Reports',
      href: '/reports',
      active: activeItem === 'reports',
      children: [
        {
          icon: Package,
          label: 'Products',
          href: '/reports/products',
          active: activeItem === 'reports-products'
        },
        {
          icon: DollarSign,
          label: 'Revenue',
          href: '/reports/revenue',
          active: activeItem === 'reports-revenue'
        },
        {
          icon: ShoppingCart,
          label: 'Orders',
          href: '/reports/orders',
          active: activeItem === 'reports-orders'
        },
        {
          icon: Zap,
          label: 'Variations',
          href: '/reports/variations',
          active: activeItem === 'reports-variations'
        },
        {
          icon: Award,
          label: 'Categories',
          href: '/reports/categories',
          active: activeItem === 'reports-categories'
        },
        {
          icon: Package,
          label: 'Stock',
          href: '/reports/stock',
          active: activeItem === 'reports-stock'
        },
        {
          icon: TrendingUp,
          label: 'Statement',
          href: '/reports/statement',
          active: activeItem === 'reports-statement'
        }
      ]
    },
    {
      icon: Clock,
      label: 'Delivery Time',
      href: '/delivery-time',
      active: activeItem === 'delivery-time'
    },
    {
      icon: Star,
      label: 'Reviews',
      href: '/reviews',
      active: activeItem === 'reviews'
    },
    {
      icon: CreditCard,
      label: 'Withdraw',
      href: '/withdraw',
      active: activeItem === 'withdraw'
    },
    {
      icon: Award,
      label: 'Badge',
      href: '/badge',
      active: activeItem === 'badge'
    },
    {
      icon: HelpCircle,
      label: 'Product Q&A',
      href: '/product-qa',
      active: activeItem === 'product-qa'
    },
    {
      icon: RotateCcw,
      label: 'Return Requests',
      href: '/returns',
      active: activeItem === 'returns'
    },
    {
      icon: Users,
      label: 'Staff',
      href: '/staff',
      active: activeItem === 'staff',
      adminOnly: userRole === 'admin'
    },
    {
      icon: UserPlus,
      label: 'Followers',
      href: '/followers',
      active: activeItem === 'followers'
    },
    {
      icon: Megaphone,
      label: 'Announcement',
      href: '/announcements',
      active: activeItem === 'announcements'
    },
    {
      icon: TrendingUp,
      label: 'Store Stats',
      href: '/store-stats',
      active: activeItem === 'store-stats'
    },
    {
      icon: Wrench,
      label: 'Tools',
      href: '/tools',
      active: activeItem === 'tools'
    },
    {
      icon: Settings,
      label: 'Settings',
      href: '/settings',
      active: activeItem === 'settings',
      children: [
        {
          icon: Store,
          label: 'Store',
          href: '/settings/store',
          active: activeItem === 'settings-store'
        },
        {
          icon: DollarSign,
          label: 'Payment',
          href: '/settings/payment',
          active: activeItem === 'settings-payment'
        },
        {
          icon: CheckCircle,
          label: 'Verification',
          href: '/settings/verification',
          active: activeItem === 'settings-verification'
        },
        {
          icon: Truck,
          label: 'Shipping',
          href: '/settings/shipping',
          active: activeItem === 'settings-shipping'
        },
        {
          icon: User,
          label: 'Social Profile',
          href: '/settings/social',
          active: activeItem === 'settings-social'
        },
        {
          icon: RotateCcw,
          label: 'RMA',
          href: '/settings/rma',
          active: activeItem === 'settings-rma'
        },
        {
          icon: Search,
          label: 'Store SEO',
          href: '/settings/seo',
          active: activeItem === 'settings-seo'
        }
      ]
    }
  ];

  const filteredItems = navigationItems.filter(item => 
    !item.adminOnly || userRole === 'admin'
  );

  const handleItemClick = (href: string, label: string) => {
    setActiveItem(label.toLowerCase().replace(/\s+/g, '-'));
    console.log(`Navigating to: ${href}`);
  };

  const toggleExpanded = (label: string) => {
    setExpandedItems(prev => 
      prev.includes(label) 
        ? prev.filter(item => item !== label)
        : [...prev, label]
    );
  };

  const renderNavigationItem = (item: NavigationItem, depth = 0) => {
    const Icon = item.icon;
    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expandedItems.includes(item.label.toLowerCase());
    const paddingLeft = depth === 0 ? 'pl-3' : 'pl-8';

    return (
      <div key={item.href} className="space-y-1">
        <button
          onClick={() => {
            if (hasChildren) {
              toggleExpanded(item.label.toLowerCase());
            } else {
              handleItemClick(item.href, item.label);
            }
          }}
          className={cn(
            "w-full flex items-center justify-between py-2.5 px-3 rounded-lg text-sm font-medium transition-all duration-200",
            item.active
              ? "bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800"
              : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white",
            collapsed && "justify-center px-2",
            paddingLeft
          )}
        >
          <div className="flex items-center space-x-3">
            <Icon className={cn(
              "h-5 w-5 flex-shrink-0",
              item.active ? "text-blue-600 dark:text-blue-400" : ""
            )} />
            
            {!collapsed && (
              <>
                <span className="truncate">{item.label}</span>
                {item.badge && (
                  <span className="ml-auto bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs px-2 py-0.5 rounded-full">
                    {item.badge}
                  </span>
                )}
              </>
            )}
          </div>
          
          {!collapsed && hasChildren && (
            <div className="ml-auto">
              {isExpanded ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </div>
          )}
        </button>

        {!collapsed && hasChildren && isExpanded && item.children && (
          <div className="space-y-1 overflow-hidden transition-all duration-300 ease-in-out animate-slide-in">
            {item.children.map(child => renderNavigationItem(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {/* Mobile Overlay */}
      {!collapsed && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onToggle}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed left-0 top-16 h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 z-50 flex flex-col",
        collapsed ? "w-16 lg:w-16" : "w-64 lg:w-64",
        "lg:translate-x-0",
        collapsed ? "-translate-x-full lg:translate-x-0" : "translate-x-0"
      )}>
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          {!collapsed && (
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm font-medium text-gray-900 dark:text-white uppercase tracking-wide">
                {userRole === 'admin' ? 'Admin Panel' : 'Vendor Panel'}
              </span>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="hidden lg:flex"
          >
            <ChevronLeft className={cn(
              "h-4 w-4 transition-transform duration-200",
              collapsed && "rotate-180"
            )} />
          </Button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto custom-scrollbar">
          {filteredItems.map(item => renderNavigationItem(item))}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          {/* User Role Badge */}
          {!collapsed && (
            <div className="mb-3 p-3 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-full flex items-center justify-center">
                  {userRole === 'admin' ? (
                    <Award className="w-4 h-4 text-white" />
                  ) : (
                    <Store className="w-4 h-4 text-white" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {userRole === 'admin' ? 'Administrator' : 'Vendor Account'}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    EliteQ India
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Logout Button */}
          <button
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all duration-200",
              collapsed && "justify-center px-2"
            )}
          >
            <LogOut className="h-5 w-5 flex-shrink-0" />
            {!collapsed && <span>Logout</span>}
          </button>
        </div>
      </aside>
    </>
  );
}