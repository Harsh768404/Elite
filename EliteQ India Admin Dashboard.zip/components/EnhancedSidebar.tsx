import React, { useState, useEffect } from 'react';
import { 
  Home, ShoppingCart, Plus, Package, Star, DollarSign, BarChart3, Settings, 
  HelpCircle, User, Eye, Activity, PieChart, FileText, Gift, Clock, BarChart,
  Award, MessageSquare, Undo2, UserPlus, Megaphone, Wrench, ShieldCheck, 
  Truck, Share2, RefreshCw, Globe, ChevronRight, Users, TrendingUp,
  Database, CreditCard, Zap, Shield, Bell, AlertTriangle, CheckCircle, Timer
} from 'lucide-react';

import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Badge } from './ui/badge';


interface MenuItem {
  id: string;
  label: string;
  icon: React.ComponentType<any>;
  children?: MenuItem[];
  badge?: string | number;
  roles?: ('vendor' | 'admin')[];
}

const menuStructure: MenuItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: Home,
    roles: ['vendor', 'admin']
  },
  {
    id: 'products',
    label: 'Products',
    icon: Package,
    roles: ['vendor', 'admin'],
    badge: '156'
  },
  {
    id: 'orders',
    label: 'Orders',
    icon: ShoppingCart,
    roles: ['vendor', 'admin'],
    badge: '12',
    children: [
      { id: 'all-orders', label: 'All Orders', icon: ShoppingCart, roles: ['vendor', 'admin'] },
      { id: 'add-order', label: 'Add New Order', icon: Plus, roles: ['vendor', 'admin'] }
    ]
  },
  {
    id: 'coupons',
    label: 'Coupons',
    icon: Gift,
    roles: ['vendor', 'admin']
  },
  {
    id: 'reports',
    label: 'Reports',
    icon: BarChart3,
    roles: ['vendor', 'admin'],
    children: [
      { id: 'products-report', label: 'Product', icon: Package, roles: ['vendor', 'admin'] },
      { id: 'revenue-report', label: 'Revenue', icon: DollarSign, roles: ['vendor', 'admin'] },
      { id: 'orders-report', label: 'Orders', icon: ShoppingCart, roles: ['vendor', 'admin'] },
      { id: 'variations-report', label: 'Variations', icon: BarChart, roles: ['vendor', 'admin'] },
      { id: 'categories-report', label: 'Categories', icon: FileText, roles: ['vendor', 'admin'] },
      { id: 'stock-statement', label: 'Stock Statement', icon: Activity, roles: ['vendor', 'admin'] }
    ]
  },
  {
    id: 'reviews',
    label: 'Reviews',
    icon: Star,
    roles: ['vendor', 'admin'],
    badge: '24'
  },
  {
    id: 'delivery-time',
    label: 'Delivery Time',
    icon: Timer,
    roles: ['vendor', 'admin']
  },
  {
    id: 'withdraw',
    label: 'Withdraw',
    icon: DollarSign,
    roles: ['vendor']
  },
  {
    id: 'badges',
    label: 'Badges',
    icon: Award,
    roles: ['vendor']
  },
  {
    id: 'product-qa',
    label: 'Product Q&A',
    icon: MessageSquare,
    roles: ['vendor', 'admin'],
    badge: '8'
  },
  {
    id: 'return-requests',
    label: 'Return Requests',
    icon: Undo2,
    roles: ['vendor', 'admin'],
    badge: '3'
  },
  {
    id: 'staff',
    label: 'Staff',
    icon: UserPlus,
    roles: ['vendor']
  },
  {
    id: 'followers',
    label: 'Followers',
    icon: User,
    roles: ['vendor'],
    badge: '1.2k'
  },
  {
    id: 'announcements',
    label: 'Announcements',
    icon: Megaphone,
    roles: ['vendor', 'admin'],
    badge: '2'
  },
  {
    id: 'store-stats',
    label: 'Store Stats',
    icon: BarChart,
    roles: ['vendor', 'admin']
  },
  {
    id: 'tools',
    label: 'Tools',
    icon: Wrench,
    roles: ['vendor', 'admin']
  },
  {
    id: 'support',
    label: 'Support',
    icon: HelpCircle,
    roles: ['vendor', 'admin']
  },
  // Admin-specific sections
  {
    id: 'vendors',
    label: 'Vendors',
    icon: Users,
    roles: ['admin'],
    badge: '67',
    children: [
      { id: 'all-vendors', label: 'All Vendors', icon: Users, roles: ['admin'] },
      { id: 'pending-approval', label: 'Pending Approval', icon: Clock, roles: ['admin'], badge: '5' },
      { id: 'vendor-analytics', label: 'Analytics', icon: TrendingUp, roles: ['admin'] }
    ]
  },
  {
    id: 'platform-reports',
    label: 'Platform Reports',
    icon: Database,
    roles: ['admin'],
    children: [
      { id: 'sales-overview', label: 'Sales Overview', icon: TrendingUp, roles: ['admin'] },
      { id: 'commission-reports', label: 'Commission Reports', icon: CreditCard, roles: ['admin'] },
      { id: 'vendor-performance', label: 'Vendor Performance', icon: BarChart3, roles: ['admin'] },
      { id: 'platform-analytics', label: 'Platform Analytics', icon: PieChart, roles: ['admin'] }
    ]
  },
  {
    id: 'compliance',
    label: 'Compliance',
    icon: Shield,
    roles: ['admin'],
    children: [
      { id: 'kyc-management', label: 'KYC Management', icon: ShieldCheck, roles: ['admin'], badge: '12' },
      { id: 'tax-compliance', label: 'Tax Compliance', icon: FileText, roles: ['admin'] },
      { id: 'audit-logs', label: 'Audit Logs', icon: Eye, roles: ['admin'] }
    ]
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: Settings,
    roles: ['vendor', 'admin'],
    children: [
      { id: 'store-settings', label: 'Store', icon: Settings, roles: ['vendor'] },
      { id: 'platform-settings', label: 'Platform', icon: Settings, roles: ['admin'] },
      { id: 'payments', label: 'Payments', icon: CreditCard, roles: ['vendor', 'admin'] },
      { id: 'kyc-verification', label: 'KYC Verification', icon: ShieldCheck, roles: ['vendor', 'admin'] },
      { id: 'shipping', label: 'Shipping', icon: Truck, roles: ['vendor', 'admin'] },
      { id: 'social-profile', label: 'Social Profile', icon: Share2, roles: ['vendor'] },
      { id: 'rma', label: 'RMA', icon: RefreshCw, roles: ['vendor', 'admin'] },
      { id: 'store-seo', label: 'Store SEO', icon: Globe, roles: ['vendor'] }
    ]
  }
];

interface MenuItemComponentProps {
  item: MenuItem;
  activeItem: string;
  setActiveItem: (id: string) => void;
  level?: number;
  darkMode?: boolean;
  currentRole: 'vendor' | 'admin';
}

const MenuItemComponent: React.FC<MenuItemComponentProps> = ({ 
  item, 
  activeItem, 
  setActiveItem, 
  level = 0, 
  darkMode,
  currentRole
}) => {
  // Filter children based on current role
  const visibleChildren = item.children?.filter(child => 
    !child.roles || child.roles.includes(currentRole)
  ) || [];
  
  const hasChildren = visibleChildren.length > 0;
  
  // Check if any child is currently active
  const hasActiveChild = visibleChildren.some(child => child.id === activeItem);
  
  // Initialize collapsed by default, expand only if contains active item
  const [isOpen, setIsOpen] = useState(false); // Always start collapsed
  
  const handleClick = () => {
    if (hasChildren) {
      setIsOpen(!isOpen);
    } else {
      setActiveItem(item.id);
    }
  };

  // Update open state when activeItem changes to expand parent of active child
  useEffect(() => {
    if (hasActiveChild && !isOpen) {
      setIsOpen(true);
    }
  }, [activeItem, hasActiveChild, isOpen]);

  return (
    <div className="w-full">
      <button
        onClick={handleClick}
        role={hasChildren ? "button" : "menuitem"}
        aria-expanded={hasChildren ? isOpen : undefined}
        aria-controls={hasChildren ? `submenu-${item.id}` : undefined}
        className={`w-full flex items-center justify-between px-4 py-3 text-left transition-all duration-200 rounded-xl group focus-visible:focus-visible ${
          level === 0 ? 'mb-1' : 'mb-0.5 ml-4'
        } ${
          activeItem === item.id
            ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg shadow-blue-600/25'
            : darkMode
            ? 'text-gray-300 hover:bg-gray-700/50 hover:text-white'
            : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
        }`}
      >
        <div className="flex items-center gap-3">
          <item.icon className={`h-5 w-5 transition-transform duration-200 group-hover:scale-110 ${
            level > 0 ? 'h-4 w-4' : ''
          }`} />
          <span className={`font-medium ${level > 0 ? 'text-sm' : ''}`}>
            {item.label}
          </span>
          {item.badge && (
            <Badge 
              variant={activeItem === item.id ? "secondary" : "default"}
              className={`text-xs ${
                activeItem === item.id 
                  ? 'bg-white/20 text-white' 
                  : 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300'
              }`}
            >
              {item.badge}
            </Badge>
          )}
        </div>
        {hasChildren && (
          <ChevronRight className={`h-4 w-4 transition-transform duration-200 ${
            isOpen ? 'rotate-90' : ''
          }`} />
        )}
      </button>
      
      {hasChildren && (
        <Collapsible open={isOpen}>
          <CollapsibleContent 
            className="space-y-1 mt-2" 
            id={`submenu-${item.id}`}
            role="menu"
          >
            {visibleChildren.map((child) => (
              <MenuItemComponent
                key={child.id}
                item={child}
                activeItem={activeItem}
                setActiveItem={setActiveItem}
                level={level + 1}
                darkMode={darkMode}
                currentRole={currentRole}
              />
            ))}
          </CollapsibleContent>
        </Collapsible>
      )}
    </div>
  );
};

interface EnhancedSidebarProps {
  activeItem: string;
  setActiveItem: (id: string) => void;
  darkMode?: boolean;
  currentRole: 'vendor' | 'admin';
  orderSummary: {
    newOrders: number;
    productsInStock: number;
  };
}

export function EnhancedSidebar({ 
  activeItem, 
  setActiveItem, 
  darkMode, 
  currentRole,
  orderSummary 
}: EnhancedSidebarProps) {
  // Filter menu items based on role only (removed search functionality)
  const filteredMenuItems = menuStructure
    .filter(item => !item.roles || item.roles.includes(currentRole));



  return (
    <div className={`${darkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'} 
      h-full flex flex-col transition-colors duration-300 border-r overflow-hidden`}>

      {/* Navigation */}
      <nav className="flex-1 p-4 overflow-y-auto custom-scrollbar">
        <div className="space-y-2">
          {filteredMenuItems.map((item) => (
            <MenuItemComponent
              key={item.id}
              item={item}
              activeItem={activeItem}
              setActiveItem={setActiveItem}
              darkMode={darkMode}
              currentRole={currentRole}
            />
          ))}
        </div>
      </nav>

      {/* Quick Stats */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-800">
        <div className="grid grid-cols-2 gap-3 text-center">
          <div className={`p-3 rounded-xl ${darkMode ? 'bg-gray-800' : 'bg-gray-50'}`}>
            <div className="text-lg font-bold text-blue-600">{orderSummary.newOrders}</div>
            <div className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {currentRole === 'admin' ? 'Total Orders' : 'New Orders'}
            </div>
          </div>
          <div className={`p-3 rounded-xl ${darkMode ? 'bg-gray-800' : 'bg-gray-50'}`}>
            <div className="text-lg font-bold text-green-600">{orderSummary.productsInStock}</div>
            <div className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {currentRole === 'admin' ? 'Active Vendors' : 'In Stock'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}